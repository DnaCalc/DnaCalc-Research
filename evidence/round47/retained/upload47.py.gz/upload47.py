"""Copy R47 raw evidence to its new dated R2 prefix. Original MIT helper."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

run=Path('/home/ubuntu/codex-runs/work47')
prefix='research/round47/'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-dna-firehorse'
remote='r2:dnacalc-evidence/'+prefix
config='/home/ubuntu/.config/dnacalc/rclone.conf'
commands=[['rclone','--config',config,'copy',str(run/'r2-upload'),remote,'--checksum'],
          ['rclone','--config',config,'check',str(run/'r2-upload'),remote,'--checksum','--one-way']]
for i,argv in enumerate(commands):
    with (run/('r2-copy.log'if i==0 else'r2-check.log')).open('x')as log:
        subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
files=[dict(name=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in sorted((run/'r2-upload').iterdir())if p.is_file()]
record=dict(bucket='dnacalc-evidence',prefix=prefix,files=files,file_count=len(files),bytes=sum(p['bytes']for p in files),copy_checksum=True,check_one_way=True)
with (run/'r2-receipt.json').open('x')as f:json.dump(record,f,indent=2)
print(record)
