
#include <math.h>
static double xa(double a,double b){volatile double z=(long double)a+(long double)b;return z;}
static double xs(double a,double b){volatile double z=(long double)a-(long double)b;return z;}
static double xm(double a,double b){volatile double z=(long double)a*(long double)b;return z;}
static double xd(double a,double b){volatile double z=(long double)a/(long double)b;return z;}
double reg(const double*y,int n){double sy=0,sxy=0,sx=0,sxx=0;for(int j=0;j<n;j++){double x=j+1;sy+=y[j];sxy+=x*y[j];sx+=x;sxx+=x*x;}return (n*sxy-sx*sy)/(n*sxx-sx*sx);}
static double slope(const double*y,int n){if(n>=7)return reg(y,n);double z[7],t=reg(y,n);for(int j=0;j<7;j++)z[j]=j<n?y[j]:y[j%2]+(j-j%2)*t;return reg(z,7);}
void run(const double*y,int n,double a,double b,int validation,double initial,double*out){
 double l=y[0],t=initial,se[2]={0,0},tr[128],err[128]={0},pred[128],sse=0;pred[0]=y[0];
 for(int j=1;j<n;j++){int q=j%2;double p=(l+t)+se[q],e=y[j]-p;err[j]=e;pred[j]=p;sse+=e*e;
 if(validation && j>=validation)l+=t;else{l+=t+a*e;t+=b*e;se[q]+=0x1p-52*e;}tr[j-1]=t;}
 int w=n<=10?n:(n+1)/2,dw=n<=10?n:n/2;double total=0,sq=0;
 for(int j=n-w;j<n-1;j++){total=xa(total,tr[j]);sq=xa(sq,xm(tr[j],tr[j]));}
 double m=xd(total,dw-1),var=xs(xd(sq,dw-1),xm(m,m));int reset=fabs(m)<xd(xm(sqrt(var),dw),dw-1);
 if(reset){l=y[n-1]-se[(n-1)%2];t=initial;b=.001;}
 double center=(se[0]+se[1])/2;l+=center;se[0]-=center;se[1]-=center;
 out[0]=sse;out[1]=a;out[2]=b;out[3]=l;out[4]=t;out[5]=se[0];out[6]=se[1];out[7]=reset;
 int count=n<=10?n:(int)(n*.4)<10?(int)(n*.4):10,start=n-count,pre=start?start:n;double mae=0,mse=0,smape=0,scale=0;
 for(int j=start;j<n;j++){mae+=fabs(err[j]);mse+=err[j]*err[j];double den=(fabs(y[j])+fabs(pred[j]))/2;smape+=den==0?0:fabs(err[j])/den;}
 for(int j=1;j<pre;j++)scale+=fabs(y[j]-y[j-1]);scale/=pre-1;
 out[8]=scale==0?0:mae/count/scale;out[9]=smape/count;out[10]=mae/count;out[11]=sqrt(mse/count);
}
void search(const double*y,int n,const double*pool,int np,double*out){
 double z[128];int m=n<7?7:n;double t0=reg(y,n);for(int j=0;j<m;j++)z[j]=j<n?y[j]:y[j%2]+(j-j%2)*t0;
 int tail=m<=10?m:(int)(m*.4)<10?(int)(m*.4):10,start=m-tail;double initial=slope(z,m),best=INFINITY,tmp[12];int chosen=0;
 for(int k=0;k<np;k++){run(z,m,pool[2*k],pool[2*k+1],start,initial,tmp);out[12+k]=tmp[0];if(tmp[0]<best){best=tmp[0];chosen=k;}}
 run(y,n,pool[2*chosen],pool[2*chosen+1],0,slope(y,n),out);out[12+np]=chosen;
}
double finish(double l,double t,double s,double h){return xa(l+h*t,s);}
