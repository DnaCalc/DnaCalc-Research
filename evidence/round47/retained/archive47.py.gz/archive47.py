"""R47 immutable raw-evidence archives, original MIT session helper."""
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import sys
import tarfile

RUN = Path('/home/ubuntu/codex-runs/work47')
MAIN = Path('/home/ubuntu/projects/DnaCalc/DnaCalc')


def archive(name, directories):
    upload=RUN/'r2-upload';upload.mkdir(exist_ok=True)
    target=upload/(name+'.tar.gz');members=[]
    with target.open('xb')as raw:
        with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,compresslevel=6)as compressed:
            with tarfile.open(fileobj=compressed,mode='w|')as tar:
                for source,label in directories:
                    for path in sorted(source.rglob('*')):
                        if not path.is_file():continue
                        relative=str(Path(label)/path.relative_to(source))
                        digest=hashlib.sha256(path.read_bytes()).hexdigest()
                        tar.add(path,arcname=relative,recursive=False)
                        members.append(dict(path=relative,bytes=path.stat().st_size,sha256=digest))
    expected={m['path']:m for m in members};seen=set()
    with tarfile.open(target,'r:gz')as tar:
        for item in tar:
            if not item.isfile():continue
            digest=hashlib.sha256();size=0
            with tar.extractfile(item)as stream:
                for chunk in iter(lambda:stream.read(1024*1024),b''):
                    digest.update(chunk);size+=len(chunk)
            if expected[item.name]['sha256']!=digest.hexdigest()or expected[item.name]['bytes']!=size:raise ValueError('archive member changed')
            seen.add(item.name)
    if seen!=set(expected):raise ValueError('missing archive members')
    result=dict(file=target.name,bytes=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),members=members,
                verified_files=len(members),raw_bytes=sum(m['bytes']for m in members))
    with (RUN/(name+'-archive.json')).open('x')as stream:json.dump(result,stream,separators=(',',':'))
    print({k:v for k,v in result.items()if k!='members'},flush=True)


if __name__=='__main__':
    if sys.argv[1]=='routes':archive('registered-routes',[(RUN/n,n)for n in ['route-before','route-candidate','route-final','route-edges']])
    elif sys.argv[1]=='corpus':archive('corpus-runs',[(MAIN/'target'/n,n)for n in ['problem-functions-mbqewowc','problem-functions-ir9ve09a']])
    else:raise ValueError('routes or corpus required')
