param($OwnedExcel,[string]$Request,[string]$Result)
$ErrorActionPreference='Stop'
$jobResult=$Result;$jobExcel=$OwnedExcel;$jobRequest=$Request
. 'C:/Work/DnaCalc/DnaCalc-win/platform/calc-oracle-excel/worker/capture-worker.ps1'
$Result=$jobResult;$excel=$jobExcel;$Request=$jobRequest
$req=Get-Content -LiteralPath $Request -Raw -Encoding utf8|ConvertFrom-Json
$book=$null;$bootstrap=$null;$fatal=$null;$records=@();$versions=@()
$security=Get-ComProperty $excel 'AutomationSecurity'
function Property($Object,$Name){try{return @{value=(Get-ComProperty $Object $Name)}}catch{return @{error=$_.Exception.ToString()}}}
try{
    $bootstrap=$excel.Workbooks.Add();$excel.Calculation=-4135;$excel.EnableEvents=$false;$excel.CalculateBeforeSave=$false
    $book=$excel.Workbooks.Open($req.input,0,$true)
    $bootstrap.Close($false);$bootstrap=$null
    $settings=@{Date1904=(Property $book 'Date1904');CompatibilityVersion=(Property $book 'CompatibilityVersion');Calculation=(Property $excel 'Calculation');AutomationSecurity=$security}
    foreach($entry in $req.inputs){
        $cell=$book.Worksheets.Item($entry.sheet).Range($entry.address)
        $records+=@{sheet=$entry.sheet;address=$entry.address;declared=$entry.declared;value=(Read-Value $cell);formula=(Get-Units (Get-ComProperty $cell 'Formula'));formula2=(Get-Units (Get-ComProperty $cell 'Formula2'))}
    }
    $metadata=@()
    foreach($entry in $req.questions){
        $cell=$book.Worksheets.Item($entry.sheet).Range($entry.formula_cell)
        $metadata+=@{id=$entry.id;sheet=$entry.sheet;address=$entry.formula_cell;formula=(Get-Units (Get-ComProperty $cell 'Formula'));formula2=(Get-Units (Get-ComProperty $cell 'Formula2'));HasArray=(Property $cell 'HasArray');SavedAsArray=(Property $cell 'SavedAsArray')}
    }
    $book.Close($false);$book=$null
    foreach($version in $req.versions){
        $item=@{requested=$version;success=$false}
        try{
            $bootstrap=$excel.Workbooks.Add();$excel.Calculation=-4135
            $book=$excel.Workbooks.Open($req.input,0,$true);$bootstrap.Close($false);$bootstrap=$null
            $item['before']=Property $book 'CompatibilityVersion'
            $book.CompatibilityVersion=[int]$version
            $item['after']=Property $book 'CompatibilityVersion'
            if($item.after.value -ne [int]$version){throw 'CompatibilityVersion setter readback differs'}
            $path=Join-Path $req.variants_directory ('compat-'+$version+'.xlsx')
            $book.SaveAs($path,51);$book.Close($false);$book=$null
            $item['path']=$path;$item['sha256']=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant();$item.success=$true
        }catch{$item['error']=$_.Exception.ToString();if($book){$book.Close($false);$book=$null}}
        $versions+=$item
    }
}catch{$fatal=$_.Exception.ToString()}
finally{if($book){$book.Close($false)};if($bootstrap){$bootstrap.Close($false)}}
$after=Get-ComProperty $excel 'AutomationSecurity'
if($after -ne $security){throw 'AutomationSecurity changed during input audit'}
$data=@{fatal=$fatal;input=$req.input;input_sha256=(Get-FileHash -LiteralPath $req.input).Hash.ToLowerInvariant();settings=$settings;inputs=$records;formula_metadata=$metadata;versions=$versions;automation_security_before=$security;automation_security_after=$after;note='Preparation and input audit only. Formula answers use the unchanged canonical capture worker separately. No calculation command issued here; input workbook opened in Manual mode and left unchanged.'}
[IO.File]::WriteAllText($Result,((ConvertTo-Json -InputObject $data -Depth 45)+"`n"),[Text.UTF8Encoding]::new($false))
