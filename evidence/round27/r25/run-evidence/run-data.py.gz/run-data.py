import collections,datetime,hashlib,json,os,pathlib,re,shutil,subprocess,sys,zipfile
import xml.etree.ElementTree as ET

R=pathlib.Path('C:/Work/DnaCalc/codex-runs'); REPO=pathlib.Path('C:/Work/DnaCalc/DnaCalc-win'); HERE=R/'xll14'
EXE=HERE/'xtask-harness.exe'; SESSION=REPO/'target/excel-session-r14'
ENV={**os.environ,'DNACALC_EXCEL_SESSION':str(SESSION)}
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(v,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
def run(args,log,env=ENV):
    log.parent.mkdir(parents=True,exist_ok=True)
    with log.open('w',encoding='utf-8') as f:p=subprocess.run([str(x) for x in args],cwd=REPO,env=env,stdout=f,stderr=subprocess.STDOUT)
    return p.returncode
def begin(name):
    out=R/('excel-results-'+name);out.mkdir(exist_ok=False)
    source=R/('excel-questions-'+name)
    if name=='r25':
        (out/'packet').mkdir()
        for n in ['README.txt','active.json']:shutil.copy2(source/n,out/'packet'/n)
        for n in ['guard-transfer','stored-steps','qr-stores']:shutil.copytree(source/n,out/'packet'/n)
        for n in ['guard-transfer','stored-steps','qr-stores']:
            for f,h in load(out/'packet'/n/'manifest.json')['files_sha256'].items():assert sha(out/'packet'/n/f)==h,(n,f)
    else:
        shutil.copytree(source,out/'packet')
        for f,h in load(out/'packet/packet-manifest.json')['files'].items():assert sha(out/'packet'/f)==h,f
    write(out/'packet-sha256.json',{p.relative_to(out/'packet').as_posix():sha(p) for p in (out/'packet').rglob('*') if p.is_file()})
    write(out/'command-executable.json',dict(path=str(EXE),sha256=sha(EXE),revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),session=str(SESSION),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),published_state=load(HERE/'published-state.json')))
    return out,{**ENV,'DNACALC_EXCEL_PACKET':str(out)}
def capture(out,env,fixture,name):
    target=out/(name+'.capture.json');assert not target.exists()
    code=run([EXE,'capture','--fixture',fixture,'--out',target,'--case',name,'--timeout','900','--work-dir',out/'worker'/name],out/(name+'.capture.log'),env)
    item=dict(name=name,fixture=str(fixture),input_sha256=sha(fixture),capture=str(target),capture_exit=code)
    if code==0:item['compare_exit']=run([EXE,'compare','--fixture',fixture,'--capture',target,'--out',out/'comparison'/name],out/(name+'.compare.log'),env)
    return item
def submit(out,env,script,request,result,log,fresh=False,timeout=900):
    args=['pwsh','-NoProfile','-File',REPO/'tools/excel-session/submit.ps1','-Script',script,'-Parameters',json.dumps(dict(Request=str(request),Result=str(result))),'-Environment','round14-input-audit','-PacketId',out,'-TimeoutSeconds',str(timeout)]
    if fresh:args.append('-FreshRequired')
    return run(args,log,env)
def r25():
    out,env=begin('r25');p=out/'packet';books=[]
    for part in ['guard-transfer','stored-steps','qr-stores']:
        m=load(p/part/'manifest.json')
        for fixture in sorted((p/part).rglob('oracle.xlsx')):
            questions=fixture.parent.parent.parent/'workbook-questions.json'
            if part!='stored-steps':questions=p/part/'workbook-questions.json'
            q=load(questions);name='r25-'+q['sheet'];books.append(dict(name=name,fixture=str(fixture),questions=str(questions),formula_cells=len(q['questions']),calls=sum(x['role']=='question' for x in q['questions'])))
    assert len(books)==7 and sum(x['formula_cells'] for x in books)==4347 and sum(x['calls'] for x in books)==1353
    write(out/'workbooks.json',books);results=[]
    for b in books:
        results.append(capture(out,env,pathlib.Path(b['fixture']),b['name']));write(out/'capture-results.json',results)
    finalize('r25')
def fn6():
    out,env=begin('fn6');results=[];books=[]
    families=load(out/'packet/families.json')
    assert sum(x['questions'] for x in families)==138
    for family in families:
        name=family['family'];fixture=next((out/'packet'/name).glob('*.xlsx'));questions=load(fixture.parent/'questions.json')
        audit=out/'input-audit'/name;audit.mkdir(parents=True);variants=out/'compatibility-inputs'/name;variants.mkdir(parents=True)
        inputs=[];seen=set()
        for q in questions:
            for f in q['fixtures']:
                key=(q['sheet'],f['target'])
                if key not in seen:inputs.append(dict(sheet=key[0],address=key[1],declared=f['value']));seen.add(key)
        # utf16 versions must be fresh independent captures; numeric_origin explicitly requests version 1.
        versions=family.get('requested_capture_versions',[])
        write(audit/'request.json',dict(input=str(fixture),inputs=inputs,questions=questions,versions=versions,variants_directory=str(variants)))
        code=submit(out,env,HERE/'prepare-input-audit.ps1',audit/'request.json',audit/'result.json',audit/'console.log')
        results.append(dict(name=name,stage='input-audit',exit=code));write(out/'capture-results.json',results)
        capname='functions-fn6-'+name
        books.append(dict(family=name,name=capname,fixture=str(fixture),questions=str(fixture.parent/'questions.json'),primary=True))
        results.append(capture(out,env,fixture,capname));write(out/'capture-results.json',results)
        if (audit/'result.json').exists():
            for v in load(audit/'result.json')['versions']:
                if v['success']:
                    cn=capname+'-compat-'+str(v['requested'])
                    books.append(dict(family=name,name=cn,fixture=v['path'],questions=str(fixture.parent/'questions.json'),primary=False,requested_version=v['requested']))
                    results.append(capture(out,env,pathlib.Path(v['path']),cn));write(out/'capture-results.json',results)
        write(out/'workbooks.json',books)
    finalize('fn6')
def a1(a):
    m=re.fullmatch(r'([A-Z]+)([0-9]+)',a);assert m,a
    col=0
    for c in m[1]:col=col*26+ord(c)-64
    return int(m[2]),col
def maps(out,name):
    p=out/(name+'.capture.json');rp=out/'worker'/name/'result.json'
    c=load(p) if p.exists() else {};r=load(rp) if rp.exists() else {}
    key=lambda x:(x['sheet'],x['row'],x['column'])
    return {key(x):x for x in c.get('observations',[])},{key(x):x for x in r.get('cells',[])},c,r
def comparison(out,name):
    p=out/'comparison'/name/'report.json'
    if not p.exists():return None
    c=load(p)['counts'];n=c['denominator'];matched=c['matched']
    return dict(formula_cells=n,pass_count=matched,fail=n-matched,pass_rate=matched/n if n else None,breakdown=c)
def formula_count(path):
    n=0
    with zipfile.ZipFile(path) as z:
        for name in z.namelist():
            if not name.startswith('xl/worksheets/') or not name.endswith('.xml'):continue
            for f in ET.fromstring(z.read(name)).findall('.//{*}f'):
                n+=1
                if f.get('t')=='array' and f.get('ref'):
                    ends=f.get('ref').split(':');top,left=a1(ends[0]);bottom,right=a1(ends[-1]);n+=(bottom-top+1)*(right-left+1)-1
    return n
def session(out):
    receipts=[];launched=set();used=set()
    for p in sorted((SESSION/'completed').glob('*/receipt.json')):
        r=load(p)
        if not pathlib.Path(r['job']['packet_id']).resolve().is_relative_to(out.resolve()):continue
        receipts.append(r);shutil.copytree(p.parent,out/'session'/p.parent.name,dirs_exist_ok=True)
        launched.update(range(r['launches_before']+1,r['launches_after']+1))
        if r.get('excel'):used.add(r['excel']['launch'])
        if r.get('success'):
            assert r['preserve_automation_security']
            assert r['baseline_before']['AutomationSecurity']==r['baseline_after']['AutomationSecurity']==r['baseline']['AutomationSecurity']
        if r.get('execution_script'):
            src=pathlib.Path(r['execution_script'])
            if src.exists():
                assert sha(src).upper()==r['execution_script_sha256'].upper()
                dst=out/'executed-scripts'/src.name;dst.parent.mkdir(exist_ok=True);shutil.copy2(src,dst)
    (out/'session-launches').mkdir(exist_ok=True)
    for n in used|launched:
        for name in [str(n)+'.json',str(n)+'-host.ps1']:
            p=SESSION/'launches'/name
            if p.exists():shutil.copy2(p,out/'session-launches'/name)
    for n in ['events.jsonl','host.stdout','host.stderr']:
        p=SESSION/n
        if p.exists():shutil.copy2(p,out/('session-'+n))
    return dict(jobs=len(receipts),failed_jobs=sum(not r['success'] for r in receipts),new_excel_launches=len(launched),new_launch_numbers=sorted(launched),used_launch_numbers=sorted(used),fresh_repeats=[r.get('leakage') for r in receipts if r.get('leakage')])
def finalize(name):
    out=R/('excel-results-'+name);answers=[];repeats=[];books=[];changed=[]
    for b in load(out/'workbooks.json'):
        oo,cc,c,raw=maps(out,b['name']);qdata=load(pathlib.Path(b['questions']));questions=qdata['questions'] if name=='r25' else qdata
        primary=b.get('primary',True)
        for q in questions:
            key=(qdata['sheet'],q['row'],q['column']) if name=='r25' else (q['sheet'],*a1(q['formula_cell']))
            o=oo.get(key);r=cc.get(key)
            answer=dict(question=q,condition=b['name'],observation=o,raw_cell=r,status='entry_refused' if r and 'entry_rejected' in r else 'observed' if o and 'excel_raw' in o else 'unread_or_refused')
            if name=='fn6':answer.update(family=b['family'],observers=[dict(address=a,observation=oo.get((q['sheet'],*a1(a))),raw_cell=cc.get((q['sheet'],*a1(a)))) for a in q['observer_cells']])
            (answers if primary else repeats).append(answer)
        books.append(dict(**b,comparison=comparison(out,b['name']),environment=c.get('environment'),capture_failures=c.get('session',{}).get('failures'),observations=len(oo)))
    if name=='fn6':
        for family in load(out/'packet/families.json'):
            p=out/'input-audit'/family['family']/'result.json'
            if p.exists():
                for item in load(p).get('inputs',[]):
                    expected=dict(item['declared'])
                    if 'number' in expected:expected['number']=expected['number'].lower().removeprefix('0x')
                    if 'text' in expected:expected['text']=''.join(f'{u:04x}' for u in expected['text'])
                    if expected=={'error':'NA'}:expected={'error_code':2042}
                    if expected!=item['value']:changed.append(dict(family=family['family'],**item,expected_raw=expected))
        for a in answers+repeats:
            a['input_changes']=[x for x in changed if x['family']==a['family'] and x['sheet']==a['question']['sheet']]
            if a['input_changes'] and a['status']=='observed':a['status']='observed_with_changed_input'
        write(out/'input-changes.json',changed)
    for n,rows in [('answers.jsonl',answers),('compatibility-answers.jsonl',repeats)]:
        (out/n).write_text(''.join(json.dumps(x,ensure_ascii=True,separators=(',',':'))+'\n' for x in rows),encoding='utf-8')
    assert len(answers)==(4347 if name=='r25' else 138)
    primarybooks=[b for b in books if b.get('primary',True)];total=sum(b['comparison']['formula_cells'] if b['comparison'] else formula_count(pathlib.Path(b['fixture'])) for b in primarybooks);passed=sum(b['comparison']['pass_count'] for b in primarybooks if b['comparison'])
    status=dict(packet=name,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),launches=session(out),results=dict(primary_answers=len(answers),statuses=dict(collections.Counter(a['status'] for a in answers)),compatibility_answers=len(repeats),compatibility_statuses=dict(collections.Counter(a['status'] for a in repeats)),input_changes=len(changed),formula_comparison=dict(denominator=total,pass_count=passed,fail=total-passed,pass_rate=passed/total if total else None),workbooks=books))
    if name=='r25':
        selected=[a for a in answers if a['question']['role']=='question'];status['results']['selected_calls']=len(selected)
        echoes=[a for a in answers if a['question']['role']=='operand_echo'];mismatch=[]
        for a in echoes:
            expected=a['question'].get('intended_bits');actual=a['observation'].get('excel_raw') if a['observation'] else None
            if expected and actual!={'number':expected.lower().removeprefix('0x')}:mismatch.append(dict(id=a['question']['id'],intended=expected,actual=actual))
        write(out/'operand-echo-differences.json',mismatch);status['results'].update(operand_echoes=len(echoes),operand_echo_differences=len(mismatch))
    evidence=out/'run-evidence';evidence.mkdir(exist_ok=True)
    for f in ['run-data.py','prepare-input-audit.ps1','published-state.json','check-publish.log']:shutil.copy2(HERE/f,evidence/f)
    final_check=load(HERE/'published-state.json')['check'];shutil.copy2(HERE/final_check,evidence/final_check)
    write(out/'delivery-status.json',status)
    (out/'README.txt').write_text('Original packet bytes, raw worker outputs, canonical captures, saved/reopened readings, frozen executable identity, comparisons and exact owned-session receipts are retained. Answers are observations and were not adjusted to predictions. All formula failures include mismatches and refusals. Read delivery-status.json and answers.jsonl; compatibility repeats are separate.\n',encoding='utf-8')
    write(out/'delivery-sha256.json',{p.relative_to(out).as_posix():sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='delivery-sha256.json'})
    print(json.dumps(dict(packet=name,launches=status['launches'],results={k:v for k,v in status['results'].items() if k!='workbooks'})),flush=True)
if __name__=='__main__':
    for name in sys.argv[1:] or ['r25','fn6']:
        if name.startswith('finalize-'):finalize(name.removeprefix('finalize-'))
        else:{'r25':r25,'fn6':fn6}[name]()
