import collections,hashlib,json,pathlib,shutil,sys
R=pathlib.Path('C:/Work/DnaCalc/codex-runs')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
for name in sys.argv[1:]:
    out=R/('excel-results-'+name)
    manifest=load(out/'delivery-sha256.json');assert all(sha(out/f)==h for f,h in manifest.items())
    status=load(out/'delivery-status.json')
    if name=='r25':
        counts=collections.Counter()
        for b in load(out/'workbooks.json'):
            q=load(pathlib.Path(b['questions']));report=load(out/'comparison'/b['name']/'report.json')
            verdict={(x['sheet'],x['row'],x['column']):x['verdict'] for x in report['cells']}
            for row in q['questions']:
                if row['role']=='question':counts[verdict.get((q['sheet'],row['row'],row['column']),'missing')]+=1
        n=sum(counts.values());matched=counts['matched']
        assert n==1353
        selected=dict(denominator=n,pass_count=matched,fail=n-matched,pass_rate=matched/n,breakdown=dict(counts))
        write(out/'selected-call-comparison.json',selected);status['results']['selected_call_comparison']=selected
        write(out/'delivery-status.json',status)
    shutil.copy2(__file__,out/'run-evidence/audit-data-delivery.py')
    write(out/'delivery-sha256.json',{p.relative_to(out).as_posix():sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='delivery-sha256.json'})
    manifest=load(out/'delivery-sha256.json');assert all(sha(out/f)==h for f,h in manifest.items())
    print(json.dumps(dict(packet=name,verified_files=len(manifest),results={k:v for k,v in status['results'].items() if k!='workbooks'})),flush=True)
