R27 unanswered rank dependency workbook.
Capture only the new workbook listed in manifest.json through the existing capture route.
R25 measured bracket endpoints are reused as inputs; no new answer is supplied.
Separate padding, repeated observations, reversed rows, predictor swap, exact column scaling and a third orthogonal predictor.
All numerical operands use exact integer limbs and have unchanged bit echoes.
Return canonical captures, raw worker values/settings and original workbook bytes.
