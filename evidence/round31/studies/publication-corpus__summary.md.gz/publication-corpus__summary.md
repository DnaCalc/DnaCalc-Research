# Corpus summary

Pass = matched live Excel from calculated workbook inputs. Fail includes mismatches, refusals, failed or missing results, external link caches, circular held caches and awaiting captures. The pass rate includes every inventoried formula cell. Files with unknown inventories are reported separately.

- cache: /home/ubuntu/codex-runs/r31/publication-corpus-cache
- command: cargo xtask corpus --oracle --no-capture --cache /home/ubuntu/codex-runs/r31/publication-corpus-cache --out /home/ubuntu/codex-runs/r31/publication-corpus
- compare_process: this xtask, a release build
- comparison_timeout_s: 10800
- corpus_inventory_sha256: 6a14abef737c13815555219cba86bd7bbf66aeeaebe15805a01b47086f22f526
- dna_only_fallback: false
- excel_build: not read (no capture needed it)
- executable_sha256: 2f5ebd22c53b8893dca3daeba08ca6dfd35f92b523b65463b7731f44041c0ce2
- execution_route: captured-policy-or-disabled-inventory
- finished_utc: 2026-11-06T20:35:31Z
- inventory: inventory.json
- listing_failures: []
- repository: f3c0258637921bd6ca06b7ab0fd5e178619cfb77+dirty
- resume: false
- resumed_stage_times: from the verified original comparison
- saved_excel_provenance_sha256: null
- shard: null
- trusted_code_sha256: null
- wall_time_s: 26.37576871

## Totals

- workbooks: 56 (56 compared, 0 not compared; 0 compared with the whole run failed)
- formula cells (known inventories): 54794; pass 52988; external links 73; circular rule 14; awaiting capture 100; fail 1806 (mismatched 1305, refused 307, failed or missing 7)
- pass rate over all formula cells: 96.70%
- failed or missing by verdict: not_run 7
- wall time (s): open 1.565, recalculation 10.002, project 0.077, judge 0.307, compare processes 20.124, captures -

## Workbooks

| Workbook | Formula cells | Pass | External links | Circular rule | Awaiting capture | Fail | Mismatched | Refused | Failed or missing | Pass rate | Open s | Recalc s | Judge s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| calc-engine/dc_10y/oracle.xlsx | 1436 | 1431 | 0 | 0 | 0 | 5 | 5 | 0 | 0 | 99.65% | 0.043 | 0.034 | 0.006 |
| calc-engine/dc_10y_iteration/oracle.xlsx | 17 | 17 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.001 | 0.005 | 0.000 |
| calc-engine/dc_86f/oracle.xlsx | 22 | 22 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.002 | 0.001 | 0.000 |
| calc-engine/dc_y2o/oracle.xlsx | 17 | 3 | 0 | 14 | 0 | 14 | 0 | 0 | 0 | 17.64% | 0.001 | 0.001 | 0.000 |
| calc-engine/eng14-raw-nonfinite/oracle.xlsx | 21 | 21 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.001 | 0.001 | 0.000 |
| calc-engine/eng15-overflow/oracle.xlsx | 94 | 94 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.001 | 0.005 | 0.000 |
| calc-engine/l3/oracle.xlsx | 112 | 112 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.004 | 0.004 | 0.000 |
| calc-fml/dc_51ka/oracle.xlsx | 183 | 183 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.005 | 0.076 | 0.001 |
| calc-fml/dc_ibp2/oracle.xlsx | 83 | 83 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.002 | 0.003 | 0.000 |
| calc-fml/dc_l10u/oracle.xlsx | 57 | 57 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.003 | 0.096 | 0.000 |
| calc-func/catalogue/oracle.xlsx | 14553 | 14100 | 0 | 0 | 0 | 453 | 451 | 2 | 0 | 96.88% | 0.914 | 8.107 | 0.118 |
| calc-func/cdoc_jpha/oracle.xlsx | 1526 | 1526 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.015 | 0.068 | 0.006 |
| calc-func/cfunc_m1_2/oracle.xlsx | 234 | 234 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.003 | 0.045 | 0.001 |
| calc-func/cfunc_m3_2/oracle.xlsx | 218 | 218 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.002 | 0.005 | 0.001 |
| calc-func/cfunc_m3_4/oracle.xlsx | 112 | 112 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.002 | 0.003 | 0.000 |
| calc-func/cfunc_m3_5/oracle.xlsx | 136 | 136 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.002 | 0.051 | 0.000 |
| calc-func/cfunc_m3_6/oracle.xlsx | 596 | 596 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.006 | 0.053 | 0.002 |
| calc-func/dc_e00t/oracle.xlsx | 1144 | 1144 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.010 | 0.070 | 0.005 |
| calc-func/dc_fwpz/oracle.xlsx | 115 | 115 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.002 | 0.004 | 0.000 |
| calc-func/dc_nzpw/oracle.xlsx | 186 | 185 | 0 | 0 | 0 | 1 | 0 | 0 | 1 | 99.46% | 0.002 | 0.004 | 0.001 |
| calc-func/dc_q9rb/oracle.xlsx | 86 | 81 | 0 | 0 | 0 | 5 | 5 | 0 | 0 | 94.18% | 0.001 | 0.002 | 0.000 |
| calc-func/dc_xrxb/oracle.xlsx | 167 | 167 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.002 | 0.046 | 0.000 |
| calc-func/dcj9k_r21/oracle.xlsx | 204 | 122 | 0 | 0 | 0 | 82 | 82 | 0 | 0 | 59.80% | 0.003 | 0.008 | 0.000 |
| calc-func/dcj9k_r22/oracle.xlsx | 105 | 105 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.003 | 0.007 | 0.000 |
| calc-func/dcj9k_r25_bessel/oracle.xlsx | 310 | 309 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 99.67% | 0.003 | 0.004 | 0.001 |
| calc-func/dcj9k_r25_discrete/oracle.xlsx | 233 | 178 | 0 | 0 | 0 | 55 | 55 | 0 | 0 | 76.39% | 0.003 | 0.036 | 0.001 |
| calc-func/dcj9k_r25_geomean/oracle.xlsx | 292 | 292 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.003 | 0.004 | 0.001 |
| calc-func/dcj9k_r25_guard_transfer/oracle.xlsx | 400 | 400 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.003 | 0.006 | 0.001 |
| calc-func/dcj9k_r25_qr_stores/oracle.xlsx | 100 | 86 | 0 | 0 | 0 | 14 | 14 | 0 | 0 | 86.00% | 0.001 | 0.006 | 0.000 |
| calc-func/dcj9k_r25_regression/oracle.xlsx | 2280 | 2088 | 0 | 0 | 0 | 192 | 192 | 0 | 0 | 91.57% | 0.024 | 0.051 | 0.012 |
| calc-func/dcj9k_r25_variance/oracle.xlsx | 732 | 732 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.006 | 0.024 | 0.003 |
| calc-func/dcj9k_r26_regression/oracle.xlsx | 3984 | 3906 | 0 | 0 | 0 | 78 | 78 | 0 | 0 | 98.04% | 0.033 | 0.108 | 0.022 |
| calc-func/dcj9k_r26_root_transfer/oracle.xlsx | 3136 | 3136 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.025 | 0.035 | 0.015 |
| calc-func/dcj9k_r26_scalar/oracle.xlsx | 2571 | 2571 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.019 | 0.054 | 0.010 |
| calc-func/dcztvv_r23/oracle.xlsx | 968 | 801 | 0 | 0 | 0 | 167 | 166 | 1 | 0 | 82.74% | 0.008 | 0.028 | 0.005 |
| calc-func/dcztvv_r24/oracle.xlsx | 4047 | 3842 | 0 | 0 | 0 | 205 | 205 | 0 | 0 | 94.93% | 0.054 | 0.148 | 0.021 |
| calc-func/fn10_sort_cycle/oracle.xlsx | 100 | 0 | 0 | 0 | 100 | 100 | 0 | 0 | 0 | 0.00% | - | - | - |
| calc-func/fn2_questions/oracle.xlsx | 956 | 928 | 0 | 0 | 0 | 28 | 18 | 4 | 6 | 97.07% | 0.077 | 0.093 | 0.007 |
| calc-func/fn3_questions/oracle.xlsx | 491 | 491 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.006 | 0.049 | 0.002 |
| calc-func/fn5_dates_1900/oracle.xlsx | 320 | 320 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.006 | 0.008 | 0.001 |
| calc-func/fn5_digits_zero/oracle.xlsx | 432 | 432 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.008 | 0.037 | 0.002 |
| calc-func/fn5_helper_boundaries/oracle.xlsx | 526 | 526 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.011 | 0.016 | 0.004 |
| calc-func/fn5_regex_results/oracle.xlsx | 160 | 160 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.005 | 0.005 | 0.000 |
| calc-func/fn5_selection_boundaries/oracle.xlsx | 408 | 408 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.008 | 0.029 | 0.002 |
| calc-func/fn6_iteration_primary/oracle.xlsx | 1200 | 1200 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.027 | 0.089 | 0.005 |
| calc-func/fn6_jamo_suffix/oracle.xlsx | 480 | 480 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.017 | 0.082 | 0.002 |
| calc-func/fn6_utf16_needles/oracle.xlsx | 320 | 320 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.006 | 0.008 | 0.001 |
| calc-func/fn6_utf16_needles_compat1/oracle.xlsx | 320 | 320 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.008 | 0.008 | 0.001 |
| calc-func/fn6_utf16_needles_compat2/oracle.xlsx | 320 | 320 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.008 | 0.009 | 0.001 |
| calc-func/fn7_argument_origins/oracle.xlsx | 480 | 480 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.033 | 0.010 | 0.001 |
| calc-func/fn7_collation_context/oracle.xlsx | 4648 | 4635 | 0 | 0 | 0 | 13 | 13 | 0 | 0 | 99.72% | 0.083 | 0.216 | 0.027 |
| calc-func/fn7_collation_contractions/oracle.xlsx | 2392 | 2092 | 0 | 0 | 0 | 300 | 0 | 300 | 0 | 87.45% | 0.034 | 0.120 | 0.013 |
| calc-func/fn7_date_argument_origins/oracle.xlsx | 480 | 480 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.006 | 0.009 | 0.002 |
| calc-func/fn7_format_context/oracle.xlsx | 160 | 140 | 0 | 0 | 0 | 20 | 20 | 0 | 0 | 87.50% | 0.004 | 0.005 | 0.001 |
| calc-host/dc_ylr/oracle.xlsx | 74 | 1 | 73 | 0 | 0 | 73 | 0 | 0 | 0 | 1.35% | 0.003 | 0.002 | 0.000 |
| calc-host/eng13_legacy/oracle.xlsx | 50 | 50 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.004 | 0.001 | 0.000 |
| **Total** | 54794 | 52988 | 73 | 14 | 100 | 1806 | 1305 | 307 | 7 | 96.70% | 1.565 | 10.002 | 0.307 |

### Captures

- calc-engine/dc_10y/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-engine/tests/captures/dc_10y/oracle.capture.json
- calc-engine/dc_10y_iteration/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-engine/tests/captures/dc_10y_iteration/oracle.capture.json
- calc-engine/dc_86f/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-engine/tests/captures/dc_86f/oracle.capture.json
- calc-engine/dc_y2o/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-engine/tests/captures/dc_y2o/oracle.capture.json
- calc-engine/eng14-raw-nonfinite/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-engine/tests/captures/eng14-raw-nonfinite/oracle.capture.json
- calc-engine/eng15-overflow/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-engine/tests/captures/eng15-overflow/oracle.capture.json
- calc-engine/l3/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-engine/tests/captures/l3/oracle.capture.json
- calc-fml/dc_51ka/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-fml/tests/captures/dc_51ka/oracle.capture.json
- calc-fml/dc_ibp2/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-fml/tests/captures/dc_ibp2/oracle.capture.json
- calc-fml/dc_l10u/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-fml/tests/captures/dc_l10u/oracle.capture.json
- calc-func/catalogue/oracle.xlsx: 25 committed section captures from 5 capture session(s); 0 section(s) awaiting capture
- calc-func/cdoc_jpha/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/cdoc_jpha/oracle.capture.json
- calc-func/cfunc_m1_2/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/cfunc_m1_2/oracle.capture.json
- calc-func/cfunc_m3_2/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/cfunc_m3_2/oracle.capture.json
- calc-func/cfunc_m3_4/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/cfunc_m3_4/oracle.capture.json
- calc-func/cfunc_m3_5/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/cfunc_m3_5/oracle.capture.json
- calc-func/cfunc_m3_6/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/cfunc_m3_6/oracle.capture.json
- calc-func/dc_e00t/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dc_e00t/oracle.capture.json
- calc-func/dc_fwpz/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dc_fwpz/oracle.capture.json
- calc-func/dc_nzpw/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dc_nzpw/oracle.capture.json
- calc-func/dc_q9rb/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dc_q9rb/oracle.capture.json
- calc-func/dc_xrxb/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dc_xrxb/oracle.capture.json
- calc-func/dcj9k_r21/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r21/oracle.capture.json
- calc-func/dcj9k_r22/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r22/oracle.capture.json
- calc-func/dcj9k_r25_bessel/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r25_bessel/oracle.capture.json
- calc-func/dcj9k_r25_discrete/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r25_discrete/oracle.capture.json
- calc-func/dcj9k_r25_geomean/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r25_geomean/oracle.capture.json
- calc-func/dcj9k_r25_guard_transfer/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r25_guard_transfer/oracle.capture.json
- calc-func/dcj9k_r25_qr_stores/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r25_qr_stores/oracle.capture.json
- calc-func/dcj9k_r25_regression/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r25_regression/oracle.capture.json
- calc-func/dcj9k_r25_variance/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r25_variance/oracle.capture.json
- calc-func/dcj9k_r26_regression/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r26_regression/oracle.capture.json
- calc-func/dcj9k_r26_root_transfer/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r26_root_transfer/oracle.capture.json
- calc-func/dcj9k_r26_scalar/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r26_scalar/oracle.capture.json
- calc-func/dcztvv_r23/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcztvv_r23/oracle.capture.json
- calc-func/dcztvv_r24/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcztvv_r24/oracle.capture.json
- calc-func/fn10_sort_cycle/oracle.xlsx: awaiting capture: no committed capture
- calc-func/fn2_questions/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn2_questions/oracle.capture.json
- calc-func/fn3_questions/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn3_questions/oracle.capture.json
- calc-func/fn5_dates_1900/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn5_dates_1900/oracle.capture.json
- calc-func/fn5_digits_zero/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn5_digits_zero/oracle.capture.json
- calc-func/fn5_helper_boundaries/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn5_helper_boundaries/oracle.capture.json
- calc-func/fn5_regex_results/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn5_regex_results/oracle.capture.json
- calc-func/fn5_selection_boundaries/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn5_selection_boundaries/oracle.capture.json
- calc-func/fn6_iteration_primary/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn6_iteration_primary/oracle.capture.json
- calc-func/fn6_jamo_suffix/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn6_jamo_suffix/oracle.capture.json
- calc-func/fn6_utf16_needles/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn6_utf16_needles/oracle.capture.json
- calc-func/fn6_utf16_needles_compat1/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn6_utf16_needles_compat1/oracle.capture.json
- calc-func/fn6_utf16_needles_compat2/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn6_utf16_needles_compat2/oracle.capture.json
- calc-func/fn7_argument_origins/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn7_argument_origins/oracle.capture.json
- calc-func/fn7_collation_context/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn7_collation_context/oracle.capture.json
- calc-func/fn7_collation_contractions/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn7_collation_contractions/oracle.capture.json
- calc-func/fn7_date_argument_origins/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn7_date_argument_origins/oracle.capture.json
- calc-func/fn7_format_context/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn7_format_context/oracle.capture.json
- calc-host/dc_ylr/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-host/tests/captures/dc_ylr/oracle.capture.json
- calc-host/eng13_legacy/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-host/tests/captures/eng13_legacy/oracle.capture.json

## Failures by root cause

### Refusals (not modelled), by owner and reason

7 causes, 291 roots, 307 cells.

| Owner | Reason | Roots | Downstream | Whole workbook | Cells | Workbooks |
|---|---|---:|---:|---:|---:|---:|
| no package named (calc-fml refused) | formula Evaluation:NotModelled | 272 | 0 | 0 | 272 | 2 |
| exactness dc-j9k | not-modelled SORT | 8 | 8 | 0 | 16 | 1 |
| exactness dc-uar | not-modelled < | 4 | 4 | 0 | 8 | 1 |
| exactness dc-uar | not-modelled = | 3 | 3 | 0 | 6 | 1 |
| exactness dc-uar | not-modelled GETPIVOTDATA | 2 | 0 | 0 | 2 | 1 |
| no package named (calc-fml refused) | formula Compile:Syntax | 1 | 1 | 0 | 2 | 1 |
| no package named (calc-fml refused) | formula Compile:Arity | 1 | 0 | 0 | 1 | 1 |

### Mismatches, by function and shape at the root

131 causes, 1285 roots, 1287 cells.

| Function | Shape | Roots | Downstream | Whole workbook | Cells | Workbooks |
|---|---|---:|---:|---:|---:|---:|
| INDEX | number, differs within 15 significant digits; observed reads: number | 230 | 0 | 0 | 230 | 3 |
| INDEX | number, differs within 15 significant digits | 133 | 0 | 0 | 133 | 3 |
| CUMPRINC | number, 1 ulp apart | 68 | 0 | 0 | 68 | 1 |
| CUMPRINC | number, 2 to 16 ulp apart | 61 | 0 | 0 | 61 | 2 |
| INDEX | number expected, error Num returned; observed reads: number | 45 | 0 | 0 | 45 | 2 |
| IPMT | number, 1 ulp apart | 41 | 0 | 0 | 41 | 2 |
| CUMPRINC | number, differs within 15 significant digits | 36 | 0 | 0 | 36 | 2 |
| INDEX | error Ref expected, number returned | 30 | 0 | 0 | 30 | 2 |
| RATE | number, differs within 15 significant digits | 29 | 0 | 0 | 29 | 3 |
| BINOM.DIST | number, 2 to 16 ulp apart | 26 | 0 | 0 | 26 | 2 |
| CUMIPMT | number, 2 to 16 ulp apart | 26 | 0 | 0 | 26 | 2 |
| YIELD | number, differs within 15 significant digits | 24 | 0 | 0 | 24 | 3 |
| INDEX | text expected, text returned; observed reads: text | 23 | 0 | 0 | 23 | 2 |
| ODDFYIELD | number, differs within 15 significant digits | 23 | 0 | 0 | 23 | 3 |
| PPMT | number, 1 ulp apart | 23 | 0 | 0 | 23 | 1 |
| BINOM.DIST | number, 1 ulp apart | 19 | 0 | 0 | 19 | 2 |
| PPMT | number, differs within 15 significant digits | 19 | 0 | 0 | 19 | 2 |
| CUMIPMT | number, 1 ulp apart | 16 | 0 | 0 | 16 | 2 |
| POISSON.DIST | number, 1 ulp apart; observed reads: number | 16 | 0 | 0 | 16 | 1 |
| INDEX | number, 1 ulp apart | 15 | 0 | 0 | 15 | 2 |
| BINOM.DIST | number, 2 to 16 ulp apart; observed reads: number | 13 | 0 | 0 | 13 | 2 |
| HYPGEOM.DIST | number, 2 to 16 ulp apart | 13 | 0 | 0 | 13 | 2 |
| HYPGEOM.DIST | number, 1 ulp apart | 11 | 0 | 0 | 11 | 2 |
| IPMT | number, 2 to 16 ulp apart | 11 | 0 | 0 | 11 | 1 |
| IPMT | number, differs within 15 significant digits | 11 | 0 | 0 | 11 | 2 |
| NEGBINOM.DIST | number, 1 ulp apart | 11 | 0 | 0 | 11 | 2 |
| NEGBINOMDIST | number, 1 ulp apart | 11 | 0 | 0 | 11 | 2 |
| BINOM.DIST | number, 1 ulp apart; observed reads: number | 10 | 0 | 0 | 10 | 1 |
| INDEX | error Ref expected, error Value returned | 10 | 0 | 0 | 10 | 1 |
| INDEX | number expected, error Num returned | 10 | 0 | 0 | 10 | 2 |
| BETADIST | number, differs within 15 significant digits | 8 | 0 | 0 | 8 | 2 |
| CUMIPMT | number, differs within 15 significant digits | 8 | 0 | 0 | 8 | 2 |
| GAMMA.DIST | number, differs within 15 significant digits | 8 | 0 | 0 | 8 | 2 |
| IRR | number, differs within 15 significant digits | 8 | 0 | 0 | 8 | 3 |
| ODDFYIELD | error Num expected, error Value returned | 8 | 0 | 0 | 8 | 2 |
| RATE | error Num expected, number returned | 8 | 0 | 0 | 8 | 2 |
| BINOM.DIST | number, differs within 15 significant digits | 7 | 0 | 0 | 7 | 2 |
| INDEX | number, 2 to 16 ulp apart; observed reads: number | 7 | 0 | 0 | 7 | 1 |
| POISSON.DIST | number, differs within 15 significant digits; observed reads: number | 7 | 0 | 0 | 7 | 1 |
| BINOM.DIST | number, differs within 15 significant digits; observed reads: number | 6 | 0 | 0 | 6 | 1 |

and 91 more in summary.json

### Other failures, by class and key

5 causes, 94 roots, 212 cells.

| Class | Key | Roots | Downstream | Whole workbook | Cells | Workbooks |
|---|---|---:|---:|---:|---:|---:|
| capture | awaiting capture | 0 | 0 | 100 | 100 | 1 |
| provenance | external link cache (dc-ylr) | 73 | 0 | 0 | 73 | 1 |
| capture | capture failure at stage entry | 6 | 18 | 0 | 24 | 1 |
| provenance | circular held cache (dc-y2o.1) | 14 | 0 | 0 | 14 | 1 |
| capture | capture failure at stage value | 1 | 0 | 0 | 1 | 1 |

