"""Original MIT diagnostic: fixed natural-log/mean/exp publication trees.

Reuse the one fingerprint library, raw service cache and directed MPFR API.
Mathematical leaves are conditional hypotheses, never private Excel readings.
All programs and contradictions are retained in fixed structural order.
"""
from collections import Counter
from fractions import Fraction as Q
import hashlib
import json
from pathlib import Path
import sys

from racer import fingerprint as f

source=Path(__file__).resolve()
bindings={str(p):f.sha(p)for p in (source,Path(f.__file__),f.ROOT/'checker/reference.py',f.ROOT/'checker/exact.py')}
client,_=f.load_service('../DnaCalc')
service=f.CachedService(client.Client(timeout=900),'evidence/round26/fingerprints',offline=True)
centers=(.13,1.3,7.,1000.)
inputs=[f'{b:016x}'for x in centers for b in range(int(f.bits(x),16)-128,int(f.bits(x),16)+128)]
logs=[]
for raw in inputs:
    lo,hi=f.elementary_bounds('LN',[client.number(raw)])
    pair=[]
    for fmt in (f.BINARY64,f.EXTENDED64):
        a,b=fmt.round(lo),fmt.round(hi)
        if a!=b:raise ValueError('uncertified mathematical logarithm publication')
        pair.append(a)
    logs.append(pair)

models=[dict(log_precision=precision,mean=association,mean_store=store,exp_publication=publication)
        for precision in (53,64)
        for association in ('divide','multiply_reciprocal53','multiply_reciprocal64')
        for store in ('direct53','pc64_then53')
        for publication in ('single','double')]
memo={};records=[]
for n in (2,3,4,5,10,17,32):
    targets=service.ask('GEOMEAN',[[client.number(raw)]+[client.number(1.)]*(n-1)for raw in inputs])['rows']
    profiles=[]
    for identity,model in enumerate(models):
        tally=Counter();first=None;digest=hashlib.sha256()
        for raw,log,target in zip(inputs,logs,targets):
            natural=log[model['log_precision']==64]
            if model['mean']=='divide':mean=natural/n
            else:
                fmt=f.BINARY64 if model['mean'].endswith('53')else f.EXTENDED64
                mean=natural*fmt.round(Q(1,n))
            if model['mean_store']=='pc64_then53':mean=f.EXTENDED64.round(mean)
            mean=f.BINARY64.round(mean);mean_bits=f.bits(float(mean))
            if mean_bits not in memo:
                memo[mean_bits]=f.publication(f.elementary_bounds('EXP',[client.number(mean_bits)]))
            predicted=memo[mean_bits][model['exp_publication']=='double']
            digest.update(bytes.fromhex(predicted))
            key='matched'if target==dict(type='number',bits=predicted)else'mismatched';tally[key]+=1
            if key=='mismatched'and first is None:first=dict(input=raw,mean=mean_bits,excel=target,candidate=predicted)
        profiles.append(dict(id=identity,model=model,counts=tally,consistent=tally['matched']==len(inputs),
                             first_contradiction=first,predictions_sha256=digest.hexdigest()))
    records.append(dict(count=n,observations=len(inputs),profiles=profiles))
    print(n,'consistent model IDs',[p['id']for p in profiles if p['consistent']],flush=True)
if bindings!={p:f.sha(p)for p in bindings}:raise ValueError('diagnostic source changed')
f.write(sys.argv[1],dict(format='dnacalc-geomean-mathematical-stages/1',complete=True,records=records,
    driver_bindings=bindings,receipts=service.receipts,centers=centers,consecutive_inputs_per_center=256,
    limitations='Conditional correctly rounded mathematical natural-log and exponential leaves only. Every mean is stored to binary64. This does not measure private Intel x87 instructions, identify a complete Excel root or imply stage counts from spectra. No candidate chosen by match count; no coefficient, threshold or selector fitted.'))
