"""Necessary geometric principal ratio cells; original read-only arithmetic."""
from pathlib import Path
from fractions import Fraction as Q
import json, hashlib, sys
sys.path.insert(0, str(Path.cwd()/"checker"))
from exact import BINARY64 as B, EXTENDED64 as E, Span, binary64
root=Path("/home/ubuntu/codex-runs/round33")
source=root/"cumprinc-power-denominators.json"
doc=json.loads(source.read_text()); pairs={}
for row in doc["records"]:
 c=row["case"]
 if c["start"]==c["end"] and c["start"]in(1,2):
  key=(c["rate"],c["periods"],c["pv"])
  assert c["start"]not in pairs.setdefault(key,{})
  pairs[key][c["start"]]=-binary64(row["answer"]["bits"])
assert len(pairs)==288 and all(set(p)=={1,2}for p in pairs.values())
states={}; records=[]
for key,values in pairs.items():
 a,b=(E.pullback(B.pullback(Span(values[k],values[k])))for k in(1,2))
 assert a.low>0 and b.low>0
 # Closed endpoint enclosure deliberately includes all open/tie cases.
 necessary=Span(b.low/a.high,b.high/a.low)
 r=key[0]; state=states.setdefault(r,{"domain":None,"pairs":0})
 state["domain"]=necessary if state["pairs"]==0 else state["domain"].meet(necessary)if state["domain"]else None
 state["pairs"]+=1
 records.append({"rate":r,"periods":key[1],"pv":key[2],"necessary_q":necessary.json()})
summary=[]
for r,state in states.items():
 domain=state["domain"]; exact=Q(1)+binary64(r); stored=B.round(exact)
 summary.append({"rate":r,"pairs":state["pairs"],"domain":domain.json()if domain else None,
  "exact_one_plus_rate_contained":bool(domain and domain.contains(exact)),
  "stored_one_plus_rate_contained":bool(domain and domain.contains(stored))})
result={"complete":True,"pairs":len(pairs),"rates":len(states),"models":summary,"records":records,
 "counts":{"nonempty":sum(x["domain"]is not None for x in summary),
 "exact_base_contained":sum(x["exact_one_plus_rate_contained"]for x in summary),
 "stored_base_contained":sum(x["stored_one_plus_rate_contained"]for x in summary)},
 "source_sha256":{str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in(source,Path(__file__),Path("checker/exact.py"))},
 "limits":"Conditional geometric hidden P2=P1*q with each real latent component inside its PC64-then-binary64 publication preimage. Closed ratio cells are necessary overapproximations; emptiness refutes only this family. Surviving cells identify no producer. No PMT/FV calls, application change or bank gain."}
(root/"cumprinc-q-envelope.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result["counts"]))
