"""Recover exact recorded source epochs; export file patches only, never messages."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess


def digest(data):
    return hashlib.sha256(data).hexdigest()


def run(session, scratch, main, research):
    session, scratch, main, research = [Path(p).resolve() for p in (session, scratch, main, research)]
    roots = ((research, '6622227b3e37'), (main, '1eb8881e96920e032d1802e6f6bb3b91514b0fab'))
    tracked = {}
    names = {}
    for repo, revision in roots:
        paths = subprocess.check_output(['git', 'ls-files'], cwd=repo, text=True).splitlines()
        for path in paths:
            full = repo / path
            if full.suffix in ('.py', '.rs', '.c'):
                tracked[str(full)] = (repo, revision, path)
                names.setdefault(full.name, []).append(str(full))

    def canonical(path):
        p = Path(path)
        if str(p) in tracked:
            return str(p)
        for repo, _ in roots:
            candidate = str(repo / p)
            if candidate in tracked:
                return candidate
        options = names.get(p.name, [])
        return options[0] if len(options) == 1 else None

    expected = set()
    needed = set()

    def inspect(value):
        if isinstance(value, dict):
            for key, child in value.items():
                if isinstance(child, str) and re.fullmatch('[0-9a-f]{64}', child):
                    needed.add(child)
                    path = canonical(key)
                    if path:
                        expected.add((path, child))
                inspect(child)
        elif isinstance(value, list):
            for child in value:
                inspect(child)

    for path in [*scratch.glob('*.json'), *scratch.glob('producers/*unit.json')]:
        if path.name.startswith(('session-file-patches', 'source-epoch-')):
            continue
        inspect(json.loads(path.read_text()))
    inspect(json.loads((research / 'round33-unit.json').read_text()))

    patches = []
    for line in session.open():
        item = json.loads(line)
        payload = item.get('payload', {})
        if payload.get('type') != 'custom_tool_call' or not isinstance(payload.get('input'), str):
            continue
        for match in re.finditer(r'"(?:[^"\\]|\\.)*"', payload['input']):
            try:
                text = json.loads(match[0])
            except ValueError:
                continue
            if text.startswith('*** Begin Patch'):
                patches.append(dict(timestamp=item.get('timestamp'), call_id=payload.get('call_id'), patch=text))

    pool = {}
    recoveries = []
    failures = []
    producers = scratch / 'producers'
    producers.mkdir(exist_ok=True)

    def retain(path, text, origin):
        data = text.encode()
        sha = digest(data)
        if sha not in needed:
            return
        target = producers / (sha + '-' + Path(path).name)
        if target.exists():
            assert target.read_bytes() == data
        else:
            target.write_bytes(data)
        recoveries.append(dict(path=path, sha256=sha, origin=origin))

    for path, (repo, revision, relative) in tracked.items():
        if not any(p == path for p, _ in expected):
            continue
        result = subprocess.run(['git', 'show', revision + ':' + relative], cwd=repo, capture_output=True)
        if result.returncode:
            continue
        pool[path] = result.stdout.decode()
        retain(path, pool[path], 'git:' + revision + ':' + relative)
        retain(path, Path(path).read_text(), 'current exact bytes')

    for item in patches:
        lines = item['patch'].splitlines()
        i = 1
        while i < len(lines):
            if not lines[i].startswith('*** Update File: '):
                i += 1
                continue
            path = canonical(lines[i][len('*** Update File: '):])
            i += 1
            part = []
            while i < len(lines) and not lines[i].startswith('*** '):
                part.append(lines[i])
                i += 1
            if path not in pool:
                continue
            chunks = []
            chunk = []
            for line in part:
                if line.startswith('@@'):
                    if chunk:
                        chunks.append(chunk)
                    chunk = []
                else:
                    chunk.append(line)
            if chunk:
                chunks.append(chunk)
            text = pool[path]
            position = 0
            for chunk in chunks:
                before = ''.join(s[1:] + '\n' for s in chunk if s.startswith((' ', '-')))
                after = ''.join(s[1:] + '\n' for s in chunk if s.startswith((' ', '+')))
                at = text.find(before, position)
                if not before or at < 0:
                    failures.append(dict(path=path, call_id=item['call_id']))
                    break
                text = text[:at] + after + text[at + len(before):]
                position = at + len(after)
            else:
                pool[path] = text
                retain(path, text, dict(call_id=item['call_id'], timestamp=item['timestamp']))

    available = {p.name[:64] for p in producers.iterdir() if p.is_file() and digest(p.read_bytes()) == p.name[:64]}
    patch_file = scratch / 'session-file-patches.json'
    patch_file.write_text(json.dumps(patches, separators=(',', ':')) + '\n')
    receipt = dict(format='dnacalc-source-epoch-recovery/1', complete=True,
                   bases={str(repo): revision for repo, revision in roots},
                   patch_sha256=digest(patch_file.read_bytes()), script_sha256=digest(Path(__file__).read_bytes()),
                   recovered=recoveries, context_failures=failures,
                   unresolved=[dict(path=p, sha256=h) for p, h in sorted(expected) if h not in available],
                   replayed_final_matches={p: value == Path(p).read_text() for p, value in pool.items()},
                   limits='Exact recorded SHA256 identities only. Only source-file patches are exported; no conversation messages or reasoning. Actual repository sources are read only.')
    (scratch / 'source-epoch-full-recovery.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(dict(source_entries=len(expected), recovered_epochs=len(available),
                          unresolved=receipt['unresolved'], context_failures=failures)))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('session', 'scratch', 'main', 'research'):
        parser.add_argument(name)
    args = parser.parse_args()
    run(args.session, args.scratch, args.main, args.research)
