"""Freeze run-specific evidence without changing original observations."""
from pathlib import Path
import gzip
import hashlib
import json
import collections
import sys

ROOT = Path('/home/ubuntu/codex-runs/round33')
DEST = Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research/evidence/round33')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    DEST.mkdir(parents=True, exist_ok=True)
    manifest = DEST/'artifacts.json'
    entries = json.loads(manifest.read_text())['artifacts'] if manifest.exists() else []
    known = {(e['original'], e['sha256']) for e in entries}
    selected = [p for p in ROOT.iterdir() if p.is_file() and p.suffix in
                ('.json', '.jsonl', '.log', '.txt', '.md', '.py', '.rs') and
                p.name != 'session-file-patches.json']
    for directory in ('producers', 'scalar-cache', 'baseline-functions', 'after-log-functions'):
        selected.extend(p for p in (ROOT/directory).rglob('*') if p.is_file() and
                        not (directory == 'baseline-functions' and p.name not in
                             ('GAMMALN.jsonl', 'GAMMALN.PRECISE.jsonl', 'receipt.json')))
    for directory in ('baseline-run', 'after-log-run', 'after-kurt-run', 'after-yield-run',
                      'incoming-baseline-run', 'final-run', 'pulled-final-run'):
        selected.extend(ROOT/directory/name for name in ('receipt.json', 'bank-counts.json'))
    selected.extend(p for p in (ROOT/'yield-final-corruption-controls').rglob('controls.json'))
    for source in sorted(set(selected)):
        if not source.exists():
            continue
        # The recorder creates this only when its subprocess has finished.
        if source.suffix == '.log' and not Path(str(source)+'.resource.json').exists():
            continue
        data = source.read_bytes()
        digest = sha(data)
        if (str(source), digest) in known:
            continue
        category = ('scalar-cache' if source.parent.name == 'scalar-cache' else
                    'producers' if source.parent.name == 'producers' else 'retained')
        name = source.name if category == 'scalar-cache' else digest+'-'+source.name+'.gz'
        target = DEST/category/name
        target.parent.mkdir(exist_ok=True)
        packed = data if category == 'scalar-cache' else gzip.compress(data, compresslevel=6, mtime=0)
        if target.exists():
            assert target.read_bytes() == packed, target
        else:
            with target.open('xb') as stream:
                stream.write(packed)
        entries.append(dict(original=str(source), archive=str(target.relative_to(DEST.parent.parent)),
                            sha256=digest, archive_sha256=sha(packed), bytes=len(data),
                            archive_bytes=len(packed)))
    result = dict(format='dnacalc-round33-artifacts/1', complete=True, artifacts=entries,
                  archive_bytes=sum({e['archive']: e['archive_bytes'] for e in entries}.values()),
                  limits='Exact original bytes or gzip thereof. No binary library, target directory, full corpus '
                         'cells, private session messages, excluded checkout or Excel lock file is archived. '
                         'Historical failed experiments remain distinct from final proofs.')
    manifest.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(dict(artifacts=len(entries), archive_bytes=result['archive_bytes'])))


if __name__ == '__main__':
    if sys.argv[1:] == ['verify']:
        entries = json.loads((DEST/'artifacts.json').read_text())['artifacts']
        for entry in entries:
            packed = (DEST.parent.parent/entry['archive']).read_bytes()
            assert sha(packed) == entry['archive_sha256'], entry['archive']
            data = packed if '/scalar-cache/' in entry['archive'] else gzip.decompress(packed)
            assert sha(data) == entry['sha256'] and len(data) == entry['bytes'], entry['archive']
        counts = collections.Counter()
        unique = set()
        refusals = []
        for source in sorted((DEST/'scalar-cache').iterdir()):
            with gzip.open(source, 'rt') as stream:
                document = json.load(stream)
            reply, request = document['reply'], document['request']
            assert reply['version'] == 1, source
            counts['bundles'] += 1
            if not reply['ok']:
                assert not reply['rows'] and reply['error'], source
                counts['failed_requests'] += 1
                counts['failed_request_calls'] += len(request['rows'])
                refusals.append(dict(file=source.name, error=reply['error']))
                continue
            assert reply['automation_security_before'] == reply['automation_security_after'], source
            assert reply['inputs'] == [[{k:v for k,v in arg.items() if k != 'mode'}
                                        for arg in row] for row in request['rows']], source
            assert len(reply['rows']) == len(request['rows']), source
            counts['successful_bundles'] += 1
            counts['observed_calls'] += len(request['rows'])
            for row in request['rows']:
                unique.add(json.dumps([request['function'], row], sort_keys=True))
        counts['distinct_observed_inputs'] = len(unique)
        counts['repeated_observed_calls'] = counts['observed_calls']-len(unique)
        result = dict(complete=True, verified_artifact_records=len(entries), scalar_cache=dict(counts),
                      failed_requests=refusals, scope='Exact archive/decompression hashes and original byte '
                      'counts; worker version, unchanged policy, readbacks and successful call counts. '
                      'Failed requests are retained and never counted as observations or passes. '
                      'The first validator prototype incorrectly required every cached reply to be successful; '
                      'it rejected the retained oversized-request refusal. Arithmetic proofs remain separate.')
        (ROOT/'archive-validation.json').write_text(json.dumps(result, indent=2)+'\n')
        print(json.dumps(result))
    else:
        main()
