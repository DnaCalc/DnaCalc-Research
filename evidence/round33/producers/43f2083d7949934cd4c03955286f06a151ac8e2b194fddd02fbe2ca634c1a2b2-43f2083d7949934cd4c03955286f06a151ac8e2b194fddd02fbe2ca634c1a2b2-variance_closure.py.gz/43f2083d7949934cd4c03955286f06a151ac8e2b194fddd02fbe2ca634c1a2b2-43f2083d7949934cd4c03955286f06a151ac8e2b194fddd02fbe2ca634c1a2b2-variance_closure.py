"""Complete value closures for arbitrary-site three-input two-pass variance.

Every addition tree/permutation and every five-model arithmetic annotation is
included. Corrected two-pass bounds deliberately drop the dependency between
sum(delta) and sum(delta^2); an exclusion of that larger set is still valid.
No arithmetic value is inferred from an expected answer.
"""
from collections import Counter
from fractions import Fraction as Q
import itertools
import json
from pathlib import Path
import sys
import time

from bessel import operation,MODELS,pair,digest,require
from intervals import B64,E64,E53,Interval,number,pow2


def encode(values):return [pair(x)for x in sorted(values)]


def sums(leaves):
    """Subset closure includes both ordered children at every binary node."""
    table={1<<i:set(values)for i,values in enumerate(leaves)}
    for mask in range(1,1 << len(leaves)):
        if mask in table:continue
        result=set();left=(mask-1)&mask
        while left:
            right=mask^left
            if right:
                for a,b,model in itertools.product(table[left],table[right],MODELS):
                    result.add(operation('add',model,a,b))
            left=(left-1)&mask
        table[mask]=result
    return table


def serialized(table):return {str(mask):encode(table[mask])for mask in range(1,8)}


def close(row):
    def flatten(arg):return list(itertools.chain.from_iterable(flatten(x)for x in arg))if isinstance(arg,list)else[arg]
    args=flatten(row['args'])
    require(len(args)==3 and all(isinstance(x,str)and x.startswith('0x')for x in args), 'outside numeric three-input scope')
    xs=[Q(number(x))for x in args]
    require(all(x==0 or pow2(-100)<=abs(x)<=pow2(100)for x in xs), 'outside input magnitude bound')
    require(row['function']in('VAR','VAR.S','VAR.P','VARP','VARA','VARPA'), 'unknown variance function')
    population=row['function']in('VAR.P','VARP','VARPA')
    divisor=Q(3 if population else 2)
    total=sums([{x}for x in xs])
    means={operation('div',model,s,Q(3))for s,model in itertools.product(total[7],MODELS)}
    plain=set();corrected=set();details=[]
    for mean in sorted(means):
        ds=[{operation('add',model,x,-mean)for model in MODELS}for x in xs]
        squares=[{operation('mul',model,d,d)for d,model in itertools.product(values,MODELS)}for values in ds]
        q=sums(squares);t=sums(ds)
        correction={operation('div',md,operation('mul',mm,d,d),Q(3))
                    for d,mm,md in itertools.product(t[7],MODELS,MODELS)}
        outputs={operation('div',model,value,divisor)for value,model in itertools.product(q[7],MODELS)}
        adjusted={operation('div',md,operation('add',ms,value,-c),divisor)
                  for value,c,ms,md in itertools.product(q[7],correction,MODELS,MODELS)}
        details.append(dict(mean=pair(mean),deltas=list(map(encode,ds)),squares=list(map(encode,squares)),
                            square_sum=serialized(q),delta_sum=serialized(t),corrections=encode(correction),
                            plain_roots=encode(outputs),corrected_roots=encode(adjusted)))
        plain.update(outputs);corrected.update(adjusted)
    target=Q(number(row['expected']));span=B64.preimage(Interval(target,target))
    reachable=lambda roots:any(span.contains(value)for value in roots)
    return dict(raw=row,mean_sum=serialized(total),means=encode(means),per_mean=details,
                plain_roots=encode(plain),corrected_roots=encode(corrected),target_span=span.json(),
                plain_reachable=reachable(plain),corrected_reachable=reachable(corrected))


def run(input_path,destination):
    start=time.monotonic();dest=Path(destination);dest.mkdir();source=digest(Path(__file__))
    rows=[json.loads(line)for line in Path(input_path).read_text().splitlines()]
    counts=Counter()
    with(dest/'closures.jsonl').open('x')as out:
        for row in rows:
            proof=close(row);out.write(json.dumps(proof)+'\n');counts['observations']+=1
            counts['plain_unreachable']+=not proof['plain_reachable'];counts['corrected_unreachable']+=not proof['corrected_reachable']
            counts['mean_values']+=len(proof['means']);counts['plain_root_values']+=len(proof['plain_roots'])
            counts['corrected_root_values']+=len(proof['corrected_roots'])
    require(digest(Path(__file__))==source, 'source changed during run')  # ubs:ignore — public integrity hashes, not secrets
    result=dict(complete=True,counts=counts,seconds=time.monotonic()-start,
                source_sha256=source,input_sha256={str(input_path):digest(input_path)},
                claim='All binary sum trees/permutations and arbitrary five-model assignments at every arithmetic site for three-input plain two-pass variance. '
                      'Corrected two-pass uses a conservative dependency-free closure containing every consistent delta/square program.',
                limits='Three-input discovery observations and listed algebra only. Reachable roots need not share a reusable program; conservative corrected roots may not have consistent leaf choices. '
                       'Zero signs are immaterial to squares and division by positive integers. No branch, fit or complete Excel kernel follows.')
    with(dest/'summary.json').open('x')as out:json.dump(result,out,indent=2);out.write('\n')
    print(json.dumps(result))


def online_close(row):
    def flatten(v):return list(itertools.chain.from_iterable(map(flatten,v)))if isinstance(v,list)else[v]
    bits=flatten(row['args']);require(len(bits)==3 and all(isinstance(v,str)and v.startswith('0x')for v in bits),'outside three-input online scope')
    xs=list(map(lambda v:Q(number(v)),bits));require(all(v==0 or pow2(-100)<=abs(v)<=pow2(100)for v in xs),'online magnitude scope')
    require(row['function']in('VAR','VAR.S','VAR.P','VARP','VARA','VARPA'),'wrong online variance function')
    divisor=Q(3 if row['function']in('VAR.P','VARP','VARPA')else 2)
    def values(kind,a,b):return{operation(kind,m,a,b)for m in MODELS}
    details=[];roots={'welford':set(),'youngs_cramer':set()}
    for perm in itertools.permutations(range(3)):
        record=dict(indices=list(perm))
        for family in roots:
            states={(xs[perm[0]],Q(0))};stages=[]
            for k,index in enumerate(perm[1:],2):
                x=xs[index];following=set()
                for accumulator,moment in states:
                    if family=='welford':
                        for delta in values('add',x,-accumulator):
                            means={v for q in values('div',delta,Q(k))for v in values('add',accumulator,q)}
                            for mean in means:
                                increments={v for e in values('add',x,-mean)for v in values('mul',delta,e)}
                                for t in increments:
                                    following.update((mean,q)for q in values('add',moment,t))
                    else:
                        for total in values('add',accumulator,x):
                            deviations={v for scaled in values('mul',Q(k),x)for v in values('add',scaled,-total)}
                            increments={v for delta in deviations for square in values('mul',delta,delta)for v in values('div',square,Q(k*(k-1)))}
                            for t in increments:following.update((total,q)for q in values('add',moment,t))
                states=following;stages.append([[pair(a),pair(b)]for a,b in sorted(states)])
            outputs={v for _,q in states for v in values('div',q,divisor)}
            record[family]=dict(stages=stages,roots=encode(outputs));roots[family].update(outputs)
        details.append(record)
    target=Q(number(row['expected']));span=B64.preimage(Interval(target,target))
    return dict(raw=row,permutations=details,roots={k:encode(v)for k,v in roots.items()},target_span=span.json(),reachable={k:any(span.contains(v)for v in values)for k,values in roots.items()})


def online_run(input_path,destination):
    start=time.monotonic();dest=Path(destination);dest.mkdir();source=digest(Path(__file__))
    rows=[json.loads(line)for line in Path(input_path).read_text().splitlines()];require(rows,'empty online observation scope')
    counts=Counter()
    with(dest/'closures.jsonl').open('x')as out:
        for row in rows:
            proof=online_close(row);out.write(json.dumps(proof)+'\n');counts['observations']+=1
            for family in('welford','youngs_cramer'):
                counts[family+'_unreachable']+=not proof['reachable'][family];counts[family+'_roots']+=len(proof['roots'][family])
                counts[family+'_state_pairs']+=sum(len(stage)for p in proof['permutations']for stage in p[family]['stages'])
    require(digest(Path(__file__))==source,'source changed during online closure')  # ubs:ignore — public integrity hashes, not secrets
    summary=dict(complete=True,counts=counts,seconds=time.monotonic()-start,source_sha256=source,input_sha256={str(input_path):digest(input_path)},
                 limits='Three-input Welford and Youngs-Cramer unrolled updates, all6 permutations and independent five-model annotations at every site. Boundary states preserve mean/sum-second-moment correlations. Reachability is not a reusable producer, fitted value or product gain.')
    with(dest/'summary.json').open('x')as out:json.dump(summary,out,indent=2);out.write('\n')
    print(json.dumps(summary))


def raw_moment_close(row, fused=False, root=False):
    """All-site closures of six fixed algebraic variance identities."""
    require(not root or fused and row.get('result_index') is None, 'STDEV scope requires fused forms and a scalar call')
    def flatten(v):
        return list(itertools.chain.from_iterable(map(flatten, v))) if isinstance(v, list) else [v]
    bits = flatten(row['args'])
    require(len(bits) == (4 if root else 3) and all(isinstance(v, str) and v.startswith('0x') for v in bits), 'raw-moment arity scope')
    xs = [Q(number(v)) for v in bits]
    require(all(v == 0 or pow2(-100) <= abs(v) <= pow2(100) for v in xs), 'raw-moment magnitude scope')
    names = ('STDEV','STDEV.S','STDEV.P','STDEVP','STDEVA','STDEVPA') if root else ('VAR','VAR.S','VAR.P','VARP','VARA','VARPA')
    require(row['function'] in names, 'raw-moment function scope')
    n = Q(len(xs))
    d = n if row['function'] in ('VAR.P','VARP','VARPA','STDEV.P','STDEVP','STDEVPA') else n-1
    full = (1 << len(xs))-1
    def combine(kind, left, right):
        return {operation(kind, model, a, b) for a, b, model in itertools.product(left, right, MODELS)}
    def subtract(left, right):
        return combine('add', left, {-v for v in right})
    def square(values):
        return {operation('mul', model, v, v) for v, model in itertools.product(values, MODELS)}
    def fma(a, b, c):
        result = set()
        for model in MODELS:
            if model == 'strict':
                a0, b0, c0 = map(B64.rn, (a, b, c))
                result.add(B64.rn(a0*b0+c0))
            else:
                value = (E53 if model.endswith('pc53') else E64).rn(a*b+c)
                result.add(B64.rn(value) if model.startswith('stored') else value)
        return result
    total = sums([{v} for v in xs])[full]
    squares = sums([square({v}) for v in xs])[full]
    if fused:
        # Every square-sum tree may fuse a leaf square with its sibling sum.
        # This includes ordinary sums, fully fused folds and mixed trees.
        table = {1 << i: square({x}) for i, x in enumerate(xs)}
        for mask in range(1, full+1):
            if mask in table:
                continue
            values = set()
            left = (mask-1) & mask
            while left:
                right = mask ^ left
                values.update(combine('add', table[left], table[right]))
                for leaf, sibling in ((left, right), (right, left)):
                    if leaf & (leaf-1) == 0:
                        x = xs[leaf.bit_length()-1]
                        values.update(v for accumulator in table[sibling] for v in fma(x, x, accumulator))
                left = (left-1) & mask
            table[mask] = values
        squares = table[full]
    total_square = square(total)
    nd = combine('mul', {n}, {d})
    roots = []
    # Independent sums and their correlations are conservatively projected.
    roots.append(combine('div', subtract(squares, combine('div', total_square, {n})), {d}))
    roots.append(combine('div', subtract(combine('mul', {n}, squares), total_square), nd))
    roots.append(subtract(combine('div', squares, {d}), combine('div', total_square, nd)))
    divided_squares = combine('div', squares, {d})
    mean_products = set()
    for value in total:
        mean_products.update(combine('mul', combine('div', {value}, {n}), combine('div', {value}, {d})))
    roots.append(subtract(divided_squares, mean_products))
    means = combine('div', total, {n})
    raw_population = subtract(combine('div', squares, {n}), square(means))
    roots.append(combine('mul', raw_population, combine('div', {n}, {d})))
    if not root:
        differences = [square(subtract({xs[i]}, {xs[j]})) for i, j in ((0, 1), (0, 2), (1, 2))]
        roots.append(combine('div', sums(differences)[7], nd))
    if fused:
        numerators = [set() for _ in range(4)]
        for value in total:
            for mean in combine('div', {value}, {n}):
                for q in squares:
                    numerators[0].update(fma(-mean, value, q))
                for q in combine('div', squares, {n}):
                    numerators[3].update(fma(-mean, mean, q))
            for q in combine('mul', {n}, squares):
                numerators[2].update(fma(-value, value, q))
        for q, s2 in itertools.product(squares, total_square):
            numerators[1].update(fma(n, q, -s2))
        roots.extend((combine('div', numerators[0], {d}),
                      combine('div', numerators[1], nd),
                      combine('div', numerators[2], nd),
                      combine('mul', numerators[3], combine('div', {n}, {d}))))
    target = Q(number(row['expected']))
    span = B64.preimage(Interval(target, target))
    import hashlib
    forms = []
    for values in roots:
        payload = json.dumps(encode(values), separators=(',', ':')).encode()
        form = dict(root_count=len(values), roots_sha256=hashlib.sha256(payload).hexdigest(),
                    reachable=any(span.contains(v) for v in values))
        if root:
            if __package__:
                from .geomean import root_publication_domains
            else:
                from geomean import root_publication_domains
            domains = root_publication_domains(values, 2, target, True)
            form.update(root_roundings=domains, reachable=any(d['reachable'] for d in domains.values()))
        forms.append(form)
    return dict(raw=row, target_span=span.json(), forms=forms,
                total_values=len(total), square_sum_values=len(squares))


def raw_moment_run(input_path, destination, fused=False, root=False):
    start = time.monotonic()
    dest = Path(destination)
    dest.mkdir()
    frozen = {str(p): digest(p) for p in (Path(input_path), Path(__file__), Path(__file__).with_name('bessel.py'), Path(__file__).with_name('intervals.py'))}
    if root:
        frozen[str(Path(__file__).with_name('geomean.py'))] = digest(Path(__file__).with_name('geomean.py'))
    counts, by_function = Counter(), {}
    rows = [json.loads(line) for line in Path(input_path).read_text().splitlines()]
    require(rows, 'empty raw-moment scope')
    with (dest/'closures.jsonl').open('x') as out:
        for row in rows:
            result = raw_moment_close(row, fused, root)
            out.write(json.dumps(result)+'\n')
            out.flush()
            function = by_function.setdefault(row['function'], Counter())
            counts['observations'] += 1
            function['observations'] += 1
            for form, values in enumerate(result['forms']):
                counts['form_'+str(form)+'_unreachable'] += not values['reachable']
                function['form_'+str(form)+'_unreachable'] += not values['reachable']
                counts['root_values'] += values['root_count']
    require(frozen == {p: digest(p) for p in frozen}, 'raw-moment source/input changed')
    summary = dict(complete=True, fused=fused, counts=counts, by_function=by_function,
        seconds=time.monotonic()-start, input_sha256=frozen,
        forms=['(Q-S*S/n)/d', '(n*Q-S*S)/(n*d)', 'Q/d-S*S/(n*d)', 'Q/d-(S/n)*(S/d)', '(Q/n-(S/n)^2)*(n/d)', 'sum_pairs((xi-xj)^2)/(n*d)']
            + (['FMA(-S/n,S,Q)/d', 'FMA(n,Q,-S*S)/(n*d)', 'FMA(-S,S,n*Q)/(n*d)', 'FMA(-S/n,S/n,Q/n)*(n/d)'] if fused else []),
        limits='Three numeric inputs; '+('ten forms including FMA' if fused else 'six identities')
            +'; all sum trees/permutations and independent five-model arithmetic choices at every site. '
            + ('Q permits every ordinary square-sum tree and any fusion of a leaf square with its sibling sum, including mixed fused/ordinary trees. ' if fused else '')
            + 'Other fusion placements are outside the declared forms. Shared-sum correlations are discarded where documented, enlarging the sets. Root digests are checked by complete independent regeneration. Reachability supplies no reusable program, fitted value, product gain or tolerance claim.')
    if root:
        summary.update(root_output=True, arity=4,
            forms=[form for i,form in enumerate(summary['forms']) if i != 5],
            limits='Four numeric inputs, nine declared uncentered/mixed-FMA variance forms, followed by a correctly rounded real square root directly to binary64 or via extended64/extended53 then binary64. '
                   'Every sum tree/permutation and five-model arithmetic site choice is covered; Q allows leaf-square/sibling-sum FMA, including mixed trees. '
                   'Six-term pairwise-difference sums, other fusion placements, arities and native approximations are outside this family. '
                   'Root-state counts are local variance states before sqrt, not programs or product matches. No fitting or tolerance pass.')
    (dest/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps(summary))


def raw_moment_scope(input_path, destination, root=False):
    """Select canonical bank rows for the existing three-input closure."""
    dest = Path(destination)
    dest.mkdir()
    frozen = {str(p): digest(p) for p in (Path(input_path), Path(__file__),
        Path(__file__).with_name('intervals.py'))}
    counts, selected = Counter(), []
    def flat(value):
        return [leaf for child in value for leaf in flat(child)] if isinstance(value, list) else [value]
    with Path(input_path).open() as source, (dest/'cases.jsonl').open('x') as out, (dest/'excluded.jsonl').open('x') as excluded:
        for index, line in enumerate(source):
            raw = json.loads(line)
            reason = None
            values = flat(raw['args'])
            names = ('STDEV','STDEV.S','STDEV.P','STDEVP','STDEVA','STDEVPA') if root else ('VAR','VAR.S','VAR.P','VARP','VARA','VARPA')
            if raw['function'] not in names:
                reason = 'other_function'
            elif root and raw.get('result_index') is not None:
                reason = 'selected_result'
            elif len(values) != (4 if root else 3):
                reason = 'other_input_count'
            elif not all(isinstance(v, str) and v.startswith('0x') and len(v) == 18 for v in values):
                reason = 'non_numeric_input'
            elif not isinstance(raw['expected'], str) or not raw['expected'].startswith('0x'):
                reason = 'non_numeric_expected'
            else:
                try:
                    xs = [Q(number(v)) for v in values]
                    expected = Q(number(raw['expected']))
                    if not all(x == 0 or pow2(-100) <= abs(x) <= pow2(100) for x in xs):
                        reason = 'outside_magnitude_scope'
                    elif root and expected <= 0:
                        reason = 'nonpositive_root_target'
                except (ValueError, OverflowError):
                    reason = 'non_finite_value'
            if reason is None and root and counts['selected:'+raw['function']] >= 32:
                reason = 'after_first_32_eligible_per_function'
            if reason:
                counts[reason] += 1
                excluded.write(json.dumps(dict(trace_index=index, reason=reason))+'\n')
            else:
                counts['selected:'+raw['function']] += 1
                selected.append(index)
                out.write(json.dumps(raw)+'\n')
    require(selected and frozen == {p: digest(p) for p in frozen}, 'empty or changed raw-moment selection')
    summary = dict(complete=True, counts=counts, selected_indices=selected, input_sha256=frozen,
        output_sha256={p.name:digest(p) for p in dest.iterdir()},
        limits='Only original decoded observations are selected; all omitted indices and reasons are retained. '
               'Original arguments, shapes, metadata and answers are unchanged. This scope is not a bank score or new capture.')
    if root:
        summary['limits'] += ' STDEV scope keeps the first32 eligible rows per function in original input order; all remaining indices are explicitly outside this bounded experiment.'
    (dest/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps(dict(complete=True, counts=counts)))


def paired_cohorts(rows):
    """Pair scalar readings by exact operands and recorded operating context.

    Per-function source/capture time differs. Equal context is not a claim that
    these calls shared an actual Excel intermediate or were simultaneous.
    """
    names = ('DEVSQ', 'VAR.S', 'VAR.P', 'STDEV.S', 'STDEV.P')
    grouped = {}
    omitted = []
    for index, row in enumerate(rows):
        if row['function'] not in names:
            omitted.append(dict(index=index, reason='other_function'))
            continue
        args = row['args']
        require(row.get('result_index') is None and len(args) >= 2 and
                all(isinstance(x, str) and x.startswith('0x') for x in args),
                'paired scalar numeric input scope')
        require(all(pow2(-100) <= abs(Q(number(x))) <= pow2(100) or number(x) == 0 for x in args),
                'paired input magnitude scope')
        require(isinstance(row['expected'], str) and row['expected'].startswith('0x') and
                pow2(-100) <= Q(number(row['expected'])) <= pow2(100), 'positive normal paired target scope')
        provenance = row.get('capture_provenance', {})
        context = dict(args=args, reading=row['reading'], transport=row.get('input_transport'),
                       environment=provenance.get('environment'), settings=provenance.get('calculation_settings'))
        key = json.dumps(context, sort_keys=True, separators=(',', ':'))
        group = grouped.setdefault(key, dict(context=context, indices={}))
        require(row['function'] not in group['indices'], 'duplicate paired function/context')
        group['indices'][row['function']] = index
    cohorts = []
    for group in grouped.values():
        if set(group['indices']) == set(names):
            cohorts.append(group)
        else:
            omitted.extend(dict(index=i, reason='incomplete_context_cohort') for i in group['indices'].values())
    require(cohorts, 'empty paired scope')
    return cohorts, sorted(omitted, key=lambda r: r['index'])


def published_points(bits):
    """Every Ext64 point in a binary64 publication cell, including tie flags."""
    target = Q(number(bits))
    require(pow2(-100) <= target <= pow2(100), 'paired publication magnitude scope')
    span = B64.preimage(Interval(target, target))
    point = E64.ceil(span.lo)
    if point == span.lo and not span.lc:
        point = E64.next(point)
    values = []
    while span.contains(point):
        values.append(point)
        point = E64.next(point)
    require(values and len(values) <= 4097, 'paired publication lattice bound')
    return values


def paired_result(rows):
    """Necessary consumer tests; arbitrary latent values are never producers."""
    import hashlib
    cohorts, omitted = paired_cohorts(rows)
    q_survivors = set(itertools.product(range(5), repeat=2))
    sigma_survivors = {name: set(range(5)) for name in ('sample', 'population')}
    details = []
    def mask_record(indices, points):
        values = [points[i] for i in sorted(indices)]
        payload = json.dumps(encode(values), separators=(',', ':')).encode()
        return dict(count=len(values), sha256=hashlib.sha256(payload).hexdigest(),
                    first=pair(values[0]) if values else None, last=pair(values[-1]) if values else None)
    for cohort in cohorts:
        selected = {name: rows[i] for name, i in cohort['indices'].items()}
        n = Q(len(cohort['context']['args']))
        q_points = published_points(selected['DEVSQ']['expected'])
        q_masks = {}
        sigma = {}
        for label, var, sd, divisor in (('sample', 'VAR.S', 'STDEV.S', n-1),
                                        ('population', 'VAR.P', 'STDEV.P', n)):
            target = Q(number(selected[var]['expected']))
            q_masks[label] = [{i for i, q in enumerate(q_points)
                              if B64.rn(operation('div', model, q, divisor)) == target} for model in MODELS]
            points = published_points(selected[sd]['expected'])
            masks = [{i for i, q in enumerate(points)
                      if B64.rn(operation('mul', model, q, q)) == target} for model in MODELS]
            sigma_survivors[label].intersection_update(i for i, mask in enumerate(masks) if mask)
            sigma[label] = dict(point_count=len(points), models=[mask_record(mask, points) for mask in masks])
        joint = [(a, b) for a, b in itertools.product(range(5), repeat=2)
                 if q_masks['sample'][a] & q_masks['population'][b]]
        q_survivors.intersection_update(joint)
        details.append(dict(cohort=cohort, q_point_count=len(q_points),
                            q_divisions={label:[mask_record(mask, q_points) for mask in masks]
                                         for label, masks in q_masks.items()},
                            q_joint_profiles=[list(p) for p in joint], sigma_square=sigma))
    return dict(models=list(MODELS), cohorts=details, omitted=omitted,
                shared_devsq_division_survivors=[list(p) for p in sorted(q_survivors)],
                separate_sigma_square_survivors={name: sorted(values) for name, values in sigma_survivors.items()})


def paired_run(input_path, destination):
    dest = Path(destination)
    dest.mkdir()
    dependencies = [Path(__file__), Path(__file__).with_name('bessel.py'), Path(__file__).with_name('intervals.py')]
    frozen = {str(p): digest(p) for p in [Path(input_path), *dependencies]}
    rows = [json.loads(line) for line in Path(input_path).read_text().splitlines()]
    result = paired_result(rows)
    require(frozen == {p: digest(p) for p in frozen}, 'paired inputs/source changed')
    (dest/'proof.json').write_text(json.dumps(result, indent=2)+'\n')
    summary = dict(complete=True, input_sha256=frozen, proof_sha256=digest(dest/'proof.json'),
        observations=len(rows), cohorts=len(result['cohorts']), omitted=len(result['omitted']),
        shared_devsq_division_survivors=result['shared_devsq_division_survivors'],
        separate_sigma_square_survivors=result['separate_sigma_square_survivors'],
        limits='Discovery necessary-consumer conditions. Shared DEVSQ latent q, then sample/population division:25 fixed model pairs. '
               'Separate sample/population STDEV latent sigma, then squaring:5 fixed models per name. '
               'Every positive extended64 point in each recorded publication cell is enumerated, with open tie endpoints. '
               'Latent points may differ per cohort; no prefix producer, shared Excel intermediate, internal regime, held-out gain or product program is identified.')
    (dest/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps(summary))


def kurt_outer(checkout, output, cache, library, offline=False):
    """Separate KURT's outer arithmetic with exact zero/unit normalization."""
    import math,random,struct
    from fingerprint import CachedService,Native,Builder,load_service,bits,value,write
    from exact import BINARY64
    from x87 import decode
    rng=random.Random(0x33c047)
    def four_squares(total):
        if not total:return [0]*4
        for _ in range(1000):
            a=rng.randrange(math.isqrt(total)+1);left=total-a*a
            b=rng.randrange(math.isqrt(left)+1);left-=b*b
            for c in range(math.isqrt(left)+1):
                d=math.isqrt(left-c*c)
                if c*c+d*d==left:return [a,b,c,d]
        raise ValueError('bounded four-square input construction exhausted')
    cases=[];seen=set()
    for n in range(5,32,2):
        k=(n-1)//2
        for depth in range(9):
            scale=1<<depth
            for _ in range(8):
                if k<4:integers=[scale]*k
                else:
                    remaining=k*scale*scale;integers=[]
                    for j in range(k-4):
                        a=rng.randrange(math.isqrt(remaining//(k-j))+1)
                        integers.append(a);remaining-=a*a
                    integers+=four_squares(remaining)
                positive=sorted(Q(a,scale)for a in integers)
                values=[-x for x in positive]+[Q(0)]+positive
                identity=tuple(values)
                if identity in seen:continue
                seen.add(identity)
                require(sum(values)==0 and sum(x*x for x in values)==n-1,'invalid zero/unit normalization')
                fourth=sum(x**4 for x in values)
                require(BINARY64.round(fourth)==fourth,'fourth moment must be exact')
                for power in (1,2,4):
                    partial=Q(0)
                    for x in values:
                        term=x**power
                        require(BINARY64.round(term)==term,'term must be exact')
                        partial+=term
                        require(BINARY64.round(partial)==partial,'partial sum must be exact')
                cases.append(dict(n=n,depth=depth,args=[bits(float(x))for x in values],fourth=bits(float(fourth))))
    # A small independent scale/order check stays inside the same exact
    # normalization premise; it is not a new arithmetic family.
    for case in cases[::max(1,len(cases)//16)]:
        for exponent in (-100,100):
            values=[math.ldexp(value(x),exponent)for x in reversed(case['args'])]
            cases.append(dict(case,n=case['n'],args=[bits(x)for x in values],normalizer_scale=exponent))
    def family(n):
        result={}
        for name in ('numerator_first','coefficient_first','common_denominator','factorized','population_excess'):
            g=Builder(1)
            c=lambda x:g.constant(bits(float(x)))
            op=lambda kind,a,b:g.op(kind,a,b)
            d2=(n-2)*(n-3);d3=(n-1)*d2
            correction=lambda:op('div',c(3*(n-1)**2),c(d2))
            if name=='numerator_first':
                left=op('div',op('mul',c(n*(n+1)),0),c(d3));right=correction()
                out=g.op('sub',left,right,store=False)
            elif name=='coefficient_first':
                left=op('mul',op('div',c(n*(n+1)),c(d3)),0);right=correction()
                out=g.op('sub',left,right,store=False)
            elif name=='common_denominator':
                top=op('sub',op('mul',c(n*(n+1)),0),c(3*(n-1)**3))
                out=g.op('div',top,c(d3),store=False)
            elif name=='factorized':
                factor=op('mul',op('div',c(n),c(n-1)),op('div',c(n+1),c(n-2)))
                factor=op('div',factor,c(n-3));left=op('mul',factor,0)
                right=op('mul',op('div',c(3*(n-1)),c(n-2)),op('div',c(n-1),c(n-3)))
                out=g.op('sub',left,right,store=False)
            else:
                excess=op('sub',op('div',op('mul',c(n),0),c((n-1)**2)),c(3))
                inside=op('add',op('mul',c(n+1),excess),c(6))
                factor=op('div',c(n-1),c(d2))
                out=g.op('mul',factor,inside,store=False)
            result[name]=g.graph(out,out)
        return result
    graphs={n:family(n)for n in range(5,32,2)}
    native=Native(library);client,_=load_service(checkout)
    service=CachedService(client.Client(timeout=300),cache,offline)
    dependencies=[Path(__file__),Path(__file__).with_name('fingerprint.py'),Path(__file__).with_name('x87_programs.py'),
                  Path(__file__).with_name('x87_native.c'),Path(library),Path(checkout)/'crates/calc-func/src/ported/moment_stats_family.rs']
    frozen={str(p.resolve()):digest(p)for p in dependencies}
    snapshots=Path(output).resolve().parent/'producers';snapshots.mkdir(exist_ok=True)
    for p,h in frozen.items():
        dest=snapshots/(h+'-'+Path(p).name)
        if not dest.exists():dest.write_bytes(Path(p).read_bytes())
    write(str(output)+'.questions.json',dict(format='dnacalc-kurt-outer-questions/1',complete=True,cases=cases,
        graphs=graphs,source_bindings=frozen,
        selection='Fixed dyadic square decompositions, exactly zero sum and sum of squares n-1. '
                  'All fourth powers and their sum are exact. Five elementary outer identities, '
                  'all PC64 store masks and one strict profile each, fixed before Excel answers.'))
    questions=[[client.number(x)for x in r['args']]for r in cases]
    averages=service.ask('AVERAGE',questions)['rows']
    deviations=service.ask('STDEV.S',questions)['rows']
    answers=service.ask('KURT',questions)['rows']
    counts=Counter();programs={};records=[];matrix=hashlib.sha256()
    calls=Path(str(output)+'.calls.jsonl').open('x')
    try:
        for index,(case,avg,std,answer)in enumerate(zip(cases,averages,deviations,answers)):
            scale=case.get('normalizer_scale',0)
            require(avg.get('type')=='number'and value(avg['bits'])==0.,'public average contradicts exact zero')
            require(std.get('type')=='number'and std['bits']==bits(math.ldexp(1.,scale)),'public deviation contradicts exact scale')
            require(answer.get('type')=='number','finite kurtosis control required')
            n=case['n'];matching=[];strict=None
            for name,graph in graphs[n].items():
                returned=native.masks(graph,[int(case['fourth'],16)],0x133f)
                predictions=[f'{native.publish(returned[20*i:20*i+10]):016x}'for i in range(1<<graph['sites'])]
                direct=f'{native.publish(native.evaluate(graph,[int(case["fourth"],16)],0x123f)[:10],0x123f):016x}'
                if name=='numerator_first':strict=direct
                for label,prediction in [(name+'/strict',direct),*[(name+'/pc64/'+str(i),p)for i,p in enumerate(predictions)]]:
                    matrix.update(bytes.fromhex(prediction))
                    p=programs.setdefault(label,dict(rows=0,matched=0,first_contradiction=None))
                    p['rows']+=1;p['matched']+=prediction==answer['bits']
                    if prediction==answer['bits']:matching.append(label)
                    elif p['first_contradiction']is None:p['first_contradiction']=dict(index=index,n=n,fourth=case['fourth'],prediction=prediction,answer=answer)
            counts['rows']+=1;counts['no_program_matches']+=not matching
            records.append(dict(case,average=avg,deviation=std,answer=answer,matching_programs=matching,strict_baseline= strict))
            calls.write(json.dumps(dict(id='kurt-outer-'+str(index),function='KURT',args=['0x'+x for x in case['args']],
                                       numeric_cell_inputs=True,actual='0x'+strict))+'\n')
    finally:calls.close()
    result=dict(format='dnacalc-kurt-outer/1',complete=True,counts=counts,programs=programs,records=records,
        prediction_matrix_sha256=matrix.hexdigest(),receipts=service.receipts,source_bindings=frozen,
        questions_sha256=digest(str(output)+'.questions.json'),calls_sha256=digest(str(output)+'.calls.jsonl'),
        limits='Exact normalized controls isolate the declared outer formulas under simple mean/variance '
               'programs; public AVERAGE and STDEV.S are independently confirmed. These are discoveries, '
               'not a complete KURT prefix or permission to select a formula by partial score. '
               'Scale/order controls may reuse the same mathematical moment and are not independent algorithms.')
    write(output,result)
    print(json.dumps(dict(counts=counts,complete_programs=[k for k,p in programs.items()if p['matched']==p['rows']])),flush=True)
    return result


if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='kurt-outer':
        args=sys.argv[2:];offline=bool(args and args[-1]=='--offline')
        if offline:args=args[:-1]
        kurt_outer(*args,offline=offline);raise SystemExit(0)
    if len(sys.argv)>1 and sys.argv[1]=='paired':paired_run(*sys.argv[2:]);raise SystemExit(0)
    if len(sys.argv)>1 and sys.argv[1]=='raw-moment-scope-stdev4':raw_moment_scope(*sys.argv[2:], root=True);raise SystemExit(0)
    if len(sys.argv)>1 and sys.argv[1]=='raw-moments-stdev4':raw_moment_run(*sys.argv[2:], fused=True, root=True);raise SystemExit(0)
    if len(sys.argv)>1 and sys.argv[1]=='raw-moment-scope':raw_moment_scope(*sys.argv[2:]);raise SystemExit(0)
    if len(sys.argv)>1 and sys.argv[1]=='raw-moments-fma':raw_moment_run(*sys.argv[2:], fused=True);raise SystemExit(0)
    if len(sys.argv)>1 and sys.argv[1]=='raw-moments':raw_moment_run(*sys.argv[2:]);raise SystemExit(0)
    if len(sys.argv)>1 and sys.argv[1]=='online':online_run(*sys.argv[2:])
    else:run(*sys.argv[1:])
