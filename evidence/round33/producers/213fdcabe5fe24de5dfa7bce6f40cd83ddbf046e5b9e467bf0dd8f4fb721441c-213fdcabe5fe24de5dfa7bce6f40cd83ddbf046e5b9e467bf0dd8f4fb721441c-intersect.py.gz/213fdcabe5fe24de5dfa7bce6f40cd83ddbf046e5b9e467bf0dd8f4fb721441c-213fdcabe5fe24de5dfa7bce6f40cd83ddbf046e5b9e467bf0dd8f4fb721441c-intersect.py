"""Exact shared-rate/nper expm1 constraints for the R7 FV=0 grammar.

Catalogues describe research programs, never answers. Raw Excel witnesses come
only from the existing loader's frozen trace. Environment remains part of keys.
"""
from fractions import Fraction as Q
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import argparse
import collections
import hashlib
import json
import sys
import time
from functools import lru_cache
from intervals import B64, E64, E53, Interval, inverse_op, inverse_add, number, stored

MODELS = dict(strict=0, stored_pc64=1, resident_pc64=2, stored_pc53=3, resident_pc53=4)


@lru_cache(maxsize=65536)
def closed_due_factor(expression, rate, timing):
    return const_value(expression,(None,rate,None,None,timing,Q(1),Q(-1)))


@lru_cache(maxsize=65536)
def due_preimage(target,pv,factor,quotient_model,final_model):
    interval=B64.preimage(Interval(target,target))
    interval=inverse_op(interval,final_model,'mul',factor,True)
    return inverse_op(interval,quotient_model,'div',pv,False)


def rnd(x, model):
    if model==0:return B64.rn(x)
    if model==1:return stored(x)
    if model==2:return E64.rn(x)
    if model==3:
        y=E53.rn(x)
        return B64.rn(y)if y is not None else None
    assert model==4
    return E53.rn(x)


def compile_expr(expr, models, site):
    if 'leaf' in expr:
        return expr['leaf'], site
    op = next(iter(expr))
    a, site = compile_expr(expr[op][0], models, site)
    b, site = compile_expr(expr[op][1], models, site)
    return (op, a, b, models[site]), site + 1


def has_em(expr):
    return expr == 2 if isinstance(expr, int) else has_em(expr[1]) or has_em(expr[2])


def const_value(expr, args):
    if isinstance(expr, int):
        assert expr != 2
        return args[expr]
    op, a, b, model = expr
    a, b = const_value(a, args), const_value(b, args)
    if model == 0:
        a, b = B64.rn(a), B64.rn(b)
    if a is None or b is None or (op == 'div' and b == 0):
        raise ArithmeticError('nonfinite/zero constant subtree')
    if op == 'mul': value=a*b
    elif op == 'div': value=a/b
    elif op == 'add': value=a+b
    else: raise ArithmeticError('unknown closed expression operation')
    result = rnd(value, model)
    if result is None:
        raise ArithmeticError('nonfinite constant subtree')
    return result


def inverse_expr(expr, args, interval):
    if interval is None:
        return None
    if isinstance(expr, int):
        assert expr == 2
        return interval
    op, a, b, model = expr
    left = has_em(a)
    assert left != has_em(b), 'exactly one occurrence of em'
    c = const_value(b if left else a, args)
    interval = inverse_op(interval, model, op, c, left)
    return inverse_expr(a if left else b, args, interval)


def row_preimage(row, profile):
    c, expr, models = profile
    if c.get('family') == 'shared_interest':
        return interest_preimage(row, models, c)
    if c.get('family') in ('timing_complement','annuity_factor','due_rate_factor'):
        rate,pv,_,timing,_=[Q(number(f'{b:016x}')) for b in row['leaves']]
        encoded=row['raw']['expected']
        if not encoded.startswith('0x'):
            raise ArithmeticError('nonnumeric target outside helper projection')
        value=number(encoded)
        if value==0 or not(-float('inf')<value<float('inf'))or not pv:
            raise ArithmeticError('zero/nonfinite target or balance outside helper projection')
        target=Q(value)
        if c.get('family')=='due_rate_factor':
            factor=closed_due_factor(expr[2],rate,timing)
            return due_preimage(target,pv,factor,expr[1][3],expr[3])
        interval=B64.preimage(Interval(target,target))
        return inverse_expr(expr,[pv,rate,None,None,timing,Q(1),Q(-1)],interval)
    rate, pv, _, timing, _ = [Q(number(f'{b:016x}')) for b in row['leaves']]
    tf = rnd(1 + rate*timing, models[0])
    target = row['raw']['expected']
    if not target.startswith('0x'):
        raise ArithmeticError('nonnumeric expected outcome')
    value = number(target)
    if value == 0 or not (-float('inf') < value < float('inf')):
        raise ArithmeticError('nonfinite/zero target')
    if pv == 0 or tf is None or tf == 0:
        raise ArithmeticError('zero/nonfinite constant')
    target = B64.preimage(Interval(Q(value), Q(value)))
    return inverse_expr(expr, [pv, rate, None, tf], target)


def interest_preimage(row, models, programme=None):
    """I=PV*rate; A=I/em; output=-(I+A)/tf, one shared unknown em."""
    rate,pv,_,timing,_=[Q(number(f'{b:016x}'))for b in row['leaves']]
    target=row['raw']['expected']
    if not target.startswith('0x'):
        raise ArithmeticError('nonnumeric interest target')
    value=number(target)
    if value==0 or not(-float('inf')<value<float('inf')):
        raise ArithmeticError('nonfinite/zero interest target')
    programme=programme or {}
    interest=rnd(pv*rate,models[0])
    tf=rnd(1+rate*timing,models[1])
    needs_interest=programme.get('sum_kind')!='fma' or programme.get('amortization_numerator')!='pv'
    if (needs_interest and (interest is None or interest==0)) or tf is None or tf==0 or pv==0:
        raise ArithmeticError('zero/nonfinite interest constant')
    # Final publication is always RN53, including resident final division.
    interval=B64.preimage(Interval(Q(-value),Q(-value)))
    interval=inverse_op(interval,models[4],'div',tf,True)
    if programme.get('sum_kind')=='fma':
        # IEEE binary64 fma(PV,rate,A): exact product/add, one RN53;
        # the A operand is explicitly stored to binary64 before the FMA.
        interval=B64.preimage(interval) if interval else None
        interval=interval.affine(Q(1),-pv*rate) if interval else None
        interval=B64.preimage(interval) if interval else None
    else:
        interval=inverse_add(interval,models[3],interest)
    if interval is None:
        return None
    constant=pv if programme.get('amortization_numerator')=='pv'else interest
    return inverse_op(interval,models[2],programme.get('amortization_operation','div'),constant,False)


def key(row):
    raw = row['raw']
    return (row['leaves'][0], raw['args'][1], json.dumps(raw['reading'], sort_keys=True))


def timing_complement_expr(models):
    """(PV/em)*(1-(r*timing)/(1+r*timing))*r, with six declared stores.

    Canonical timing multiplication is exact; negation stays resident, so
    neither is an additional rounded site. Leaf2 is the sole unknown helper.
    """
    tf,ratio,complement,quotient,product,final=models
    rt=('mul',1,4,2)
    factor=('add',5,('mul',6,('div',rt,('add',5,rt,tf),ratio),2),complement)
    return ('mul',('mul',('div',0,2,quotient),factor,product),1,final)


def due_rate_expr(form, models):
    """PV/em times an ordinary rearrangement of r/(1+r*timing).

    The helper occurs once. All constants are exact 0,1,-1 and canonical
    timing. These identities change intermediate stores, not mathematics.
    """
    rt=('mul',1,4,2)
    negative=lambda expr:('mul',6,expr,2)
    if form==0:
        tf,product,ratio,difference,quotient,final=models
        correction=('div',('mul',1,rt,product),('add',5,rt,tf),ratio)
        factor=('add',1,negative(correction),difference)
    elif form==1:
        tf,ratio,complement,product,quotient,final=models
        ratio_expr=('div',rt,('add',5,rt,tf),ratio)
        factor=('mul',1,('add',5,negative(ratio_expr),complement),product)
    else:
        assert form==2
        reciprocal,timing,coefficient,quotient,final=models
        factor=('div',5,('add',('div',5,1,reciprocal),4,timing),coefficient)
    return ('mul',('div',0,2,quotient),factor,final)


ROWS = None
PROFILES = None


def process(item):
    gid, ids = item
    records = []
    counts = collections.Counter()
    for profile in PROFILES:
        c = profile[0]
        current = None
        lower_id = upper_id = None
        unsupported = 0
        visited = 0
        contradiction = None
        for idx in ids:
            row = ROWS[idx]
            try:
                preimage = row_preimage(row, profile)
            except (ArithmeticError, AssertionError) as e:
                unsupported += 1
                counts['unsupported_row_profile_constraints'] += 1
                continue
            visited += 1
            if preimage is None:
                contradiction = dict(new_row=idx, previous_interval=None,
                                     new_preimage=None, bound_rows=[])
                current = None
                break
            if current is None:
                current = preimage
                lower_id = upper_id = idx
                continue
            new = current.intersect(preimage)
            if new is None:
                contradiction = dict(new_row=idx, previous_interval=current.json(),
                                     new_preimage=preimage.json(),
                                     bound_rows=sorted(set([lower_id, upper_id])))
                current = None
                break
            if new.lo != current.lo or new.lc != current.lc:
                lower_id = idx
            if new.hi != current.hi or new.hc != current.hc:
                upper_id = idx
            current = new
        status = 'empty' if contradiction else 'nonempty' if current is not None else 'unsupported'
        counts[status + '_group_profiles'] += 1
        b64 = current is not None and B64.preimage(current) is not None
        e64 = current is not None and E64.preimage(current) is not None
        counts['group_profiles_with_binary64_em'] += b64
        counts['group_profiles_with_ext80_em'] += e64
        records.append(dict(group=gid, combine=c['id'], constraints_visited=visited,
                            unsupported_constraints=unsupported, status=status,
                            interval=current.json() if current is not None else None,
                            binary64_value_exists=b64, ext80_value_exists=e64,
                            bound_rows=sorted(set([lower_id,upper_id])) if current else [],
                            first_empty=contradiction))
    return gid, records, dict(counts)


def main():
    global ROWS, PROFILES
    parser = argparse.ArgumentParser()
    parser.add_argument('input')
    parser.add_argument('catalogue')
    parser.add_argument('output')
    parser.add_argument('--profiles', choices=['baseline', 'all', 'uniform'], default='all')
    parser.add_argument('--groups', choices=['all', 'discovery'], default='discovery')
    parser.add_argument('--group-limit', type=int, default=32)
    parser.add_argument('--workers', type=int, default=8)
    a = parser.parse_args()
    start = time.monotonic()
    # Original complete records stay in the frozen input. Fork only fields
    # needed by rational arithmetic; this keeps the eight-worker budget small.
    ROWS = []
    environments = {}
    with open(a.input)as source:
        for line in source:
            r = json.loads(line)
            if number(f'{r["leaves"][2]:016x}') != 0:
                continue
            raw = r['raw']
            env = json.dumps(raw['reading'], sort_keys=True)
            environment = environments.setdefault(env, raw['reading'])
            ROWS.append(dict(leaves=r['leaves'], trace_index=r['trace_index'],
                raw=dict(args=[None, raw['args'][1]], expected=raw['expected'], reading=environment)))
    groups = collections.defaultdict(list)
    for idx, r in enumerate(ROWS):
        groups[key(r)].append(idx)
    group_list = list(groups.values())
    if a.groups == 'discovery':
        group_list = group_list[:a.group_limit]
    cat = Path(a.catalogue)
    expressions = json.loads((cat/'expressions.json').read_text())
    combines = json.loads((cat/'combines.json').read_text())
    if a.profiles == 'baseline':
        combines = [c for c in combines if c['id'] == 36]
    if a.profiles == 'uniform':
        combines = [c for c in combines if len(set(c['models'])) == 1]
    PROFILES = []
    for c in combines:
        models = [MODELS[m] for m in c['models']]
        expr, site = compile_expr(expressions[c['expression']], models, 1)
        assert site == 4
        PROFILES.append((c, expr, models))
    out = Path(a.output)
    out.mkdir(parents=True, exist_ok=True)
    with (out/'groups.jsonl').open('x') as f:
        for gid, ids in enumerate(group_list):
            r = ROWS[ids[0]]
            f.write(json.dumps(dict(group=gid, rate=f'0x{r["leaves"][0]:016x}',
                nper=r['raw']['args'][1], environment=r['raw']['reading'], rows=ids,
                trace_indices=[ROWS[i]['trace_index'] for i in ids]))+'\n')
    total = collections.Counter()
    completed = 0
    with (out/'intersections.jsonl').open('x') as f, ProcessPoolExecutor(a.workers) as executor:
        for start_group in range(0, len(group_list), 2*a.workers):
            # Bound submitted/result groups; one slow group cannot accumulate
            # the results of the rest of the entire evidence bank in memory.
            batch = list(enumerate(group_list))[start_group:start_group+2*a.workers]
            for gid, records, counts in executor.map(process, batch, chunksize=1):
                for r in records:
                    f.write(json.dumps(r,separators=(',',':'))+'\n')
                total.update(counts)
                completed += 1
            f.flush()
            checkpoint = dict(groups_done=completed, total_groups=len(group_list),
                              counts=total, seconds=time.monotonic()-start)
            (out/'checkpoint.json').write_text(json.dumps(checkpoint, indent=2)+'\n')
            print(json.dumps(checkpoint), flush=True)
    result = dict(complete=True, group_selection=a.groups, groups=len(group_list),
        profiles=len(PROFILES), counts=total, seconds=time.monotonic()-start,
        arithmetic='exact rational preimages of every store/operation; endpoint parity included',
        scope='FV=0 finite discount; one common arbitrary em per rate/nper/environment and combine profile. Empty intersection rules out that shared helper/profile, not all programs.',
        unsupported_policy='unsupported constraints are counted and supply no conclusion; an empty intersection remains a contradiction of the supported subset',
        input_sha256=hashlib.sha256(Path(a.input).read_bytes()).hexdigest(),
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    with (out/'summary.json').open('x') as f:
        json.dump(result,f,indent=2)
    print(json.dumps(result))


if __name__ == '__main__':
    main()
