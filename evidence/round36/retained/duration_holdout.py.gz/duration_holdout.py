import sys,json,itertools,datetime as dt,random,struct,math
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc/tools/excel-service')
from client import Client,number
def bits(x):return struct.pack('>d',x).hex()
rng=random.Random(360319); cases=[]
for n,f,exponent in itertools.product((2,4,7,13,23,47), (1,2,4), (-40,-12,-1,0,12,40)):
    rate=math.ldexp(1.+rng.random(),exponent)
    months=2020*12+n*(12//f); year,month=divmod(months,12)
    maturity=(dt.date(year,month+1,1)-dt.date(1899,12,30)).days
    coupon=100.*rate/f; den=num=0.
    for k in range(1,n+1):
        den+=coupon;num+=k*coupon
    den+=100.;num+=n*100.
    cases.append(dict(settlement=43831,maturity=maturity,rate=rate,frequency=f,n=n,prediction=bits(num/den/f)))
rows=[[number(z['settlement']),number(z['maturity']),number(z['rate']),number(0.),number(z['frequency']),number(0.)] for z in cases]
c=Client(timeout=180)
with open('/home/ubuntu/codex-runs/round36/duration_holdout.jsonl','x') as out:
    for func in ('DURATION','MDURATION'):
        reply=c.ask(func,rows)
        out.write(json.dumps(dict(function=func,cases=cases,reply=reply),separators=(',',':'))+'\n');out.flush()
        failures=[(i,z,a) for i,(z,a) in enumerate(zip(cases,reply['rows'])) if a.get('bits')!=z['prediction']]
        print(func,'matches',len(cases)-len(failures),'/',len(cases),'first',failures[:1],flush=True)
