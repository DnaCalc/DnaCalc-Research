import sys,json,math
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc/tools/excel-service')
from client import Client,number
times=[-1.,-0.1,-1e-13,0.,1e-13,1e-10,.1,.5,.9,
       math.nextafter(1.,0.),1.,math.nextafter(1.,2.),1.+1e-13,1.1,1.9,2.]
rows=[[number(.01),number(12.),number(100.),number(2.),number(4.),number(t)] for t in times]
c=Client(timeout=180)
with open('/home/ubuntu/codex-runs/round36/cumulative_timing_qualified.jsonl','x') as out:
    for func in ('CUMPRINC','CUMIPMT'):
        reply=c.ask(func,rows)
        out.write(json.dumps(dict(function=func,times=times,reply=reply),separators=(',',':'))+'\n');out.flush()
        print(func,list(zip(times,reply['rows'])),flush=True)
