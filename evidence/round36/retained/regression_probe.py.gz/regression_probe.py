import sys, json, itertools
sys.path.insert(0, '/home/ubuntu/projects/DnaCalc/DnaCalc/tools/excel-service')
from client import Client, number_array, boolean

cases = []
for shift, scale, reverse, collinear, const in itertools.product(
        (0., 1., 10., 1024.), (1., 2.**-20, 2.**20),
        (False, True), (False, True), (False, True)):
    x = [shift + scale*t for t in (-3., -1., 1., 3.)]
    xs = [[v, 2*v] if collinear else [v] for v in x]
    y = [[t] for t in (1., -1., -1., 1.)]
    if reverse:
        xs.reverse()
        y.reverse()
    cases.append(dict(x=xs, y=y, constant=const, shift=shift, scale=scale,
                      reverse=reverse, collinear=collinear))

c = Client(timeout=180)
with open('/home/ubuntu/codex-runs/round36/regression.jsonl', 'x') as f:
    for collinear in (False, True):
        subset = [z for z in cases if z['collinear'] == collinear]
        rows = [[number_array(z['y']), number_array(z['x']),
                 boolean(z['constant']), boolean(True)] for z in subset]
        for selection in ((2, 3 if collinear else 2), (2, 1), (3, 2), (4, 2), (5, 2)):
            reply = c.ask('LINEST', rows, result_index=selection)
            f.write(json.dumps(dict(selection=selection, cases=subset, reply=reply),
                               separators=(',', ':'))+'\n')
            f.flush()
            print(collinear, selection, len(rows), reply['excel_build'], flush=True)
