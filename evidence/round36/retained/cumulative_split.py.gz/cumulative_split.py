import sys,gzip,json,struct
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc/tools/excel-service')
from client import Client,number
path='/home/ubuntu/projects/DnaCalc/DnaCalc-Research/evidence/round35/retained/cumulative-long-questions.json.gz'
source=json.load(gzip.open(path,'rt'))['rows']
cases=[]; inputs=[]
for row in source:
    a,b=row['start'],row['end']
    if a>=b:continue
    mid=(a+b)//2
    for lo,hi in ((a,b),(a,mid),(mid+1,b)):
        args=list(row['args']);args[3]=number(float(lo));args[4]=number(float(hi))
        inputs.append(args)
    cases.append(dict(loan=row['loan'],start=a,mid=mid,end=b))
c=Client(timeout=180)
with open('/home/ubuntu/codex-runs/round36/cumulative_split.jsonl','x') as out:
    for func in ('CUMPRINC','CUMIPMT'):
        reply=c.ask(func,inputs)
        out.write(json.dumps(dict(function=func,cases=cases,reply=reply),separators=(',',':'))+'\n')
        out.flush()
        matched=0
        for i in range(len(cases)):
            p,q,r=reply['rows'][3*i:3*i+3]
            if any(t['type']!='number' for t in (p,q,r)):continue
            f=lambda t:struct.unpack('>d',bytes.fromhex(t['bits']))[0]
            got=struct.pack('>d',f(q)+f(r)).hex()
            matched += got==p['bits']
        print(func,'split matches',matched,'of',len(cases),'build',reply['excel_build'],flush=True)
