import sys, json, itertools, datetime as dt
sys.path.insert(0, '/home/ubuntu/projects/DnaCalc/DnaCalc/tools/excel-service')
from client import Client, number

cases=[]
for frequency, n, rate in itertools.product((1, 2, 4), (2, 3, 5, 10, 19),
                                               (0., 2.**-40, .01, .1, .5, 1., 2., 5., 10., 2.**20)):
    months=2020*12+n*(12//frequency)
    year, month=divmod(months,12)
    maturity=(dt.date(year,month+1,1)-dt.date(1899,12,30)).days
    cases.append(dict(settlement=43831, maturity=maturity, rate=rate, frequency=frequency, n=n))
rows=[[number(z['settlement']), number(z['maturity']), number(z['rate']), number(0.),
       number(z['frequency']), number(0.)] for z in cases]
c=Client(timeout=180)
with open('/home/ubuntu/codex-runs/round36/duration_zero_yield.jsonl','x') as out:
    for function in ('DURATION','MDURATION'):
        reply=c.ask(function,rows)
        out.write(json.dumps(dict(function=function,cases=cases,reply=reply),separators=(',',':'))+'\n')
        out.flush()
        print(function,len(rows),reply['excel_build'],flush=True)
