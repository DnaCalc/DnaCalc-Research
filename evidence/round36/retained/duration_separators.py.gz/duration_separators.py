import sys,json,itertools,datetime as dt,random,struct,math
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc/tools/excel-service')
from client import Client,number
def bits(x): return struct.pack('>d',x).hex()
def programs(n,f,rate):
    out=[]
    for order,redemption,numerator in itertools.product(('forward','reverse'),('first','last'),('weighted','accumulated')):
        coupon=100.*rate/f
        terms=list(range(1,n+1))
        if order=='reverse': terms.reverse()
        den=100. if redemption=='first' else 0.
        num=100.*n if redemption=='first' else 0.
        for k in terms:
            den+=coupon
            if numerator=='weighted': num+=k*coupon
            else:
                term=0.
                for _ in range(k): term+=coupon
                num+=term
        if redemption=='last': den+=100.; num+=100.*n
        out.append(bits((num/den)/f))
    return out
rng=random.Random(3602); cases=[]
for n,f in itertools.product((2,3,5,10,19,31), (1,2,4)):
    found=0
    for _ in range(20000):
        rate=math.ldexp(1.+rng.random(),rng.randint(-16,12))
        predictions=programs(n,f,rate)
        if len(set(predictions))<3: continue
        months=2020*12+n*(12//f); year,month=divmod(months,12)
        maturity=(dt.date(year,month+1,1)-dt.date(1899,12,30)).days
        cases.append(dict(settlement=43831,maturity=maturity,rate=rate,frequency=f,n=n,predictions=predictions))
        found+=1
        if found==6:break
rows=[[number(z['settlement']),number(z['maturity']),number(z['rate']),number(0.),number(z['frequency']),number(0.)] for z in cases]
reply=Client(timeout=180).ask('DURATION',rows)
with open('/home/ubuntu/codex-runs/round36/duration_separators.json','x') as out:
    json.dump(dict(cases=cases,reply=reply),out,separators=(',',':'))
print('cases',len(cases),'build',reply['excel_build'])
for i in range(8):
    failures=[(j,z,a) for j,(z,a) in enumerate(zip(cases,reply['rows'])) if a.get('bits')!=z['predictions'][i]]
    print(i,'matched',len(cases)-len(failures),'first',failures[0] if failures else None)
