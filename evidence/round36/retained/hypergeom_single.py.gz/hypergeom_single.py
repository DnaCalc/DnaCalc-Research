import sys,json,itertools,struct
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc/tools/excel-service')
from client import Client,number,boolean
cases=[]
for total in (3,7,11,17,31,127,1023,1000003):
    for count in sorted(set((1,2,total//3,total//2,total-2,total-1))):
        if not 0<count<total:continue
        for success in (0,1):
            cases.append(dict(total=total,count=count,success=success))
rows=[[number(z['success']),number(1.),number(z['count']),number(z['total']),boolean(False)] for z in cases]
reply=Client(timeout=180).ask('HYPGEOM.DIST',rows)
with open('/home/ubuntu/codex-runs/round36/hypergeom_single.json','x') as out:
    json.dump(dict(cases=cases,reply=reply),out,separators=(',',':'))
def bits(v):return struct.pack('>d',v).hex()
matches=0;fails=[]
for z,a in zip(cases,reply['rows']):
    expected=(z['count'] if z['success'] else z['total']-z['count'])/z['total']
    if a.get('bits')==bits(expected):matches+=1
    else:fails.append((z,a,bits(expected)))
print('matches',matches,'/',len(cases),'first mismatches',fails[:3],flush=True)
