import sys,json,itertools,struct
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc/tools/excel-service')
from client import Client,number,boolean
def step(x,k):
    u=struct.unpack('>Q',struct.pack('>d',x))[0]
    return struct.unpack('>d',struct.pack('>Q',u+k))[0]
cases=[dict(k=k,mean=step(center,offset),center=center,offset=offset)
       for k,center,offset in itertools.product((0,1,2,4,8,19),(0.7,1.1,2.,20.),(-2,-1,0,1,2))]
poisson=[[number(z['k']),number(z['mean']),boolean(True)] for z in cases]
chi=[[number(2*z['mean']),number(2*(z['k']+1))] for z in cases]
gamma=[[number(z['mean']),number(z['k']+1),number(1.),boolean(True)] for z in cases]
c=Client(timeout=180)
with open('/home/ubuntu/codex-runs/round36/poisson_pairs.jsonl','x') as out:
    for func,rows in (('POISSON.DIST',poisson),('CHISQ.DIST.RT',chi),('GAMMA.DIST',gamma)):
        reply=c.ask(func,rows)
        out.write(json.dumps(dict(function=func,cases=cases,reply=reply),separators=(',',':'))+'\n');out.flush()
        print(func,len(rows),reply['excel_build'],flush=True)
