import json, struct, itertools
rows=[json.loads(s) for s in open('/home/ubuntu/codex-runs/round36/duration_zero_yield.jsonl')]
def bits(x): return struct.pack('>d',x).hex()
programs=[]
for coupon_word, order, redemption, numerator in itertools.product(
        ('multiply_first','divide_first'),('forward','reverse'),('first','last'),('weighted','accumulated')):
    programs.append(dict(coupon_word=coupon_word,order=order,redemption=redemption,numerator=numerator,
                         matches=0,first_failure=None))
numeric=0; same=0
for i,z in enumerate(rows[0]['cases']):
    ans=rows[0]['reply']['rows'][i]; md=rows[1]['reply']['rows'][i]
    same += ans==md
    if ans['type']!='number': continue
    numeric+=1
    n,f,rate=z['n'],z['frequency'],z['rate']
    for p in programs:
        coupon=100.*rate/f if p['coupon_word']=='multiply_first' else 100.*(rate/f)
        terms=list(range(1,n+1))
        if p['order']=='reverse': terms.reverse()
        den=100. if p['redemption']=='first' else 0.
        num=100.*n if p['redemption']=='first' else 0.
        for k in terms:
            den+=coupon
            if p['numerator']=='weighted': num+=k*coupon
            else:
                term=0.
                for _ in range(k): term+=coupon
                num+=term
        if p['redemption']=='last': den+=100.; num+=100.*n
        got=bits((num/den)/f)
        if got==ans['bits']: p['matches']+=1
        elif p['first_failure'] is None: p['first_failure']=dict(case=z,expected=ans['bits'],predicted=got)
print(json.dumps(dict(numeric=numeric,duration_equals_modified=same,programs=programs),indent=2))
