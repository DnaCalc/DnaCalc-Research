import json,math,struct,collections
records=[json.loads(s) for s in open('/home/ubuntu/codex-runs/round36/regression_edges.jsonl')]
def get(a):return struct.unpack('>d',bytes.fromhex(a['bits']))[0] if a['type']=='number' else None
def bits(a):return struct.pack('>d',a).hex()
for func in ('LINEST','LOGEST'):
    r={tuple(z['selection']):z for z in records if z['function']==func}
    counts=collections.Counter(); first={}
    for i,c in enumerate(r[(2,2)]['cases']):
        b,sx,sy,df,ss=[get(r[k]['reply']['rows'][i]) for k in ((2,2),(2,1),(3,2),(4,2),(5,2))]
        if any(x is None for x in (b,sx,sy,df,ss)) or df==0:counts['excluded']+=1;continue
        xs=[row[0] for row in c['x']];mean=sum(xs)/len(xs);xx=sum((x-mean)**2 for x in xs)
        if not xx:counts['excluded']+=1;continue
        v=1/len(xs)+mean*mean/xx
        candidates={'centered_ss':math.sqrt(ss/df*v), 'centered_sy':sy*math.sqrt(v),
                    'published_slope':math.sqrt((sy/math.sqrt(len(xs)))**2+(mean*sx)**2)}
        counts['eligible']+=1
        for name,prediction in candidates.items():
            if bits(prediction)==bits(b):counts[name]+=1
            elif name not in first:first[name]=dict(case=c,observed=bits(b),prediction=bits(prediction))
    print(func,dict(counts),json.dumps(first))
