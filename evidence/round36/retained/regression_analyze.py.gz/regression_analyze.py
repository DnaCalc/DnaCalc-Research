import json, math, struct, collections

records = [json.loads(s) for s in open('/home/ubuntu/codex-runs/round36/regression.jsonl')]
groups = {}
for r in records:
    col = len(r['cases'][0]['x'][0])
    groups[col, tuple(r['selection'])] = r

def value(answer):
    return struct.unpack('>d', bytes.fromhex(answer['bits']))[0] if answer['type'] == 'number' else None

def bits(x):
    return struct.pack('>d', x).hex()

for col in (1, 2):
    stat = groups[col, (2, col + 1)]
    sy = groups[col, (3, 2)]
    residual = groups[col, (5, 2)]
    df = groups[col, (4, 2)]
    counts = collections.Counter()
    failures = []
    for i, c in enumerate(stat['cases']):
        if not c['constant']:
            counts['false_intercept_'+stat['reply']['rows'][i]['type']] += 1
            continue
        b = value(stat['reply']['rows'][i]); s = value(sy['reply']['rows'][i])
        ss = value(residual['reply']['rows'][i]); d = value(df['reply']['rows'][i])
        x = [r[0] for r in c['x']]; n = len(x); mean = sum(x)/n
        xx = sum((v-mean)**2 for v in x)
        if xx == 0 or b is None or s is None or ss is None or not d:
            counts['excluded'] += 1
            continue
        v = 1/n + mean*mean/xx
        cand = {'centred_ss': math.sqrt(ss/d*v), 'centred_se': s*math.sqrt(v),
                'se_squares': math.sqrt(s*s/n + (s*mean/math.sqrt(xx))**2)}
        counts['eligible'] += 1
        for name, predicted in cand.items():
            counts[name] += bits(predicted) == bits(b)
        if not any(bits(z)==bits(b) for z in cand.values()):
            failures.append(dict(case=c, observed=bits(b), predictions={k:bits(v) for k,v in cand.items()}))
    print(col, dict(counts), 'no-candidate', len(failures))
    print(json.dumps(failures[:3]))
