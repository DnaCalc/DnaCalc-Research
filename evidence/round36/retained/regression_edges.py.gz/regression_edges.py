import sys, json, itertools, math, struct
sys.path.insert(0, '/home/ubuntu/projects/DnaCalc/DnaCalc/tools/excel-service')
from client import Client, number_array, boolean

def step(x, offset):
    u = struct.unpack('>Q', struct.pack('>d', x))[0]
    return struct.unpack('>d', struct.pack('>Q', u+offset))[0]

cases = []
for shift, offset, scale, reverse in itertools.product((1., 16., 1024.), (-2, -1, 0, 1, 2), (2.**-20, 1.), (False, True)):
    center = step(shift, offset)
    xs = [[center+scale*t] for t in (-3., -1., 1., 3.)]
    y = [[t] for t in (1., -1., -1., 1.)]
    logy = [[t] for t in (2., .5, .5, 2.)]
    if reverse:
        xs.reverse(); y.reverse(); logy.reverse()
    cases.append(dict(x=xs, y=y, logy=logy, shift=shift, offset=offset, scale=scale, reverse=reverse))

c = Client(timeout=180)
with open('/home/ubuntu/codex-runs/round36/regression_edges.jsonl', 'x') as f:
    for function in ('LINEST', 'LOGEST'):
        rows = [[number_array(z['logy' if function == 'LOGEST' else 'y']),
                 number_array(z['x']), boolean(True), boolean(True)] for z in cases]
        for selection in ((2,2), (2,1), (3,2), (4,2), (5,2)):
            reply = c.ask(function, rows, result_index=selection)
            f.write(json.dumps(dict(function=function, selection=selection, cases=cases, reply=reply), separators=(',', ':'))+'\n')
            f.flush()
            print(function, selection, len(rows), reply['excel_build'], flush=True)
