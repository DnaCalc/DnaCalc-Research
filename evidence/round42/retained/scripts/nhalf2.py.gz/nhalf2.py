"""Near-half two-rounding forms x = RN(RN(q*a) op b) for natural constants b; feasible set of a."""
import math, json, struct, sys
from fractions import Fraction as Fr
from nlib import load, f, bits
A, V, W = load()
pts = []
for i in [64, 65]:
    s0 = int(W[i]['start'], 16)
    for j in range(0, 8192, int(sys.argv[1])):
        if V[i, j]:
            p = f(s0 + j); q = p - 0.5
            if q > 0: pts.append((q, f(A[i, j])))
def ulp(x): return math.ulp(x)
def nb(x, k): return f(bits(x) + k)
def preimage_doubles(target, b, op):
    """doubles y with RN(y op b) == target (op '*' or '/'), positive values"""
    lo = Fr(target) - Fr(ulp(target)) / 2; hi = Fr(target) + Fr(ulp(target)) / 2
    # rounding ties-to-even: closed if target mantissa even
    even = bits(target) % 2 == 0
    if op == '*': ylo, yhi = lo / Fr(b), hi / Fr(b)
    else: ylo, yhi = lo * Fr(b), hi * Fr(b)
    y = float(ylo); ys = []
    for k in range(-2, 4):
        c = nb(y, k)
        v = Fr(c) * Fr(b) if op == '*' else Fr(c) / Fr(b)
        if (lo < v < hi) or (even and (v == lo or v == hi)): ys.append(c)
    return sorted(set(ys))
def a_interval(y, q):
    """a with RN(q*a) == y: open/closed interval approx (treat closed)"""
    lo = (Fr(y) - Fr(ulp(y)) / 2) / Fr(q); hi = (Fr(y) + Fr(ulp(y)) / 2) / Fr(q)
    return (lo, hi)
consts = {'sqrt2pi': math.sqrt(2 * math.pi), 'sqrt2': math.sqrt(2.0), 'inv_sqrt2pi': 1 / math.sqrt(2 * math.pi), 'inv_sqrt2': 1 / math.sqrt(2.0),
          'pi': math.pi, 'two_pi': 2 * math.pi, 'sqrt_pi': math.sqrt(math.pi), 'sqrt_pi_over2': math.sqrt(math.pi / 2), 'sqrt_2_over_pi': math.sqrt(2 / math.pi)}
for name, c in consts.items():
    for k in [-1, 0, 1]:
        b = nb(c, k)
        for op in ['*', '/']:
            feas = None; fail_at = None
            for idx, (q, x) in enumerate(pts):
                ys = preimage_doubles(x, b, op)
                ivs = [a_interval(y, q) for y in ys]
                if feas is None: new = ivs
                else:
                    new = []
                    for (l1, h1) in feas:
                        for (l2, h2) in ivs:
                            l, h = max(l1, l2), min(h1, h2)
                            if l <= h: new.append((l, h))
                if not new: fail_at = idx; break
                feas = new
            if fail_at is None:
                print('FEASIBLE', name, k, op, [(float(l), float(h)) for l, h in feas][:3], flush=True)
            elif fail_at > 50:
                print('late fail', name, k, op, fail_at, flush=True)
print('done', len(pts))
