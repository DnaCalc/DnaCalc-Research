import sys, json, struct, math, numpy as np, mpmath as mp
from scipy.special import ndtri
mp.mp.dps = 50
def f(b): return struct.unpack('<d', struct.pack('<Q', int(b)))[0]
A = np.load('normal-dense-outputs.npz')['answers']; V = np.load('normal-dense-validity.npz')['numeric']
W = json.load(open('normal-dense-frozen.json'))['windows']
def true_q(p):
    x = mp.mpf(ndtri(p)); pm = mp.mpf(p)
    for _ in range(3): x = x - (mp.ncdf(x) - pm) / mp.npdf(x)
    return x
i = int(sys.argv[1]); j0 = int(sys.argv[2]); n = int(sys.argv[3])
s = int(W[i]['start'], 16)
row = []
for j in range(j0, j0+n):
    p = f(s+j); xe = f(A[i, j]); xt = true_q(p)
    e = float((mp.mpf(xe) - xt) / math.ulp(float(xt)))
    row.append('%+.1f' % e)
print(' '.join(row))
