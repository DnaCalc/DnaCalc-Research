"""Frozen fresh LINEST/LOGEST questions separating the rank-revealing stop from remove-and-continue.
Predictions are computed by the two racer builds before any question is asked."""
import json, random, struct, sys, os
def hx(x): return '0x%016x' % struct.unpack('<Q', struct.pack('<d', x))[0]
rng = random.Random(4201)
cases = []
def add(tag, ys, cols, const):
    n = len(ys)
    X = [[hx(cols[j][i]) for j in range(len(cols))] for i in range(n)]
    Y = [[hx(v)] for v in ys]
    cases.append(dict(tag=tag, args=[Y, X, const, True]))
# D1: collinear pair detected while a smaller independent column is still unstepped
for t in range(48):
    n = rng.choice([6, 8, 12, 16, 24])
    a = [float(rng.randint(-50, 50)) for _ in range(n)]
    k = rng.randrange(n)
    d = 2.0 ** -rng.randint(19, 24)
    b = [2 * v for v in a]; b[k] += d
    eps = 2.0 ** -rng.randint(30, 40)
    c = [eps * rng.choice([-3, -1, 1, 2, 5]) for _ in range(n)]
    ys = [float(rng.randint(-20, 20)) for _ in range(n)]
    order = rng.choice([[a, b, c], [b, a, c], [c, a, b], [a, c, b]])
    add('D1', ys, order, rng.random() < 0.5)
# D2: zero column with a near-collinear pair, random layouts
for t in range(48):
    n = rng.choice([4, 5, 8, 12, 16])
    a = [float(rng.randint(-30, 30)) for _ in range(n)]
    m = rng.choice([2.0, 3.0, 0.5, -1.0])
    b = [m * v for v in a]
    if rng.random() < 0.6:
        b[rng.randrange(n)] += 2.0 ** -rng.randint(20, 26)
    z = [0.0] * n
    ys = [float(rng.randint(-20, 20)) for _ in range(n)]
    lay = rng.choice([[z, a, b], [a, z, b], [a, b, z], [z, b, a], [b, a, z]])
    add('D2', ys, lay, rng.random() < 0.5)
# D3: full-rank controls
for t in range(32):
    n = rng.choice([5, 8, 12, 20]); k = rng.choice([1, 2, 3])
    cols = [[rng.uniform(-10, 10) for _ in range(n)] for _ in range(k)]
    ys = [rng.uniform(-10, 10) for _ in range(n)]
    add('D3', ys, cols, rng.random() < 0.5)
sels = [(1, 1), (1, 2), (1, 3), (4, 2), (5, 2), (3, 2)]
for fn in ['LINEST', 'LOGEST']:
    ws = []
    for ci, c in enumerate(cases):
        args = c['args']
        if fn == 'LOGEST':
            args = [[[hx(abs(struct.unpack('<d', struct.pack('<Q', int(r[0], 16)))[0]) + 1.0)] for r in args[0]]] + args[1:]
        k = len(args[1][0])
        for r, cc in sels:
            if r == 1 and cc > k + 1: continue
            ws.append(dict(id='%d:%d:%d' % (ci, r, cc), tag=c['tag'], args=args, result_index=[r, cc]))
    json.dump(dict(function=fn, witnesses=ws), open(sys.argv[1] + '/%s.questions.json' % fn, 'w'))
    print(fn, len(ws))
