import math, sys
from fractions import Fraction as Fr
exec(open('nhalf2.py').read().split("consts = {")[0])
from x87e import rn
import mpmath as mp
mp.mp.dps = 40
sqrtpi = Fr(mp.nstr(mp.sqrt(mp.pi), 38))
s2 = Fr(math.sqrt(2.0)); s2x = Fr(mp.nstr(mp.sqrt(2), 38))
def R53(v): return rn(v, 53)
def R64(v): return rn(v, 64)
models = {
 'y=RN53(q*sqrtpi) x=RN53(y*s2d)': lambda q: R53(R53(Fr(q) * sqrtpi) * s2),
 'y=RN53(q*sqrtpi) x=x87(y*s2d)': lambda q: R53(R64(R53(Fr(q) * sqrtpi) * s2)),
 'y=RN64(q*sqrtpi) x=x87(y*s2d)': lambda q: R53(R64(R64(Fr(q) * sqrtpi) * s2)),
 'y=RN53(q*sqrtpi) x=RN53(y*s2exact)': lambda q: R53(R53(Fr(q) * sqrtpi) * s2x),
 'y=RN53(2q*RN64(sqrtpi/2)) x=x87(y*s2d)': lambda q: R53(R64(R53(2 * Fr(q) * R64(sqrtpi / 2)) * s2)),
 'y=x87(2q*RN64(sqrtpi/2)) x=x87(y*s2d)': lambda q: R53(R64(R53(R64(2 * Fr(q) * R64(sqrtpi / 2))) * s2)),
 'x=x87(x87(q*RN64(sqrtpi))*s2d) no store': lambda q: R53(R64(R64(Fr(q) * R64(sqrtpi)) * s2)),
}
for name, m in models.items():
    bad = [(q, x) for q, x in pts if float(m(q)) != x]
    print('%-45s mismatches %d of %d' % (name, len(bad), len(pts)), [ (q.hex(), x.hex()) for q, x in bad[:2]])
