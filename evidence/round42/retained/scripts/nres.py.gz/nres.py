import sys, json, struct, math, numpy as np, mpmath as mp
mp.mp.dps = 40
def f(b): return struct.unpack('<d', struct.pack('<Q', int(b)))[0]
A = np.load('normal-dense-outputs.npz')['answers']; V = np.load('normal-dense-validity.npz')['numeric']
W = json.load(open('normal-dense-frozen.json'))['windows']
step = int(sys.argv[1])
for i, w in enumerate(W):
    s = int(w['start'], 16); res = []
    for j in range(0, w['count'], step):
        if not V[i, j]: continue
        p = f(s+j); xe = f(A[i, j])
        if w['region']=='upper':
            r = (mp.ncdf(-xe) - (1-mp.mpf(p)))*-1   # Phi(x)-p computed via upper tail
            ref = 1-p
        else:
            r = mp.ncdf(xe) - mp.mpf(p); ref = p
        res.append(float(r))
    if not res: continue
    r = np.array(res); p0 = f(s+4096)
    print(i, w['region'], '%.6g'%p0, 'absmax %.3g  rel(p) %.3g  rel(tail) %.3g  /ulp(p) %.2f' % (abs(r).max(), abs(r).max()/p0, abs(r).max()/min(p0,1-p0), abs(r).max()/math.ulp(p0)))
