import json, struct, math, numpy as np
def f(b): return struct.unpack('<d', struct.pack('<Q', int(b)))[0]
def bits(x): return struct.unpack('<Q', struct.pack('<d', x))[0]
A = np.load('normal-dense-outputs.npz')['answers']; V = np.load('normal-dense-validity.npz')['numeric']
W = json.load(open('normal-dense-frozen.json'))['windows']
C=[1.4234371107496835,4.630337846156546,5.769497221460691,3.6478483247632045,1.2704582524523684,0.2417807251774506,0.022723844989269184,0.0007745450142783414]
D=[1.0,2.053191626637759,1.6763848301838038,0.6897673349851,0.14810397642748008,0.015198666563616457,0.0005475938084995345,1.0507500716444169e-09]
E=[6.657904643501103,5.463784911164114,1.7848265399172913,0.29656057182850487,0.026532189526576124,0.0012426609473880784,2.7115555687434876e-05,2.0103343992922881e-07]
F=[1.0,0.599832206555888,0.1369298809227358,0.014875361290850615,0.0007868691311456133,1.8463183175100548e-05,1.421511758316446e-07,2.0442631033899397e-15]
def h(c,r):
    v=c[7]
    for k in range(6,-1,-1): v=v*r+c[k]
    return v
def tail(p):
    q=p-0.5; t=p if q<0 else 1.0-p
    r=math.sqrt(-math.log(t))
    if r<=5: r-=1.6; x=h(C,r)/h(D,r)
    else: r-=5; x=h(E,r)/h(F,r)
    return -x if q<0 else x
for i,w in enumerate(W):
    s=int(w['start'],16); n=0; m=0; d=[]
    for j in range(w['count']):
        if not V[i,j]: continue
        p=f(s+j)
        if p<=0: continue
        pr=bits(tail(p)); a=int(A[i,j]); n+=1; m+=(pr==a)
        d.append((a-pr) if a>>63==pr>>63 else 99)
    p0=f(s+4096)
    d=np.array(d); sm=d[np.abs(d)<50]
    if n: print(i,w["region"],"%.5g"%p0,"match %d/%d"%(m,n), "small-diff %d mean %.2f"%(len(sm), sm.mean() if len(sm) else 0), np.unique(sm,return_counts=True)[1][:12] if len(sm) else "")
