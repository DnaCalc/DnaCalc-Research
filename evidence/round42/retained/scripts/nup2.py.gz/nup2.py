import json, gzip, glob, os, collections
from nlib import f, bits, h16, invoke
R = '/home/ubuntu/projects/DnaCalc/DnaCalc-Research/evidence/'
pairs = []
# every retained NORM.S.INV point/answer file of rounds 39-41 with points+answers or witnesses
for path in sorted(glob.glob(R + 'round39/retained/*normal*') + glob.glob(R + 'round40/retained/*normal*') + glob.glob(R + 'round41/retained/normal-*')):
    if not path.endswith('.json.gz'): continue
    try: d = json.load(gzip.open(path))
    except Exception: continue
    if isinstance(d, dict) and 'points' in d and 'answers' in d and isinstance(d['answers'], list):
        for p, a in zip(d['points'], d['answers']):
            if isinstance(a, dict) and a.get('bits') and isinstance(p, float): pairs.append((os.path.basename(path), p, int(a['bits'], 16)))
    if isinstance(d, dict) and d.get('function') == 'NORM.S.INV' and 'witnesses' in d:
        for w in d['witnesses']:
            if 'expected' in w: pairs.append((os.path.basename(path), f(int(w['args'][0], 16)), int(w['expected'], 16)))
print(len(pairs), collections.Counter(n for n, _, _ in pairs))
import subprocess
for racer in ['racer-base', 'racer-cand']:
    import nlib; nlib.RACER = os.path.expanduser('~/codex-runs/r42/' + racer)
    out = invoke([('NORM.S.INV', [p]) for _, p, _ in pairs])
    res = collections.Counter()
    for (n, p, a), o in zip(pairs, out):
        reg = 'tail' if p - 0.5 < -0.425 or p > 15/16 else ('B' if p > 0.925 else 'central')
        res[(reg, 'n')] += 1; res[(reg, 'm')] += isinstance(o, float) and bits(o) == a
    print(racer, dict(res))
