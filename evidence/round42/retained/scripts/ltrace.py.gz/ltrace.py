import sys, math
from x87e import x87
EPS = 2.0 ** -41
def ls(cols, y, const, trace=True, stop=True):
    n = len(y)
    mean = lambda v: sum(v) / n   # forward fold in double
    def fmean(v):
        s = 0.0
        for t in v: s = s + t
        return s / n
    means = [fmean(c) for c in cols]
    mats = []
    if const: mats.append(('1', [1.0] * n))
    for i, c in enumerate(cols): mats.append(('x%d' % i, [v - means[i] for v in c] if const else c[:]))
    tgt = [v - fmean(y) for v in y] if const else y[:]
    def sqf(v, a):
        s = 0.0
        for t in v[a:]: s = s + x87('*', t, t)
        return s
    scale = [sqf(c, 0) for _, c in mats]
    j = 0; counted = []
    while j < len(mats):
        if mats[j][0] != '1':
            best = j; bs = -1.0; cand = []
            for k in range(j, len(mats)):
                s = sqf(mats[k][1], j); cand.append((mats[k][0], s))
                if s > bs: bs = s; best = k
            if trace: print('  j', j, 'candidates', cand, '-> pick', mats[best][0])
            mats[j], mats[best] = mats[best], mats[j]; scale[j], scale[best] = scale[best], scale[j]
        x0 = mats[j][1][j]; rest = sqf(mats[j][1], j + 1); squares = sqf(mats[j][1], j)
        before = scale[j]; rem = before
        for r in mats[j][1][:j]: rem = rem - r * r
        coll = before > 0 and mats[j][0] != '1' and rem < before * EPS
        if trace: print('    step', mats[j][0], 'squares', squares, 'before', before, 'rem', rem, 'collinear', coll)
        if before > 0 and mats[j][0] != '1' and (squares == 0 or coll):
            if stop: 
                if trace: print('    STOP; dropped', [m[0] for m in mats[j:]])
                mats = mats[:j]; break
            del mats[j]; del scale[j]; continue
        if squares == 0:
            counted.append(mats[j][0]); j += 1; continue
        alpha = -math.copysign(math.sqrt(squares), x0)
        v = mats[j][1][j:]; v = [x87('-', x0, alpha)] + v[1:]
        vv = x87('+', rest, x87('*', v[0], v[0]))
        def refl(a):
            t = 0.0
            for vi, ai in zip(v, a[j:]): t = x87('+', t, x87('*', vi, ai))
            fct = x87('/', x87('*', 2.0, t), vv)
            for i in range(j, n): a[i] = x87('-', a[i], x87('*', fct, v[i - j]))
        for k in range(j + 1, len(mats)): refl(mats[k][1])
        refl(tgt); counted.append(mats[j][0]); j += 1
    ssr = 0.0
    for t in tgt[j:]: ssr = ssr + x87('*', t, t)
    return counted, n - len(counted), ssr
if __name__ == '__main__':
    n = 16
    x = [float(i) for i in range(1, n + 1)]; x2 = [2 * v for v in x]; z = [0.0] * n
    y = [1.0] + [0.0] * (n - 1)
    for name, cols in [('a zero-first', [z, x, x2]), ('b zero-last', [x, x2, z])]:
        print(name); print('  ->', ls(cols, y, True))
