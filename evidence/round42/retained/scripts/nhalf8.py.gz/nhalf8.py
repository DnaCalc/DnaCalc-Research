import math, sys
from fractions import Fraction as Fr
exec(open('nhalf2.py').read().split("consts = {")[0])
from x87e import rn
lo = Fr('1.772453850905516103923238') / 2; hi = Fr('1.772453850905516103940755') / 2
# 64-bit mantissa values in [lo, hi]: value = m * 2^-64 for 0.886 in [0.5,1): spacing 2^-64
sp = Fr(1, 2**64)
m0 = (lo / sp).numerator // (lo / sp).denominator
cands = [Fr(m, 2**64) for m in range(m0 - 2, m0 + 4) if lo <= Fr(m, 2**64) <= hi]
print('64-bit K in interval:', [float(k) for k in cands], [hex(int(k * 2**64)) for k in cands])
near = [Fr(m, 2**64) for m in range(m0 - 1, m0 + 3)]
s2 = Fr(math.sqrt(2.0)); R53 = lambda v: rn(v, 53); R64 = lambda v: rn(v, 64)
for K in near:
    for name, m in [('y=RN53(RN64(t*K)) x=RN53(y*s2)', lambda q: R53(R53(R64(2 * Fr(q) * K)) * s2)),
                    ('y=RN53(RN64(t*K)) x=x87(y*s2)', lambda q: R53(R64(R53(R64(2 * Fr(q) * K)) * s2))),
                    ('y=RN53(t*K) x=x87(y*s2)', lambda q: R53(R64(R53(2 * Fr(q) * K) * s2)))]:
        bad = sum(float(m(q)) != x for q, x in pts)
        print(hex(int(K * 2**64)), 'in' if lo <= K <= hi else 'out', name, bad)
