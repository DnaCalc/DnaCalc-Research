"""Pade [m/n] of erfinv(t)/t in s = t^2 with x87 PC64 stores (numpy longdouble = 80-bit):
x = st(st(t*R)*sqrt2), R = st(P/Q) or y = st(st(t*P)/Q). Screened on noisy piece-1 windows."""
import sys, math, numpy as np, mpmath as mp
from nlib import load, f
mp.mp.dps = 60
A, V, W = load()
LD = np.longdouble
def st(v): return v.astype(np.float64)        # store: RN64 result -> RN53
def mul(a, b): return st(a.astype(LD) * b.astype(LD))
def add(a, b): return st(a.astype(LD) + b.astype(LD))
def div(a, b): return st(a.astype(LD) / b.astype(LD))
N = 40
c = [mp.mpf(1)]
for k in range(1, N): c.append(sum(c[m] * c[k - 1 - m] / ((m + 1) * (2 * m + 1)) for m in range(k)))
a = [c[k] / (2 * k + 1) * (mp.sqrt(mp.pi) / 2) ** (2 * k + 1) for k in range(N)]
wins = [i for i, w in enumerate(W) if 0.25 < abs(f(int(w['start'], 16) + 4096) - 0.5) < 0.336]
pts = []
for i in wins:
    s0 = int(W[i]['start'], 16)
    for j in range(0, 8192, 32):
        if V[i, j]: pts.append((f(s0 + j), int(A[i, j])))
P_ = np.array([p for p, _ in pts]); X_ = np.array([x for _, x in pts], dtype=np.uint64)
T = 2 * (P_ - 0.5); S = mul(T, T); s2 = np.full_like(T, math.sqrt(2.0))
def hor(cs, s):
    v = np.full_like(s, cs[-1])
    for cc in cs[-2::-1]: v = add(mul(v, s), np.full_like(s, cc))
    return v
res = []
for tot in range(4, 26):
    for n in range(0, tot + 1):
        m = tot - n
        try: p, q = mp.pade(a, m, n)
        except Exception: continue
        pd = [float(v) for v in p]; qd = [float(v) for v in q] if n else [1.0]
        Pv = hor(pd, S); Qv = hor(qd, S) if n else np.ones_like(S)
        for form, y in [('t(P/Q)', mul(T, div(Pv, Qv))), ('(tP)/Q', div(mul(T, Pv), Qv))]:
            x = mul(y, s2)
            res.append((int((x.view(np.uint64) == X_).sum()), m, n, form))
res.sort(reverse=True)
print(len(pts), 'points;', res[:10])
