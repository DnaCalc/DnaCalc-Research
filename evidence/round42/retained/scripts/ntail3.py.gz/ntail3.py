import math, collections, sys
exec(open('ntail2.py').read().split("k = 0; res")[0])
step = int(sys.argv[1])
res = collections.Counter(); tot = 0
for i, w in enumerate(W):
    s = int(w['start'], 16)
    if f(s + 4096) >= 0.075: continue
    for j in range(0, w['count'], step):
        p = f(s + j)
        if not V[i, j] or not (p - 0.5 < -0.425) or p <= 0: continue
        e = '0x%016x' % int(A[i, j]); tot += 1
        for m in ['dbl', 'x87store']:
            res[m] += '0x%016x' % bits(tailx(p, m)) == e
print(tot, dict(res))
