import json, struct, math, numpy as np, mpmath as mp
from scipy.special import ndtri
mp.mp.dps = 40
d = json.load(open('/home/ubuntu/codex-runs/claude-r42/fresh/NORM.S.INV.mapping.replies.json'))
def f(h): return struct.unpack('<d', struct.pack('<Q', int(h, 16)))[0]
def tq(p):
    x = mp.mpf(ndtri(p)); pm = mp.mpf(p)
    for _ in range(2): x = x - (mp.ncdf(x) - pm) / mp.npdf(x)
    return x
for r in d['replies']:
    w = r['window']; s0 = int(w['start'], 16); rows = (r['reply'] or {}).get('rows') or []
    e = []
    for j, row in enumerate(rows):
        if row.get('type') != 'number': continue
        p = f('%016x' % (s0 + j)); x = f(row['bits']); t = tq(p)
        e.append(float((mp.mpf(x) - t) / math.ulp(float(t))))
    e = np.array(e); p0 = f('%016x' % (s0 + 128))
    print('%-22s p=%.5f q=%+.4f n=%d mean %+.2f sd %.2f' % (w['purpose'], p0, p0 - 0.5, len(e), e.mean(), e.std()))
