"""Screen Pade approximants of erfinv(t)/t in s = t^2 (coefficients exact, rounded to binary64)
against Excel's central NORM.S.INV answers: x = sqrt2 * (t * P(s)/Q(s)), t = 2q."""
import sys, math, numpy as np, mpmath as mp
from nlib import load, f, bits
mp.mp.dps = 60
A, V, W = load()
# Taylor coefficients of erfinv(z)/z in s=z^2
N = 40
c = [mp.mpf(1)]
for k in range(1, N):
    c.append(sum(c[m] * c[k - 1 - m] / ((m + 1) * (2 * m + 1)) for m in range(k)))
a = [c[k] / (2 * k + 1) * (mp.sqrt(mp.pi) / 2) ** (2 * k + 1) for k in range(N)]
wins = [i for i, w in enumerate(W) if 0.18 < abs(f(int(w['start'], 16) + 4096) - 0.5) < 0.336]
pts = []
for i in wins:
    s0 = int(W[i]['start'], 16)
    for j in range(0, 8192, 64):
        if V[i, j]: pts.append((f(s0 + j), int(A[i, j])))
print(len(wins), 'windows', len(pts), 'points')
P_ = np.array([p for p, _ in pts]); X_ = np.array([x for _, x in pts], dtype=np.uint64)
T = 2 * (P_ - 0.5); S = T * T; s2 = math.sqrt(2.0)
res = []
for tot in range(4, 24):
    for n in range(1, tot):
        m = tot - n
        try: p, q = mp.pade(a, m, n)
        except Exception: continue
        pd = [float(v) for v in p]; qd = [float(v) for v in q]
        def hor(cs, s):
            v = np.full_like(s, cs[-1])
            for cc in cs[-2::-1]: v = v * s + cc
            return v
        Pv = hor(pd, S); Qv = hor(qd, S)
        for form, y in [('tP/Q', (T * Pv) / Qv), ('t(P/Q)', T * (Pv / Qv))]:
            x = y * s2
            mt = int((x.view(np.uint64) == X_).sum())
            err = np.abs(x - X_.view(np.float64)) / np.abs(X_.view(np.float64))
            res.append((mt, m, n, form, float(np.median(err))))
res.sort(reverse=True)
for r in res[:15]: print(r)
