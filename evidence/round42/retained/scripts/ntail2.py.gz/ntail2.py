import math, collections, sys
from fractions import Fraction as Fr
from nlib import *
from x87e import rn
A, V, W = load()
c = [l.strip() for l in open('norm.cand.out')]
E = [6.657904643501103,5.463784911164114,1.7848265399172913,0.29656057182850487,0.026532189526576124,0.0012426609473880784,2.7115555687434876e-05,2.0103343992922881e-07]
F = [1.0,0.599832206555888,0.1369298809227358,0.014875361290850615,0.0007868691311456133,1.8463183175100548e-05,1.421511758316446e-07,2.0442631033899397e-15]
C = [1.4234371107496835,4.630337846156546,5.769497221460691,3.6478483247632045,1.2704582524523684,0.2417807251774506,0.022723844989269184,0.0007745450142783414]
D = [1.0,2.053191626637759,1.6763848301838038,0.6897673349851,0.14810397642748008,0.015198666563616457,0.0005475938084995345,1.0507500716444169e-09]
def x87op(a, b, op):
    a = Fr(a); b = Fr(b)
    v = a + b if op == '+' else (a - b if op == '-' else (a * b if op == '*' else a / b))
    return float(rn(rn(v, 64), 53))
def ext(v): return rn(Fr(v), 64)
def horner(cs, r, mode):
    if mode == 'dbl':
        v = cs[7]
        for k in range(6, -1, -1): v = v * r + cs[k]
        return v
    if mode == 'x87store':
        v = cs[7]
        for k in range(6, -1, -1): v = x87op(x87op(v, r, '*'), cs[k], '+')
        return v
    if mode == 'ext':   # whole Horner in 64-bit, no stores
        v = Fr(cs[7]); R = Fr(r)
        for k in range(6, -1, -1): v = rn(rn(v * R, 64) + Fr(cs[k]), 64)
        return v
def tailx(p, mode):
    r = math.sqrt(-math.log(p))
    if r <= 5: rr = r - 1.6; N, Dd = horner(C, rr, mode), horner(D, rr, mode)
    else: rr = r - 5.0; N, Dd = horner(E, rr, mode), horner(F, rr, mode)
    if mode == 'ext': return -float(rn(N / Dd, 53))
    if mode == 'x87store': return -x87op(N, Dd, '/')
    return -(N / Dd)
k = 0; res = collections.Counter()
for i, w in enumerate(W):
    s = int(w['start'], 16)
    for j in range(w['count']):
        if V[i, j] and f(s + 4096) < 0.075 and f(s+j) - 0.5 < -0.425:
            e = '0x%016x' % int(A[i, j])
            if c[k] != e:
                p = f(s + j)
                ms = tuple(m for m in ['dbl', 'x87store', 'ext'] if '0x%016x' % bits(tailx(p, m)) == e)
                res[(i, ms)] += 1
        k += 1
for kk, v in sorted(res.items()): print(kk, v)
