import math, sys, collections
exec(open('ntail2.py').read().split("k = 0; res")[0])
def tail_r(p, r, mode='x87store'):
    big = r > 5
    rr = (r - 5.0) if big else (r - 1.6)
    cs = (E, F) if big else (C, D)
    N, Dd = horner(cs[0], rr, mode), horner(cs[1], rr, mode)
    return -x87op(N, Dd, '/')
i = int(sys.argv[1]); s = int(W[i]['start'], 16)
c = collections.Counter(); ex = 0
for j in range(8192):
    p = f(s + j); e = int(A[i, j])
    r = math.sqrt(-math.log(p))
    if bits(tail_r(p, r)) == e: c['ok'] += 1; continue
    found = None
    for dl in [-2, -1, 1, 2]:
        L = -math.log(p); L2 = f(bits(L) + dl); 
        if bits(tail_r(p, math.sqrt(L2))) == e: found = 'log%+d' % dl; break
    if not found:
        for dr in [-2, -1, 1, 2]:
            if bits(tail_r(p, f(bits(r) + dr))) == e: found = 'r%+d' % dr; break
    c[found] += 1
    if ex < 3: print(hex(s + j), 'excel', hex(e), 'model', hex(bits(tail_r(p, r))), found); ex += 1
print(dict(c))
