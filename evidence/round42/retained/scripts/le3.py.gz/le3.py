import json, struct, collections, math
from fractions import Fraction as Fr
import lvar3
from lvar3 import ls
f = lambda h: struct.unpack('<d', struct.pack('<Q', int(h, 16)))[0]
QD = '/home/ubuntu/codex-runs/r42/questions'; RD = '/home/ubuntu/codex-runs/claude-r42/fresh'
ans = {}
for ch in json.load(open(RD + '/LINEST.pivot-questions.replies.json'))['replies']:
    for i, row in zip(ch['ids'], (ch['reply'] or {}).get('rows') or []):
        ans[i] = f(row['bits']) if row.get('type') == 'number' else None
Ps = {b: {json.loads(l)['id']: json.loads(l)['calc_func_prediction'] for l in open(QD + '/LINEST.pivot-pred-%s.jsonl' % b)} for b in ['sign', 'downlast']}
# exact-criterion variant: monkeypatch the down criterion to exact arithmetic
orig_sqf = lvar3.sqf
cases = []
for w in json.load(open(QD + '/LINEST.pivot-questions.json'))['witnesses']:
    if w['result_index'] != [5, 2] or ans.get(w['id']) is None: continue
    a = w['args']; n = len(a[0]); X = [[f(v) for v in r] for r in a[1]]
    cases.append((w['tag'], w['id'], [[X[i][j] for i in range(n)] for j in range(len(X[0]))], [f(r[0]) for r in a[0]], a[2], ans[w['id']]))
base = dict(center=True, ones='first', pivot_ones=False, move='swap', sign='new', stop=True)
for name, extra in [('fresh-first', dict(crit='fresh', tie='first')), ('down-first', dict(crit='down', tie='first')), ('down-last', dict(crit='down', tie='last')), ('fresh-last', dict(crit='fresh', tie='last'))]:
    c = collections.Counter(); agree = collections.Counter()
    for tag, i, cols, ys, const, e in cases:
        cnt, ssr, one = ls(cols, ys, const, dict(base, **extra))
        c[tag] += ssr == e; c[tag + 'n'] += 1
        if name == 'fresh-first': agree['emu=rust(sign)'] += '0x%016x' % struct.unpack('<Q', struct.pack('<d', ssr))[0] == Ps['sign'][i]
        if name == 'down-last': agree['emu=rust(downlast)'] += '0x%016x' % struct.unpack('<Q', struct.pack('<d', ssr))[0] == Ps['downlast'][i]
    print(name, {t: '%d/%d' % (c[t], c[t + 'n']) for t in ['E1', 'E2', 'E3']}, dict(agree))
