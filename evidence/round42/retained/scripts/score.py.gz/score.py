"""Score the R42 fresh replies against the predictions frozen before asking.

usage: python3 score.py <questions-dir> <replies-dir>
Every unread, error or missing reply counts as a failure for both builds.
"""
import json, os, sys, collections

QD, RD = sys.argv[1], sys.argv[2]
out = {}
p = os.path.join(RD, 'NORM.S.INV.lower.replies.json')
if os.path.exists(p):
    q = json.load(open(os.path.join(QD, 'NORM.S.INV.lower.json')))
    answers = [None] * len(q['points'])
    for chunk in json.load(open(p))['replies']:
        rows = (chunk['reply'] or {}).get('rows') or []
        for k, row in enumerate(rows):
            answers[chunk['start'] + k] = row.get('bits') if row.get('type') == 'number' else None
    res = collections.Counter(n=len(answers), answered=sum(a is not None for a in answers))
    for build, preds in q['predictions'].items():
        res[build] = sum(a is not None and a == pr for a, pr in zip(answers, preds))
    out['NORM.S.INV.lower'] = dict(res)
for qf in ['LINEST.questions.json', 'LOGEST.questions.json', 'LINEST.sign-questions.json', 'LINEST.zero-questions.json']:
    p = os.path.join(RD, qf.replace('.json', '.replies.json'))
    if not os.path.exists(p): continue
    base = qf.replace('questions.json', '')
    preds = {}
    for f in os.listdir(QD):
        if f.startswith(base.replace('LINEST.', 'LINEST.').rstrip('.')) and f.endswith('.jsonl') and 'pred' in f:
            if (qf == 'LINEST.questions.json' and f.startswith('LINEST.pred-')) or (qf == 'LOGEST.questions.json' and f.startswith('LOGEST.pred-')) \
               or (qf == 'LINEST.sign-questions.json' and f.startswith('LINEST.sign-pred-')) or (qf == 'LINEST.zero-questions.json' and f.startswith('LINEST.zero-pred-')):
                preds[f] = {json.loads(l)['id']: json.loads(l)['calc_func_prediction'] for l in open(os.path.join(QD, f))}
    answers = {}
    for chunk in json.load(open(p))['replies']:
        rows = (chunk['reply'] or {}).get('rows') or []
        for i, row in zip(chunk['ids'], rows):
            if row.get('type') == 'number': answers[i] = '0x' + row['bits']
            elif row.get('type') == 'error': answers[i] = 'error:' + str(row.get('code') or row.get('value'))
    ids = [w['id'] for w in json.load(open(os.path.join(QD, qf)))['witnesses']]
    res = collections.Counter(n=len(ids), answered=sum(i in answers for i in ids))
    for f, pr in preds.items():
        res[f] = sum(answers.get(i) is not None and answers.get(i) == pr.get(i) for i in ids)
    out[qf] = dict(res)
print(json.dumps(out, indent=1))
