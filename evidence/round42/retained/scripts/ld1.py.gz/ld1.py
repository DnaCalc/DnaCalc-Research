import json, sys, collections, struct
f = lambda h: struct.unpack('<d', struct.pack('<Q', int(h, 16)))[0]
QD = '/home/ubuntu/codex-runs/r42/questions'; RD = '/home/ubuntu/codex-runs/claude-r42/fresh'
fn = 'LINEST'
Q = json.load(open(QD + '/%s.questions.json' % fn))['witnesses']
P = {b: {json.loads(l)['id']: json.loads(l)['calc_func_prediction'] for l in open(QD + '/%s.pred-%s.jsonl' % (fn, b))} for b in ['base', 'stop']}
ans = {}
for ch in json.load(open(RD + '/%s.questions.replies.json' % fn))['replies']:
    for i, row in zip(ch['ids'], (ch['reply'] or {}).get('rows') or []):
        ans[i] = ('0x' + row['bits']) if row.get('type') == 'number' else None
case = collections.defaultdict(dict)
for w in Q:
    if w['tag'] != 'D1': continue
    c = w['id'].split(':')[0]; case[c]['args'] = w['args']
    case[c][tuple(w['result_index'])] = (ans.get(w['id']), P['base'][w['id']], P['stop'][w['id']])
kinds = collections.Counter()
for c, d in case.items():
    a = d['args']; n = len(a[0]); X = [[f(v) for v in r] for r in a[1]]
    cols = [[X[i][j] for i in range(n)] for j in range(3)]
    scale = ['small' if max(abs(v) for v in col) < 1e-6 else 'big' for col in cols]
    dfE, dfB, dfS = d.get((4, 2), (None,) * 3)
    k = ('const' if a[2] else 'noconst', tuple(scale), 'df=base' if dfE == dfB else ('df=stop' if dfE == dfS else 'df=other'))
    kinds[k] += 1
for k, v in sorted(kinds.items()): print(v, k)
import math
print('---')
rows = []
for c, d in case.items():
    a = d['args']; n = len(a[0]); X = [[f(v) for v in r] for r in a[1]]
    cols = [[X[i][j] for i in range(n)] for j in range(3)]
    small = [j for j in range(3) if max(abs(v) for v in cols[j]) < 1e-6][0]
    big = [j for j in range(3) if j != small]
    A_, B_ = cols[big[0]], cols[big[1]]
    # which is 2x+d
    if max(abs(v) for v in A_) > max(abs(v) for v in B_): A_, B_ = B_, A_
    dvec = [bv - 2 * av for av, bv in zip(A_, B_)]
    dd = max(abs(v) for v in dvec); eps = max(abs(v) for v in cols[small])
    dfE, dfB, dfS = d.get((4, 2), (None,) * 3)
    out = 'keep' if dfE == dfB else ('drop' if dfE == dfS else 'other')
    rows.append((round(math.log2(dd)), round(math.log2(eps)), a[2], n, small, out))
for r in sorted(rows): print(r)
print('===')
cnt = collections.Counter()
for c, d in case.items():
    a = d['args']; n = len(a[0]); X = [[f(v) for v in r] for r in a[1]]
    cols = [[X[i][j] for i in range(n)] for j in range(3)]
    small = [j for j in range(3) if max(abs(v) for v in cols[j]) < 1e-6][0]
    def z(t): return None if t is None else (t == '0x0000000000000000')
    # LINEST row 1 is reversed: (1,1)=col2, (1,2)=col1, (1,3)=col0
    pat = []
    for j in range(3):
        e = d.get((1, 3 - j), (None, None, None))
        pat.append('?' if e[0] is None else ('0' if z(e[0]) else 'x'))
    lab = ''.join(('s' if j == small else 'b') for j in range(3))
    dfE, dfB, dfS = d.get((4, 2), (None,) * 3)
    out = 'keep' if dfE == dfB else ('drop' if dfE == dfS else 'other')
    cnt[(lab, ''.join(pat), out)] += 1
for k, v in sorted(cnt.items()): print(v, k)
