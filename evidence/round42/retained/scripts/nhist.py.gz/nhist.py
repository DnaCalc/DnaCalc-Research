import sys, json, struct, math, numpy as np, mpmath as mp
from scipy.special import ndtri
mp.mp.dps = 40
def f(b): return struct.unpack('<d', struct.pack('<Q', int(b)))[0]
A = np.load('normal-dense-outputs.npz')['answers']; V = np.load('normal-dense-validity.npz')['numeric']
W = json.load(open('normal-dense-frozen.json'))['windows']
def true_q(p):
    x = mp.mpf(ndtri(p)); pm = mp.mpf(p)
    for _ in range(2): x = x - (mp.ncdf(x) - pm) / mp.npdf(x)
    return x
i = int(sys.argv[1]); n = int(sys.argv[2])
s = int(W[i]['start'], 16); errs=[]
for j in range(0, n):
    p = f(s+j); xe = f(A[i, j]); xt = true_q(p)
    errs.append(float((mp.mpf(xe) - xt) / math.ulp(float(xt))))
e = np.array(errs)
h, edges = np.histogram(e, bins=26)
for c, a in zip(h, edges): print('%7.1f %s' % (a, '#'*(c*200//n)))
# autocorrelation
ec = e - e.mean()
print('autocorr lag1..4', [round(float((ec[:-k]*ec[k:]).mean()/ec.var()),3) for k in range(1,5)])
np.save('err_%d.npy' % i, e)
