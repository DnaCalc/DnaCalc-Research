import sys, math
from nlib import *
A, V, W = load()
wins = [int(x) for x in sys.argv[1].split(',')]
step = int(sys.argv[2]) if len(sys.argv) > 2 else 16
for i in wins:
    s = int(W[i]['start'], 16)
    pts = [(f(s + j), f(A[i, j])) for j in range(0, 8192, step) if V[i, j]]
    rows = []
    for p, xe in pts:
        x0 = as241(p)
        rows += [('NORM.S.DIST', [x0, 'T']), ('NORM.S.DIST', [x0, 'F'])]
        for k in range(-3, 4): rows.append(('NORM.S.DIST', [nxt(xe, k), 'T']))
    out = invoke(rows)
    stats = {}
    rootpos = {}
    for n, (p, xe) in enumerate(pts):
        o = out[n*9:(n+1)*9]
        x0 = as241(p); P0, d0 = o[0], o[1]
        cands = {
          'x0': x0,
          'newton': x0 - (P0 - p) / d0,
          'newton_plus': x0 + (p - P0) / d0,
        }
        for k, v in cands.items(): stats[k] = stats.get(k, 0) + (bits(v) == bits(xe))
        # where does p fall among Phi_E(xe+k)?
        F = o[2:]
        sgn = ''.join('+' if v > p else ('=' if v == p else '-') for v in F)
        rootpos[sgn] = rootpos.get(sgn, 0) + 1
    print(i, '%.5g' % pts[0][0], len(pts), stats)
    print('   sign pattern of Phi_E(xe+k)-p, k=-3..3:', sorted(rootpos.items(), key=lambda t: -t[1])[:8])
