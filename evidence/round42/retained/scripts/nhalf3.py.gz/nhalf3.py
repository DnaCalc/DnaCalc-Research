import math, sys
from fractions import Fraction as Fr
exec(open('nhalf2.py').read().split("consts = {")[0])
from x87e import rn
b = math.sqrt(2.0)
feas = None
for idx, (q, x) in enumerate(pts):
    ys = preimage_doubles(x, b, '*'); ivs = [a_interval(y, q) for y in ys]
    if feas is None: new = ivs
    else:
        new = [(max(l1, l2), min(h1, h2)) for (l1, h1) in feas for (l2, h2) in ivs if max(l1, l2) <= min(h1, h2)]
    if not new:
        print('fail at', idx, 'q', q.hex(), 'x', x.hex(), 'ys', [y.hex() for y in ys]); break
    feas = new
print('feasible before', [(float(l), float(h), float(h - l) / float(l)) for l, h in feas])
a_lo, a_hi = feas[0]
# candidate doubles a in the interval
a = float(a_lo)
cands = []
for k in range(-3, 6):
    c = f(bits(a) + k)
    if a_lo <= Fr(c) <= a_hi: cands.append(c)
print('double a candidates', [c.hex() for c in cands], [repr(c) for c in cands])
print('a/2 vs sqrt(pi)/2:', [repr(c / 2) for c in cands], repr(math.sqrt(math.pi) / 2))
# test models on all pts
def model(q, a, m):
    if m == 'strict': return float(Fr(float(Fr(q) * Fr(a))) * Fr(b)) if False else (q * a) * b
    if m == 'x87final':
        y = q * a; return float(rn(rn(Fr(y) * Fr(b), 64), 53))
    if m == 'x87both':
        y = float(rn(rn(Fr(q) * Fr(a), 64), 53)); return float(rn(rn(Fr(y) * Fr(b), 64), 53))
    if m == 'ext_y':
        y = rn(Fr(q) * Fr(a), 64); return float(rn(rn(y * Fr(b), 64), 53))
for c in cands:
    for m in ['strict', 'x87final', 'x87both', 'ext_y']:
        bad = sum(model(q, c, m) != x for q, x in pts)
        print(c.hex(), m, 'mismatches', bad, 'of', len(pts))
