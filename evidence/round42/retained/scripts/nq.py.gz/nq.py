"""Frozen fresh NORM.S.INV lower-tail questions (R42). Seeded; predictions from both builds before asking."""
import random, math, json, os, sys
sys.path.insert(0, os.path.expanduser('~/codex-runs/r42/work'))
import nlib
from nlib import f, bits, h16, invoke
rng = random.Random(42042)
pts = []
for _ in range(1600): pts.append(math.exp(rng.uniform(math.log(1e-300), math.log(0.075))))
for _ in range(200): pts.append(rng.uniform(0.0625, 0.075))
b = bits(0.075)
pts += [f(b + k) for k in range(-40, 41)]                    # the AS241 boundary q = -0.425
for e in [2, 4, 5, 8, 12, 20, 40, 100, 200, 500, 1000, 1020]:   # exponent edges 2^-e +- ulps
    c = bits(2.0 ** -e)
    pts += [f(c + k) for k in range(-4, 5)]
r5 = math.exp(-25.0); c5 = bits(r5)                            # the r = 5 branch edge
pts += [f(c5 + k) for k in range(-30, 31)]
pts = [p for p in pts if 0 < p < 0.5]
rows = [('NORM.S.INV', [p]) for p in pts]
out = {}
for name in ['racer-base', 'racer-cand']:
    nlib.RACER = os.path.expanduser('~/codex-runs/r42/' + name)
    out[name] = ['%016x' % bits(v) if isinstance(v, float) else v for v in invoke(rows)]
doc = dict(function='NORM.S.INV', seed=42042, points=[h16(p) for p in pts], predictions=out,
           method='R42 frozen before asking: 1,600 log-uniform lower p, 200 in [1/16, 0.075), 81 around p = 0.075, exponent edges, the r = 5 edge.')
json.dump(doc, open(os.path.expanduser('~/codex-runs/r42/questions/NORM.S.INV.lower.json'), 'w'))
print(len(pts), 'separating', sum(a != b for a, b in zip(out['racer-base'], out['racer-cand'])))
