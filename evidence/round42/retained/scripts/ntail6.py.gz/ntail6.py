import math, sys, collections
exec(open('ntail5.py').read().split("i = int(sys.argv[1])")[0])
LN2 = math.log(2.0)
def L_variants(p):
    m, e = math.frexp(p)            # m in [0.5,1)
    out = {'crt': -math.log(p)}
    out['frexp_half'] = -(math.log(m) + e * LN2)
    out['frexp_one'] = -(math.log(2 * m) + (e - 1) * LN2)
    return out
res = collections.Counter(); n = 0
for i, w in enumerate(W):
    s = int(w['start'], 16)
    if f(s + 4096) >= 0.075: continue
    for j in range(0, 8192, int(sys.argv[1])):
        p = f(s + j)
        if not V[i, j] or not (p - 0.5 < -0.425) or p <= 0: continue
        e = int(A[i, j]); n += 1
        for k, L in L_variants(p).items():
            res[k] += bits(tail_r(p, math.sqrt(L))) == e
print(n, dict(res))
