import sys, math, json, struct, collections, itertools
from x87e import x87
EPS = 2.0 ** -41
def f(h): return struct.unpack('<d', struct.pack('<Q', int(h, 16)))[0] if isinstance(h, str) and h.startswith('0x') else h
def fmean(v):
    s = 0.0
    for t in v: s = s + t
    return s / len(v)
def sqf(v, a):
    s = 0.0
    for t in v[a:]: s = s + x87('*', t, t)
    return s
def ls(cols, y, const, opt):
    n = len(y)
    means = [fmean(c) for c in cols]
    mats = []
    if const and opt['ones']: mats.append(('1', [1.0] * n))
    for i, c in enumerate(cols): mats.append((i, [v - means[i] for v in c] if const else c[:]))
    tgt = [v - fmean(y) for v in y] if const else y[:]
    scale = [sqf(c, 0) for _, c in mats]
    j = 0; counted = []
    while j < len(mats):
        if j >= n: mats = mats[:j]; break
        if mats[j][0] != '1':
            best = j; bs = None
            for k in range(j, len(mats)):
                if opt['crit'] == 'down':
                    s = scale[k]
                    for r in mats[k][1][:j]: s = s - r * r
                else: s = sqf(mats[k][1], j)
                if bs is None or s > bs or (opt['tie'] == 'last' and s == bs): bs = s; best = k
            if opt['move'] == 'swap':
                mats[j], mats[best] = mats[best], mats[j]; scale[j], scale[best] = scale[best], scale[j]
            else:
                m = mats.pop(best); s_ = scale.pop(best); mats.insert(j, m); scale.insert(j, s_)
        x0 = mats[j][1][j]; rest = sqf(mats[j][1], j + 1); squares = sqf(mats[j][1], j)
        before = scale[j]; rem = before
        for r in mats[j][1][:j]: rem = rem - r * r
        coll = before > 0 and mats[j][0] != '1' and rem < before * EPS
        if before > 0 and mats[j][0] != '1' and (squares == 0 or coll):
            if opt['stop'] == 'stop' or (opt['stop'] == 'stop-coll' and coll and squares != 0):
                mats = mats[:j]; break
            del mats[j]; del scale[j]; continue
        if squares == 0:
            counted.append(mats[j][0]); j += 1; continue
        alpha = -math.copysign(math.sqrt(squares), x0)
        v = [x87('-', x0, alpha)] + mats[j][1][j + 1:]
        vv = x87('+', rest, x87('*', v[0], v[0]))
        def refl(a):
            t = 0.0
            for vi, ai in zip(v, a[j:]): t = x87('+', t, x87('*', vi, ai))
            fct = x87('/', x87('*', 2.0, t), vv)
            for i in range(j, n): a[i] = x87('-', a[i], x87('*', fct, v[i - j]))
        for k in range(j + 1, len(mats)): refl(mats[k][1])
        refl(tgt); counted.append(mats[j][0]); j += 1
    ssr = 0.0
    for t in tgt[j:]: ssr = ssr + x87('*', t, t)
    p = len(counted) + (1 if const and not opt['ones'] else 0)
    return n - p, ssr
def load(fn):
    W = json.load(open('lin/%s.inputs.json' % fn))['witnesses']
    G = collections.defaultdict(dict)
    for w in W: G[json.dumps(w['args'])][tuple(w['result_index'])] = f(w['expected'])
    out = []
    for k, o in G.items():
        if (4, 2) not in o: continue
        a = json.loads(k); n = len(a[0]); X = [[f(v) for v in r] for r in a[1]]
        cols = [[X[i][j] for i in range(n)] for j in range(len(X[0]))]
        ys = [f(r[0]) for r in a[0]]
        if fn == 'LOGEST': ys = [math.log(v) for v in ys]
        out.append((cols, ys, a[2], o[(4, 2)], o.get((5, 2))))
    return out
if __name__ == '__main__':
    cases = load('LINEST')
    if len(sys.argv) > 1: cases = cases[::int(sys.argv[1])]
    for opt in [dict(ones=o, crit=c, tie=t, move=m, stop=s) for o in [True, False] for c in ['fresh', 'down'] for t in ['first', 'last'] for m in ['swap', 'rot'] for s in ['remove', 'stop', 'stop-coll']]:
        dfok = ssok = ssn = 0
        for cols, ys, const, edf, essr in cases:
            df, ssr = ls(cols, ys, const, opt)
            dfok += df == edf
            if isinstance(essr, float): ssn += 1; ssok += (abs(ssr - essr) <= 1e-12 * abs(essr)) if essr else ssr == 0
        print(opt, 'df %d/%d ssr %d/%d' % (dfok, len(cases), ssok, ssn), flush=True)
