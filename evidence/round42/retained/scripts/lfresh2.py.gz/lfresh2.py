"""Score builds on the fresh R42 regression replies and the retained cohorts."""
import json, sys, os, subprocess, collections
QD = '/home/ubuntu/codex-runs/r42/questions'; RD = '/home/ubuntu/codex-runs/claude-r42/fresh'; WK = '/home/ubuntu/codex-runs/r42/work'
build = sys.argv[1]; racer = '/home/ubuntu/codex-runs/r42/' + build
def norm_ans(row):
    if row.get('type') == 'number': return '0x' + row['bits']
    if row.get('type') == 'error': return 'error:' + {'#NUM!': 'Num', '#VALUE!': 'Value', '#REF!': 'Ref', '#N/A': 'NA', '#DIV/0!': 'Div0'}.get(row.get('code'), row.get('code'))
    return None
for qf in ['LINEST.questions.json', 'LOGEST.questions.json', 'LINEST.sign-questions.json', 'LINEST.zero-questions.json']:
    out = WK + '/fresh.%s.%s.jsonl' % (qf, build)
    subprocess.run([racer, 'invoke-inputs', QD + '/' + qf, out], check=True)
    P = {json.loads(l)['id']: json.loads(l)['calc_func_prediction'] for l in open(out)}
    ans = {}
    for ch in json.load(open(RD + '/' + qf.replace('.json', '.replies.json')))['replies']:
        for i, row in zip(ch['ids'], (ch['reply'] or {}).get('rows') or []): ans[i] = norm_ans(row)
    c = collections.Counter()
    for w in json.load(open(QD + '/' + qf))['witnesses']:
        t = w.get('tag', ''); c[t + ' n'] += 1; c[t + ' ok'] += ans.get(w['id']) is not None and ans.get(w['id']) == P[w['id']]
        c[t + ' unread'] += ans.get(w['id']) is None
    print(qf, dict(sorted(c.items())))
for fn in ['LINEST', 'LOGEST', 'R38L', 'R38G']:
    out = WK + '/lin/%s.%s.jsonl' % (fn, build)
    subprocess.run([racer, 'invoke-inputs', WK + '/lin/%s.inputs.json' % fn, out], check=True)
    W = {w['id']: w['expected'] for w in json.load(open(WK + '/lin/%s.inputs.json' % fn))['witnesses']}
    B = {json.loads(l)['id']: json.loads(l)['calc_func_prediction'] for l in open(WK + '/lin/%s.base.jsonl' % fn)}
    S = {json.loads(l)['id']: json.loads(l)['calc_func_prediction'] for l in open(out)}
    print(fn, 'base', sum(B[i] == e for i, e in W.items()), 'build', sum(S[i] == e for i, e in W.items()), 'of', len(W),
          'gains', sum(S[i] == e and B[i] != e for i, e in W.items()), 'losses', sum(S[i] != e and B[i] == e for i, e in W.items()))
