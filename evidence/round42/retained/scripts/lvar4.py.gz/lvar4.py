import sys
from lvar3 import ls
from lvar import load
cases = load(sys.argv[1])
if len(sys.argv) > 2: cases = cases[::int(sys.argv[2])]
for name, opt in [('rust-like', dict(center=True, ones='first', pivot_ones=False, move='swap', tie='first', crit='fresh', stop=True, sign='new')),
                  ('ones-last-pivoted', dict(center=True, ones='last', pivot_ones=True, move='swap', tie='first', crit='fresh', stop=True, sign='new')),
                  ('uncentred-ones-last', dict(center=False, ones='last', pivot_ones=True, move='swap', tie='first', crit='fresh', stop=True, sign='new'))]:
    dfok = ssok = ssn = 0
    for cols, ys, const, edf, essr in cases:
        cnt, ssr, onefit = ls(cols, ys, const, opt)
        df = len(ys) - len(cnt) - (1 if const else 0)
        dfok += df == edf
        if isinstance(essr, float): ssn += 1; ssok += (abs(ssr - essr) <= 1e-12 * abs(essr)) if essr else ssr == 0
    print(name, 'df %d/%d ssr %d/%d' % (dfok, len(cases), ssok, ssn), flush=True)
