import json, sys, struct, collections
f = lambda h: struct.unpack('<d', struct.pack('<Q', int(h, 16)))[0]
WK = '/home/ubuntu/codex-runs/r42/work'; fn, A, B = sys.argv[1:4]
W = {w['id']: w for w in json.load(open(WK + '/lin/%s.inputs.json' % fn))['witnesses']}
a = {json.loads(l)['id']: json.loads(l)['calc_func_prediction'] for l in open(WK + '/lin/%s.%s.jsonl' % (fn, A))}
b = {json.loads(l)['id']: json.loads(l)['calc_func_prediction'] for l in open(WK + '/lin/%s.%s.jsonl' % (fn, B))}
c = collections.Counter(); ex = []
for i, w in W.items():
    e = w['expected']
    if a[i] == e and b[i] != e:
        ar = w['args']; n = len(ar[0]); X = [[f(v) for v in r] for r in ar[1]]; k = len(X[0])
        cols = [[X[r][j] for r in range(n)] for j in range(k)]
        z = tuple(j for j in range(k) if all(v == 0 for v in cols[j]))
        ints = all(v == round(v) for cc in cols for v in cc)
        c[(n, k, ar[2], z, 'int' if ints else 'pert', str(w['result_index']))] += 1
        if len(ex) < 3: ex.append((n, ar[2], [cc[:4] for cc in cols], w['result_index'], f(e) if e.startswith('0x') else e, f(b[i]) if b[i].startswith('0x') else b[i]))
for k, v in c.most_common(25): print(v, k)
for e in ex: print(e)
