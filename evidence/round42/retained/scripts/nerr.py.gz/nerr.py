import sys, json, struct, numpy as np, mpmath as mp
from scipy.special import ndtri
mp.mp.dps = 50
def f(b): return struct.unpack('<d', struct.pack('<Q', int(b)))[0]
def ulp(x):
    import math
    return math.ulp(x)
A = np.load('normal-dense-outputs.npz')['answers']; V = np.load('normal-dense-validity.npz')['numeric']
W = json.load(open('normal-dense-frozen.json'))['windows']
def true_q(p):
    x = mp.mpf(ndtri(p))
    pm = mp.mpf(p)
    for _ in range(3):
        x = x - (mp.ncdf(x) - pm) / mp.npdf(x)
    return x
step = int(sys.argv[1]) if len(sys.argv) > 1 else 64
out = []
for i, w in enumerate(W):
    s = int(w['start'], 16)
    errs = []
    for j in range(0, w['count'], step):
        if not V[i, j]: continue
        p = f(s + j); xe = f(A[i, j])
        xt = true_q(p)
        errs.append(float((mp.mpf(xe) - xt) / ulp(float(xt))))
    e = np.array(errs)
    if len(e)==0: out.append((i, w['region'], w['start'], 0)); continue
    print(i, w['region'], w['start'], '%.6g' % f(s), len(e), 'mean %.2f sd %.2f min %.2f max %.2f |e|<=.5: %.2f' % (e.mean(), e.std(), e.min(), e.max(), (abs(e) <= 0.5).mean()), flush=True)
