"""Hypothesis: central NORM.S.INV = sqrt2 * erfinv(2q), erfinv refined by Newton steps on Excel's ERF.
Initial approximation unknown: use the true erfinv perturbed by a smooth relative 1e-8, two steps."""
import sys, math, numpy as np, mpmath as mp
from nlib import *
mp.mp.dps = 40
A, V, W = load()
c = 2 / math.sqrt(math.pi)
s2 = math.sqrt(2.0)
wins = [int(x) for x in sys.argv[1].split(',')]
for i in wins:
    s = int(W[i]['start'], 16)
    pts = [(f(s + j), f(A[i, j])) for j in range(0, 8192, 16) if V[i, j]]
    ts = [2 * (p - 0.5) for p, _ in pts]
    x = [float(mp.erfinv(mp.mpf(t))) * (1 + 1e-8) for t in ts]
    for step in range(2):
        out = invoke([('ERF', [v]) for v in x] + [('EXP', [-(v * v)]) for v in x])
        n = len(x); erf = out[:n]; ex = out[n:]
        x = [v - (e - t) / (c * g) for v, e, t, g in zip(x, erf, ts, ex)]
    res = [v * s2 for v in x]
    errs = []; m = 0
    for (p, xe), r in zip(pts, res):
        tq = mp.sqrt(2) * mp.erfinv(2 * (mp.mpf(p) - mp.mpf(0.5)))
        errs.append(float((mp.mpf(r) - tq) / math.ulp(float(tq)))); m += bits(r) == bits(xe)
    e = np.array(errs)
    print(i, '%.4f' % pts[0][0], 'model mean %+.2f sd %.2f' % (e.mean(), e.std()), 'exact matches', m, 'of', len(pts))
