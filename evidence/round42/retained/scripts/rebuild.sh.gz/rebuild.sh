#!/bin/bash
# rebuild.sh <outname>: bind every changed application file into round42-candidates-unit.json, build, copy binary
set -e
cd ~/projects/DnaCalc/DnaCalc-Research
python3 - <<"PY"
import json, subprocess
main = "/home/ubuntu/projects/DnaCalc/DnaCalc"
changed = subprocess.run(["git", "-C", main, "diff", "--name-only", "HEAD", "--", "crates/calc-func/src", "crates/calc-value/src", "tools/calc-verdict/src", "apps", "crates"], capture_output=True, text=True).stdout.split()
u = json.load(open("round42-candidates-unit.json"))
u["application_working_blobs"] = {p: subprocess.run(["git", "-C", main, "hash-object", p], capture_output=True, text=True).stdout.strip() for p in changed}
json.dump(u, open("round42-candidates-unit.json", "w"), indent=2); open("round42-candidates-unit.json", "a").write("\n")
print(u["application_working_blobs"])
PY
export TMPDIR=~/codex-runs/r42/tmp PATH=~/.cargo/bin:$PATH
DNA_RESEARCH_UNIT=round42-candidates-unit.json cargo build --release -q 2>&1 | grep -E "^error|panicked" -A3 | head -20 || true
cp target/release/symbolic-racer ~/codex-runs/r42/$1
