import numpy as np, math
from fractions import Fraction as Fr
exec(open("nnoise.py").read().split("wins = ")[0])
C=Fr(2.5066282746310006857)
for i in [64,0,19,65]:
    s0=int(W[i]["start"],16); rows=[]
    for j in range(0,8192,1):
        if not V_[i,j]: continue
        p=f(s0+j); q=p-0.5; x=f(A_[i,j])
        if q==0: continue
        # error of x vs RN(q*C) in ulps, and fractional position of q*C within ulp grid
        e=Fr(q)*C; u=Fr(math.ulp(float(e)))
        rows.append((float((Fr(x)-e)/u), float(q)))
    r=np.array(rows)
    # bin by q
    qs=r[:,1]; es=r[:,0]
    order=np.argsort(np.abs(qs)); n=len(order)
    for k in range(4):
        sel=order[k*n//4:(k+1)*n//4]
        e=es[sel]
        print(i,"|q| %.2e-%.2e"%(abs(qs[sel]).min(),abs(qs[sel]).max()),"err mean %+.3f sd %.3f  |err|>0.5: %.3f"%(e.mean(),e.std(),(abs(e)>0.5).mean()))
