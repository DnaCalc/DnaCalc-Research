import sys, math, json, struct, collections, itertools
from x87e import x87
EPS = 2.0 ** -41
def fmean(v):
    s = 0.0
    for t in v: s = s + t
    return s / len(v)
def sqf(v, a):
    s = 0.0
    for t in v[a:]: s = s + x87('*', t, t)
    return s
def ls(cols, y, const, opt):
    """opt: center(bool), ones('first'|'last'|None), pivot_ones(bool), move, tie, crit, stop"""
    n = len(y)
    means = [fmean(c) for c in cols] if (const and opt['center']) else [0.0] * len(cols)
    mats = [(i, [v - means[i] for v in c]) for i, c in enumerate(cols)]
    if const:
        if opt['ones'] == 'first': mats.insert(0, ('1', [1.0] * n))
        else: mats.append(('1', [1.0] * n))
    tgt = [v - fmean(y) for v in y] if (const and opt['center']) else y[:]
    scale = [sqf(c, 0) for _, c in mats]
    j = 0; counted = []
    while j < len(mats):
        if j >= n: mats = mats[:j]; break
        fixed = (mats[j][0] == '1' and not opt['pivot_ones'])
        if not fixed:
            best = j; bs = None
            for k in range(j, len(mats)):
                if mats[k][0] == '1' and not opt['pivot_ones']: continue
                if opt['crit'] == 'down':
                    s = scale[k]
                    for r in mats[k][1][:j]: s = s - r * r
                else: s = sqf(mats[k][1], j)
                if bs is None or s > bs or (opt['tie'] == 'last' and s == bs): bs = s; best = k
            if opt['move'] == 'swap':
                mats[j], mats[best] = mats[best], mats[j]; scale[j], scale[best] = scale[best], scale[j]
            else:
                m = mats.pop(best); s_ = scale.pop(best); mats.insert(j, m); scale.insert(j, s_)
        x0 = mats[j][1][j]; rest = sqf(mats[j][1], j + 1); squares = sqf(mats[j][1], j)
        before = scale[j]; rem = before
        for r in mats[j][1][:j]: rem = rem - r * r
        isone = mats[j][0] == '1'
        coll = before > 0 and rem < before * EPS
        if before > 0 and (squares == 0 or coll):
            if opt['stop']:
                mats = mats[:j]; break
            del mats[j]; del scale[j]; continue
        if squares == 0:
            counted.append(mats[j][0]); j += 1; continue
        alpha = -math.copysign(math.sqrt(squares), x0)
        v = [x87('-', x0, alpha)] + mats[j][1][j + 1:]
        vv = x87('+', rest, x87('*', v[0], v[0]))
        def refl(a):
            t = 0.0
            for vi, ai in zip(v, a[j:]): t = x87('+', t, x87('*', vi, ai))
            fct = x87('/', x87('*', 2.0, t), vv)
            for i in range(j, n): a[i] = x87('-', a[i], x87('*', fct, v[i - j]))
        for k in range(j + 1, len(mats)): refl(mats[k][1])
        refl(tgt); counted.append(mats[j][0]); j += 1
    ssr = 0.0
    for t in tgt[j:]: ssr = ssr + x87('*', t, t)
    return [c for c in counted if c != '1'], ssr, ('1' in counted)
EXP = {(False, '[0,2xa,xa]'): {4: 2, 8: 1, 16: 2, 32: 1}, (False, '[0,2xd,xd]'): {4: 1, 8: 2, 16: 2, 32: 1}}
for lay in ['[0,xa,2xa]', '[0,xd,2xd]', '[2xa,xa,0]', '[2xd,xd,0]', '[xa,2xa,0]', '[xd,2xd,0]']: EXP[(False, lay)] = {n: 1 for n in (4, 8, 16, 32)}
for lay in ['[0,2xa,xa]', '[0,2xd,xd]', '[0,xa,2xa]', '[0,xd,2xd]']: EXP[(True, lay)] = {n: 1 for n in (4, 8, 16, 32)}
for lay in ['[2xa,xa,0]', '[2xd,xd,0]', '[xa,2xa,0]', '[xd,2xd,0]']: EXP[(True, lay)] = {n: 2 for n in (4, 8, 16, 32)}
def build(lay, n):
    out = []
    for t in lay.strip('[]').split(','):
        if t == '0': out.append([0.0] * n); continue
        base = list(range(1, n + 1)) if t.endswith('a') else list(range(n, 0, -1))
        out.append([float(2 * v if t.startswith('2') else v) for v in base])
    return out
if __name__ == '__main__':
    opts = [dict(center=c, ones=o, pivot_ones=po, move=m, tie=t, crit=cr, stop=s)
            for c in [True, False] for o in ['first', 'last'] for po in [False, True] for m in ['swap', 'rot']
            for t in ['first', 'last'] for cr in ['fresh', 'down'] for s in [True, False]]
    res = []
    for opt in opts:
        ok = tot = 0
        for (const, lay), d in EXP.items():
            for n, e in d.items():
                y = [1.0] + [0.0] * (n - 1)
                cnt, ssr, onefit = ls(build(lay, n), y, const, opt)
                tot += 1; ok += (len(cnt) == e) and (onefit or not const)
        res.append((ok, tot, opt))
    res.sort(key=lambda t: -t[0])
    for r in res[:15]: print(r)
