import math, sys
from fractions import Fraction as Fr
exec(open('nhalf2.py').read().split("consts = {")[0])
from x87e import rn
import mpmath as mp
mp.mp.dps = 40
K = Fr(float(mp.sqrt(mp.pi) / 2)); c = Fr(float(2 / mp.sqrt(mp.pi))); s2 = Fr(math.sqrt(2.0))
R53 = lambda v: rn(v, 53); R64 = lambda v: rn(v, 64)
for name, m in [('t*K', lambda q: R53(R64(R53(R64(2 * Fr(q) * K)) * s2))),
                ('t/c', lambda q: R53(R64(R53(R64(2 * Fr(q) / c)) * s2))),
                ('q*2K', lambda q: R53(R64(R53(R64(Fr(q) * 2 * K)) * s2)))]:
    print(name, 'mismatches', sum(float(m(q)) != x for q, x in pts), 'of', len(pts), flush=True)
