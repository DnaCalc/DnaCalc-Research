import json, gzip, math, collections, struct
exec(open('ntail2.py').read().split("k = 0; res")[0])
R = '/home/ubuntu/projects/DnaCalc/DnaCalc-Research/evidence/round39/retained/'
pairs = []
for fn in ['step6-normal-upper-fresh-answers', 'step6-normal-upper-mapping-answers', 'step6-normal-tail-answers']:
    d = json.load(gzip.open(R + fn + '.json.gz'))
    ks = list(d.keys())
    ans = d.get('answers')
    for p, a in zip(d['points'], ans):
        if isinstance(a, dict) and a.get('bits'): pairs.append((p, int(a['bits'], 16)))
for fn in ['normal-upper-route-inputs', 'normal-upper-route-v2-inputs', 'normal-upper-route-v3-inputs']:
    d = json.load(gzip.open(R + fn + '.json.gz'))
    for w in d['witnesses']: pairs.append((f(int(w['args'][0], 16)), int(w['expected'], 16)))
def tailu(p, mode):
    t = 1.0 - p if p > 0.5 else p
    r = math.sqrt(-math.log(t))
    if r <= 5: rr = r - 1.6; cs = (C, D)
    else: rr = r - 5.0; cs = (E, F)
    N, Dd = horner(cs[0], rr, mode), horner(cs[1], rr, mode)
    v = x87op(N, Dd, '/') if mode == 'x87store' else N / Dd
    return v if p > 0.5 else -v
res = collections.Counter(); n = 0
for p, a in pairs:
    if not (p > 15 / 16): continue
    n += 1
    for m in ['dbl', 'x87store']: res[m] += bits(tailu(p, m)) == a
print('upper > 15/16 answers', n, dict(res))
