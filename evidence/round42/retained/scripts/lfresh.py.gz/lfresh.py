import json, sys, collections, struct, math
from lvar3 import ls
f = lambda h: struct.unpack('<d', struct.pack('<Q', int(h, 16)))[0]
QD = '/home/ubuntu/codex-runs/r42/questions'; RD = '/home/ubuntu/codex-runs/claude-r42/fresh'
Q = json.load(open(QD + '/LINEST.questions.json'))['witnesses']
ans = {}
for ch in json.load(open(RD + '/LINEST.questions.replies.json'))['replies']:
    for i, row in zip(ch['ids'], (ch['reply'] or {}).get('rows') or []):
        ans[i] = f(row['bits']) if row.get('type') == 'number' else None
cases = []
for w in Q:
    if w['result_index'] != [4, 2] or ans.get(w['id']) is None: continue
    a = w['args']; n = len(a[0]); X = [[f(v) for v in r] for r in a[1]]
    cases.append((w['tag'], [[X[i][j] for i in range(n)] for j in range(len(X[0]))], [f(r[0]) for r in a[0]], a[2], ans[w['id']]))
base = dict(center=True, ones='first', pivot_ones=False, move='swap', tie='first', sign='new')
for name, extra in [('stop-fresh', dict(crit='fresh', stop=True)), ('stop-down', dict(crit='down', stop=True)), ('cont-fresh', dict(crit='fresh', stop=False)), ('cont-down', dict(crit='down', stop=False))]:
    opt = dict(base, **extra); c = collections.Counter()
    for tag, cols, ys, const, edf in cases:
        cnt, ssr, one = ls(cols, ys, const, opt)
        df = len(ys) - len(cnt) - (1 if const else 0)
        c[tag] += df == edf; c[tag + 'n'] += 1
    print(name, {t: '%d/%d' % (c[t], c[t + 'n']) for t in ['D1', 'D2', 'D3']})
