import math, sys
from fractions import Fraction as Fr
exec(open('nhalf2.py').read().split("consts = {")[0])
from x87e import rn
import mpmath as mp
mp.mp.dps = 40
b = math.sqrt(2.0)
def feas_run(points, final):
    feas = None
    for idx, (q, x) in enumerate(points):
        if final == 'strict': ys = preimage_doubles(x, b, '*')
        else:
            # y doubles with RN53(RN64(y*b)) == x
            y0 = x / b; ys = []
            for k in range(-3, 4):
                c = f(bits(y0) + k)
                if float(rn(rn(Fr(c) * Fr(b), 64), 53)) == x: ys.append(c)
        ivs = [a_interval(y, q) for y in ys]
        new = ivs if feas is None else [(max(l1, l2), min(h1, h2)) for (l1, h1) in feas for (l2, h2) in ivs if max(l1, l2) <= min(h1, h2)]
        if not new: return idx, feas
        feas = new
    return None, feas
for final in ['strict', 'x87']:
    idx, feas = feas_run(pts, final)
    print(final, 'fail index', idx, 'of', len(pts))
    for l, h in feas:
        print('   a in [%s, %s]' % (mp.nstr(mp.mpf(l.numerator) / l.denominator, 25), mp.nstr(mp.mpf(h.numerator) / h.denominator, 25)))
print('sqrt(pi) =', mp.nstr(mp.sqrt(mp.pi), 25))
