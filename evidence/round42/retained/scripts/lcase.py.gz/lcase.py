import json, struct, collections, math
from x87e import x87
f = lambda h: struct.unpack('<d', struct.pack('<Q', int(h, 16)))[0]
WK = '/home/ubuntu/codex-runs/r42/work'
W = json.load(open(WK + '/lin/LINEST.inputs.json'))['witnesses']
seen = set()
for w in W:
    a = w['args']; n = len(a[0])
    if n != 5 or not a[2] or len(a[1][0]) != 2: continue
    X = [[f(v) for v in r] for r in a[1]]; cols = [[X[i][j] for i in range(n)] for j in range(2)]
    key = json.dumps(cols)
    if key in seen: continue
    seen.add(key)
    # centred, ones reflection
    def fmean(v):
        s = 0.0
        for t in v: s += t
        return s / n
    cc = [[v - fmean(c) for v in c] for c in cols]
    sq = lambda v, a0: sum(x87('*', t, t) for t in v[a0:]) if False else None
    def sqf(v, a0):
        s = 0.0
        for t in v[a0:]: s = s + x87('*', t, t)
        return s
    init = [sqf(c, 0) for c in cc]
    ones = [1.0] * n; alpha = -math.sqrt(n); v = [x87('-', 1.0, alpha)] + ones[1:]
    vv = x87('+', sqf(ones, 1), x87('*', v[0], v[0]))
    def refl(col):
        t = 0.0
        for vi, ai in zip(v, col): t = x87('+', t, x87('*', vi, ai))
        fct = x87('/', x87('*', 2.0, t), vv)
        return [x87('-', ai, x87('*', fct, vi)) for ai, vi in zip(col, v)]
    rc = [refl(c) for c in cc]
    fresh = [sqf(c, 1) for c in rc]; down = [init[k] - rc[k][0] * rc[k][0] for k in range(2)]
    print('cols(units 2^-20)', [[round(x * 2**20, 3) for x in c] for c in cols], 'init', init, 'fresh', fresh, 'down', down, 'fresh picks', 0 if fresh[0] >= fresh[1] else 1, 'down picks', 0 if down[0] >= down[1] else 1)
    if len(seen) > 8: break
