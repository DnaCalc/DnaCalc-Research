"""R42 frozen fresh questions for the zero-diagonal reflection sign: designs whose pivot entry is
exactly zero after the ones column's step (symmetric x around its mean, the first entry at the mean
after centring), random scales and y; both constants."""
import json, random, struct, sys
def hx(x): return '0x%016x' % struct.unpack('<Q', struct.pack('<d', x))[0]
rng = random.Random(4202)
cases = []
for t in range(96):
    n = rng.choice([3, 4, 5, 6, 8])
    scale = 2.0 ** rng.randint(-20, 20) * rng.choice([1.0, 3.0, 0.5])
    half = [rng.randint(1, 9) for _ in range(n // 2)]
    xs = []
    for h in half: xs += [h, -h]
    if n % 2: xs.append(0)
    rng.shuffle(xs)
    if rng.random() < 0.5:
        # make the first entry sit exactly at the mean
        z = xs.index(0) if 0 in xs else None
        if z is not None: xs[0], xs[z] = xs[z], xs[0]
    x = [scale * v for v in xs]
    y = [float(rng.randint(-9, 9)) for _ in range(n)]
    cases.append(dict(args=[[[hx(v)] for v in y], [[hx(v)] for v in x], rng.random() < 0.8, True]))
ws = []
for ci, c in enumerate(cases):
    for r, cc in [(1, 1), (2, 1), (3, 2), (5, 2), (2, 2), (1, 2)]:
        ws.append(dict(id='S%d:%d:%d' % (ci, r, cc), tag='D4', args=c['args'], result_index=[r, cc]))
json.dump(dict(function='LINEST', witnesses=ws), open(sys.argv[1] + '/LINEST.sign-questions.json', 'w'))
print(len(ws))
