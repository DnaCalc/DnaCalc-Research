import math, collections, sys
import mpmath as mp
mp.mp.dps = 50
exec(open('ntail2.py').read().split("k = 0; res")[0])
def tail_v(p, rmode, hmode):
    if rmode == 'dbl': r = math.sqrt(-math.log(p)); rr = (r - 1.6) if r <= 5 else (r - 5.0); big = r > 5
    else:
        L = -mp.log(mp.mpf(p))
        if rmode == 'log53': L = mp.mpf(float(L))
        R = mp.sqrt(L)
        Rf = Fr(mp.nstr(R, 45)) if True else None
        R64 = rn(Rf, 64) if rmode in ('ext', 'log53') else rn(Rf, 53)
        big = R64 > 5
        rr = float(rn(R64 - (Fr(5) if big else Fr(1.6)), 53))
    cs = (E, F) if big else (C, D)
    N, Dd = horner(cs[0], rr, hmode), horner(cs[1], rr, hmode)
    return -x87op(N, Dd, '/') if hmode == 'x87store' else -(N / Dd)
c = [l.strip() for l in open('norm.cand.out')]
k = 0; res = collections.Counter(); n = 0
for i, w in enumerate(W):
    s = int(w['start'], 16)
    for j in range(w['count']):
        if i == int(sys.argv[1]) and V[i, j]:
            p = f(s + j); e = '0x%016x' % int(A[i, j]); n += 1
            for rm in ['dbl', 'crt53', 'ext', 'log53']:
                for hm in ['dbl', 'x87store']:
                    res[(rm, hm)] += '0x%016x' % bits(tail_v(p, rm, hm)) == e
        k += 1
print(n, sorted(res.items(), key=lambda t: -t[1]))
