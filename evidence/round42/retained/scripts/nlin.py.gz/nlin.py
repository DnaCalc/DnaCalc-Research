import numpy as np, math
from fractions import Fraction as Fr
exec(open("nnoise.py").read().split("wins = ")[0])
ivs=[]
for i in [0,64]:
    s0=int(W[i]["start"],16)
    for j in range(0,8192,2):
        if not V_[i,j]: continue
        p=f(s0+j); q=p-0.5; x=f(A_[i,j])
        if q==0: continue
        u=math.ulp(x)/2
        lo=(Fr(x)-Fr(u))/Fr(q); hi=(Fr(x)+Fr(u))/Fr(q)
        if lo>hi: lo,hi=hi,lo
        ivs.append((lo,hi))
# sweep: find C maximizing number of intervals containing C
ev=[]
for lo,hi in ivs: ev.append((lo,1)); ev.append((hi,-1))
ev.sort(key=lambda t:(t[0],-t[1]))
best=0;cur=0;bc=None
for v,d in ev:
    cur+=d
    if cur>best: best=cur; bc=v
print(len(ivs),"max consistent",best,"at C=%.20g"%float(bc), "sqrt2pi=%.20g"%math.sqrt(2*math.pi))
print("C - sqrt(2pi) rel = %.3e"%(float(bc)/math.sqrt(2*math.pi)-1))
