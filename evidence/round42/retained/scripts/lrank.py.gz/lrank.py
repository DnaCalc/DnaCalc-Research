import json, gzip, collections, struct, math, sys
R = '/home/ubuntu/projects/DnaCalc/DnaCalc-Research/evidence/round41/retained/regression-after-route/'
def f(h): return struct.unpack('<d', struct.pack('<Q', int(h, 16)))[0] if isinstance(h, str) and h.startswith('0x') else h
def cases(fn):
    W = json.load(gzip.open(R + fn + '.inputs.json.gz'))['witnesses']
    P = {}
    for l in gzip.open(R + fn + '.predictions.jsonl.gz'):
        r = json.loads(l); P[r['id']] = r['calc_func_prediction']
    G = collections.defaultdict(dict)
    for w in W:
        G[json.dumps(w['args'])][tuple(w['result_index'])] = (f(w['expected']), f(P[w['id']]))
    for k, outs in G.items():
        a = json.loads(k)
        ys = [f(r[0]) for r in a[0]]; X = [[f(v) for v in r] for r in a[1]]
        yield ys, X, a[2], outs
EPS = 2.0 ** -41
def fit(ys, X, const, rule):
    n = len(ys); k = len(X[0])
    cols = [[X[i][j] for i in range(n)] for j in range(k)]
    mean = lambda v: sum(v) / n
    if const:
        mats = [(None, [1.0] * n)] + [(j, [v - mean(c) for v in c]) for j, c in enumerate(cols)]
        y = [v - mean(ys) for v in ys]
    else:
        mats = [(j, c[:]) for j, c in enumerate(cols)]; y = ys[:]
    sq = lambda v, a: sum(t * t for t in v[a:])
    scale = [sq(c, 0) for _, c in mats]
    j = 0; dropped = []; counted = []; stopped = False; diag = []
    while j < len(mats):
        if j >= n: dropped += [m[0] for m in mats[j:]]; mats = mats[:j]; break
        if stopped:
            dropped += [m[0] for m in mats[j:]]; mats = mats[:j]; break
        if mats[j][0] is not None:
            best = j; bs = -1.0
            for kk in range(j, len(mats)):
                if rule.get('pivotby') == 'down':
                    s = scale[kk]
                    for t in mats[kk][1][:j]: s -= t * t
                else:
                    s = sq(mats[kk][1], j)
                if (s > bs) if rule.get('pivot') != 'last' else (s >= bs): bs = s; best = kk
            mats[j], mats[best] = mats[best], mats[j]; scale[j], scale[best] = scale[best], scale[j]
        col = mats[j][1]; x0 = col[j]; squares = sq(col, j)
        before = scale[j]
        rem = before
        for t in col[:j]: rem -= t * t
        collinear = before > 0 and mats[j][0] is not None and rem < before * EPS
        if before > 0 and mats[j][0] is not None and (squares == 0 or collinear):
            dropped.append(mats[j][0]); del mats[j]; del scale[j]
            if rule.get('after') == 'stop': stopped = True
            if rule.get('after') == 'dropzero': rule = dict(rule, dropzero=True)
            continue
        if squares == 0:
            if rule.get('dropzero') and mats[j][0] is not None:
                dropped.append(mats[j][0]); del mats[j]; del scale[j]; continue
            counted.append(mats[j][0]); diag.append(0.0); j += 1; continue
        norm = math.sqrt(squares); alpha = -math.copysign(norm, x0)
        v = col[j:]; v = [x0 - alpha] + v[1:]
        vv = sum(t * t for t in v)
        def refl(a):
            t = sum(vi * ai for vi, ai in zip(v, a[j:])); fct = 2 * t / vv
            for i in range(j, n): a[i] -= fct * v[i - j]
        for kk in range(j + 1, len(mats)): refl(mats[kk][1])
        refl(y); counted.append(mats[j][0]); diag.append(alpha); j += 1
    rows = j
    ssr = sum(t * t for t in y[rows:])
    return n - len(counted), ssr, set(d for d in dropped if d is not None)
def score(fn, rule, show=0):
    tot = collections.Counter(); ok = collections.Counter(); shown = 0
    for ys, X, const, outs in cases(fn):
        if (4, 2) not in outs: continue
        df, ssr, dropped = fit(ys, X, const, dict(rule))
        e_df = outs[(4, 2)][0]
        tot['df'] += 1; ok['df'] += (df == e_df)
        if (5, 2) in outs and isinstance(outs[(5, 2)][0], float):
            e = outs[(5, 2)][0]; tot['ssr'] += 1
            ok['ssr'] += abs(ssr - e) <= 1e-9 * max(abs(e), 1e-300) or (e == 0 and abs(ssr) < 1e-20)
        if df != e_df and shown < show:
            shown += 1; print('   MISS', 'n', len(ys), 'const', const, 'cols', [[X[i][j] for i in range(len(ys))] for j in range(len(X[0]))][:3], 'excel', e_df, 'model', df)
    return {k: '%d/%d' % (ok[k], tot[k]) for k in tot}
if __name__ == '__main__':
    for rule in [{}, {'after': 'stop'}, {'after': 'stop', 'pivotby': 'down'}, {'after': 'dropzero', 'pivotby': 'down'}, {'pivotby': 'down'}]:
        print(rule, 'LINEST', score('LINEST', rule, int(sys.argv[1]) if len(sys.argv) > 1 else 0))
