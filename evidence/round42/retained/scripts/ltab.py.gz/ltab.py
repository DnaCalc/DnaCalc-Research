import json, sys, struct, collections
def f(h): return struct.unpack('<d', struct.pack('<Q', int(h, 16)))[0] if isinstance(h, str) and h.startswith('0x') else h
fn = sys.argv[1]
W = {w['id']: w for w in json.load(open('lin/%s.inputs.json' % fn))['witnesses']}
a = {json.loads(l)['id']: json.loads(l)['calc_func_prediction'] for l in open('lin/%s.base.jsonl' % fn)}
b = {json.loads(l)['id']: json.loads(l)['calc_func_prediction'] for l in open('lin/%s.stop.jsonl' % fn)}
groups = collections.defaultdict(dict)
for i, w in W.items(): groups[json.dumps(w['args'])][tuple(w['result_index'])] = (w['expected'], a[i], b[i])
tab = collections.Counter()
for k, outs in groups.items():
    args = json.loads(k); n = len(args[0]); X = [[f(v) for v in r] for r in args[1]]
    cols = [[X[i][j] for i in range(n)] for j in range(len(X[0]))]
    z = tuple(j for j in range(len(cols)) if all(v == 0 for v in cols[j]))
    if not z: continue
    nz = [c for c in cols if any(cols)]
    pert = 'exact' if all(abs(c[-1] - round(c[-1])) == 0 for c in cols) else 'pert'
    big = tuple(int(max(abs(v) for v in c)) for c in cols)
    def ok(m): return all(v[0] == v[m] for idx, v in outs.items() if idx in ((4, 2), (5, 2)))
    tab[(args[2], z, big, pert, n, 'base' if ok(1) else '-', 'stop' if ok(2) else '-')] += 1
for k, v in sorted(tab.items(), key=str): print(v, k)
