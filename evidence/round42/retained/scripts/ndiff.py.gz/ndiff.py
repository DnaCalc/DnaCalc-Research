import math, numpy as np
exec(open("nnoise.py").read().split("wins = ")[0])
import sys
for i in [int(x) for x in sys.argv[1].split(",")]:
    s0=int(W[i]["start"],16); d=[]
    for j in range(0,8192,8):
        p=f(s0+j); c=cands(p)["as241_qsq"]; e=f(A_[i,j]); d.append((e-c)/math.ulp(e))
    d=np.array(d); u,cn=np.unique(d,return_counts=True)
    print(i,"%.4f"%f(s0),"excel-qsq mean %.2f sd %.2f"%(d.mean(),d.std()), dict(zip(u[:12],cn[:12])) if len(u)<12 else "")
