import sys, math, numpy as np, mpmath as mp
from fractions import Fraction as Fr
from nlib import *
from scipy.special import ndtri
mp.mp.dps = 40
A_, V_, W = load()
def tq(p):
    x = mp.mpf(ndtri(p)); pm = mp.mpf(p)
    for _ in range(2): x = x - (mp.ncdf(x) - pm) / mp.npdf(x)
    return x
# expanded AS241 central into q^2 basis (exact rational expansion, rounded to double)
def expand(c):
    # c highest-first in r; r = 0.180625 - s ; return highest-first in s
    cr = [Fr(v) for v in c][::-1]  # lowest first
    k = Fr(180625, 1000000)
    out = [Fr(0)] * len(cr)
    from math import comb
    for n, a in enumerate(cr):
        for m in range(n + 1):
            out[m] += a * comb(n, m) * k ** (n - m) * (-1) ** m
    return [float(v) for v in out][::-1]
EN = expand(AS[0]); ED = expand(AS[1])
ACK_A=[-3.969683028665376e1,2.209460984245205e2,-2.759285104469687e2,1.383577518672690e2,-3.066479806614716e1,2.506628277459239]
ACK_B=[-5.447609879822406e1,1.615858368580409e2,-1.556989798598866e2,6.680131188771972e1,-1.328068155288572e1,1.0]
BS_A=[-25.44106049637,41.39119773534,-18.61500062529,2.50662823884]
BS_B=[3.13082909833,-21.06224101826,23.08336743743,-8.47351093090,1.0]
def cands(p):
    q = p - 0.5; s = q*q; r = 0.180625 - s
    return {
      'as241': q*horner(AS[0], r)/horner(AS[1], r),
      'as241_qsq': q*horner(EN, s)/horner(ED, s),
      'acklam': q*horner(ACK_A, s)/horner(ACK_B, s),
      'bsm': q*horner(BS_A, s)/horner(BS_B, s),
    }
wins = [int(x) for x in sys.argv[1].split(',')]
for i in wins:
    s0 = int(W[i]['start'], 16); E = {}
    for j in range(0, 8192, 32):
        p = f(s0+j); t = tq(p); u = math.ulp(float(t))
        E.setdefault('excel', []).append(float((mp.mpf(f(A_[i, j])) - t)/u))
        for k, v in cands(p).items(): E.setdefault(k, []).append(float((mp.mpf(v) - t)/u))
    print(i, '%.4f' % f(s0), '  '.join('%s %.2f/%.2f' % (k, np.mean(v), np.std(v)) for k, v in E.items()))
