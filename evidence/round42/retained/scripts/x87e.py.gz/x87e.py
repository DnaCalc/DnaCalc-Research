from fractions import Fraction as Fr
import math
def rn(x, p):
    """round Fraction x to p-bit mantissa, nearest-even, unbounded exponent (normal range)"""
    if x == 0: return Fr(0)
    s = -1 if x < 0 else 1; a = abs(x)
    e = a.numerator.bit_length() - a.denominator.bit_length()
    if Fr(2) ** e > a: e -= 1
    # a in [2^e, 2^(e+1))
    scale = Fr(2) ** (e - p + 1)
    q = a / scale
    n = q.numerator // q.denominator; r = q - n
    if r > Fr(1, 2) or (r == Fr(1, 2) and n % 2 == 1): n += 1
    return s * n * scale
def d(x): return float(rn(Fr(x), 53))
def x87(op, a, b):
    a = Fr(a); b = Fr(b)
    if op == '+': v = a + b
    elif op == '-': v = a - b
    elif op == '*': v = a * b
    else: v = a / b
    return float(rn(rn(v, 64), 53))
