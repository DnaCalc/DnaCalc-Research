import sys, math, collections
from nlib import *
A, V, W = load()
for i in [int(x) for x in sys.argv[1].split(',')]:
    s = int(W[i]['start'], 16)
    pts = [(f(s + j), f(A[i, j])) for j in range(0, 8192, 8) if V[i, j]]
    rows = []
    for p, xe in pts:
        x0 = as241(p); rows += [('NORM.S.DIST', [x0, 'T']), ('NORM.S.DIST', [x0, 'F'])]
    out = invoke(rows)
    for name, fn in [('newton', lambda x0, P, d, p: x0 - (P - p) / d), ('newton_tail', lambda x0, P, d, p: x0 + ((1 - P) - (1 - p)) / d)]:
        h = collections.Counter()
        for n, (p, xe) in enumerate(pts):
            x0 = as241(p); P, d = out[2*n], out[2*n+1]
            v = fn(x0, P, d, p); h[(bits(xe) - bits(v))] += 1
        print(i, '%.4f' % pts[0][0], name, sorted(h.items())[:12])
    h = collections.Counter(bits(xe) - bits(as241(p)) for p, xe in pts)
    print(i, 'excel-as241', sorted(h.items()))
