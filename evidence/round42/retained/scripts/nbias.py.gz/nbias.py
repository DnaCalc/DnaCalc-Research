import sys, json, struct, math, numpy as np, mpmath as mp
from scipy.special import ndtri
from nlib import load, f
mp.mp.dps = 40
A, V, W = load()
def tq(p):
    x = mp.mpf(ndtri(p)); pm = mp.mpf(p)
    for _ in range(2): x = x - (mp.ncdf(x) - pm) / mp.npdf(x)
    return x
rows = []
for i, w in enumerate(W):
    s0 = int(w["start"], 16); p0 = f(s0 + 4096)
    if not (0.075 < p0 < 0.925): continue
    e = []; er = []
    for j in range(0, 8192, 8):
        if not V[i, j]: continue
        p = f(s0 + j); x = f(A[i, j])
        if p == 0.5: continue
        t = tq(p)
        e.append(float((mp.mpf(x) - t) / math.ulp(float(t)))); er.append(float(mp.mpf(x)/t - 1))
    e = np.array(e); er = np.array(er)
    q = p0 - 0.5
    rows.append((abs(q), q, e.mean(), e.std(), er.mean()))
rows.sort()
for aq, q, m, s, rel in rows: print("%.5f q=%+.5f mean %+.3f sd %.2f relbias %+.3e" % (aq, q, m, s, rel))
