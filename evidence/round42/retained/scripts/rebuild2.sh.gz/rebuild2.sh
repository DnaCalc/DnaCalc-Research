#!/bin/bash
set -e
cd ~/projects/DnaCalc/DnaCalc-Research
python3 - <<"PY"
import json, subprocess
main = "/home/ubuntu/projects/DnaCalc/DnaCalc"
u = json.load(open("round42-final-unit.json"))
u["application_working_blobs"] = {p: subprocess.run(["git","-C",main,"hash-object",p],capture_output=True,text=True).stdout.strip() for p in u["application_working_blobs"]}
json.dump(u, open("round42-final-unit.json","w"), indent=2); open("round42-final-unit.json","a").write("\n")
PY
export TMPDIR=~/codex-runs/r42/tmp PATH=~/.cargo/bin:$PATH
DNA_RESEARCH_UNIT=round42-final-unit.json cargo build --release -q 2>&1 | grep -E "^error" -A7 | head -20 || true
cp target/release/symbolic-racer ~/codex-runs/r42/$1
