import json, sys, struct, collections
def f(h): return struct.unpack('<d', struct.pack('<Q', int(h, 16)))[0] if isinstance(h, str) and h.startswith('0x') else h
fn = sys.argv[1]; want_const = sys.argv[2] == 'T'; want_z = int(sys.argv[3]); want_n = int(sys.argv[4]); want_big = int(sys.argv[5])
W = {w['id']: w for w in json.load(open('lin/%s.inputs.json' % fn))['witnesses']}
a = {json.loads(l)['id']: json.loads(l)['calc_func_prediction'] for l in open('lin/%s.base.jsonl' % fn)}
b = {json.loads(l)['id']: json.loads(l)['calc_func_prediction'] for l in open('lin/%s.stop.jsonl' % fn)}
groups = collections.defaultdict(dict)
for i, w in W.items(): groups[json.dumps(w['args'])][tuple(w['result_index'])] = (w['expected'], a[i], b[i])
for k, outs in groups.items():
    args = json.loads(k); n = len(args[0]); X = [[f(v) for v in r] for r in args[1]]
    cols = [[X[i][j] for i in range(n)] for j in range(len(X[0]))]
    if len(cols) < 3: continue
    if n != want_n or args[2] != want_const or not all(v == 0 for v in cols[want_z]): continue
    if int(max(abs(v) for v in cols[1 if want_z == 0 else 0])) != want_big: continue
    ys = [f(r[0]) for r in args[0]]
    pert = [(j, i, cols[j][i]) for j in range(len(cols)) for i in range(n) if cols[j][i] != round(cols[j][i])]
    yi = [i for i, v in enumerate(ys) if v]
    row = []
    for idx in [(4, 2), (5, 2), (1, 1), (1, 2), (1, 3)]:
        if idx in outs:
            e, x, y = outs[idx]; row.append('%s:E=%.6g B=%.6g S=%.6g' % (idx, f(e), f(x), f(y)))
    print('y', yi, 'pert', pert, ' | ', '  '.join(row))
