"""R42 second fresh set (frozen before asking): pivot criterion and tie direction.
E1 small independent column vs a collinear remainder (as D1, new seed); E2 zero-column layouts;
E3 equal-sum-of-squares column pairs (permuted entries) so the pivot is a rounding tie."""
import json, random, struct, sys
def hx(x): return '0x%016x' % struct.unpack('<Q', struct.pack('<d', x))[0]
rng = random.Random(4204)
cases = []
def add(tag, ys, cols, const):
    n = len(ys)
    cases.append(dict(tag=tag, args=[[[hx(v)] for v in ys], [[hx(cols[j][i]) for j in range(len(cols))] for i in range(n)], const, True]))
for t in range(64):
    n = rng.choice([6, 8, 12, 16, 24]); a = [float(rng.randint(-50, 50)) for _ in range(n)]
    b = [2 * v for v in a]; b[rng.randrange(n)] += 2.0 ** -rng.randint(19, 24)
    eps = 2.0 ** -rng.randint(28, 40); c = [eps * rng.choice([-3, -1, 1, 2, 5]) for _ in range(n)]
    ys = [float(rng.randint(-20, 20)) for _ in range(n)]
    add('E1', ys, rng.choice([[a, b, c], [b, a, c], [c, a, b], [a, c, b], [c, b, a]]), rng.random() < 0.5)
for t in range(64):
    n = rng.choice([4, 6, 8, 12, 16]); a = [float(rng.randint(-30, 30)) for _ in range(n)]
    m = rng.choice([2.0, 4.0, 0.5, -1.0, 3.0]); b = [m * v for v in a]
    if rng.random() < 0.5: b[rng.randrange(n)] += 2.0 ** -rng.randint(20, 26)
    z = [0.0] * n; ys = [float(rng.randint(-20, 20)) for _ in range(n)]
    add('E2', ys, rng.choice([[z, a, b], [a, z, b], [a, b, z], [z, b, a], [b, a, z], [b, z, a]]), rng.random() < 0.5)
for t in range(64):
    n = rng.choice([4, 5, 6, 8]); base = [float(rng.randint(-9, 9)) for _ in range(n)]
    perm = base[:]; rng.shuffle(perm)
    if perm == base: perm = base[::-1]
    s = 2.0 ** rng.randint(-20, 20)
    ys = [float(rng.randint(-9, 9)) for _ in range(n)]
    add('E3', ys, [[s * v for v in base], [s * v for v in perm]], rng.random() < 0.6)
ws = []
for ci, c in enumerate(cases):
    k = len(c['args'][1][0])
    for r, cc in [(1, 1), (1, 2), (1, 3), (4, 2), (5, 2), (3, 2), (2, 1)]:
        if r == 1 and cc > k + 1: continue
        ws.append(dict(id='E%d:%d:%d' % (ci, r, cc), tag=c['tag'], args=c['args'], result_index=[r, cc]))
json.dump(dict(function='LINEST', witnesses=ws), open(sys.argv[1] + '/LINEST.pivot-questions.json', 'w'))
print(len(ws))
