import numpy as np, math, sys
exec(open("nnoise.py").read().split("wins = ")[0])
pts=[];ans=[]
for i in [0,19,64,65]:
    s0=int(W[i]["start"],16)
    for j in range(8192):
        if V_[i,j]: pts.append(f(s0+j)); ans.append(int(A_[i,j]))
P=np.array(pts); Q=P-0.5; X=np.array(ans,dtype=np.uint64).view(np.float64)
print(len(P), "EN0 %r ED0 %r ratio %r"%(EN[-1],ED[-1],EN[-1]/ED[-1]))
n0b=bits(EN[-1]); d0b=bits(ED[-1]); R=int(sys.argv[1])
best=[]
for dk in range(-R,R+1):
    D0=f(d0b+dk)
    # for each dk, scan N0 over a window around ratio-preserving value
    c=EN[-1]/ED[-1]*D0; cb=bits(c)
    for nk in range(-40,41):
        N0=f(cb+nk)
        y=(Q*N0)/D0
        m=int((y.view(np.uint64)==X.view(np.uint64)).sum())
        best.append((m,dk,nk,N0,D0))
best.sort(reverse=True); print(best[:10])
