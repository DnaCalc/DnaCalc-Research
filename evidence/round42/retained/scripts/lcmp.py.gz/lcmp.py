import json, sys, struct, collections
def f(h): return struct.unpack('<d', struct.pack('<Q', int(h, 16)))[0] if isinstance(h, str) and h.startswith('0x') else h
fn, A, B = sys.argv[1], sys.argv[2], sys.argv[3]
W = {w['id']: w for w in json.load(open('lin/%s.inputs.json' % fn))['witnesses']}
a = {json.loads(l)['id']: json.loads(l)['calc_func_prediction'] for l in open('lin/%s.%s.jsonl' % (fn, A))}
b = {json.loads(l)['id']: json.loads(l)['calc_func_prediction'] for l in open('lin/%s.%s.jsonl' % (fn, B))}
groups = collections.defaultdict(dict)
for i, w in W.items():
    groups[json.dumps(w['args'])][tuple(w['result_index'])] = (w['expected'], a[i], b[i])
kind = collections.Counter(); shown = 0
for k, outs in groups.items():
    loss = [idx for idx, (e, x, y) in outs.items() if x == e and y != e]
    gain = [idx for idx, (e, x, y) in outs.items() if x != e and y == e]
    if not loss: continue
    args = json.loads(k); n = len(args[0]); X = [[f(v) for v in r] for r in args[1]]
    cols = [[X[i][j] for i in range(n)] for j in range(len(X[0]))]
    z = tuple(j for j in range(len(cols)) if all(v == 0 for v in cols[j]))
    kind[(n, len(cols), args[2], z, tuple(sorted(loss)))] += 1
    if shown < int(sys.argv[4]):
        shown += 1
        print('n', n, 'const', args[2], 'cols', [[('%.10g' % v) for v in c[:5]] for c in cols], 'y', [f(r[0]) for r in args[0]][:5])
        for idx in sorted(outs):
            e, x, y = outs[idx]; print('     ', idx, 'excel', f(e), 'base', f(x), 'stop', f(y))
for k, v in kind.most_common(30): print(v, k)
