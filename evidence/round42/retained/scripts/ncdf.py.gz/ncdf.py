import sys, math, numpy as np, mpmath as mp
from nlib import *
mp.mp.dps = 40
xs = []
for c in np.arange(-1.6, 1.61, 0.05):
    b = bits(float(c))
    xs += [(float(c), f(b + k) if c >= 0 else f(b + k)) for k in range(0, 200, 1)]
out = invoke([('NORM.S.DIST', [x, 'T']) for _, x in xs])
cur = None; e = []
def flush():
    if cur is None: return
    a = np.array(e); print('%6.2f  err(ulp p) mean %+.2f sd %.2f min %+.1f max %+.1f' % (cur, a.mean(), a.std(), a.min(), a.max()))
for (c, x), v in zip(xs, out):
    if c != cur:
        flush(); cur = c; e = []
    t = mp.ncdf(x); e.append(float((mp.mpf(v) - t) / math.ulp(float(t))))
flush()
