import math, sys
from fractions import Fraction as Fr
exec(open('nhalf2.py').read().split("consts = {")[0])
from x87e import rn
amid = (Fr('1.772453850905516103923238') + Fr('1.772453850905516103940755')) / 2
s2 = Fr(math.sqrt(2.0))
R53 = lambda v: rn(v, 53); R64 = lambda v: rn(v, 64)
for name, m in [('strict', lambda q: R53(R53(Fr(q) * amid) * s2)), ('x87final', lambda q: R53(R64(R53(Fr(q) * amid) * s2)))]:
    bad = [(i, q, x, float(m(q))) for i, (q, x) in enumerate(pts) if float(m(q)) != x]
    print(name, len(bad), 'of', len(pts))
    for i, q, x, pr in bad[:8]: print('   ', i, q.hex(), 'excel', x.hex(), 'model', pr.hex(), 'y=', float(R53(Fr(q) * amid)).hex())
