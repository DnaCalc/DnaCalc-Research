"""R42 frozen fresh questions for the zero-diagonal reflection sign. With a constant and n in
{4, 9, 16}, a zero-mean column whose first entry is (sqrt(n)+1)*2^e*m has an exactly zero entry
after the ones column's step. Random e, m, other entries and y; both signs of the first entry."""
import json, random, struct, sys, math
def hx(x): return '0x%016x' % struct.unpack('<Q', struct.pack('<d', x))[0]
rng = random.Random(4203)
cases = []
for t in range(160):
    n = rng.choice([4, 9, 16]); r = int(math.isqrt(n))
    e = rng.randint(-12, 12); m = rng.choice([1, -1, 2, -2, 3, -3, 5, -5])
    x0 = (r + 1) * m * 2.0 ** e
    others = [rng.randint(-20, 20) * 2.0 ** e for _ in range(n - 2)]
    last = -(x0 + sum(others))
    x = [x0] + others + [last]
    y = [float(rng.randint(-9, 9)) for _ in range(n)]
    cases.append(dict(args=[[[hx(v)] for v in y], [[hx(v)] for v in x], True, True]))
ws = []
for ci, c in enumerate(cases):
    for rr, cc in [(1, 1), (2, 1), (3, 2), (5, 2), (2, 2), (1, 2)]:
        ws.append(dict(id='Z%d:%d:%d' % (ci, rr, cc), tag='D5', args=c['args'], result_index=[rr, cc]))
json.dump(dict(function='LINEST', witnesses=ws), open(sys.argv[1] + '/LINEST.zero-questions.json', 'w'))
print(len(ws))
