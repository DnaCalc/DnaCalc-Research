import json, collections, sys, subprocess
QD = '/home/ubuntu/codex-runs/r42/questions'; RD = '/home/ubuntu/codex-runs/claude-r42/fresh'
qf = sys.argv[2] if len(sys.argv) > 2 else 'LINEST.pivot-questions.json'
out = '/home/ubuntu/codex-runs/r42/tmp/%s.%s.jsonl' % (qf, sys.argv[1])
subprocess.run(['/home/ubuntu/codex-runs/r42/' + sys.argv[1], 'invoke-inputs', QD + '/' + qf, out], check=True)
P = {json.loads(l)['id']: json.loads(l)['calc_func_prediction'] for l in open(out)}
B = {json.loads(l)['id']: json.loads(l)['calc_func_prediction'] for l in open(QD + '/' + qf.replace('questions.json', 'pred-base.jsonl'))}
ans = {}
for ch in json.load(open(RD + '/' + qf.replace('.json', '.replies.json')))['replies']:
    for i, row in zip(ch['ids'], (ch['reply'] or {}).get('rows') or []):
        ans[i] = ('0x' + row['bits']) if row.get('type') == 'number' else None
c = collections.Counter()
for w in json.load(open(QD + '/' + qf))['witnesses']:
    i = w['id']; a = ans.get(i); c[w['tag']] += a == P[i]; c['gain'] += a == P[i] and a != B[i]; c['loss'] += a != P[i] and a == B[i]
print(qf, dict(c))
