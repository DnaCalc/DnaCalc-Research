"""R42 mapping windows for NORM.S.INV (no predictions; mapping before programs):
256 consecutive doubles at |q| = 0.336..0.361 (step 0.001, both sides) for the central split,
(0.925, 0.9375] in steps of 0.0005, and just above 15/16."""
import json, struct, sys
def bits(x): return struct.unpack('<Q', struct.pack('<d', x))[0]
wins = []
for k in range(26):
    q = 0.336 + 0.001 * k
    for p in (0.5 + q, 0.5 - q): wins.append(dict(purpose='central split', start='%016x' % (bits(p) - 128), count=256))
for k in range(26):
    p = 0.925 + 0.0005 * k
    wins.append(dict(purpose='upper (0.925, 15/16]', start='%016x' % (bits(p) - 128), count=256))
wins.append(dict(purpose='just above 15/16', start='%016x' % bits(15 / 16), count=256))
json.dump(dict(function='NORM.S.INV', windows=wins), open(sys.argv[1] + '/NORM.S.INV.mapping.json', 'w'))
print(len(wins), sum(w['count'] for w in wins))
