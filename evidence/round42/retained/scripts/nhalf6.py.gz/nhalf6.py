import math, sys
from fractions import Fraction as Fr
exec(open('nhalf2.py').read().split("consts = {")[0])
from x87e import rn
c = Fr(math.sqrt(math.pi) / 2)   # RN(sqrt(pi)/2)
c2 = Fr(math.sqrt(math.pi))
s2 = Fr(math.sqrt(2.0))
R53 = lambda v: rn(v, 53); R64 = lambda v: rn(v, 64)
models = {
 'y=x87(2q*c) x=x87(y*s2)': lambda q: R53(R64(R53(R64(2 * Fr(q) * c)) * s2)),
 'y=x87(2q*c) x=RN(y*s2)': lambda q: R53(R53(R64(2 * Fr(q) * c)) * s2),
 'y=ext(2q*c) x=x87(y*s2)': lambda q: R53(R64(R64(2 * Fr(q) * c) * s2)),
 'y=RN(2q*c) x=RN(y*s2)': lambda q: R53(R53(2 * Fr(q) * c) * s2),
 'y=x87(q*c2) x=x87(y*s2)': lambda q: R53(R64(R53(R64(Fr(q) * c2)) * s2)),
}
for name, m in models.items():
    bad = [(q, x) for q, x in pts if float(m(q)) != x]
    print('%-30s mismatches %d of %d' % (name, len(bad), len(pts)), [(q.hex(), x.hex()) for q, x in bad[:2]], flush=True)
