import json, sys, collections
QD = '/home/ubuntu/codex-runs/r42/questions'; RD = '/home/ubuntu/codex-runs/claude-r42/fresh'
fn = sys.argv[1]
Q = json.load(open(QD + '/%s.questions.json' % fn))['witnesses']
P = {b: {json.loads(l)['id']: json.loads(l)['calc_func_prediction'] for l in open(QD + '/%s.pred-%s.jsonl' % (fn, b))} for b in ['base', 'stop', 'sign']}
ans = {}
for ch in json.load(open(RD + '/%s.questions.replies.json' % fn))['replies']:
    rows = (ch['reply'] or {}).get('rows') or []
    for i, row in zip(ch['ids'], rows):
        ans[i] = ('0x' + row['bits']) if row.get('type') == 'number' else json.dumps(row)
    if not rows: print('no rows', ch['result_index'], ch.get('error'))
c = collections.Counter(); ex = []
for w in Q:
    i = w['id']; t = w['tag']; a = ans.get(i)
    c[(t, 'n')] += 1; c[(t, 'answered')] += a is not None and a.startswith('0x')
    for b in P: c[(t, b)] += a == P[b][i]
    if P['base'][i] != P['stop'][i]:
        c[(t, 'sep')] += 1; c[(t, 'sep-stop')] += a == P['stop'][i]; c[(t, 'sep-base')] += a == P['base'][i]
        if a not in (P['stop'][i], P['base'][i]) and len(ex) < 6: ex.append((i, w['result_index'], a, P['base'][i], P['stop'][i]))
for t in ['D1', 'D2', 'D3']: print(t, {k[1]: v for k, v in c.items() if k[0] == t})
nonnum = collections.Counter(a for a in ans.values() if not a.startswith('0x')); print(nonnum.most_common(3))
for e in ex: print(e)
