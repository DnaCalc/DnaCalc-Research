import json, struct, math, subprocess, os, tempfile, numpy as np
RACER = os.path.expanduser('~/projects/DnaCalc/DnaCalc-Research/target/release/symbolic-racer')
def f(b): return struct.unpack('<d', struct.pack('<Q', int(b) & 0xffffffffffffffff))[0]
def bits(x): return struct.unpack('<Q', struct.pack('<d', x))[0]
def h16(x): return '%016x' % bits(x)
def nxt(x, k=1): 
    b = bits(x)
    if x >= 0: return f(b + k) if x != 0 or k > 0 else -f(-k)
    return f(b - k)
def load():
    A = np.load('normal-dense-outputs.npz')['answers']; V = np.load('normal-dense-validity.npz')['numeric']
    W = json.load(open('normal-dense-frozen.json'))['windows']
    return A, V, W
def invoke(rows):
    """rows: list of (function, [args]) where args are floats or 'T'/'F'. Returns list of float/None/str."""
    d = tempfile.mkdtemp(dir=os.path.expanduser('~/codex-runs/r42/tmp'))
    fi = os.path.join(d, 'in'); fo = os.path.join(d, 'out')
    with open(fi, 'w') as fh:
        for fn, args in rows:
            fh.write(fn + ' ' + ' '.join(a if isinstance(a, str) else h16(a) for a in args) + '\n')
    subprocess.run([RACER, 'invoke-rows', fi, fo], check=True)
    out = []
    for line in open(fo):
        s = line.strip()
        out.append(f(int(s, 16)) if s.startswith('0x') else s)
    os.remove(fi); os.remove(fo); os.rmdir(d)
    return out
AS = [
 [2.5090809287301226727e3,3.3430575583588128105e4,6.7265770927008700853e4,4.5921953931549871457e4,1.3731693765509461125e4,1.9715909503065514427e3,1.3314166789178437745e2,3.3871328727963666080],
 [5.2264952788528545610e3,2.8729085735721942674e4,3.9307895800092710610e4,2.1213794301586595867e4,5.3941960214247511077e3,6.8718700749205790830e2,4.2313330701600911252e1,1.0],
 [7.74545014278341407640e-4,2.27238449892691845833e-2,2.41780725177450611770e-1,1.27045825245236838258,3.64784832476320460504,5.76949722146069140550,4.63033784615654529590,1.42343711074968357734],
 [1.05075007164441684324e-9,5.47593808499534494600e-4,1.51986665636164571966e-2,1.48103976427480074590e-1,6.89767334985100004550e-1,1.67638483018380384940,2.05319162663775882187,1.0],
 [2.01033439929228813265e-7,2.71155556874348757815e-5,1.24266094738807843860e-3,2.65321895265761230930e-2,2.96560571828504891230e-1,1.78482653991729133580,5.46378491116411436990,6.65790464350110377720],
 [2.04426310338993978564e-15,1.42151175831644588870e-7,1.84631831751005468180e-5,7.86869131145613259100e-4,1.48753612908506148525e-2,1.36929880922735805310e-1,5.99832206555887937690e-1,1.0]]
def horner(c, r):
    v = c[0]
    for a in c[1:]: v = v * r + a
    return v
def as241(p, form=0):
    q = p - 0.5
    if abs(q) <= 0.425:
        r = 0.180625 - q * q
        n = horner(AS[0], r); d = horner(AS[1], r)
        return (q * n) / d if form == 0 else q * (n / d)
    t = p if q < 0 else 1.0 - p
    r = math.sqrt(-math.log(t))
    if r <= 5.0: r -= 1.6; x = horner(AS[2], r) / horner(AS[3], r)
    else: r -= 5.0; x = horner(AS[4], r) / horner(AS[5], r)
    return -x if q < 0 else x
