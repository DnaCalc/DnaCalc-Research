import math, collections, sys
import mpmath as mp
mp.mp.dps = 40
exec(open('ntail2.py').read().split("k = 0; res")[0])
s2 = math.sqrt(2.0)
sc = {
 'C/sqrt2': [float(mp.mpf(c) / mp.sqrt(2)) for c in C],
 'C*RN(1/sqrt2)': [c * (1 / s2) for c in C],
 'C/RN(sqrt2)': [c / s2 for c in C],
}
def model(p, Cs, mode, final):
    t1 = 1.0 - p
    r = math.sqrt(-math.log(t1)); rr = r - 1.6
    N = horner(Cs, rr, mode); Dd = horner(D, rr, mode)
    y = x87op(N, Dd, '/') if mode == 'x87store' else N / Dd
    if final == 'x87': return x87op(y, s2, '*')
    return y * s2
pts = []
for i in [73, 74, 100, 72]:
    s = int(W[i]['start'], 16)
    for j in range(0, 8192, 8):
        p = f(s + j)
        if V[i, j] and 0.925 < p <= 15 / 16: pts.append((p, int(A[i, j])))
print(len(pts))
for name, Cs in sc.items():
    for mode in ['dbl', 'x87store']:
        for final in ['dbl', 'x87']:
            h = collections.Counter(a - bits(model(p, Cs, mode, final)) for p, a in pts)
            print(name, mode, final, 'exact', h[0], 'of', len(pts), sorted(h.items())[:7])
