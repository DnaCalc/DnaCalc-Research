# Corpus summary

Pass = matched live Excel from calculated workbook inputs. Fail includes mismatches, refusals, failed or missing results, external link caches, circular held caches and awaiting captures. The pass rate includes every inventoried formula cell. Files with unknown inventories are reported separately.

- cache: /home/ubuntu/codex-runs/r34/final-capture-cache
- command: cargo xtask corpus --oracle --no-capture --cache /home/ubuntu/codex-runs/r34/final-capture-cache --out /home/ubuntu/codex-runs/r34/scoped-corpus
- compare_process: this xtask, a release build
- comparison_timeout_s: 10800
- corpus_inventory_sha256: 6a14abef737c13815555219cba86bd7bbf66aeeaebe15805a01b47086f22f526
- dna_only_fallback: false
- excel_build: not read (no capture needed it)
- executable_sha256: e0df74e6636f0f8ac78bd39ea9e13cd1a88bc1cfe5bf78b4f4686ff31d9feec0
- execution_route: captured-policy-or-disabled-inventory
- finished_utc: 2026-11-07T08:29:24Z
- inventory: inventory.json
- listing_failures: []
- repository: c3c88ba2adf6f1608a0eb5ad25f457d7b4d1e588+dirty
- resume: false
- resumed_stage_times: from the verified original comparison
- saved_excel_provenance_sha256: null
- shard: null
- trusted_code_sha256: null
- wall_time_s: 18.090579473

## Totals

- workbooks: 56 (56 compared, 0 not compared; 0 compared with the whole run failed)
- formula cells (known inventories): 54794; pass 53160; external links 73; circular rule 14; awaiting capture 100; fail 1634 (mismatched 1135, refused 305, failed or missing 7)
- pass rate over all formula cells: 97.01%
- failed or missing by verdict: not_run 7
- wall time (s): open 1.111, recalculation 6.498, project 0.060, judge 0.234, compare processes 13.687, captures -

## Workbooks

| Workbook | Formula cells | Pass | External links | Circular rule | Awaiting capture | Fail | Mismatched | Refused | Failed or missing | Pass rate | Open s | Recalc s | Judge s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| calc-engine/dc_10y/oracle.xlsx | 1436 | 1436 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.024 | 0.037 | 0.005 |
| calc-engine/dc_10y_iteration/oracle.xlsx | 17 | 17 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.002 | 0.005 | 0.000 |
| calc-engine/dc_86f/oracle.xlsx | 22 | 22 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.002 | 0.001 | 0.000 |
| calc-engine/dc_y2o/oracle.xlsx | 17 | 3 | 0 | 14 | 0 | 14 | 0 | 0 | 0 | 17.64% | 0.002 | 0.001 | 0.000 |
| calc-engine/eng14-raw-nonfinite/oracle.xlsx | 21 | 21 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.001 | 0.001 | 0.000 |
| calc-engine/eng15-overflow/oracle.xlsx | 94 | 94 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.002 | 0.004 | 0.000 |
| calc-engine/l3/oracle.xlsx | 112 | 112 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.004 | 0.006 | 0.000 |
| calc-fml/dc_51ka/oracle.xlsx | 183 | 183 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.005 | 0.045 | 0.001 |
| calc-fml/dc_ibp2/oracle.xlsx | 83 | 83 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.001 | 0.002 | 0.000 |
| calc-fml/dc_l10u/oracle.xlsx | 57 | 57 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.001 | 0.038 | 0.000 |
| calc-func/catalogue/oracle.xlsx | 14553 | 14145 | 0 | 0 | 0 | 408 | 408 | 0 | 0 | 97.19% | 0.630 | 5.240 | 0.090 |
| calc-func/cdoc_jpha/oracle.xlsx | 1526 | 1526 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.015 | 0.062 | 0.005 |
| calc-func/cfunc_m1_2/oracle.xlsx | 234 | 234 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.003 | 0.030 | 0.001 |
| calc-func/cfunc_m3_2/oracle.xlsx | 218 | 218 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.002 | 0.004 | 0.001 |
| calc-func/cfunc_m3_4/oracle.xlsx | 112 | 112 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.001 | 0.002 | 0.000 |
| calc-func/cfunc_m3_5/oracle.xlsx | 136 | 136 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.003 | 0.044 | 0.000 |
| calc-func/cfunc_m3_6/oracle.xlsx | 596 | 596 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.007 | 0.045 | 0.001 |
| calc-func/dc_e00t/oracle.xlsx | 1144 | 1144 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.010 | 0.044 | 0.004 |
| calc-func/dc_fwpz/oracle.xlsx | 115 | 115 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.002 | 0.004 | 0.000 |
| calc-func/dc_nzpw/oracle.xlsx | 186 | 185 | 0 | 0 | 0 | 1 | 0 | 0 | 1 | 99.46% | 0.002 | 0.003 | 0.001 |
| calc-func/dc_q9rb/oracle.xlsx | 86 | 81 | 0 | 0 | 0 | 5 | 5 | 0 | 0 | 94.18% | 0.002 | 0.001 | 0.000 |
| calc-func/dc_xrxb/oracle.xlsx | 167 | 167 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.002 | 0.048 | 0.001 |
| calc-func/dcj9k_r21/oracle.xlsx | 204 | 122 | 0 | 0 | 0 | 82 | 82 | 0 | 0 | 59.80% | 0.003 | 0.008 | 0.001 |
| calc-func/dcj9k_r22/oracle.xlsx | 105 | 105 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.003 | 0.007 | 0.000 |
| calc-func/dcj9k_r25_bessel/oracle.xlsx | 310 | 309 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 99.67% | 0.003 | 0.004 | 0.001 |
| calc-func/dcj9k_r25_discrete/oracle.xlsx | 233 | 187 | 0 | 0 | 0 | 46 | 46 | 0 | 0 | 80.25% | 0.002 | 0.020 | 0.001 |
| calc-func/dcj9k_r25_geomean/oracle.xlsx | 292 | 292 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.003 | 0.003 | 0.001 |
| calc-func/dcj9k_r25_guard_transfer/oracle.xlsx | 400 | 400 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.004 | 0.008 | 0.001 |
| calc-func/dcj9k_r25_qr_stores/oracle.xlsx | 100 | 86 | 0 | 0 | 0 | 14 | 14 | 0 | 0 | 86.00% | 0.001 | 0.004 | 0.000 |
| calc-func/dcj9k_r25_regression/oracle.xlsx | 2280 | 2088 | 0 | 0 | 0 | 192 | 192 | 0 | 0 | 91.57% | 0.015 | 0.027 | 0.007 |
| calc-func/dcj9k_r25_variance/oracle.xlsx | 732 | 732 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.007 | 0.012 | 0.002 |
| calc-func/dcj9k_r26_regression/oracle.xlsx | 3984 | 3906 | 0 | 0 | 0 | 78 | 78 | 0 | 0 | 98.04% | 0.034 | 0.071 | 0.017 |
| calc-func/dcj9k_r26_root_transfer/oracle.xlsx | 3136 | 3136 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.028 | 0.027 | 0.013 |
| calc-func/dcj9k_r26_scalar/oracle.xlsx | 2571 | 2571 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.017 | 0.043 | 0.007 |
| calc-func/dcztvv_r23/oracle.xlsx | 968 | 875 | 0 | 0 | 0 | 93 | 92 | 1 | 0 | 90.39% | 0.008 | 0.024 | 0.004 |
| calc-func/dcztvv_r24/oracle.xlsx | 4047 | 3881 | 0 | 0 | 0 | 166 | 166 | 0 | 0 | 95.89% | 0.038 | 0.086 | 0.014 |
| calc-func/fn10_sort_cycle/oracle.xlsx | 100 | 0 | 0 | 0 | 100 | 100 | 0 | 0 | 0 | 0.00% | - | - | - |
| calc-func/fn2_questions/oracle.xlsx | 956 | 928 | 0 | 0 | 0 | 28 | 18 | 4 | 6 | 97.07% | 0.041 | 0.058 | 0.004 |
| calc-func/fn3_questions/oracle.xlsx | 491 | 491 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.005 | 0.035 | 0.001 |
| calc-func/fn5_dates_1900/oracle.xlsx | 320 | 320 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.005 | 0.006 | 0.001 |
| calc-func/fn5_digits_zero/oracle.xlsx | 432 | 432 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.007 | 0.010 | 0.002 |
| calc-func/fn5_helper_boundaries/oracle.xlsx | 526 | 526 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.007 | 0.010 | 0.002 |
| calc-func/fn5_regex_results/oracle.xlsx | 160 | 160 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.003 | 0.004 | 0.000 |
| calc-func/fn5_selection_boundaries/oracle.xlsx | 408 | 408 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.006 | 0.008 | 0.001 |
| calc-func/fn6_iteration_primary/oracle.xlsx | 1200 | 1200 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.015 | 0.053 | 0.003 |
| calc-func/fn6_jamo_suffix/oracle.xlsx | 480 | 480 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.008 | 0.048 | 0.002 |
| calc-func/fn6_utf16_needles/oracle.xlsx | 320 | 320 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.006 | 0.008 | 0.001 |
| calc-func/fn6_utf16_needles_compat1/oracle.xlsx | 320 | 320 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.007 | 0.009 | 0.001 |
| calc-func/fn6_utf16_needles_compat2/oracle.xlsx | 320 | 320 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.008 | 0.007 | 0.001 |
| calc-func/fn7_argument_origins/oracle.xlsx | 480 | 480 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.006 | 0.008 | 0.001 |
| calc-func/fn7_collation_context/oracle.xlsx | 4648 | 4635 | 0 | 0 | 0 | 13 | 13 | 0 | 0 | 99.72% | 0.045 | 0.125 | 0.022 |
| calc-func/fn7_collation_contractions/oracle.xlsx | 2392 | 2092 | 0 | 0 | 0 | 300 | 0 | 300 | 0 | 87.45% | 0.031 | 0.082 | 0.008 |
| calc-func/fn7_date_argument_origins/oracle.xlsx | 480 | 480 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.010 | 0.011 | 0.002 |
| calc-func/fn7_format_context/oracle.xlsx | 160 | 140 | 0 | 0 | 0 | 20 | 20 | 0 | 0 | 87.50% | 0.004 | 0.005 | 0.000 |
| calc-host/dc_ylr/oracle.xlsx | 74 | 1 | 73 | 0 | 0 | 73 | 0 | 0 | 0 | 1.35% | 0.003 | 0.002 | 0.000 |
| calc-host/eng13_legacy/oracle.xlsx | 50 | 50 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.003 | 0.002 | 0.000 |
| **Total** | 54794 | 53160 | 73 | 14 | 100 | 1634 | 1135 | 305 | 7 | 97.01% | 1.111 | 6.498 | 0.234 |

### Captures

- calc-engine/dc_10y/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-engine/tests/captures/dc_10y/oracle.capture.json
- calc-engine/dc_10y_iteration/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-engine/tests/captures/dc_10y_iteration/oracle.capture.json
- calc-engine/dc_86f/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-engine/tests/captures/dc_86f/oracle.capture.json
- calc-engine/dc_y2o/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-engine/tests/captures/dc_y2o/oracle.capture.json
- calc-engine/eng14-raw-nonfinite/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-engine/tests/captures/eng14-raw-nonfinite/oracle.capture.json
- calc-engine/eng15-overflow/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-engine/tests/captures/eng15-overflow/oracle.capture.json
- calc-engine/l3/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-engine/tests/captures/l3/oracle.capture.json
- calc-fml/dc_51ka/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-fml/tests/captures/dc_51ka/oracle.capture.json
- calc-fml/dc_ibp2/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-fml/tests/captures/dc_ibp2/oracle.capture.json
- calc-fml/dc_l10u/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-fml/tests/captures/dc_l10u/oracle.capture.json
- calc-func/catalogue/oracle.xlsx: 25 committed section captures from 5 capture session(s); 0 section(s) awaiting capture
- calc-func/cdoc_jpha/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/cdoc_jpha/oracle.capture.json
- calc-func/cfunc_m1_2/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/cfunc_m1_2/oracle.capture.json
- calc-func/cfunc_m3_2/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/cfunc_m3_2/oracle.capture.json
- calc-func/cfunc_m3_4/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/cfunc_m3_4/oracle.capture.json
- calc-func/cfunc_m3_5/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/cfunc_m3_5/oracle.capture.json
- calc-func/cfunc_m3_6/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/cfunc_m3_6/oracle.capture.json
- calc-func/dc_e00t/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dc_e00t/oracle.capture.json
- calc-func/dc_fwpz/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dc_fwpz/oracle.capture.json
- calc-func/dc_nzpw/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dc_nzpw/oracle.capture.json
- calc-func/dc_q9rb/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dc_q9rb/oracle.capture.json
- calc-func/dc_xrxb/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dc_xrxb/oracle.capture.json
- calc-func/dcj9k_r21/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r21/oracle.capture.json
- calc-func/dcj9k_r22/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r22/oracle.capture.json
- calc-func/dcj9k_r25_bessel/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r25_bessel/oracle.capture.json
- calc-func/dcj9k_r25_discrete/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r25_discrete/oracle.capture.json
- calc-func/dcj9k_r25_geomean/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r25_geomean/oracle.capture.json
- calc-func/dcj9k_r25_guard_transfer/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r25_guard_transfer/oracle.capture.json
- calc-func/dcj9k_r25_qr_stores/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r25_qr_stores/oracle.capture.json
- calc-func/dcj9k_r25_regression/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r25_regression/oracle.capture.json
- calc-func/dcj9k_r25_variance/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r25_variance/oracle.capture.json
- calc-func/dcj9k_r26_regression/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r26_regression/oracle.capture.json
- calc-func/dcj9k_r26_root_transfer/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r26_root_transfer/oracle.capture.json
- calc-func/dcj9k_r26_scalar/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r26_scalar/oracle.capture.json
- calc-func/dcztvv_r23/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcztvv_r23/oracle.capture.json
- calc-func/dcztvv_r24/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcztvv_r24/oracle.capture.json
- calc-func/fn10_sort_cycle/oracle.xlsx: awaiting capture: no committed capture
- calc-func/fn2_questions/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn2_questions/oracle.capture.json
- calc-func/fn3_questions/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn3_questions/oracle.capture.json
- calc-func/fn5_dates_1900/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn5_dates_1900/oracle.capture.json
- calc-func/fn5_digits_zero/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn5_digits_zero/oracle.capture.json
- calc-func/fn5_helper_boundaries/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn5_helper_boundaries/oracle.capture.json
- calc-func/fn5_regex_results/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn5_regex_results/oracle.capture.json
- calc-func/fn5_selection_boundaries/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn5_selection_boundaries/oracle.capture.json
- calc-func/fn6_iteration_primary/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn6_iteration_primary/oracle.capture.json
- calc-func/fn6_jamo_suffix/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn6_jamo_suffix/oracle.capture.json
- calc-func/fn6_utf16_needles/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn6_utf16_needles/oracle.capture.json
- calc-func/fn6_utf16_needles_compat1/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn6_utf16_needles_compat1/oracle.capture.json
- calc-func/fn6_utf16_needles_compat2/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn6_utf16_needles_compat2/oracle.capture.json
- calc-func/fn7_argument_origins/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn7_argument_origins/oracle.capture.json
- calc-func/fn7_collation_context/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn7_collation_context/oracle.capture.json
- calc-func/fn7_collation_contractions/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn7_collation_contractions/oracle.capture.json
- calc-func/fn7_date_argument_origins/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn7_date_argument_origins/oracle.capture.json
- calc-func/fn7_format_context/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn7_format_context/oracle.capture.json
- calc-host/dc_ylr/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-host/tests/captures/dc_ylr/oracle.capture.json
- calc-host/eng13_legacy/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-host/tests/captures/eng13_legacy/oracle.capture.json

## Failures by root cause

### Refusals (not modelled), by owner and reason

6 causes, 289 roots, 305 cells.

| Owner | Reason | Roots | Downstream | Whole workbook | Cells | Workbooks |
|---|---|---:|---:|---:|---:|---:|
| no package named (calc-fml refused) | formula Evaluation:NotModelled | 272 | 0 | 0 | 272 | 2 |
| exactness dc-j9k | not-modelled SORT | 8 | 8 | 0 | 16 | 1 |
| exactness dc-uar | not-modelled < | 4 | 4 | 0 | 8 | 1 |
| exactness dc-uar | not-modelled = | 3 | 3 | 0 | 6 | 1 |
| no package named (calc-fml refused) | formula Compile:Syntax | 1 | 1 | 0 | 2 | 1 |
| no package named (calc-fml refused) | formula Compile:Arity | 1 | 0 | 0 | 1 | 1 |

### Mismatches, by function and shape at the root

100 causes, 1115 roots, 1117 cells.

| Function | Shape | Roots | Downstream | Whole workbook | Cells | Workbooks |
|---|---|---:|---:|---:|---:|---:|
| INDEX | number, differs within 15 significant digits; observed reads: number | 230 | 0 | 0 | 230 | 3 |
| INDEX | number, differs within 15 significant digits | 133 | 0 | 0 | 133 | 3 |
| CUMPRINC | number, 1 ulp apart | 68 | 0 | 0 | 68 | 1 |
| CUMPRINC | number, 2 to 16 ulp apart | 61 | 0 | 0 | 61 | 2 |
| INDEX | number expected, error Num returned; observed reads: number | 45 | 0 | 0 | 45 | 2 |
| IPMT | number, 1 ulp apart | 42 | 0 | 0 | 42 | 2 |
| CUMPRINC | number, differs within 15 significant digits | 36 | 0 | 0 | 36 | 2 |
| INDEX | error Ref expected, number returned | 30 | 0 | 0 | 30 | 2 |
| CUMIPMT | number, 2 to 16 ulp apart | 26 | 0 | 0 | 26 | 2 |
| YIELD | number, differs within 15 significant digits | 24 | 0 | 0 | 24 | 3 |
| INDEX | text expected, text returned; observed reads: text | 23 | 0 | 0 | 23 | 2 |
| ODDFYIELD | number, differs within 15 significant digits | 23 | 0 | 0 | 23 | 3 |
| PPMT | number, 1 ulp apart | 23 | 0 | 0 | 23 | 1 |
| PPMT | number, differs within 15 significant digits | 19 | 0 | 0 | 19 | 2 |
| BINOM.DIST | number, 2 to 16 ulp apart | 17 | 0 | 0 | 17 | 1 |
| CUMIPMT | number, 1 ulp apart | 16 | 0 | 0 | 16 | 2 |
| INDEX | number, 1 ulp apart | 15 | 0 | 0 | 15 | 2 |
| BINOM.DIST | number, 1 ulp apart | 14 | 0 | 0 | 14 | 2 |
| BINOM.DIST | number, differs within 15 significant digits | 13 | 0 | 0 | 13 | 2 |
| BINOM.DIST | number, 2 to 16 ulp apart; observed reads: number | 11 | 0 | 0 | 11 | 1 |
| IPMT | number, 2 to 16 ulp apart | 11 | 0 | 0 | 11 | 1 |
| INDEX | error Ref expected, error Value returned | 10 | 0 | 0 | 10 | 1 |
| INDEX | number expected, error Num returned | 10 | 0 | 0 | 10 | 2 |
| IPMT | number, differs within 15 significant digits | 10 | 0 | 0 | 10 | 2 |
| POISSON.DIST | number, 1 ulp apart; observed reads: number | 10 | 0 | 0 | 10 | 1 |
| BINOM.DIST | number, 1 ulp apart; observed reads: number | 9 | 0 | 0 | 9 | 1 |
| BETADIST | number, differs within 15 significant digits | 8 | 0 | 0 | 8 | 2 |
| CUMIPMT | number, differs within 15 significant digits | 8 | 0 | 0 | 8 | 2 |
| RATE | error Num expected, number returned | 8 | 0 | 0 | 8 | 1 |
| BINOM.DIST | number, differs within 15 significant digits; observed reads: number | 7 | 0 | 0 | 7 | 2 |
| INDEX | number, 2 to 16 ulp apart; observed reads: number | 7 | 0 | 0 | 7 | 1 |
| INDEX | error Ref expected, error Num returned | 6 | 0 | 0 | 6 | 2 |
| INDEX | error Ref expected, error Value returned; observed reads: blank | 6 | 0 | 0 | 6 | 1 |
| ODDFYIELD | number, differs within 15 significant digits; observed reads: number | 6 | 0 | 0 | 6 | 2 |
| POISSON.DIST | number, differs within 15 significant digits; observed reads: number | 6 | 0 | 0 | 6 | 1 |
| PPMT | number, 2 to 16 ulp apart | 6 | 0 | 0 | 6 | 1 |
| YIELD | number, differs within 15 significant digits; observed reads: number | 6 | 0 | 0 | 6 | 2 |
| HSTACK | array expected, array returned; observed reads: number | 5 | 0 | 0 | 5 | 1 |
| Infix & | text expected, text returned; observed reads: number | 5 | 0 | 0 | 5 | 1 |
| SORT | array expected, array returned; observed reads: text | 3 | 2 | 0 | 5 | 1 |

and 60 more in summary.json

### Other failures, by class and key

5 causes, 94 roots, 212 cells.

| Class | Key | Roots | Downstream | Whole workbook | Cells | Workbooks |
|---|---|---:|---:|---:|---:|---:|
| capture | awaiting capture | 0 | 0 | 100 | 100 | 1 |
| provenance | external link cache (dc-ylr) | 73 | 0 | 0 | 73 | 1 |
| capture | capture failure at stage entry | 6 | 18 | 0 | 24 | 1 |
| provenance | circular held cache (dc-y2o.1) | 14 | 0 | 0 | 14 | 1 |
| capture | capture failure at stage value | 1 | 0 | 0 | 1 | 1 |

