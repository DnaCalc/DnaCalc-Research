from pathlib import Path
import hashlib, json, subprocess

root = Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
run = Path('/home/ubuntu/codex-runs/r34')
index = root / 'evidence/round34/index.json'
before = json.loads((run/'baseline-problems.json').read_text())
after = json.loads((run/'published-problems.json').read_text())
delta = json.loads((run/'final-combined-corpus-delta.json').read_text())
equiv = json.loads((run/'published-corpus-equivalence.json').read_text())
assert after['bank']['matched'] == 3887320
assert after['corpus']['matched'] == 53255
assert not equiv['counts'].get('changed_values', 0)
assert delta['counts']['gains'] == 168 and delta['counts']['losses'] == 18

data = dict(
    format='dnacalc-round34-evidence/1', complete=True,
    status='Final published numeric measurement; remaining algorithms explicitly open.',
    role='Original black-box Excel analyst and implementer. Existing cleared code, exact arithmetic and fixed mathematical hypotheses; no tier3/4 implementation source read.',
    published_numeric_commit=after['application']['revision'],
    historical_checkpoint_commit='9fe982a',
    historical_note='The earlier index is preserved at the checkpoint commit. Historical manifests, rejected inputs and unqualified attempts retain their original bytes; final qualification does not rewrite their claims.',
    landed={
        'e26aea59':'Bounded numeric arrays and scalar INDEX selections in the audited Excel question service.',
        'c3c88ba2':'ROUNDUP publishes the normal decimal unit from PC64 before the existing addition.',
        '2ce99d3d':'Normalized radix16 decimal publication; EUROTOOL keeps its independently observed direct route; CUMIPMT skips the first beginning period; ODDFYIELD schedule/date admission.',
        '3c7de7a2':'Integration push of the preceding three numerical stages.',
        '8f61880f':'Beginning IPMT uses the existing reciprocal timing coefficient.',
        'b84f2c6e':'Interest/principal retain the balance before FV; moment square root stored from PC64; finite invalid YIELD dates return NUM.',
        '15e41f86':'Stored per-1 admission and the shared PMT positive-rate component remove the final four initial IPMT failures.'},
    measurement={
        'before':{k:before[k] for k in ('application','bank','corpus')},
        'after':{k:after[k] for k in ('application','bank','corpus')},
        'own_bank':dict(gains=39,losses=1,net=38,
            per_function_net={'ROUNDUP':13,'ROUNDDOWN':7,'TRUNC':9,'ROUND':4,'IPMT':3,'SKEW':2,'CUMIPMT':0}),
        'own_corpus':dict(gains=89,losses=0,
            per_function={'IPMT':67,'ODDFYIELD':14,'YIELD':6,'PPMT':2}),
        'incoming_bank':dict(net=724),
        'incoming_corpus':dict(gains=79,losses=18,net=61),
        'combined_corpus':delta['counts'],
        'qualification':'Published clean numeric source has identical full-bank canonical trace and function totals to the guarded edge measurement. All corpus returned values match that edge run. The original bank has116 unread failures and corpus has100 pending failures; neither is counted as a pass. Populations and overlapping fresh cohorts are never summed as unique calls.'},
    losses={
        'retained_bank':'CUMIPMT r15-cumipmt-007 changes from the matching c02c8112f5edfa28 to c02c8112f5edfa20. Every changed original bank call was repeated live with its start2 shadow; this loss equals the unchanged shadow with the same independent Excel answer. The summation defect remains open.',
        'intermediate_ipmt':'The earlier timing stage had54 fresh losses and4 corpus losses; all are restored by the later pre-FV balance stage. Final own corpus comparison has zero losses.',
        'incoming':'The18 final corpus losses belong to incoming RATE10, BINOM.DIST7 and BINOM.DIST.RANGE1 changes. Their original inputs and outputs remain in the combined delta.'},
    proofs={
        'regression':'Four readiness refusals, including the final raw worker response, show the running Windows service has not loaded the new array/selection policy. Controlled rank and decomposition questions are prepared; no new regression answers or kernel inference.',
        'decimal_unit':'Exact rational PC64 then RN53 evaluation of all616 normal finite decimal exponents; only10^126 distinguishes directRN53. Registered workbook route improves615/616 to616/616.',
        'decimal_scale':'286 structural discriminants plus386 normalized/padded controls identify low-nibble-first radix16 scaling. Allfour whole-number outputs match386/386. Position ROUNDUP still has377 unresolved unit/drop failures, kept in the evidence.',
        'cumipmt_start':'252 short and216 long paired identities;2592 controlled values establish skipping beginning period1 after the PMT guard. Fresh87gains/15losses all map to the unchanged start2 shadow. Original bank1gain/1loss.',
        'odd_dates':'820 discovery and1560 holdout schedule calls, all cross-checked with the independently observed COUPPCD.45 exact/adjacent equality calls preserve NUM.',
        'payment_balance':'36 inverse groups covering288 PMT records uniquely identify the pre-FV quotient under the stated PMT leaf premise.4224 paired observations distinguish it from the refuted post-FV fold. All2112 IPMT outputs and1056 end-PPMT outputs match; beginning PPMT remains unchanged. Additional3600 boundary observations lose no original matches.',
        'payment_periods':'436 discovery plus210 holdout guards per function identify the stored zero-based comparison. The fixed higher-component candidate matches1944 discovery and1512 holdout observations including unadopted beginning PPMT. Tiny-nper observations refute reassociation of nper-per+1.',
        'assertion_correction':'One old unmeasured nper0.5/type1 first-interest NUM assertion is corrected to independently measured zero.56 exact/neighbor Excel calls retain the original inputs and confirm nper0 remains NUM. An additional invalid-nper assertion is retained. This is not a changed original captured answer.',
        'moment_root':'177 discovery/window plus72 holdout SKEW/SQRT readings,169+72 KURT readings and independent exact-rational square-root rounding certify the stored root. STDEV.S differs and is unchanged. Two bank gains; no corpus gain.',
        'cumulative_sums':'The singleton-term/ordinary-sum premise has417 contradictions. All300 explicit-power/common-factor programs,225 stored-component sums,120 free-initial-value geometric recurrences and72 free-initial-value/public-PMT affine-balance loops are refuted. Original first contradictions and independently replayed inverse domains retained. No cumulative kernel adopted.',
        'bond_solver':'180 on-coupon zero-coupon cases retain1476 qualified paired PRICE calls;288 untransportable subnormal-neighbor calls are explicitly excluded. All1600 fixed finite Newton programs refute, conditional on existing price leaves.252 exact-dyadic YIELD/ODDFYIELD pairs return identically:202 numeric,50NUM,39 exact mathematical roots per surface. Fifteen dyadic money-scale groups each have4or5 distinct returned answers. A further1143-call negative-root raster yields698 numeric and445NUM, with all roots mathematically inside(-frequency,0). Scale dependence refutes a homogeneous relative-stop premise without identifying a seed, derivative, tolerance or fallback.'},
    still_open=[
        'LINEST/LOGEST rank decision, decomposition, statistics and constFALSE await the updated live array service.',
        'CUMPRINC/CUMIPMT summation arithmetic and beginning PPMT; the latter timing trial breaks an exact cumulative-route pin and was not adopted.',
        'ROUNDUP dropped-unit/position cases and remaining rounding mismatches.',
        'YIELD/ODDFYIELD multi-period solver, off-coupon discounts and conditional private numerical leaves.',
        'Absolute GAMMA and incomplete beta stayed at rest. Reserved RATE,IRR,POISSON,HYPGEOM,BINOM,NEGBINOM implementations and the excluded sibling checkout were not touched.'],
    provenance_limits=[
        'Early Python producer bytes were not all frozen. Original unit hashes remain unchanged, and qualified offline replays are distinguished from those producer epochs.',
        'The original due discovery and holdout Python producers are independently reconstructed/frozen with their exact original hashes. Later producer edits have retained source snapshots.',
        'The aborted reading-problems report detected source mutation; its log is diagnostic, not a qualified complete measurement.',
        'The first bond solver retry had a one-line source mismatch; its separately bound qualified repeat refutes the same1600 hypotheses.',
        'Initial unprefixed-hex invocation files decoded as text and are excluded. Corrected typed-input files and unchanged failed originals both remain.',
        'One original SKEW holdout selection label was wrong; verified offline metadata corrects the label while proving original cases, answers and counts identical.',
        'The owned accidental nested evidence symlink was removed; parent evidence link and all evidence file bytes and hashes are unchanged. Historical status fields are not rewritten.',
        'Full corpus cells, executable binaries and the full bank trace remain outside Git. Compressed original answers, input identities, hash inventories, per-stage deltas and binary provenance are retained.'],
    validation={
        'latest_numeric_full_check':dict(passed=2040,failed=0,ignored=5,not_run=3,log='check-period-edge.log'),
        'research_rust':dict(passed=138,failed=0,ignored=2,log='research-final-tests.log'),
        'research_python':dict(passed=130,failed=0,log='python-published-tests.log'),
        'published_unit':'round34-published-unit.json; compiled provenance checks all78 research source hashes and exact published application hashes.',
        'check_recipe':'Each numerical work chunk used one full cargo xtask check. Rejected pushes were followed only by pull-no-rebase, workspace build, touched-crate tests and immediate push. The first missing-Pillow paint failure was rerun in the installed Pillow/NumPy environment; no second full check for the same work.',
        'review':'One read-only agent reviewed each landed stage and independently replayed the225/120/72 late cumulative refutations and all1143 raster replies. Final report/archive audit follows separately.'},
    reproduction=[
        'DNA_RESEARCH_UNIT=$PWD/round34-published-unit.json TMPDIR=<disk-folder> cargo build --release --locked',
        'python3 -m unittest discover -s checker -p test_*.py',
        'python3 racer/corpus_cases.py problem-functions ../DnaCalc ../DnaCalc/docs/generated/problem-functions <new-run-dir> <qualified-corpus-dir>',
        'python3 racer/audit.py corpus-delta <before-corpus> <after-corpus> - <output-json>',
        'Artifacts are indexed by artifacts.json: verify archive_sha256, decompress retained/*.gz, then verify original byte count and sha256. scalar-cache/*.gz are raw original compressed service records.'],
    source_references=[
        'https://support.microsoft.com/en-us/excel/functions/linest-function',
        'https://support.microsoft.com/en-us/excel/functions/yield-function',
        'https://support.microsoft.com/en-us/excel/functions/oddfyield-function',
        'https://netlib.org/lawson-hanson/all'],
    scope_note='Public contracts and the Netlib public-domain HFTI norm-recompute hypothesis were consulted; no kernel copied. Mathematical assertions retain their declared premises.')

old=index.read_text();new=json.dumps(data,indent=2)+'\n'
patch='*** Begin Patch\n*** Update File: '+str(index)+'\n@@\n'+''.join('-'+s+'\n'for s in old.splitlines())+''.join('+'+s+'\n'for s in new.splitlines())+'*** End Patch\n'
subprocess.run(['apply_patch'],input=patch,text=True,check=True)
print('Final index written,',len(new.splitlines()),'lines')
