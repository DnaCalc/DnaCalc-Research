from pathlib import Path
import gzip, hashlib, json, subprocess

src = Path('/home/ubuntu/codex-runs/r34')
root = Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
dst = root / 'evidence/round34'
manifest = json.loads((dst / 'artifacts.json').read_text())
known = {r['archive']: r for r in manifest}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def retain(path, relative=None, raw=False):
    data = path.read_bytes()
    relative = Path(relative or path.relative_to(src))
    target = dst / ('scalar-cache' if raw else 'retained') / relative
    if not raw:
        target = target.with_name(target.name + '.gz')
    if target.exists() and known.get(str(target.relative_to(dst)), {}).get('sha256') != sha(data):
        target = dst / 'retained/versions' / sha(data) / target.name
    archive = str(target.relative_to(dst))
    if archive in known:
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data if raw else gzip.compress(data, compresslevel=9, mtime=0))
    record = dict(original=str(path), archive=archive, original_bytes=len(data),
                  sha256=sha(data), archive_sha256=sha(target.read_bytes()))
    known[archive] = record
    manifest.append(record)

for path in sorted((src / 'scalar-cache').glob('*.gz')):
    retain(path, path.name, True)
for path in sorted(src.iterdir()):
    if path.is_file() and path.suffix in ('.json', '.log', '.patch', '.py', '.rs', '.txt'):
        retain(path)
for directory in sorted(src.iterdir()):
    if not directory.is_dir():
        continue
    if directory.name.startswith(('cumulative-', 'rounding-', 'yield-')):
        for path in sorted(directory.rglob('*')):
            if path.is_file() and path.suffix in ('.json', '.jsonl', '.txt', '.log'):
                retain(path)
    elif directory.name.endswith('-corpus'):
        for name in ('summary.json', 'summary.md'):
            path = directory / name
            if path.exists():
                retain(path)
    elif directory.name.endswith('-run'):
        for name in ('bank.log', 'classification/summary.json', 'corpus-functions/table.json'):
            path = directory / name
            if path.exists():
                retain(path)
excluded = []
for path in sorted((src / 'producers').glob('*')):
    if not path.is_file():
        continue
    data = path.read_bytes()
    if data.startswith(b'\x7fELF'):
        excluded.append(dict(path=str(path), sha256=sha(data), bytes=len(data),
                             reason='Generated executable; compiled-unit provenance and original source retained.'))
    else:
        retain(path)
for base, category in [(root, 'research-current'), (root.parent / 'DnaCalc', 'application-current')]:
    paths = subprocess.check_output(['git', '-C', str(base), 'diff', '--name-only', '--',
                                    'racer', 'crates/calc-func/src', 'crates/calc-func/tests'], text=True).splitlines()
    for name in paths:
        path = base / name
        if path.is_file():
            retain(path, Path(category) / sha(path.read_bytes()) / name)
for name in ('test.log', 'build.log'):
    path = root.parent / 'DnaCalc/target/check' / name
    if path.exists():
        retain(path, Path('checks-latest') / sha(path.read_bytes()) / name)
(dst / 'excluded-binaries.json').write_text(json.dumps(excluded, indent=2) + '\n')
(dst / 'artifacts.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(dict(artifacts=len(manifest),
                      bytes=sum(p.stat().st_size for p in dst.rglob('*') if p.is_file()),
                      excluded_binaries=len(excluded))))
