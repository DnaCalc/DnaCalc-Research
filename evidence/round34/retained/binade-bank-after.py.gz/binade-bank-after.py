from pathlib import Path
import json,subprocess,time,hashlib,itertools
r=Path('/home/ubuntu/codex-runs/r34');a=Path('/home/ubuntu/projects/DnaCalc/DnaCalc');research=a.parent/'DnaCalc-Research'
deadline=time.monotonic()+300
while True:
    try:
        p=a/'docs/generated/problem-functions.json';d=json.loads(p.read_text())
        if d['application']['revision'].startswith('fb445e7e')and d['application']['source_diff_sha256']!='e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855':break
    except (ValueError,OSError):pass
    if time.monotonic()>deadline:raise TimeoutError('Final full bank report has not qualified; no parallel judge launched')
    time.sleep(.2)
if(r/'binade-problems.json').exists():assert(r/'binade-problems.json').read_text()==p.read_text()
else:
    with(r/'binade-problems.json').open('x')as f:f.write(p.read_text())
out=[]
for name in('ROUNDUP','ROUNDDOWN','TRUNC'):
    trace=r/('binade-'+name+'-after.jsonl')
    if not trace.exists():
        with(r/('binade-'+name+'-judge.log')).open('xb')as log:
            subprocess.run([str(a/'target/xtask-corpus/release/xtask-harness'),'witness','judge','--bank','full','--func',name,'--trace',str(trace)],cwd=a,stdout=log,stderr=subprocess.STDOUT,check=True)
    before=r/('radix-'+name+'-after.jsonl');counts=dict(rows=0,before=0,after=0,gains=0,losses=0,changed_outputs=0);changes=[]
    for old,new in itertools.zip_longest(before.open(),trace.open()):
        assert old is not None and new is not None,'Added or removed original obligation'
        x,y=json.loads(old),json.loads(new)
        assert {k:v for k,v in x.items()if k!='actual'}=={k:v for k,v in y.items()if k!='actual'},'Original identity,answer,context or capture selection changed'
        p=x['actual']==x['expected'];q=y['actual']==y['expected'];counts['rows']+=1;counts['before']+=p;counts['after']+=q;counts['gains']+=q and not p;counts['losses']+=p and not q;counts['changed_outputs']+=x['actual']!=y['actual']
        if x['actual']!=y['actual']:changes.append(dict(before=x,after=y))
    out.append(dict(function=name,counts=counts,changes=changes,input_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in(before,trace,Path(__file__))},limits='Strict positional reconciliation of every original canonical-judge record, including repeated NaN-argument identities. All fields except actual must be byte-equivalent JSON values; no deduplication, removed obligation or changed answer admitted. Existing unique-key bank-delta correctly refused duplicate NaN keys; its failed attempt is retained.'))
with(r/'binade-bank-deltas.json').open('x')as f:json.dump(out,f,indent=2)
print(json.dumps({x['function']:x['counts']for x in out}),flush=True)
