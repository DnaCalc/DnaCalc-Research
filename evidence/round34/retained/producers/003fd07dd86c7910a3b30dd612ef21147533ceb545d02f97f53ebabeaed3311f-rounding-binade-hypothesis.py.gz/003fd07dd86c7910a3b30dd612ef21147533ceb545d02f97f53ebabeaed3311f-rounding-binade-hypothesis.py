"""One fixed original initial-reading hypothesis; no application changes."""
from pathlib import Path
from fractions import Fraction as Q
import hashlib,json,math,struct,sys
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer')
from number_conversion import decade,ten,radix16_scale
from checker.exact import EXTENDED64 as F

def number(s):return struct.unpack('>d',bytes.fromhex(s.removeprefix('0x')))[0]
def bits(x):return '0x'+struct.pack('>d',x).hex()
def reading(x):
    # A binary exponent chooses an upper-bound decimal decade. The same
    # low-nibble-first power scaling established for publication then brings
    # the value near15 digits; a single factor10 corrects its decade.
    v=Q(abs(x));e=math.frexp(abs(x))[1];rough=decade(Q(2)**e)
    y=radix16_scale(v,14-rough)
    if y<Q(10**14):y=F.round(y*10);rough-=1
    if y>=Q(10**15):y=F.round(y/10);rough+=1
    coefficient=int(y+Q(1,2));power=rough-14
    while coefficient and coefficient%10==0:coefficient//=10;power+=1
    result=float(radix16_scale(Q(coefficient),power))
    return -result if x<0 else result

root=Path('/home/ubuntu/codex-runs/r34');source=root/'radix-TRUNC-after.jsonl'
scoped=0;excluded=0;matched=0;old_matched=0;first=[]
for line in source.open():
    row=json.loads(line)
    if not row['expected'].startswith('0x'):excluded+=1;continue
    args=row['args']
    if len(args)not in(1,2)or any(not isinstance(a,str)or not a.startswith('0x')for a in args):excluded+=1;continue
    x=number(args[0]);n=number(args[1])if len(args)==2 else 0.
    if not math.isfinite(x)or not math.isfinite(n)or abs(x)<sys.float_info.min:excluded+=1;continue
    # Read whole fifteen-digit publications only; all other digit decisions
    # are outside this declared initial-stage constraint.
    places=(int(abs(n))&65535)if abs(n)<2**32 else 32768
    if n<0 or places>=32768 or places<14-decade(Q(abs(x))):excluded+=1;continue
    expected=number(row['expected'])
    if not math.isfinite(expected)or abs(expected)<sys.float_info.min:excluded+=1;continue
    try:got=bits(reading(x))
    except OverflowError:got='error:Num'
    scoped+=1;matched+=got==row['expected'];old_matched+=row['actual']==row['expected']
    if got!=row['expected']and len(first)<5:first.append(dict(original=row,prediction=got))
out=dict(complete=True,program='upper-binade decade; PC64 low-nibble signed power scaling; one decimal correction; half-up coefficient; independently established normalized publication',scoped=scoped,excluded=excluded,matching_publications=matched,prior_application_matching=old_matched,first_contradictions=first,inputs_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in(source,Path(__file__),Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer/number_conversion.py'))},limits='One fixed mathematical initial-reading hypothesis on unchanged bank inputs; all old observations are discovery. This is not an application result, product gain, fitted table or an identified full conversion kernel.')
with(root/'rounding-binade-hypothesis.json').open('x')as f:json.dump(out,f,indent=2)
print(json.dumps({k:out[k]for k in('scoped','excluded','matching_publications','prior_application_matching')}))
