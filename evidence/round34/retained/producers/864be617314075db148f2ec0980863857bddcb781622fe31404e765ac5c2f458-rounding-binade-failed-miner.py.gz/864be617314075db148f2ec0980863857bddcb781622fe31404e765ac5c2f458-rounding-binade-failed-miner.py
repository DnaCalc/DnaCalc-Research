from pathlib import Path
from fractions import Fraction as Q
import importlib.util,hashlib,json,math,struct,sys
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer')
from number_conversion import decade,ten,radix16_scale
from checker.exact import EXTENDED64 as F
from fingerprint import load_service,CachedService

def bits(x):return struct.pack('>d',float(x)).hex()
def candidate(x):
    e=decade(Q(2)**math.frexp(x)[1]);y=radix16_scale(Q(x),14-e)
    if y<10**14:y=F.round(y*10);e-=1
    if y>=10**15:y=F.round(y/10);e+=1
    c=int(y+Q(1,2));power=e-14
    while c and c%10==0:c//=10;power+=1
    return bits(radix16_scale(Q(c),power))
def old(x):
    e=decade(Q(x));shift=14-e
    y=F.round(Q(x)*ten(shift))if abs(shift)<=27 else F.round(Q(x)*F.round(ten(shift)))if shift>0 else F.round(Q(x)/F.round(ten(-shift)))
    c=int(y+Q(1,2));power=e-14
    while c and c%10==0:c//=10;power+=1
    return bits(radix16_scale(Q(c),power))

root=Path('/home/ubuntu/codex-runs/r34');cases=[]
for cohort,seed in [('discovery',340011),('holdout',88173)]:
    selected=0
    for e in range(-300,301,7):
        for _ in range(1000):
            seed=(6364136223846793005*seed+1442695040888963407)%2**64
            c=100000000000000+seed%900000000000000
            x=float((Q(c)+Q(1,2))*ten(e-14))
            if not math.isfinite(x)or x<=sys.float_info.min*2:continue
            if candidate(x)==old(x):continue
            for sign in(1,-1):
                wanted=candidate(x);prior=old(x)
                if sign<0:wanted=bits(-struct.unpack('>d',bytes.fromhex(wanted))[0]);prior=bits(-struct.unpack('>d',bytes.fromhex(prior))[0])
                cases.append(dict(cohort=cohort,input_bits=bits(sign*x),expected_program=wanted,prior_program=prior))
            selected+=1
            if selected>=16:break
        if selected>=16:break
    if selected!=16:raise ValueError('insufficient independent discriminants')
client,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');service=CachedService(client.Client(timeout=120),root/'scalar-cache')
questions=dict(cases=cases,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),selection='Two fixed independent integer sequences; exact half-coefficient neighborhoods; first16 old/new initial-stage discriminants per cohort before asking Excel; both signs. Initial64-target mining attempt found too few cases and made no service request; fixed16-point budget selected before any new answer.')
with(root/'rounding-binade-fresh-questions.json').open('x')as f:json.dump(questions,f,indent=2)
answers={};counts={}
for function in('TRUNC','ROUNDDOWN','ROUNDUP'):
    answers[function]=service.ask_rows(function,[[client.number(c['input_bits']),client.number(32000.)]for c in cases])
    counts[function]={cohort:dict(rows=sum(c['cohort']==cohort for c in cases),candidate=sum(c['cohort']==cohort and a.get('bits')==c['expected_program']for c,a in zip(cases,answers[function])),prior=sum(c['cohort']==cohort and a.get('bits')==c['prior_program']for c,a in zip(cases,answers[function])))for cohort in('discovery','holdout')}
with(root/'rounding-binade-fresh.json').open('x')as f:json.dump(dict(complete=True,counts=counts,cases=cases,answers=answers,receipts=service.receipts,source_sha256=questions['source_sha256'],limits='Whole initial-reading publications only, newly read through the existing audited service. Fixed algorithm, no fitted table. Later digit decisions and initial-underflow branch remain separate.'),f,indent=2)
print(json.dumps(counts),flush=True)
