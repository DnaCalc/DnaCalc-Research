from pathlib import Path
from fractions import Fraction as Q
import importlib.util,hashlib,json,math,struct,sys
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer')
from number_conversion import decade,ten,radix16_scale
from checker.exact import EXTENDED64 as F
from fingerprint import load_service,CachedService

def bits(x):return struct.pack('>d',float(x)).hex()
def candidate(x):
    e=decade(Q(2)**math.frexp(x)[1]);y=radix16_scale(Q(x),14-e)
    if y<10**14:y=F.round(y*10);e-=1
    if y>=10**15:y=F.round(y/10);e+=1
    c=int(y+Q(1,2));power=e-14
    while c and c%10==0:c//=10;power+=1
    return bits(radix16_scale(Q(c),power))
def old(x):
    e=decade(Q(x));shift=14-e
    y=F.round(Q(x)*ten(shift))if abs(shift)<=27 else F.round(Q(x)*F.round(ten(shift)))if shift>0 else F.round(Q(x)/F.round(ten(-shift)))
    c=int(y+Q(1,2));power=e-14
    while c and c%10==0:c//=10;power+=1
    return bits(radix16_scale(Q(c),power))

root=Path('/home/ubuntu/codex-runs/r34');cases=[];seen=set();anchors=[]
for line in(root/'radix-TRUNC-after.jsonl').open():
    row=json.loads(line);args=row['args']
    if not args or not isinstance(args[0],str)or not args[0].startswith('0x'):continue
    x=abs(struct.unpack('>d',bytes.fromhex(args[0][2:]))[0])
    if not math.isfinite(x)or x<2*sys.float_info.min:continue
    encoded=bits(x)
    if encoded in seen:continue
    seen.add(encoded)
    try:different=candidate(x)!=old(x)
    except OverflowError:continue
    if different:anchors.append(x)
anchors.sort();assert len(anchors)>=16
for index in range(16):
    anchor=anchors[index*(len(anchors)-1)//15]
    for offset in(-3,-1,0,1,3):
        x=anchor
        for _ in range(abs(offset)):x=math.nextafter(x,0. if offset<0 else math.inf)
        for sign in(1,-1):
            wanted=candidate(x);prior=old(x)
            if sign<0:wanted=bits(-struct.unpack('>d',bytes.fromhex(wanted))[0]);prior=bits(-struct.unpack('>d',bytes.fromhex(prior))[0])
            cases.append(dict(cohort='center'if offset==0 else'neighbor',anchor=bits(anchor),offset=offset,previously_recorded_input=bits(x)in seen,input_bits=bits(sign*x),expected_program=wanted,prior_program=prior))
client,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');service=CachedService(client.Client(timeout=120),root/'scalar-cache')
questions=dict(cases=cases,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),selection='One fixed program;16 evenly spaced ascending input anchors where old/new mathematical programs differ, independent of Excel answers; offsets-3,-1,0,1,3 and both signs. Centers are discovery repeats; neighbors explicitly mark any prior-bank overlap. Failed64/16-target independent miners made no service request; they remain failed attempts, not validation.')
with(root/'rounding-binade-fresh-questions.json').open('x')as f:json.dump(questions,f,indent=2)
answers={};counts={}
for function in('TRUNC','ROUNDDOWN','ROUNDUP'):
    answers[function]=service.ask_rows(function,[[client.number(c['input_bits']),client.number(32000.)]for c in cases])
    counts[function]={cohort:dict(rows=sum(c['cohort']==cohort for c in cases),candidate=sum(c['cohort']==cohort and a.get('bits')==c['expected_program']for c,a in zip(cases,answers[function])),prior=sum(c['cohort']==cohort and a.get('bits')==c['prior_program']for c,a in zip(cases,answers[function])))for cohort in('center','neighbor')}
with(root/'rounding-binade-fresh.json').open('x')as f:json.dump(dict(complete=True,counts=counts,cases=cases,answers=answers,receipts=service.receipts,source_sha256=questions['source_sha256'],limits='Whole initial-reading publications only, newly read through the existing audited service. Fixed algorithm, no fitted table. Later digit decisions and initial-underflow branch remain separate.'),f,indent=2)
print(json.dumps(counts),flush=True)
