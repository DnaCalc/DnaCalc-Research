from racer.ets_seasonal import *

grid=read(OUT/'step7-gamma-structured-fresh-frozen.json')['grid'];rows=[]
for name in ['step7-initialization-fresh','step7-initialization-window-fresh','step7-initialization-partial-fresh']:
 d=read(OUT/(name+'-parameters.json'));st=grouped(d)
 for i,cs in enumerate(d['cases']):
  y=cs['y'];p=cs['season'];init=moving_initial(y,p);n=len(y)
  tail=n if n<=10 else min(int(.4*n),10);start=n-tail
  def score(par):
   a,b,g=par;l,t,se=init[0],init[1],init[2].copy();errors=[0.]
   for j,v in enumerate(y[1:],1):
    q=j%p;e=v-((l+t)+se[q]);errors.append(e)
    if start and j>=start:l+=t
    else:l=l+(t+a*e);t+=b*e;se[q]+=g*e
   return sequential_total(v*v for v in errors)
  actual=[value(st[i][str(k)]['bits'])for k in [1,2,3]];pred=min(grid,key=score)
  rows.append(dict(source=name,case=i,actual=actual,predicted=pred,matched=actual==pred,observed_triple_in_family=actual in grid))
write(OUT/'step7-gamma-generalization-refutations.json',dict(rows=rows,matched=sum(z['matched']for z in rows),total=len(rows),missing_reported_triples=sorted(set(tuple(z['actual'])for z in rows if not z['observed_triple_in_family'])),producer_source=Path(__file__).read_text(),model_source=Path('racer/ets_seasonal.py').read_text(),limits='Out-of-domain check refutes extending the25-point nullspace family to general period-two noise. No extra triples are appended and no product extension follows.'))
print('bounded family outside proved region:',sum(z['matched']for z in rows),'of',len(rows),'observed triple absent',sum(not z['observed_triple_in_family']for z in rows))
