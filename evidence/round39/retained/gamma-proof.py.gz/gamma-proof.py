import random,math
from pathlib import Path
from racer.ets import *
from racer.ets_proof import freeze,finish
rng=random.Random(399903);cases=[]
for i in range(64):
 n=rng.randrange(3,33)if i<32 else rng.randrange(3,8);ex=rng.randrange(-350,351)
 base=value(f'{int(bits(1.3),16)+rng.randrange(-16,17):016x}')
 y=[math.ldexp(base,ex)]*n if i<32 else[math.ldexp(rng.randrange(-64,65)/16,ex)for _ in range(n)]
 cases.append(dict(y=y,season=0))
pred=[bits(2.**-52)]*len(cases);name='step6-independent-gamma';freeze(name,dict(cases=cases,predictions=pred,extra_source=Path(__file__).read_text(),program='Nonseasonal gamma is epsilon independently of the unidentified initial state; short and rounded-constant histories.'))
finish(name,cases,pred,'FORECAST.ETS.STAT',[3])
