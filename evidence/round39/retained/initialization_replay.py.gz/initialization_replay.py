from racer.ets_seasonal import *

rows=[]
for name in ['step7-initialization-fresh','step7-initialization-window-fresh']:
 d=read(OUT/(name+'-parameters.json'));st=grouped(d)
 fo=grouped(read(OUT/(name+'-forecast-answers.json')))
 stats=grouped(read(OUT/(name+'-stat-answers.json')));badf=[];bads=[]
 for i,cs in enumerate(d['cases']):
  y=cs['y'];a,b,g=[value(st[i][str(k)]['bits'])for k in [1,2,3]]
  l,t,se,e,pr=fit(y,2,a,b,g,moving_initial(y,2))
  for h in [0.,1.,2.,5.]:
   predicted=bits((l+h*t)+se[(len(y)-1+int(h))%2]);actual=fo[i][str(h)]['bits']
   if predicted!=actual:badf.append(dict(case=i,n=len(y),h=h,predicted=predicted,actual=actual))
  for k,v in zip([4,5,6,7],statistics_from_errors(y,e,pr)):
   if bits(v)!=stats[i][str(k)]['bits']:bads.append(dict(case=i,n=len(y),stat=k,predicted=bits(v),actual=stats[i][str(k)]['bits']))
 rows.append(dict(source=name,forecast_selections=512,forecast_failures=badf,stat_selections=512,stat_failures=bads))
write(OUT/'step7-initialization-partial-retained.json',dict(rows=rows,producer_source=Path(__file__).read_text(),model_source=Path('racer/ets_seasonal.py').read_text(),limits='Retained validation after refuting both complete-cycle count rules. Fresh independent boundary proof is required and stored separately.'))
print([(z['source'],len(z['forecast_failures']),len(z['stat_failures']))for z in rows])
