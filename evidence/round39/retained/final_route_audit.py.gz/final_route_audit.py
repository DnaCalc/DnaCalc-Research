from pathlib import Path
from collections import Counter
import gzip,hashlib,json

r=Path('/home/ubuntu/codex-runs/round39');replay=r/'application-replay-pushed-complete'
read=lambda p:json.loads(gzip.decompress(p.read_bytes())if p.suffix=='.gz'else p.read_bytes())
groups={};losses=[];totals=Counter()
def verdict(row,pred):
 p=pred['calc_func_prediction']
 return 'matched'if p==row['expected']else'refused'if p.startswith('fault:')and'NotHeld'in p else'failed'if p.startswith('fault:')else'mismatched'
def ordered(raw):
 v=int(raw,16)
 return (~v)&((1<<64)-1)if v>>63 else v|(1<<63)
summary=read(replay/'summary.json')
for name in summary['functions']:
 q=read(replay/(name+'.inputs.json.gz'))['witnesses']
 p=[json.loads(line)for line in gzip.decompress((replay/(name+'.predictions.jsonl.gz')).read_bytes()).splitlines()]
 assert len(q)==len(p);groups[name]=list(zip(q,p))
 for row,pred in groups[name]:
  assert row['id']==pred['id']and row['args']==pred['args'];kind=verdict(row,pred);totals[kind]+=1
  if kind=='mismatched':
   e,a=row['expected'],pred['calc_func_prediction'];ulp=abs(ordered(e[2:])-ordered(a[2:]))if e.startswith('0x')and a.startswith('0x')else None
   losses.append(dict(function=name,**row,prediction=a,ulp=ulp))
prefixes=['step45-final-validation','step7-zero-residual','step7-zero-edges','step8-automatic-two','step8-automatic-lattice-edges','step7-initialization-partial-fresh']
subsets={}
for prefix in prefixes:
 for path in sorted(r.glob(prefix+'-*-answers.json')):
  d=read(path);name=d['function'];files={z['file']for z in d['receipts']if z['function']==name}
  chosen=[(a,b)for a,b in groups[name]if a['source'].split('/')[-1]in files]
  assert len(chosen)==len(d['answers']),(path,len(chosen),len(d['answers']))
  subsets[path.stem.removesuffix('-answers')]=dict(total=len(chosen),counts=Counter(verdict(a,b)for a,b in chosen))
q=read(r/'normal-upper-route-v3-inputs.json')['witnesses'];p=[json.loads(line)for line in(r/'normal-upper-pushed-predictions.jsonl').read_text().splitlines()]
assert len(q)==len(p)==177
normal=Counter()
for a,b in zip(q,p):
 assert a['id']==b['id']and a['args']==b['args'];normal[verdict(a,b)]+=1
doc=dict(totals=totals,mismatches_by_function=Counter(x['function']for x in losses),magnitude_counts=Counter('non_numeric'if x['ulp']is None else'small_ulp_1_to_16'if x['ulp']<=16 else'larger_than_16_ulp'for x in losses),losses=losses,subsets=subsets,normal_upper=dict(total=177,counts=normal),executable_sha256=summary['executable_sha256'],compiled_provenance=summary['compiled_provenance'],producer_source=Path(__file__).read_text())
(r/'final-registered-route-audit.json').write_text(json.dumps(doc,indent=2)+'\n')
print('totals',dict(totals),'magnitude',dict(doc['magnitude_counts']),'normal',dict(normal))
print('subsets',subsets)
