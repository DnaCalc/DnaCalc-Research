import random,math,json
from pathlib import Path
from racer.ets import *
from racer.ets_optimizer import parameters,corrected
from racer.ets_proof import freeze,finish
rng=random.Random(399775);cases=[];pred=[];raw=[]
for i in range(24):
 n=rng.randrange(8,33);ex=rng.randrange(-200,201);half=[rng.randrange(-32,33)for _ in range((n+1)//2)];ys=half+half[-2::-1]if n%2 else half+half[::-1]
 for drift in [0.,2.**-20,2.**-40]:
  y=[math.ldexp(v+drift*j,ex)for j,v in enumerate(ys)];a,b=parameters(y);l,t,se,pb,e,p,corr=corrected(y,a,b);t0=initial_trend(y)
  if t0==0.:
   l,t,se,e,p=numeric_fit(y,a,b,t0)
  cases.append(dict(y=y,season=0));raw.append(dict(alpha=a,beta=b,initial_trend=t0,correction=corr))
  pred.extend(bits((l+h*t)+se[(n-1+int(h))%2])for h in [0.,1.,2.,5.])
name='step5-zero-trend-correction';freeze(name,dict(cases=cases,predictions=pred,raw=raw,extra_source=Path(__file__).read_text(),candidate='Apply the measured correction only for a nonzero initial regression trend; explicit zero and tiny nonzero drift separate the condition.'))
finish(name,cases,pred,'FORECAST.ETS',[0.,1.,2.,5.])
