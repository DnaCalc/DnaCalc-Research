from racer.ets_seasonal import *

def analyze():
 d=read(OUT/'step7-positive-basis-stat.json');st=grouped(d);fo=grouped(read(OUT/'step7-positive-basis-forecast.json'));programs=[]
 for ma,adj,lev in itertools.product(['direct','subtract_add','add_difference'],['centered','raw'],['centered','raw']):
  exact=0;bad=[];worst=0
  for i,cs in enumerate(d['cases']):
   y,p=cs['y'],cs['season'];pars=[value(st[i][str(k)]['bits'])for k in [1,2,3]];l,t,se,e,pr=fit(y,p,*pars,moving_initial(y,p,ma,adj,lev))
   for h in range(10):
    predicted=bits((l+h*t)+se[(len(y)-1+h)%p]);actual=fo[i][str(h)]['bits']
    if predicted==actual:exact+=1
    else:
     ulp=abs(int(predicted,16)-int(actual,16));worst=max(worst,ulp)
     if len(bad)<5:bad.append(dict(case=i,h=h,predicted=predicted,actual=actual,ulp=ulp))
  programs.append(dict(ma=ma,adjustment=adj,level=lev,exact=exact,total=2050,worst_ulp=worst,first_refutations=bad))
 write(OUT/'step7-moving-average-programs.json',dict(programs=programs,producer_source=Path(__file__).read_text(),shape='First min(3,n//p-2) cycles; forward 2p-point average, observation offset p//2-1; center phase deviations; regress seasonally adjusted whole history. Original tier1 basis mapping; no polynomial fitting.',limits='Retained diagnostic comparisons, not fresh proof.'))
 print(sorted(programs,key=lambda z:z['exact'],reverse=True)[:3])

if __name__=='__main__':analyze()
