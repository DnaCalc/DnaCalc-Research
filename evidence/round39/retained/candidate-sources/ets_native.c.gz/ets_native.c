/* Original MIT experiment: prescribed extended intermediates, binary64 state. */
#include <math.h>
static long double st(long double x, int yes) { if(yes) { volatile double y=(double)x; return y; } return x; }
static long double initial(const double *y,int n,int sk,int mask) {
 if(sk<0)return y[n];
 long double sy=0,sxy=0,sx=0,sxx=0,mean=0,mx=(n-1)/2.L;
 for(int i=0;i<n;i++) sy=st(sy+y[i],mask&1);
 mean=st(sy/n,mask&2);
 for(int i=0;i<n;i++) {
  long double x=i+(sk==3||sk==5);
  sx=st(sx+x,mask&1);sxx=st(sxx+st(x*x,mask&4),mask&1);
  if(sk==0) sxy=st(sxy+st((i-mx)*st(y[i]-mean,mask&8),mask&4),mask&1);
  else if(sk==1) sxy=st(sxy+st((i-mx)*y[i],mask&4),mask&1);
  else sxy=st(sxy+st(x*y[i],mask&4),mask&1);
 }
 if(sk<2)return st(sxy/(n*(n*(long double)n-1)/12.L),mask&16);
 if(sk<4)return st(st(st(n*sxy,mask&4)-st(sx*sy,mask&4),mask&8)/st(n*sxx-sx*sx,mask&8),mask&16);
 return st(st(sxy-st(st(sx/n,mask&2)*sy,mask&4),mask&8)/st(sxx-st(sx*sx/n,mask&4),mask&8),mask&16);
}
double ets_initial(const double *y,int n,int sk,int mask,int pc) {
 unsigned short saved,cw=pc==53?0x127f:0x137f;__asm__ volatile("fnstcw %0; fldcw %1":"=m"(saved):"m"(cw));
 volatile double out=(double)initial(y,n,sk,mask);
 __asm__ volatile("fldcw %0"::"m"(saved));return out;
}
void ets_fit(const double *y,int n,double a,double b,int sk,int sm,int m,double *out) {
 long double l=y[0],t=initial(y,n,sk,sm),s[2]={0,0};out[2]=0;
 for(int i=1;i<n;i++) {
  int q=i%2;long double p=st(l+t,m&1),e;
  if(m&16384)e=st(y[i]-st(p+s[q],m&512),m&2);
  else e=st(st(y[i]-p,m&512)-s[q],m&2);
  long double next=st(st(a*st(y[i]-s[q],m&1024),m&4)+st(st(1.L-a,m&8)*p,m&16),m&32);
  if(m&32768)next=st(p+st(a*e,m&4),m&32);
  t=st(t+st(b*e,m&64),m&128); l=next; s[q]=st(s[q]+st(0x1p-52L*e,m&2048),m&4096);
  out[2+i]=(double)e;
 }
 out[0]=(double)l;out[1]=(double)t;
 for(int h=0;h<6;h++)out[2+n+h]=m&65536?(double)(st(l+s[(n-1+h)%2],m&8192)+st(h*t,m&256)):(double)(st(l+st(h*t,m&256),m&8192)+s[(n-1+h)%2]);
}

void ets_tree_fit(const double *y,int n,double a,double b,int sk,int sm,int m,int variant,double *out) {
 long double l=sk==-2?y[n+1]:y[0],t=initial(y,n,sk,sm),s[2]={0,0},g=0x1p-52L;
 int ek=variant%5,tk=variant/5%5,sg=variant/25%6,lk=variant/150%6;
 for(int i=1;i<n;i++) {
  int q=i%2;long double old=l,oldt=t,ss=s[q],p=st(l+t,m&1),e;
  if(ek==0)e=st(y[i]-st(p+ss,m&512),m&2);
  else if(ek==1)e=st(st(y[i]-p,m&512)-ss,m&2);
  else if(ek==2)e=st(st(y[i]-ss,m&512)-p,m&2);
  else if(ek==3)e=st(st(st(y[i]-ss,m&512)-l,m&512)-t,m&2);
  else e=st(st(st(y[i]-l,m&512)-t,m&512)-ss,m&2);
  if(lk==0)l=st(st(a*st(y[i]-ss,m&1024),m&4)+st(st(1.L-a,m&8)*p,m&16),m&32);
  else if(lk==1)l=st(p+st(a*e,m&4),m&32);
  else if(lk==2)l=st(st(st(a*(long double)y[i],m&4)+st(st(1.L-a,m&8)*st(p+ss,m&1),m&16),m&32)-ss,m&32);
  else if(lk==3)l=st(st(st(a*(long double)y[i],m&4)+st(st(1.L-a,m&8)*p,m&16),m&32)-st(a*ss,m&4),m&32);
  else {long double d=st(st(y[i]-old,m&512)-ss,m&1024),ae=st(a*d,m&4),tp=st(st(1.L-a,m&8)*oldt,m&16);l=lk==4?st(st(old+ae,m&1)+tp,m&32):st(old+st(ae+tp,m&1),m&32);}
  if(tk==0)t=st(t+st(b*e,m&64),m&128);
  else if(tk==1)t=st(st(b*st(st(y[i]-ss,m&512)-old,m&2),m&64)+st(st(1.L-b,m&8)*oldt,m&16),m&128);
  else if(tk==2) { long double r=st(b/a,m&8); t=st(st(r*st(l-old,m&2),m&64)+st(st(1.L-r,m&8)*oldt,m&16),m&128); }
  else if(tk==3)t=st(oldt+st(b*st(st(st(y[i]-ss,m&512)-old,m&512)-oldt,m&2),m&64),m&128);
  else t=st(oldt+st(b*st(st(y[i]-ss,m&512)-st(old+oldt,m&1),m&2),m&64),m&128);
  if(sg==0)s[q]=st(ss+st(g*e,m&2048),m&4096);
  else if(sg==1)s[q]=st(st(g*st(y[i]-p,m&2),m&2048)+st((1-g)*ss,m&16),m&4096);
  else if(sg==2) { long double r=st(g/st(1.L-a,m&8),m&8);s[q]=st(st(r*st(y[i]-l,m&2),m&2048)+st(st(1.L-r,m&8)*ss,m&16),m&4096); }
  else if(sg==3) { long double r=st(g/st(1.L-a,m&8),m&8);s[q]=st(ss+st(r*st(st(y[i]-l,m&512)-ss,m&2),m&2048),m&4096); }
  else if(sg==4)s[q]=st(st(g*st(st(y[i]-old,m&512)-t,m&2),m&2048)+st((1-g)*ss,m&16),m&4096);
  else s[q]=st(st(g*st(st(y[i]-l,m&512)-t,m&2),m&2048)+st((1-g)*ss,m&16),m&4096);
 }
 if(!(m&1048576)) { long double mean=st((s[0]+s[1])/2,!(m&131072)); l=st(l+mean,!(m&262144));s[0]=st(s[0]-mean,!(m&524288));s[1]=st(s[1]-mean,!(m&524288)); }
 out[0]=(double)l;out[1]=(double)t;
 for(int h=0;h<6;h++)out[2+n+h]=m&65536?(double)(st(l+s[(n-1+h)%2],m&8192)+st(h*t,m&256)):(double)(st(l+st(h*t,m&256),m&8192)+s[(n-1+h)%2]);
}

#include <stdint.h>
#include <string.h>
int ets_search(double *y,int n,double a,double b,uint64_t raw,int radius,const uint32_t *profiles,int count,uint32_t *out_profiles,uint64_t *out_spans,const uint64_t *expected) {
 double out[200];int kept=0,hs[4]={0,1,2,5};
 for(int i=0;i<count;i++) {
  int m=profiles[i]>>10,v=profiles[i]&1023;uint64_t span=0;
  for(int k=-radius;k<=radius;k++) {
   uint64_t r=raw+k;memcpy(&y[n],&r,8);ets_tree_fit(y,n,a,b,-1,0,m,v,out);int same=1;
   for(int h=0;h<4;h++) {uint64_t got;memcpy(&got,&out[2+n+hs[h]],8);if(got!=expected[h]){same=0;break;}}
   if(same)span|=1ULL<<(k+radius);
  }
  if(span){out_profiles[kept]=profiles[i];out_spans[kept]=span;kept++;}
 }
 return kept;
}

int ets_search_first(double *y,int n,double a,double b,uint64_t raw,int radius,const uint32_t *profiles,int count,uint32_t *out_profiles,int *offsets,const uint64_t *expected) {
 double out[200];int kept=0,hs[4]={0,1,2,5};
 for(int i=0;i<count;i++) {
  int m=profiles[i]>>10,v=profiles[i]&1023;
  for(int k=-radius;k<=radius;k++) {
   uint64_t r=raw+k;memcpy(&y[n],&r,8);ets_tree_fit(y,n,a,b,-1,0,m,v,out);int same=1;
   for(int h=0;h<4;h++) {uint64_t got;memcpy(&got,&out[2+n+hs[h]],8);if(got!=expected[h]){same=0;break;}}
   if(same){out_profiles[kept]=profiles[i];offsets[kept]=k;kept++;break;}
  }
 }
 return kept;
}

int ets_search_first53(double *y,int n,double a,double b,uint64_t raw,int radius,const uint32_t *profiles,int count,uint32_t *out_profiles,int *offsets,const uint64_t *expected) {
 unsigned short saved,cw=0x127f;__asm__ volatile("fnstcw %0; fldcw %1":"=m"(saved):"m"(cw));
 int result=ets_search_first(y,n,a,b,raw,radius,profiles,count,out_profiles,offsets,expected);
 __asm__ volatile("fldcw %0"::"m"(saved));return result;
}

void ets_matrix_fit(const double *y,int n,double a,double b,int m,int order,double *out) {
 int permutations[6][3]={{0,1,2},{0,2,1},{1,0,2},{1,2,0},{2,0,1},{2,1,0}};
 long double l=y[0],t=y[n],s[2]={0,0},g=0x1p-52L;
 long double co[3][3]={{st(1.L-a,m&1),st(1.L-a,m&1),-a},{-b,st(1.L-b,m&1),-b},{-g,-g,st(1.L-g,m&1)}};
 long double gains[3]={a,b,g};
 for(int j=1;j<n;j++) {
  int q=j%2;long double state[3]={l,t,s[q]},next[3];
  for(int row=0;row<3;row++) {
   long double term=st(gains[row]*y[j],m&128),sum=order>=6?term:0;
   for(int k=0;k<3;k++) {int c=permutations[order%6][k];long double p=st(co[row][c]*state[c],m&(2<<row));sum=st(sum+p,m&(16<<row));}
   if(order<6)sum=st(sum+term,m&(16<<row));next[row]=st(sum,1);
  }
  l=next[0];t=next[1];s[q]=next[2];
 }
 if(m&1024){long double mu=st((s[0]+s[1])/2,!(m&2048));l=st(l+mu,!(m&4096));s[0]=st(s[0]-mu,!(m&8192));s[1]=st(s[1]-mu,!(m&8192));}
 for(int h=0;h<6;h++)out[h]=m&16384?(double)(st(l+s[(n-1+h)%2],m&512)+st(h*t,m&256)):(double)(st(l+st(h*t,m&256),m&512)+s[(n-1+h)%2]);
}
int ets_matrix_search(double *y,int n,double a,double b,uint64_t raw,int radius,const uint32_t *profiles,int count,uint32_t *kept,int *offsets,const uint64_t *expected) {
 int nk=0,hs[4]={0,1,2,5};double out[6];
 for(int i=0;i<count;i++) {int m=profiles[i]>>4,ord=profiles[i]&15;
  for(int k=-radius;k<=radius;k++){uint64_t r=raw+k;memcpy(&y[n],&r,8);ets_matrix_fit(y,n,a,b,m,ord,out);int same=1;for(int j=0;j<4;j++){uint64_t got;memcpy(&got,&out[hs[j]],8);if(got!=expected[j]){same=0;break;}}
   if(same){kept[nk]=profiles[i];offsets[nk]=k;nk++;break;}
  }
 }
 return nk;
}
