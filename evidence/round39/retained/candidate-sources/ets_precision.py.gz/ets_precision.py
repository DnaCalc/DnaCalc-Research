"""Finite instruction/store/precision experiments for the ETS state equations.

Original MIT code. Uses the existing native ISA interpreter, never a host-float
substitute for a proposed instruction. Candidate programs must match every row.
"""
from itertools import combinations, product
import ctypes as C
import json
from pathlib import Path
import numpy as np
from .ets import OUT, read, grouped, bits, write, sha
from .x87_programs import Builder, Native, Node, build_library

TAGS=['complement','prediction','error','difference','alpha_product','trend_product',
      'delta','level','beta_parameter','beta_complement','beta_product','trend','gamma_parameter','gamma_complement','gamma_product','season','mean','center','season_center','horizon','forecast','publication']

def graph(phases=(), stores=None, error_form=0, alpha_kind=0, beta_kind=0, slope_input=False, level_form=0, trend_form=0, season_form=0):
    g=Builder(4 if slope_input else 3); phases=set(phases)
    if stores is None:stores={'prediction','delta','level','beta_product','trend','gamma_product','season','mean','center','season_center','horizon','forecast'}
    stores=set(stores)
    def op(kind,a,b,tag):
        g.phase=int(tag in phases)
        result=g.op(kind,a,b,store=tag in stores)
        g.nodes[result]['tag']=tag
        return result
    z=g.constant(bits(0.));two=g.constant(bits(2.));a=g.constant(bits(.1));b=g.constant(bits(.099));gamma=g.constant(bits(2.**-52))
    if alpha_kind:a=g.op('div',g.one,g.constant(bits(10.)),store=False)
    if beta_kind==1:b=g.op('sub',a,g.constant(bits(.001)),store=False)
    elif beta_kind==2:b=g.op('div',g.constant(bits(99.)),g.constant(bits(1000.)),store=False)
    elif beta_kind==3:b=g.op('sub',a,g.op('div',g.one,g.constant(bits(1000.)),store=False),store=False)
    comp=op('sub',g.one,a,'complement');l=0;t=3 if slope_input else z;s=[z,z]
    br=op('div',b,a,'beta_parameter')if trend_form else b
    bc=op('sub',g.one,br,'beta_complement')if trend_form else None
    gr=op('div',gamma,comp,'gamma_parameter')if season_form else gamma
    gc=op('sub',g.one,gr,'gamma_complement')if season_form else None
    for j,y in [(1,1),(2,0)]:
        q=j%2;old=l;tt=t;p=op('add',l,t,'prediction')
        if error_form==0:e=op('sub',y,op('add',p,s[q],'error'),'error')
        else:e=op('sub',op('sub',y,p,'error'),s[q],'error')
        if level_form==1:
            d=op('sub',y,s[q],'difference');ae=op('mul',a,d,'alpha_product');tp=op('mul',comp,p,'trend_product');l=op('add',ae,tp,'level')
        else:
            d=op('sub',op('sub',y,l,'difference'),s[q],'difference')
            ae=op('mul',a,d,'alpha_product');tp=op('mul',comp,t,'trend_product')
            if level_form==2:l=op('add',op('add',l,ae,'delta'),tp,'level')
            else:
                delta=op('add',ae,tp,'delta');l=op('add',l,delta,'level')
        if trend_form:
            change=op('sub',l,old,'difference');be=op('mul',br,change,'beta_product');bt=op('mul',bc,tt,'beta_product');t=op('add',be,bt,'trend')
        else:
            be=op('mul',b,e,'beta_product');t=op('add',t,be,'trend')
        if season_form:
            ge=op('mul',gr,op('sub',y,l,'difference'),'gamma_product');gs=op('mul',gc,s[q],'gamma_product');s[q]=op('add',ge,gs,'season')
        else:
            ge=op('mul',gamma,e,'gamma_product');s[q]=op('add',s[q],ge,'season')
    mean=op('div',op('add',s[0],s[1],'mean'),two,'mean')
    l=op('add',l,mean,'center');s=[op('sub',v,mean,'season_center')for v in s]
    # Input2 is the horizon; each graph separately chooses its observed phase.
    outputs=[]
    for v in s:
        p=op('mul',2,t,'horizon');p=op('add',l,p,'forecast');outputs.append(op('add',p,v,'publication'))
    return g.graph(*outputs)

def run():
    lib=OUT/'x87-ets.so'
    build_library(lib);native=Native(lib)
    d=read(OUT/'step2-three-stat.json');fo=grouped(read(OUT/'step2-three-forecast.json'))
    inputs=[];expected=[]
    for i,z in enumerate(d['cases']):
        for h in [0.,1.,2.,5.]:
            inputs.append([int(bits(z['y'][0]),16),int(bits(z['y'][1]),16),int(bits(h),16)])
            expected.append(int(fo[i][str(h)]['bits'],16))
    inputs=np.array(inputs,dtype='uint64');expected=np.array(expected,dtype='uint64');selector=np.array([int(h)%2 for _ in d['cases']for h in [0.,1.,2.,5.]])
    results=[];tops=[]
    ptr=C.POINTER(C.c_uint64);probe_inputs=np.ascontiguousarray(inputs[88:92]);probe_out=np.empty((4,2),dtype='uint64');full_out=np.empty((len(inputs),2),dtype='uint64')
    for error_form in [0,1]:
        g=graph(error_form=error_form);mask=(1<<g['sites'])-1
        encoded=native.nodes(json.dumps(g,sort_keys=True));nodes=(Node*len(g['nodes'])).from_buffer_copy(bytes(encoded))
        bytag=[[i for i,n in enumerate(g['nodes'])if n.get('tag')==tag]for tag in TAGS]
        previous=0
        for k in range(1<<len(TAGS)):
            phase=k^(k>>1);changed=phase^previous
            if changed:
                bit=changed.bit_length()-1
                for i in bytag[bit]:nodes[i].phase=int(bool(phase&changed))
            previous=phase
            rc=native.lib.x87_grid(nodes,len(nodes),probe_inputs.ctypes.data_as(ptr),3,4,0x123f133f,mask,*g['outputs'],probe_out.ctypes.data_as(ptr))
            if rc:raise ValueError('malformed precision graph')
            if not np.array_equal(probe_out[np.arange(4),selector[88:92]],expected[88:92]):continue
            rc=native.lib.x87_grid(nodes,len(nodes),inputs.ctypes.data_as(ptr),3,len(inputs),0x123f133f,mask,*g['outputs'],full_out.ctypes.data_as(ptr))
            if rc:raise ValueError('malformed precision graph')
            actual=full_out[np.arange(len(inputs)),selector];matched=int(np.count_nonzero(actual==expected))
            pp=tuple(tag for i,tag in enumerate(TAGS)if phase&(1<<i));tops.append((matched,error_form,pp))
            if matched==len(expected):results.append(dict(error_form=error_form,phases=pp,graph=graph(pp,error_form=error_form),mask=mask))
    write(OUT/'step2-precision-search.json',dict(survivors=results,top=sorted(tops,reverse=True)[:30],producer_sha256=sha(__file__)))
    print('complete survivors',len(results),'top',sorted(tops,reverse=True)[:8])

def search_stores():
    lib=OUT/'x87-ets.so';build_library(lib);native=Native(lib)
    d=read(OUT/'step2-three-stat.json');fo=grouped(read(OUT/'step2-three-forecast.json'))
    inputs=np.array([[int(bits(z['y'][0]),16),int(bits(z['y'][1]),16),int(bits(h),16)]for z in d['cases']for h in [0.,1.,2.,5.]],dtype='uint64')
    expected=np.array([int(fo[i][str(h)]['bits'],16)for i in range(64)for h in [0.,1.,2.,5.]],dtype='uint64');selector=np.array([int(h)%2 for _ in range(64)for h in [0.,1.,2.,5.]])
    indices=np.array([i*4+j for i in [22,8]for j in range(4)]);probe_inputs=np.ascontiguousarray(inputs[indices]);probe_out=np.empty((8,2),dtype='uint64');out=np.empty((256,2),dtype='uint64');ptr=C.POINTER(C.c_uint64)
    mandatory={'season','season_center','publication'}
    phase_choices=[()]
    results=[];tops=[]
    for form,tf,sf,ef,phases in product([1,0,2],[1,0],[1,0],[0,1],phase_choices):
        g=graph(phases,stores=TAGS,error_form=ef,level_form=form,trend_form=tf,season_form=sf);nodes=native.nodes(json.dumps(g,sort_keys=True))
        present={n.get('tag')for n in g['nodes']};variable=[tag for tag in TAGS if tag not in mandatory and tag in present]
        tagmask={tag:sum(1<<n['site']for n in g['nodes']if n.get('tag')==tag and 'site'in n)for tag in TAGS}
        mask=sum(tagmask[t]for t in mandatory);previous=0
        for k in range(1<<len(variable)):
            code=k^(k>>1);changed=code^previous
            if changed:mask^=tagmask[variable[changed.bit_length()-1]]
            previous=code
            rc=native.lib.x87_grid(nodes,len(nodes),probe_inputs.ctypes.data_as(ptr),3,8,0x123f133f,mask,*g['outputs'],probe_out.ctypes.data_as(ptr))
            if rc:raise ValueError('invalid store graph')
            if not np.array_equal(probe_out[np.arange(8),selector[indices]],expected[indices]):continue
            rc=native.lib.x87_grid(nodes,len(nodes),inputs.ctypes.data_as(ptr),3,256,0x123f133f,mask,*g['outputs'],out.ctypes.data_as(ptr))
            if rc:raise ValueError('invalid store graph')
            matched=int(np.count_nonzero(out[np.arange(256),selector]==expected));stores=sorted(mandatory|{t for j,t in enumerate(variable)if code&(1<<j)})
            tops.append((matched,ef,phases,stores))
            if matched==256:results.append(dict(level_form=form,trend_form=tf,season_form=sf,error_form=ef,phases=phases,stores=stores,mask=mask,graph=g))
        print('store pass',form,tf,sf,ef,phases,'complete',len(results),flush=True)
        if results:break
    write(OUT/'step2-store-search.json',dict(survivors=results,top=sorted(tops,reverse=True)[:30],producer_sha256=sha(__file__)))
    print('complete store survivors',len(results),'top',sorted(tops,reverse=True)[:4])

if __name__=='__main__':
    import sys
    if len(sys.argv)>1 and sys.argv[1]=='stores':search_stores()
    else:run()
