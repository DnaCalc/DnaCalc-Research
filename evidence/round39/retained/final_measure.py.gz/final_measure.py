import hashlib,json,os,pathlib,shutil,subprocess,time

repo=pathlib.Path('/home/ubuntu/projects/DnaCalc/DnaCalc')
out=pathlib.Path('/home/ubuntu/codex-runs/round39')
env=os.environ.copy();env.pop('CARGO_TARGET_DIR',None)
env.update(TMPDIR='/home/ubuntu/codex-runs/tmp39',DNACALC_PAINT_PYTHON='python3')
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
def run(label,command,extra=None):
 start=time.time()
 with (out/(label+'.log')).open('w')as log:
  p=subprocess.run(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipt=dict(command=command,revision=revision,exit_code=p.returncode,seconds=time.time()-start,**(extra or {}))
 (out/(label+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 print(label,receipt['exit_code'],round(receipt['seconds'],2),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
run('final-corpus',['cargo','xtask','corpus','--oracle','--no-capture','--out',str(out/'final-corpus')])
harness=repo/'target/xtask/run/round39-final-bank-harness'
shutil.copyfile(repo/'target/debug/xtask-harness',harness);harness.chmod(0o755)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources={str(p.relative_to(repo)):sha(p)for p in(repo/'crates/calc-func/src').rglob('*.rs')}
run('final-bank',[str(harness),'witness','judge','--bank','full','--report',str(out/'final-bank.json')],
 dict(executable_sha256=sha(harness),calc_func_source_sha256=sources,
      limits='Current pushed source; every excluded or unread bank row remains a failure. The bank has no ETS or inverse-normal rows and does not prove those surfaces.'))
