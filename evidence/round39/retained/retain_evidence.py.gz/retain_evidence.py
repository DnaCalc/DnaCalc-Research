# Extend R38's compact retention route for R39. No candidate binaries or matrices.
import gzip,hashlib,json,shutil
from pathlib import Path
r=Path('/home/ubuntu/codex-runs/round39');repo=Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research');out=repo/'evidence/round39';out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
old=json.loads((out/'files.json').read_text())if(out/'files.json').exists()else[]
records={x['original_path']:x for x in old}
# Keep one full current route trace; retain earlier summaries and every loss.
intermediate={'application-replay-final','application-replay-narrowed','application-replay-publication','application-replay-bounded','application-replay-seasonal','application-replay-pushed'}
def omitted(rel):
 return rel.split('/')[0]in intermediate and ('.inputs.json' in rel or '.predictions.jsonl' in rel)
for rel in list(records):
 if omitted(rel):
  dest=repo/records.pop(rel)['path']
  if dest.is_relative_to(out):dest.unlink(missing_ok=True)
files=list(r.glob('*.json'))+list(r.glob('*.txt'))+list(r.glob('*.py'))
for name in ['service-cache','ets-catalogue','ets-seasonal-catalogue','application-replay-final','application-replay-narrowed','application-replay-publication','application-replay-bounded','application-replay-seasonal','application-replay-pushed','application-replay-pushed-complete','check','seasonal-check','research-rust-tests','measurement','unit-sources','unit-history']:
 files.extend(p for p in(r/name).rglob('*')if p.is_file())
for name in ['before-corpus','after-corpus','after-corpus-narrowed','publication-corpus','bounded-publication-corpus','postmerge-corpus','seasonal-corpus','final-corpus']:
 files.extend(p for p in(r/name).glob('*')if p.is_file())
for p in sorted(set(files)):
 if p.suffix not in ['.json','.gz','.jsonl','.txt','.log','.py','.md','.rs']:continue
 rel=str(p.relative_to(r))
 if omitted(rel):continue
 raw=p.read_bytes();same=rel.endswith('.gz');payload=raw if same else gzip.compress(raw,mtime=0)
 dest=out/'retained'/(rel if same else rel+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(payload)
 records[rel]=dict(path=str(dest.relative_to(repo)),original_path=rel,source_sha256=sha(raw),stored_sha256=sha(payload),bytes=len(raw),stored_bytes=len(payload),already_compressed=same)
for p in repo.glob('round39*-unit.json'):
 raw=p.read_bytes();payload=gzip.compress(raw,mtime=0);rel='units/'+p.name;dest=out/'retained'/(rel+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(payload)
 records[rel]=dict(path=str(dest.relative_to(repo)),original_path=rel,source_sha256=sha(raw),stored_sha256=sha(payload),bytes=len(raw),stored_bytes=len(payload),already_compressed=False)
for x in records.values():
 payload=(repo/x['path']).read_bytes();raw=payload if x['already_compressed']else gzip.decompress(payload)
 if sha(payload)!=x['stored_sha256']or sha(raw)!=x['source_sha256']:raise ValueError(x['path'])
(out/'ets-catalogue').mkdir(exist_ok=True);shutil.copyfile(r/'ets-catalogue/mapping.json.gz',out/'ets-catalogue/mapping.json.gz')
(out/'ets-seasonal-catalogue').mkdir(exist_ok=True);shutil.copyfile(r/'ets-seasonal-catalogue/mapping.json.gz',out/'ets-seasonal-catalogue/mapping.json.gz')
(out/'files.json').write_text(json.dumps(sorted(records.values(),key=lambda x:x['path']),indent=2)+'\n')
print('verified records',len(records),'stored bytes',sum(x['stored_bytes']for x in records.values()))
