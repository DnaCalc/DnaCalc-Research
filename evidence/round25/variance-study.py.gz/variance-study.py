import collections,itertools,json,pathlib,sys,time
sys.path.insert(0,str(pathlib.Path.cwd()/"checker"))
from variance import evaluate,arithmetic
from exact import binary64
from normal import encoding
from fractions import Fraction as Q
rows=[json.loads(x)for x in pathlib.Path(sys.argv[1]).read_text().splitlines()]
models=["strict","stored_pc64","resident_pc64"]
counts={}; changes=[]; start=time.monotonic()
for mode in itertools.product(models,repeat=2):
 key=":".join(mode); c=collections.Counter(); selected=[]
 for row in rows:
  r=row['raw']; xs=list(map(binary64,row['values_bits'])); f=r['function']; pop=f in ['VAR.P','VARP','VARPA','STDEV.P','STDEVP','STDEVPA']; a=8 if pop else 7
  m=[mode[0],mode[1],mode[1],mode[0],mode[1]]
  op=lambda k,x,y: arithmetic(k,mode[1],x,y)
  s=Q(0); q=Q(0)
  for x in xs:
   s=arithmetic('add',mode[0],s,x);q=arithmetic('add',mode[0],q,op('mul',x,x))
  n=Q(len(xs));sq=op('mul',s,s)
  left=op('mul',n,q) if pop else q
  right=sq if pop else op('div',sq,n)
  delta=op('add',left,-right)
  fallback=delta<op('mul',left,Q(float(0.01)))
  profile=dict(algorithm=0 if fallback else a,linear_order=0,square_order=0,models=m)
  z=evaluate(profile,xs,f)
  got="error:Num" if z is None else encoding(z)
  was=r['expected']==r['actual'];now=r['expected']==got
  c['all']+=1;c['match']+=now;c['baseline']+=was;c['gain']+=now and not was;c['loss']+=was and not now;c['fallback']+=fallback
  if got!=r['actual']:selected.append(dict(id=r['id'],function=f,formula=r.get('formula'),expected=r['expected'],baseline=r['actual'],prediction=got,fallback=fallback,ratio=float(delta/left)if left else 0.0))
 counts[key]=dict(c)
 changes.append(dict(policy=key,changes=selected))
 print(key,dict(c),flush=True)
pathlib.Path(sys.argv[2]).write_text(json.dumps(dict(counts=counts,changes=changes,seconds=time.monotonic()-start),indent=2)+"\n")
