//! R7: explicit expm1 precision/store programs and FV=0 rational associations.
//! Own annuity algebra and IEEE 754; current cleared Fpu/elementary chains.
use crate::{Row, dsl::*, eval::*, json_write, ported::excel_numeric::*};
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use std::{
    collections::{HashMap, HashSet},
    fs,
    io::{BufWriter, Write},
    path::Path,
    sync::atomic::{AtomicUsize, Ordering},
    time::Instant,
};

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Helper {
    pub id: usize,
    pub t: EvalModel,
    pub exp_store: bool,
    pub difference: EvalModel,
    pub log_store: bool,
    pub association: usize,
    pub arithmetic: [EvalModel; 2],
    pub em_store: bool,
    pub correction: bool,
}

pub fn helpers() -> Vec<Helper> {
    let mut out = vec![];
    for t in MODELS {
        for exp_store in [true, false] {
            for difference in MODELS {
                for correction in [true, false] {
                    for log_store in if correction {
                        vec![true, false]
                    } else {
                        vec![true]
                    } {
                        for association in 0..if correction { 3 } else { 1 } {
                            for a in if correction {
                                MODELS.to_vec()
                            } else {
                                vec![EvalModel::Strict]
                            } {
                                for b in if correction {
                                    MODELS.to_vec()
                                } else {
                                    vec![EvalModel::Strict]
                                } {
                                    for em_store in [true, false] {
                                        out.push(Helper {
                                            id: out.len(),
                                            t,
                                            exp_store,
                                            difference,
                                            log_store,
                                            association,
                                            arithmetic: [a, b],
                                            em_store,
                                            correction,
                                        });
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    assert_eq!(out.len(), 1980);
    out
}

pub fn neg(v: Val) -> Val {
    match v {
        Val::F64(b) => Val::F64(b ^ (1 << 63)),
        Val::Ext(mut e) => {
            e.0[9] ^= 0x80;
            Val::Ext(e)
        }
    }
}
pub fn store<F: Fpu>(v: Val, yes: bool) -> Val {
    if yes { Val::f64(v.to_f64::<F>()) } else { v }
}
fn less_one<F: Fpu>(v: Val) -> bool {
    // Compare the absolute extended value without reducing it to binary64.
    let mut e = v.to_ext();
    e.0[9] &= 0x7f;
    let one = research_load(1.0);
    let d = F::sub(&e, &one, CW);
    d.0[9] & 0x80 != 0 && d.0[..8].iter().any(|b| *b != 0)
}
/// Full-width helper arithmetic with explicit conditional elementary leaves.
/// Shared by the existing timing proofs and the compact loan certificates.
pub fn helper_trace<F: Fpu>(h: &Helper, n: f64, log: Val) -> (Val, Value) {
    let (t, u, em) = helper_components::<F>(h, n, log);
    let exp_raw = Val::Ext(research_exp::<F>(&t.to_ext()));
    let log_raw = if h.correction && less_one::<F>(t) && u.to_ext().0 != research_load(1.0).0 {
        Some(Val::Ext(research_log::<F>(&u.to_ext())).exact_encoding())
    } else {
        None
    };
    (em, json!({"t":t.exact_encoding(),"u":u.exact_encoding(),
        "em":em.exact_encoding(),"exp_raw":exp_raw.exact_encoding(),"log_raw":log_raw}))
}
pub fn helper<F: Fpu>(h: &Helper, rate: f64, n: f64, log: f64) -> Val {
    let _ = rate; // Rate's frozen log1p is an explicit leaf, never refitted.
    helper_components::<F>(h, n, Val::f64(log)).2
}
pub fn helper_components<F: Fpu>(h: &Helper, n: f64, log: Val) -> (Val, Val, Val) {
    let t = neg(binop::<F>(Op::Mul(0, 1), h.t, Val::f64(n), log));
    let u = store::<F>(Val::Ext(research_exp::<F>(&t.to_ext())), h.exp_store);
    let one = Val::f64(1.0);
    if u.to_ext().0 == one.to_ext().0 {
        return (t, u, store::<F>(t, h.em_store));
    }
    let d = binop::<F>(Op::Add(0, 1), h.difference, u, neg(one));
    if !h.correction || !less_one::<F>(t) {
        return (t, u, store::<F>(d, h.em_store));
    }
    let logu = store::<F>(Val::Ext(research_log::<F>(&u.to_ext())), h.log_store);
    let [a, b] = h.arithmetic;
    let e = match h.association {
        0 => binop::<F>(Op::Div(0, 1), b, binop::<F>(Op::Mul(0, 1), a, d, t), logu),
        1 => binop::<F>(Op::Mul(0, 1), b, d, binop::<F>(Op::Div(0, 1), a, t, logu)),
        2 => binop::<F>(Op::Mul(0, 1), b, binop::<F>(Op::Div(0, 1), a, d, logu), t),
        _ => unreachable!(),
    };
    (t, u, store::<F>(e, h.em_store))
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Expr {
    Leaf(usize),
    Mul(Box<Expr>, Box<Expr>),
    Div(Box<Expr>, Box<Expr>),
}
fn l(i: usize) -> Expr {
    Expr::Leaf(i)
}
fn m(a: Expr, b: Expr) -> Expr {
    Expr::Mul(Box::new(a), Box::new(b))
}
fn d(a: Expr, b: Expr) -> Expr {
    Expr::Div(Box::new(a), Box::new(b))
}
pub fn expressions() -> Vec<Expr> {
    // Leaves P=0,R=1,E=2,T=3. Each appears exactly once; all ten programs
    // are algebraically P*R/(E*T), but floating-point associations stay distinct.
    vec![
        m(d(d(l(0), l(2)), l(3)), l(1)),
        d(m(l(0), l(1)), m(l(2), l(3))),
        m(d(l(0), l(3)), d(l(1), l(2))),
        m(l(0), d(d(l(1), l(2)), l(3))),
        m(l(0), d(l(1), m(l(2), l(3)))),
        d(d(m(l(0), l(1)), l(2)), l(3)),
        m(d(l(0), l(2)), d(l(1), l(3))),
        d(l(0), d(m(l(2), l(3)), l(1))),
        d(l(0), m(l(2), d(l(3), l(1)))),
        d(m(l(0), d(l(1), l(3))), l(2)),
    ]
}
pub fn all_expressions() -> Vec<Expr> {
    let out = expressions_with_powers([1, 1, -1, -1]);
    assert_eq!(out.len(), 60);
    for e in expressions() {
        assert!(out.contains(&e))
    }
    out
}
pub fn expressions_with_powers(target: [i8; 4]) -> Vec<Expr> {
    fn generate(mask: u8) -> Vec<(Expr, [i8; 4])> {
        if mask.count_ones() == 1 {
            let i = mask.trailing_zeros() as usize;
            let mut powers = [0i8; 4];
            powers[i] = 1;
            return vec![(l(i), powers)];
        }
        let mut out = vec![];
        let mut a = (mask - 1) & mask;
        while a != 0 {
            let b = mask ^ a;
            for (left, lp) in generate(a) {
                for (right, rp) in generate(b) {
                    out.push((
                        m(left.clone(), right.clone()),
                        std::array::from_fn(|i| lp[i] + rp[i]),
                    ));
                    out.push((
                        d(left.clone(), right),
                        std::array::from_fn(|i| lp[i] - rp[i]),
                    ));
                }
            }
            a = (a - 1) & mask;
        }
        out
    }
    let mut out: Vec<_> = generate(15)
        .into_iter()
        .filter_map(|(e, p)| (p == target).then_some(e))
        .collect();
    out.sort_by_cached_key(|e| serde_json::to_string(e).unwrap());
    for (i, e) in out.iter().enumerate() {
        assert!(!out[..i].contains(e))
    }
    out
}
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Combine {
    pub id: usize,
    pub expression: usize,
    pub models: [EvalModel; 4],
}
pub fn combines() -> Vec<Combine> {
    combines_for(expressions().len())
}
fn combines_for(count: usize) -> Vec<Combine> {
    let mut out = vec![];
    for expression in 0..count {
        for mut code in 0..81 {
            let mut models = [EvalModel::Strict; 4];
            for v in &mut models {
                *v = MODELS[code % 3];
                code /= 3;
            }
            out.push(Combine {
                id: out.len(),
                expression,
                models,
            });
        }
    }
    out
}
pub(crate) fn eval_expr<F: Fpu>(
    expr: &Expr,
    args: &[Val; 4],
    models: &[EvalModel; 4],
    site: &mut usize,
) -> Val {
    let (a, b, op) = match expr {
        Expr::Leaf(i) => return args[*i],
        Expr::Mul(a, b) => (a, b, Op::Mul(0, 1)),
        Expr::Div(a, b) => (a, b, Op::Div(0, 1)),
    };
    let av = eval_expr::<F>(a, args, models, site);
    let bv = eval_expr::<F>(b, args, models, site);
    let model = models[*site];
    *site += 1;
    binop::<F>(op, model, av, bv)
}
pub fn combine<F: Fpu>(c: &Combine, exprs: &[Expr], r: &Row, em: Val) -> Val {
    let [rate, pv, _, timing, _] = r.args();
    // rate * canonical timing is exact on the scoped finite inputs.
    let tf = binop::<F>(
        Op::Add(0, 1),
        c.models[0],
        Val::f64(1.0),
        Val::f64(rate * timing),
    );
    eval_expr::<F>(
        &exprs[c.expression],
        &[Val::f64(pv), Val::f64(rate), em, tf],
        &c.models,
        &mut 1,
    )
}
fn value_set<F: Fpu>(expr: &Expr, args: &[Vec<Val>; 4]) -> Vec<Val> {
    let (a, b, op) = match expr {
        Expr::Leaf(i) => return args[*i].clone(),
        Expr::Mul(a, b) => (a, b, Op::Mul(0, 1)),
        Expr::Div(a, b) => (a, b, Op::Div(0, 1)),
    };
    let av = value_set::<F>(a, args);
    let bv = value_set::<F>(b, args);
    let mut out = vec![];
    for a in av {
        for b in &bv {
            for model in MODELS {
                let v = binop::<F>(op, model, a, *b);
                if !out.contains(&v) {
                    out.push(v)
                }
            }
        }
    }
    out
}
pub fn roots<F: Fpu>(exprs: &[Expr], r: &Row, ems: &[Val]) -> Vec<Val> {
    let [rate, pv, _, timing, _] = r.args();
    let mut tfs = vec![];
    for model in MODELS {
        let tf = binop::<F>(Op::Add(0, 1), model, Val::f64(1.0), Val::f64(rate * timing));
        if !tfs.contains(&tf) {
            tfs.push(tf)
        }
    }
    let args = [vec![Val::f64(pv)], vec![Val::f64(rate)], ems.to_vec(), tfs];
    let mut out = vec![];
    for e in exprs {
        for v in value_set::<F>(e, &args) {
            if !out.contains(&v) {
                out.push(v)
            }
        }
    }
    out
}
fn group(r: &Row) -> (u64, u64, u64) {
    (r.leaves[0], nper(r).to_bits(), r.log1p)
}
pub fn nper(r: &Row) -> f64 {
    let a = &r.raw["args"][1];
    let v = calc_verdict::decode_argument(a, "args[1]").unwrap();
    match v.core() {
        crate::value::CoreValue::Number(n) => *n,
        _ => panic!("not numeric nper"), // ubs:ignore — reject a control outside the declared numeric research scope
    }
}
fn fv0(r: &Row) -> bool {
    r.args()[2] == 0.0
}

pub fn run<F: Fpu + 'static>(all: &[Row], output: &str) {
    run_inner::<F>(all, output, false)
}

/// Existing helper programs crossed with two correlated timing identities.
/// FV0 makes numerator=N=PV exact for finite helpers and nonzero normal PV;
/// canonical timing multiplication is exact too. The six remaining stores are
/// independently annotated. Equal helper values share a consumer execution,
/// while every original helper/program ID remains in the first-kill records.
pub fn timing_helpers<F: Fpu>(
    all: &[Row],
    output: &str,
    multiple_logs: bool,
    direct: bool,
    pc53: bool,
) {
    helper_consumers::<F>(all, output, multiple_logs, direct, pc53, false)
}

/// Keep the actuarial discount-rate operation correlated with its log input.
pub fn discount_helpers<F: Fpu>(all: &[Row], output: &str) {
    helper_consumers::<F>(all, output, false, false, false, true)
}

fn helper_consumers<F: Fpu>(
    all: &[Row],
    output: &str,
    multiple_logs: bool,
    direct: bool,
    pc53: bool,
    discount: bool,
) {
    use crate::enumerate::{AssociationCandidate, timing_template};
    let start = Instant::now();
    fs::create_dir(output).unwrap();
    let out = Path::new(output);
    let hs = helpers();
    let helper_count = if direct { 162 } else { hs.len() };
    let profiles: Vec<_> = (0..if discount {
        9
    } else if multiple_logs {
        5
    } else {
        1
    })
        .flat_map(|lp| {
            (0..helper_count)
                .map(move |h| json!({"id":lp*helper_count+h,"log_provider":lp,"helper":h}))
        })
        .collect();
    let mut cs = vec![];
    // PC53 consumes full resident operands before rounding its result. This
    // is distinct from Strict, whose operands are first stored to binary64.
    let consumer_models: &[EvalModel] = if pc53 { &WIDE_MODELS[..4] } else { &MODELS };
    let model_count = consumer_models.len().pow(if discount { 4 } else { 6 });
    for form in 0..if discount { 1 } else { 2 } {
        let sites = if form == 0 {
            [10, 11, 12, 13, 16, 17]
        } else {
            [10, 11, 12, 13, 14, 17]
        };
        for mut code in 0..model_count {
            let mut graph = if discount {
                crate::enumerate::template(0, 5)
            } else {
                timing_template(0, form)
            };
            let mut models = vec![];
            let active_sites = if discount {
                vec![10, 11, 12, 13]
            } else {
                sites.to_vec()
            };
            for site in active_sites {
                let model = consumer_models[code % consumer_models.len()];
                code /= consumer_models.len();
                graph.nodes[site].model = model;
                models.push(model);
            }
            cs.push(AssociationCandidate {
                id: cs.len(),
                numerator: Some(0),
                combine: if discount { 5 } else { 9 + form },
                models,
                graph,
            });
        }
    }
    assert_eq!(
        cs.len(),
        if discount {
            model_count
        } else {
            2 * model_count
        }
    );
    if direct {
        let descriptors: Vec<_> = (0..162)
            .map(|id| {
                let mut code = id / 2;
                let mut models = vec![];
                for _ in 0..4 {
                    models.push(MODELS[code % 3]);
                    code /= 3;
                }
                json!({"id":id,"models":models,"f2xm1_store":id%2!=0})
            })
            .collect();
        json_write(out.join("helpers.json"), &descriptors);
        json_write(
            out.join("constants.json"),
            &json!({"ROM_log2e":Val::Ext(research_l2e()).exact_encoding()}),
        );
    } else {
        json_write(out.join("helpers.json"), &hs);
    }
    json_write(out.join("helper-profiles.json"), &profiles);
    json_write(out.join("consumers.json"), &cs);
    let rate_programs: Vec<usize> = cs
        .iter()
        .map(|c| {
            if !discount {
                return 0;
            }
            let index = |m| MODELS.iter().position(|&v| v == m).unwrap();
            index(c.models[0]) * 3 + index(c.models[2])
        })
        .collect();
    if discount {
        json_write(out.join("rate-programs.json"), &rate_programs);
    }
    let rows: Vec<_> = all
        .iter()
        .filter(|r| {
            let a = r.args();
            a[0] > 0.0
                && (!discount || (a[0] <= 1.0 && a[3] == 1.0))
                && (!multiple_logs || a[0] <= 0.25)
                && nper(r) > 0.0
                && a[2] == 0.0
                && a[1].is_normal()
                && calc_verdict::decode_result(r.expected())
                    .ok()
                    .is_some_and(|v| v.as_number().is_some_and(f64::is_normal))
        })
        .collect();
    let mut alive: Vec<Vec<bool>> = cs
        .iter()
        .map(|c| {
            profiles
                .iter()
                .map(|p| {
                    !discount || p["log_provider"].as_u64().unwrap() as usize == rate_programs[c.id]
                })
                .collect()
        })
        .collect();
    let total = alive.iter().flatten().filter(|&&v| v).count();
    if discount {
        assert_eq!(total, 160380);
    }
    let mut remaining = total;
    let mut evaluations = 0usize;
    let mut kills = BufWriter::new(fs::File::create(out.join("first-kills.jsonl")).unwrap());
    let mut helper_rows =
        BufWriter::new(fs::File::create(out.join("helper-values.jsonl")).unwrap());
    let mut statistics = vec![];
    for (order, r) in rows.iter().enumerate() {
        if remaining == 0 {
            break;
        }
        let mut values = vec![];
        let mut components = vec![];
        let mut rate_values = vec![];
        let log_inputs = if discount {
            let mut logs = vec![];
            for tf_model in MODELS {
                let tf = binop::<F>(
                    Op::Add(0, 1),
                    tf_model,
                    Val::f64(1.0),
                    Val::f64(r.args()[0]),
                );
                for d_model in MODELS {
                    let d = binop::<F>(Op::Div(0, 1), d_model, Val::f64(r.args()[0]), tf);
                    let argument = -d.to_f64::<F>();
                    let raw_log = excel_log1p(argument);
                    assert!(raw_log.is_finite() && raw_log < 0.0);
                    logs.push(Val::f64(-raw_log));
                    rate_values.push(json!({"tf":tf.exact_encoding(),"d":d.exact_encoding(),
                        "argument":Val::f64(argument).exact_encoding(),"raw_log":Val::f64(raw_log).exact_encoding()}));
                }
            }
            logs
        } else if multiple_logs {
            crate::annuity_early::logs::<F>(r.args()[0], r.log1p).to_vec()
        } else {
            vec![Val::F64(r.log1p)]
        };
        for profile in &profiles {
            let h_index = profile["helper"].as_u64().unwrap() as usize;
            let log = log_inputs[profile["log_provider"].as_u64().unwrap() as usize];
            if direct {
                let v = crate::annuity_early::direct_component_details::<F>(h_index, -nper(r), log);
                values.push(v[9]);
                components
                    .push(json!({"nodes":v.map(Val::exact_encoding),"em":v[9].exact_encoding()}));
                continue;
            }
            let h = &hs[h_index];
            let (em, component) = helper_trace::<F>(h, nper(r), log);
            values.push(em);
            components.push(component);
        }
        // Values are records of the declared helper programs, never latent
        // values recovered from the target. Preserve full-width operands.
        let mut helper_record = json!({"order":order,"witness":r.raw,
            "trace_index":r.trace_index,"values":values.iter().map(|v|v.exact_encoding()).collect::<Vec<_>>(),
            "components":components,"log_inputs":log_inputs.iter().map(|v|v.exact_encoding()).collect::<Vec<_>>()});
        if discount {
            helper_record["rate_values"] = json!(rate_values);
        }
        serde_json::to_writer(&mut helper_rows, &helper_record).unwrap();
        writeln!(helper_rows).unwrap();
        let mut groups: HashMap<Val, Vec<usize>> = HashMap::new();
        for (h, v) in values.iter().enumerate() {
            groups.entry(*v).or_default().push(h);
        }
        // Stable ordering makes both backend certificates directly comparable.
        let mut groups: Vec<_> = groups.into_iter().collect();
        groups.sort_by_key(|(_, ids)| ids[0]);
        let before = remaining;
        for c in &cs {
            for (em, ids) in &groups {
                let active: Vec<_> = ids.iter().copied().filter(|&h| alive[c.id][h]).collect();
                if active.is_empty() {
                    continue;
                }
                let mut args = r.args().map(Val::f64);
                args[4] = *em;
                let trace = graph_values_typed::<F>(&c.graph, &args);
                let got = outcome::<F>(trace[c.graph.output]);
                evaluations += 1;
                if got != r.expected() {
                    for &h in &active {
                        alive[c.id][h] = false;
                        remaining -= 1;
                    }
                    serde_json::to_writer(
                        &mut kills,
                        &json!({"consumer":c.id,"helpers":active,
                        "order":order,"trace_index":r.trace_index,"witness":r.raw,
                        "helper_value":em.exact_encoding(),"expected":r.expected(),"got":got,
                        "nodes":trace.iter().map(|v|v.exact_encoding()).collect::<Vec<_>>()}),
                    )
                    .unwrap();
                    writeln!(kills).unwrap();
                }
            }
        }
        let stat = json!({"order":order,"trace_index":r.trace_index,"id":r.raw["id"],
            "killed":before-remaining,"remaining":remaining,"distinct_helper_values":groups.len()});
        println!("timing/helper {stat}");
        statistics.push(stat);
        kills.flush().unwrap();
        helper_rows.flush().unwrap();
    }
    let survivors: Vec<_> = alive
        .iter()
        .enumerate()
        .flat_map(|(c, hs)| {
            hs.iter()
                .enumerate()
                .filter_map(move |(h, &yes)| yes.then_some(json!({"consumer":c,"helper":h})))
        })
        .collect();
    assert_eq!(survivors.len(), remaining);
    json_write(out.join("survivors.json"), &survivors);
    json_write(out.join("statistics.json"), &statistics);
    json_write(
        out.join("summary.json"),
        &json!({"complete":true,"consumers":cs.len(),
        "programs":total,"helpers":helper_count,"direct":direct,"discount":discount,"consumer_models":consumer_models,"helper_profiles":profiles.len(),"log_providers":if discount{9}else if multiple_logs{5}else{1},"survivors":remaining,"consumer_group_evaluations":evaluations,
        "source_rows":all.len(),"scoped_rows":rows.len(),"rows_visited":statistics.len(),
        "seconds":start.elapsed().as_secs_f64(),"backend":std::any::type_name::<F>(),
        "scope":if discount { "FV0,canonical timing1,positive period,0<rate<=1,normal nonzero balance/target.81 four-site consumer assignments, each correlated with its own rate-factor/division log input and1980 existing helpers:160380 compatible programs. Cleared log1p/exp/log calls remain recorded conditional leaves. Discovery only; no fitted helper or chosen survivor." } else { "FV0,positive rate/periods,normal nonzero balance/targets. Multiple-log mode additionally requires rate<=0.25. Existing helper programs and declared log providers; two correlated timing corrections, six independently annotated sites. Native FYL2XP1 remains a measured hardware leaf in both backend runs. Discovery only; no fitted helper or chosen survivor." }}),
    );
}
pub fn run_wide<F: Fpu + 'static>(all: &[Row], output: &str) {
    run_inner::<F>(all, output, true)
}
fn run_inner<F: Fpu + 'static>(all: &[Row], output: &str, wide: bool) {
    fs::create_dir_all(output).unwrap();
    let out = Path::new(output);
    let start = Instant::now();
    let rows: Vec<_> = all.iter().filter(|r| fv0(r)).cloned().collect();
    let hs = helpers();
    let es = if wide {
        all_expressions()
    } else {
        expressions()
    };
    let cs = combines_for(es.len());
    json_write(out.join("helpers.json"), &hs);
    json_write(out.join("combines.json"), &cs);
    json_write(out.join("expressions.json"), &es);
    let grammar = hash_bytes(&serde_json::to_vec(&(&hs, &cs, &es)).unwrap());
    let mut index = HashMap::new();
    let mut inputs = vec![];
    let mut indices = vec![];
    for r in &rows {
        let g = group(r);
        let next = inputs.len();
        let id = *index.entry(g).or_insert_with(|| {
            inputs.push(g);
            next
        });
        indices.push(id);
    }
    let worker_limit = std::env::var("DNA_RESEARCH_WORKERS")
        .ok()
        .map(|v| v.parse::<usize>().unwrap())
        .unwrap_or(8);
    assert!(worker_limit >= 1 && worker_limit <= 8);
    let cursor = AtomicUsize::new(0);
    let workers = worker_limit.min(inputs.len());
    let values: Vec<(usize, Vec<Val>, Vec<Val>)> = std::thread::scope(|scope| {
        let mut tasks = vec![];
        for _ in 0..workers {
            let cursor = &cursor;
            let inputs = &inputs;
            let hs = &hs;
            tasks.push(scope.spawn(move || {
                let mut found = vec![];
                loop {
                    let i = cursor.fetch_add(1, Ordering::Relaxed);
                    if i >= inputs.len() {
                        break;
                    }
                    let (r, n, l) = inputs[i];
                    let vals: Vec<_> = hs
                        .iter()
                        .map(|h| {
                            helper::<F>(h, f64::from_bits(r), f64::from_bits(n), f64::from_bits(l))
                        })
                        .collect();
                    let mut distinct = vec![];
                    for &v in &vals {
                        if !distinct.contains(&v) {
                            distinct.push(v)
                        }
                    }
                    found.push((i, vals, distinct));
                }
                found
            }));
        }
        tasks.into_iter().flat_map(|h| h.join().unwrap()).collect()
    });
    let mut values = values;
    values.sort_by_key(|x| x.0);
    println!(
        "prepared {} input groups, {} helpers, {} combines in {:.2}s",
        inputs.len(),
        hs.len(),
        cs.len(),
        start.elapsed().as_secs_f64()
    );
    let mut emfile = BufWriter::new(fs::File::create(out.join("em-values.jsonl")).unwrap());
    for (i, _, distinct) in &values {
        serde_json::to_writer(&mut emfile,&json!({"group":i,"rate":format!("0x{:016x}",inputs[*i].0),"nper":format!("0x{:016x}",inputs[*i].1),"log1p":format!("0x{:016x}",inputs[*i].2),"distinct":distinct.iter().map(|v|v.exact_encoding()).collect::<Vec<_>>()})).unwrap();
        writeln!(emfile).unwrap();
    }
    emfile.flush().unwrap();
    let total = hs.len() * cs.len();
    for (name, without_one) in [("all-fv0", false), ("nonunit-fv0", true)] {
        let mut alive: Vec<_> = (0..total).collect();
        let mut evals = 0usize;
        let mut kill_summary = vec![];
        let mut kills = BufWriter::new(
            fs::File::create(out.join(format!("{name}-first-kills.jsonl"))).unwrap(),
        );
        let mut stats = BufWriter::new(
            fs::File::create(out.join(format!("{name}-witness-kills.jsonl"))).unwrap(),
        );
        let mut orders = 0;
        for (order, r) in rows.iter().enumerate() {
            if without_one && nper(r) == 1.0 {
                continue;
            }
            orders += 1;
            let before = alive.len();
            let mut next = vec![];
            let ems = &values[indices[order]].1;
            for id in alive {
                let h = id / cs.len();
                let c = id % cs.len();
                let got = outcome::<F>(combine::<F>(&cs[c], &es, r, ems[h]));
                evals += 1;
                if got == r.expected() {
                    next.push(id)
                } else {
                    serde_json::to_writer(&mut kills,&json!({"candidate_id":id,"helper":h,"combine":c,"order":order,"trace_index":r.trace_index,"expected":r.expected(),"got":got})).unwrap();
                    writeln!(kills).unwrap();
                }
            }
            let record = json!({"order":order,"trace_index":r.trace_index,"id":r.raw["id"],"killed":before-next.len(),"remaining":next.len()});
            if before != next.len() {
                println!("{name} {record}");
                kill_summary.push(record.clone());
            }
            serde_json::to_writer(&mut stats, &record).unwrap();
            writeln!(stats).unwrap();
            alive = next;
        }
        kills.flush().unwrap();
        stats.flush().unwrap();
        json_write(out.join(format!("{name}-survivors.json")), &alive);
        json_write(
            out.join(format!("{name}-summary.json")),
            &json!({"grammar_hash":grammar,"programs":total,"survivors":alive.len(),"rows":orders,"evaluations":evals,"nonzero_kills":kill_summary,"complete":true}),
        );
    }
    let cursor = AtomicUsize::new(0);
    let progress = AtomicUsize::new(0);
    let counts: Vec<_> = std::thread::scope(|scope| {
        let mut tasks = vec![];
        for worker in 0..workers {
            let cursor = &cursor;
            let progress = &progress;
            let rows = &rows;
            let indices = &indices;
            let values = &values;
            let es = &es;
            tasks.push(scope.spawn(move||{
            let mut f=BufWriter::new(fs::File::create(out.join(format!("reachability-{worker}.jsonl"))).unwrap());
            let mut u=BufWriter::new(fs::File::create(out.join(format!("unreachable-roots-{worker}.jsonl"))).unwrap());
            let mut counts=[0usize;5];
            loop {let order=cursor.fetch_add(1,Ordering::Relaxed);if order>=rows.len(){break}let r=&rows[order];
                let roots=roots::<F>(es,r,&values[indices[order]].2);let published=publish_roots::<F>(&roots);
                let reachable=published.iter().any(|b|bits_outcome(*b)==r.expected());
                counts[0]+=1;counts[1]+=(!reachable)as usize;counts[2]+=published.len();counts[3]+=roots.len();counts[4]+=(!reachable&&nper(r)!=1.0)as usize;
                let record=json!({"order":order,"trace_index":r.trace_index,"id":r.raw["id"],"expected":r.expected(),"reachable":reachable,"outputs":published.iter().map(|b|bits_outcome(*b)).collect::<Vec<_>>()});
                serde_json::to_writer(&mut f,&record).unwrap();writeln!(f).unwrap();
                if !reachable {serde_json::to_writer(&mut u,&json!({"order":order,"trace_index":r.trace_index,"expected":r.expected(),"raw_roots":roots.iter().map(|v|v.exact_encoding()).collect::<Vec<_>>()})).unwrap();writeln!(u).unwrap();}
                let done=progress.fetch_add(1,Ordering::Relaxed)+1;if done%25000==0 {println!("reachability {done}/{} {:.1}s",rows.len(),start.elapsed().as_secs_f64());}
            }counts
        }));
        }
        tasks.into_iter().map(|h| h.join().unwrap()).collect()
    });
    let mut totals = [0usize; 5];
    for c in counts {
        for i in 0..5 {
            totals[i] += c[i]
        }
    }
    assert_eq!(totals[0], rows.len());
    let summary = json!({"grammar_hash":grammar,"programs":total,"helpers":hs.len(),"combines":cs.len(),"scoped_recorded_rows":rows.len(),"input_groups":inputs.len(),"whole_family_unreachable":totals[1],"whole_family_reachable":rows.len()-totals[1],"published_outcomes":totals[2],"tagged_roots":totals[3],"nonunit_unreachable":totals[4],"complete":true,"seconds":start.elapsed().as_secs_f64(),"fresh_validation":0,"backend":std::any::type_name::<F>(),"workers":workers});
    json_write(out.join("summary.json"), &summary);
    println!("{summary}");
}

pub fn self_test(all: &[Row]) {
    test_inner(all, false)
}
pub fn test_wide(all: &[Row]) {
    test_inner(all, true)
}
fn test_inner(all: &[Row], wide: bool) {
    let hs = helpers();
    let es = if wide {
        all_expressions()
    } else {
        expressions()
    };
    let cs = combines_for(es.len());
    let mut tests = 0usize;
    for r in all.iter().filter(|r| fv0(r)).take(8) {
        let n = nper(r);
        let log = f64::from_bits(r.log1p);
        let mut ems = vec![];
        for h in &hs {
            let hard = helper::<Hard>(h, r.args()[0], n, log);
            let soft = helper::<Soft>(h, r.args()[0], n, log);
            assert_eq!(
                hard.exact_encoding(),
                soft.exact_encoding(),
                "helper {} {}",
                h.id,
                r.raw["id"]
            );
            if !ems.contains(&hard) {
                ems.push(hard)
            }
        }
        let mut hard = roots::<Hard>(&es, r, &ems);
        let soft = roots::<Soft>(&es, r, &ems);
        assert_eq!(hard.len(), soft.len());
        for v in &hard {
            assert!(soft.contains(v));
        }
        let mut explicit = vec![];
        for h in &hs {
            let em = helper::<Hard>(h, r.args()[0], n, log);
            for c in &cs {
                let v = combine::<Hard>(c, &es, r, em);
                if !explicit.contains(&v) {
                    explicit.push(v)
                }
                tests += 1;
            }
        }
        assert_eq!(explicit.len(), hard.len());
        for v in hard.drain(..) {
            assert!(explicit.contains(&v));
        }
    }
    println!(
        "R7 self-test: {tests} explicit graph evaluations; all helper/root native-software controls agree"
    );
}

pub fn inverse_controls(all: &[Row], output: &str) {
    let rows: Vec<_> = all.iter().filter(|r| fv0(r)).collect();
    let cs = combines();
    let es = expressions();
    let mut f = BufWriter::new(fs::File::create(output).unwrap());
    let mut controls = 0;
    let mut selected: Vec<_> = (0..8).collect();
    for i in 1..=8 {
        selected.push(i * (rows.len() - 1) / 8)
    }
    for row_index in selected {
        let r = rows[row_index];
        let base = Val::F64(r.leaves[4]);
        let ems = [
            base,
            Val::Ext(base.to_ext()),
            binop::<Hard>(
                Op::Div(0, 1),
                EvalModel::ResidentPc64,
                binop::<Hard>(
                    Op::Add(0, 1),
                    EvalModel::ResidentPc64,
                    base,
                    Val::F64(r.leaves[4] + 1),
                ),
                Val::f64(2.0),
            ),
        ];
        for c in &cs {
            for em in ems {
                let got = outcome::<Hard>(combine::<Hard>(c, &es, r, em));
                let soft = outcome::<Soft>(combine::<Soft>(c, &es, r, em));
                serde_json::to_writer(&mut f,&json!({"row_index":row_index,"combine_id":c.id,"em":em.exact_encoding(),"control_target":got,"software_control_target":soft,"kind":"synthetic forward/inverse arithmetic control, never an Excel answer"})).unwrap();
                writeln!(f).unwrap();
                controls += 1;
            }
        }
    }
    f.flush().unwrap();
    println!("{controls} independent native forward/inverse controls exported");
}
