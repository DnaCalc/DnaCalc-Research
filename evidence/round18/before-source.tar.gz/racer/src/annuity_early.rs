//! Earlier PMT structure: continuous log1p, coupled growth/expm1 components.
//! Implementer; Intel SDM FYL2XP1, DLMF4.6.6, annuity algebra, cleared Fpu.
//! FYL2XP1 is a measured hardware leaf even in the soft-arithmetic replay.
use crate::{
    Row,
    boundary::{self, store},
    dsl::*,
    eval::*,
    json_write,
    ported::excel_numeric::*,
};
use serde_json::json;
use std::{
    fs,
    io::{BufWriter, Write},
    path::Path,
};

fn op<F: Fpu>(kind: Op, a: Val, b: Val) -> Val {
    binop::<F>(kind, EvalModel::ResidentPc64, a, b)
}
fn add<F: Fpu>(a: Val, b: Val) -> Val {
    op::<F>(Op::Add(0, 1), a, b)
}
fn mul<F: Fpu>(a: Val, b: Val) -> Val {
    op::<F>(Op::Mul(0, 1), a, b)
}
fn div<F: Fpu>(a: Val, b: Val) -> Val {
    op::<F>(Op::Div(0, 1), a, b)
}

fn hardware_log1p(rate: f64) -> Val {
    assert!(rate.abs() <= 0.25 && rate.is_finite());
    let ln2 = research_ln2();
    let mut result = Extended([0; 10]);
    let cw = CW;
    let mut saved = 0u16;
    // SAFETY: all pointers are live locals; two loads, one FYL2XP1 pop and
    // one store/pop balance the x87 stack; restore the caller's control word.
    unsafe {
        core::arch::asm!(
            "fnstcw word ptr [{saved}]","fldcw word ptr [{cw}]",
            "fld tbyte ptr [{ln2}]","fld qword ptr [{rate}]","fyl2xp1",
            "fstp tbyte ptr [{result}]","fldcw word ptr [{saved}]",
            saved=in(reg)&mut saved,cw=in(reg)&cw,ln2=in(reg)&ln2,rate=in(reg)&rate,result=in(reg)&mut result,
            options(nostack,preserves_flags),
        );
    }
    Val::Ext(result)
}
fn series_log1p<F: Fpu>(rate: f64) -> Val {
    // DLMF4.6.6, a=1: log(1+r)=2*sum(z^(2k+1)/(2k+1)), z=r/(2+r).
    // PC64 floating summation stops when the stored register value is unchanged.
    assert!(rate.abs() <= 0.25 && rate.is_finite());
    let z = div::<F>(Val::f64(rate), add::<F>(Val::f64(2.0), Val::f64(rate)));
    let square = mul::<F>(z, z);
    let mut term = z;
    let mut sum = z;
    for k in (3..=1023).step_by(2) {
        term = mul::<F>(term, square);
        let next = add::<F>(sum, div::<F>(term, Val::f64(k as f64)));
        if next == sum {
            return mul::<F>(Val::f64(2.0), sum);
        }
        sum = next;
    }
    panic!("log1p floating series did not reach its declared unchanged sum") // ubs:ignore — abort unsupported series; never publish an unconverged value
}
pub(crate) fn logs<F: Fpu>(rate: f64, frozen: u64) -> [Val; 5] {
    let hw = hardware_log1p(rate);
    let series = series_log1p::<F>(rate);
    [
        Val::F64(frozen),
        hw,
        store::<F>(hw, true),
        series,
        store::<F>(series, true),
    ]
}
fn nper(row: &Row) -> f64 {
    let arg = calc_verdict::decode_argument(&row.raw["args"][1], "nper bits").unwrap();
    match arg.core() {
        crate::value::CoreValue::Number(x) => *x,
        _ => panic!("numeric period scope"), // ubs:ignore — reject out-of-scope research input rather than inventing a result
    }
}

pub fn controls(input: &str, out: &str) {
    let rows = crate::lines::<Row>(input);
    let hs = boundary::helpers();
    let mut checks = 0usize;
    let mut differing = 0usize;
    let mut f = BufWriter::new(fs::File::create(out).unwrap());
    for row in rows.iter().filter(|r| r.args()[0].abs() <= 0.25).take(64) {
        let r = row.args()[0];
        let n = nper(row);
        let hard = logs::<Hard>(r, row.log1p);
        let soft = logs::<Soft>(r, row.log1p);
        assert_eq!(hard[1].exact_encoding(), soft[1].exact_encoding());
        assert_eq!(hard[3].exact_encoding(), soft[3].exact_encoding());
        for h in &hs {
            let (_, _, em) = boundary::helper_components::<Hard>(h, n, Val::F64(row.log1p));
            assert_eq!(
                em.exact_encoding(),
                boundary::helper::<Hard>(h, r, n, f64::from_bits(row.log1p)).exact_encoding()
            );
            checks += 1;
        }
        differing += (hard[1].to_f64::<Hard>().to_bits() != row.log1p) as usize;
        serde_json::to_writer(&mut f,&json!({"witness":row.raw,"native_log_values":hard.map(Val::exact_encoding),"soft_arithmetic_log_values":soft.map(Val::exact_encoding)})).unwrap();
        writeln!(f).unwrap();
    }
    println!(
        "{}",
        json!({"helper_wrapper_checks":checks,"sample_stored_hardware_vs_frozen_differences":differing,"FYL2XP1":"native hardware leaf on both arithmetic backends; no software instruction emulation claim"})
    );
}

fn scoped_rows(input: &str, root: &Path) -> (Vec<Row>, std::collections::BTreeMap<String, usize>) {
    let original = crate::lines::<Row>(input);
    let mut rows = vec![];
    let mut counts = std::collections::BTreeMap::<String, usize>::new();
    let mut excluded = BufWriter::new(fs::File::create(root.join("excluded.jsonl")).unwrap());
    for row in original {
        let a = row.args();
        let tau = nper(&row) * f64::from_bits(row.log1p);
        let reason = if a[2] != 0.0 {
            "FV_nonzero_control"
        } else if a[0] <= 0.0 || a[0] > 0.25 {
            "outside_FYL2XP1_safe_domain"
        } else if !(tau > 0.0 && tau < 1.0) {
            "outside_small_exponent_arm"
        } else {
            "scoped"
        };
        *counts.entry(reason.into()).or_default() += 1;
        if reason == "scoped" {
            rows.push(row)
        } else {
            serde_json::to_writer(&mut excluded, &json!({"reason":reason,"row":row})).unwrap();
            writeln!(excluded).unwrap();
        }
    }
    (rows, counts)
}
fn direct_components<F: Fpu>(id: usize, n: f64, log: Val) -> (Val, Val, Val) {
    let v = direct_component_details::<F>(id, n, log);
    (v[5], v[2], v[9])
}

pub(crate) fn direct_component_details<F: Fpu>(id: usize, n: f64, log: Val) -> [Val; 10] {
    let mut code = id / 2;
    let mut next = || {
        let m = MODELS[code % 3];
        code /= 3;
        m
    };
    let t = binop::<F>(Op::Mul(0, 1), next(), Val::f64(n), log);
    let x = binop::<F>(Op::Mul(0, 1), next(), t, Val::Ext(research_l2e()));
    let k = Val::Ext(F::rndint(&x.to_ext(), CW));
    let fraction = binop::<F>(Op::Add(0, 1), next(), x, boundary::neg(k));
    // Intel's F2XM1 argument interval is [-1,1]; nearest integer reduction
    // confines this fractional argument to [-1/2,1/2]. No answer-derived cut.
    assert!(fraction.to_f64::<F>().abs() <= 0.5);
    let raw_f = Val::Ext(F::f2xm1(&fraction.to_ext(), CW));
    let f = store::<F>(raw_f, id % 2 != 0);
    let scaled = Val::Ext(F::scale(&f.to_ext(), &k.to_ext(), CW));
    let two_k = Val::Ext(F::scale(&Val::f64(1.0).to_ext(), &k.to_ext(), CW));
    let integer_part = binop::<F>(
        Op::Add(0, 1),
        EvalModel::ResidentPc64,
        two_k,
        Val::f64(-1.0),
    );
    let em = binop::<F>(Op::Add(0, 1), next(), scaled, integer_part);
    assert_eq!(code, 0);
    [t, x, k, fraction, raw_f, f, scaled, two_k, integer_part, em]
}

pub fn direct_controls(input: &str, out: &str) {
    let rows = crate::lines::<Row>(input);
    let mut f = BufWriter::new(fs::File::create(out).unwrap());
    let mut count = 0;
    for row in rows
        .iter()
        .filter(|r| {
            r.args()[0] > 0.0
                && r.args()[0] <= 0.25
                && nper(r) * f64::from_bits(r.log1p) > 0.0
                && nper(r) * f64::from_bits(r.log1p) < 1.0
        })
        .take(64)
    {
        let lh = logs::<Hard>(row.args()[0], row.log1p);
        let ls = logs::<Soft>(row.args()[0], row.log1p);
        for lp in 0..5 {
            for helper in 0..162 {
                let (hf, hk, he) = direct_components::<Hard>(helper, nper(row), lh[lp]);
                let (sf, sk, se) = direct_components::<Soft>(helper, nper(row), ls[lp]);
                serde_json::to_writer(
                    &mut f,
                    &json!({"witness":row.raw,"log_provider":lp,"helper":helper,
                    "native":[hf.exact_encoding(),hk.exact_encoding(),he.exact_encoding()],
                    "hybrid":[sf.exact_encoding(),sk.exact_encoding(),se.exact_encoding()]}),
                )
                .unwrap();
                writeln!(f).unwrap();
                count += 1;
            }
        }
    }
    println!(
        "{}",
        json!({"paired_controls":count,"policy":"Raw direct F2XM1 components on original inputs; differences are retained, never asserted away. FYL2XP1 uses native hardware in both runs."})
    );
}

fn prefix_value<F: Fpu>(
    row: &Row,
    g: Val,
    em: Val,
    association: usize,
    mut code: usize,
    interest_model: EvalModel,
) -> Val {
    let ms: [EvalModel; 4] = std::array::from_fn(|_| {
        let m = MODELS[code % 3];
        code /= 3;
        m
    });
    let [rate, pv, _, timing, _] = row.args();
    let interest = binop::<F>(Op::Mul(0, 1), interest_model, Val::f64(pv), Val::f64(rate));
    let n = binop::<F>(Op::Mul(0, 1), ms[0], interest, g);
    let tf = if timing == 0.0 {
        Val::f64(1.0)
    } else {
        binop::<F>(Op::Add(0, 1), ms[1], Val::f64(1.0), Val::f64(rate))
    };
    let d = |a, b, m| binop::<F>(Op::Div(0, 1), m, a, b);
    let result = match association {
        0 => d(d(n, em, ms[2]), tf, ms[3]),
        1 => d(n, binop::<F>(Op::Mul(0, 1), ms[2], em, tf), ms[3]),
        2 => d(d(n, tf, ms[2]), em, ms[3]),
        _ => unreachable!(),
    };
    boundary::neg(result)
}

pub fn run<F: Fpu>(input: &str, out: &str, direct: bool, prefix_precondition: Option<&str>) {
    fs::create_dir_all(out).unwrap();
    let root = Path::new(out);
    let hs = if direct { vec![] } else { boundary::helpers() };
    let helper_count = if direct { 162 } else { hs.len() };
    let (rows, counts) = scoped_rows(input, root);
    let selectors = if direct { 9 } else { 5 };
    let log_count = 5;
    let precondition = prefix_precondition
        .map(|p| serde_json::from_slice::<serde_json::Value>(&fs::read(p).unwrap()).unwrap());
    let interest_models: Vec<EvalModel> = if let Some(ref p) = precondition {
        assert_eq!(p["baseline_application_trace_matches"], 2501);
        serde_json::from_value(p["allowed_models"].clone()).unwrap()
    } else {
        vec![EvalModel::Strict]
    };
    let root_profiles = if precondition.is_some() { 81 } else { 243 };
    let per_helper = selectors * interest_models.len() * 3 * root_profiles;
    let count = log_count * helper_count * per_helper;
    if direct {
        json_write(
            root.join("grammar.json"),
            &json!({
            "log_providers":["frozen binary64 log1p","resident native FYL2XP1-ROMln2","stored native FYL2XP1-ROMln2","resident DLMF4.6.E6 PC64 unchanged-sum","stored DLMF4.6.E6"],
            "helpers":162,"helper_layout":"id=2*little_endian_base3(t_product,x_product,fraction_subtraction,em_sum)+f2xm1_binary64_store",
            "helper_programme":"t=nper*log1p; x=t*ROMlog2e; k=nearest_integer(x); f=F2XM1(x-k); em=scale(f,k)+(scale(1,k)-1)",
            "growth_selectors":"0..5: scale(round_model(1+f),k) with three models and final binary64 store boolean;6..8: round_model(1+em)",
            "models":MODELS,"sites":["PV*growth","tf addition","combine op1","combine op2","combine op3"],
            "combines":["((N/em)/tf)*rate","(N*rate)/(em*tf)","(N/tf)*(rate/em)"],
            "layout":"id=(((log_provider*162+helper)*9+growth_selector)*3+combine)*243+little_endian_base3_root_site_code",
            "programs":count,"scope_counts":counts,"instruction_policy":"FYL2XP1 is a native measured leaf in both modes; all other operations including F2XM1 use declared backend",
            "source":"Intel SDM F2XM1/FSCALE/FRNDINT/FLDL2E public ISA; annuity algebra; DLMF4.6.E6; current cleared Fpu",
            "constant_policy":"Existing64-bit ROM log2e/ln2, exact0/1/2, mathematical nearest-integer reduction; no fitted constants or boundary",
            "arithmetic_backend":std::any::type_name::<F>()}),
        );
    } else {
        json_write(
            root.join("grammar.json"),
            &json!({"positive_expm1_helpers":hs,"log_providers":["frozen binary64 log1p","resident FYL2XP1 with64-bit ROM ln2","stored FYL2XP1","resident DLMF4.6.6 PC64 unchanged-sum loop","stored DLMF4.6.6 PC64 unchanged-sum loop"],
        "growth_selectors":["helper exponential u","binary64 store of u","strict 1+em","stored-PC64 1+em","resident-PC64 1+em"],
        "helper_components":"t=nper*log1p, u=exp(t), em=declared Kahan/difference programme; u/em share the same computed t/u",
        "sites":["PV*growth","tf addition","combine op1","combine op2","combine op3"],"models":MODELS,
        "combines":["((N/em)/tf)*rate","(N*rate)/(em*tf)","(N/tf)*(rate/em)"],
        "layout":"id=(((log_provider*1980+helper)*5+growth_selector)*3+combine)*243+little_endian_base3_site_code",
        "programs":count,"scope_counts":counts,"constant_policy":"Only0,1,2, exact positive odd integers and existing64-bit ROM ln2; no fitted coefficients or threshold",
        "arithmetic_backend":std::any::type_name::<F>(),"instruction_backend":"FYL2XP1 leaf measured on this AMD hardware for both modes; remaining operations use declared Fpu backend",
        "sources":["Intel SDM vol2A FYL2XP1 public ISA","https://dlmf.nist.gov/4.6.E6","annuity algebra","cleared Fpu"],
        "claim":"Tests continuous-log and coupled growth/annuity structure on PMT only; no claim that its growth helper is shared with the independently constrained PV/FV program"}),
        );
    }
    if let Some(ref condition) = precondition {
        let path = root.join("grammar.json");
        let mut grammar: serde_json::Value =
            serde_json::from_slice(&fs::read(&path).unwrap()).unwrap();
        grammar["earlier_interest_prefix"] = json!(true);
        grammar["NPER_precondition"] = condition.clone();
        grammar["interest_product_models"] = json!(interest_models);
        grammar["sites"] = json!(["I*growth", "tf addition", "root op1", "root op2"]);
        grammar["combines"] = json!(["((I*G)/em)/tf", "(I*G)/(em*tf)", "((I*G)/tf)/em"]);
        grammar["sharing"] = json!(
            "I=PV*rate is formed before G; its model is jointly constrained by the registered NPER graph. This is distinct from the I+I/em programme."
        );
        grammar["layout"] = json!(
            "id=((((log_provider*helper_count+helper)*growth_selectors+selector)*interest_model_count+interest_model_index)*3+combine)*81+little_endian_base3_root_code"
        );
        grammar["programs"] = json!(count);
        grammar["root_profiles"] = json!(81);
        json_write(path, &grammar);
    }
    let mut alive: Vec<usize> = (0..count).collect();
    let mut evaluations = 0u64;
    let mut kills = BufWriter::new(fs::File::create(root.join("first-kills.jsonl")).unwrap());
    let mut stats = BufWriter::new(fs::File::create(root.join("witness-kills.jsonl")).unwrap());
    let mut killing = vec![];
    for (idx, row) in rows.iter().enumerate() {
        let before = alive.len();
        let mut rejected = std::collections::BTreeMap::<String, Vec<usize>>::new();
        if before > 0 {
            let log = logs::<F>(row.args()[0], row.log1p);
            let n = nper(row);
            let components: Vec<Vec<_>> = log
                .iter()
                .map(|&l| {
                    (0..helper_count)
                        .map(|h| {
                            if direct {
                                direct_components::<F>(h, n, l)
                            } else {
                                boundary::helper_components::<F>(&hs[h], -n, l)
                            }
                        })
                        .collect()
                })
                .collect();
            alive.retain(|&id| {
                let code = id % root_profiles;
                let combine = (id / root_profiles) % 3;
                let im = (id / (root_profiles * 3)) % interest_models.len();
                let selector = (id / (root_profiles * 3 * interest_models.len())) % selectors;
                let helper = (id / per_helper) % helper_count;
                let lp = id / (per_helper * helper_count);
                let (a, u, em) = components[lp][helper];
                let g = if direct {
                    if selector < 6 {
                        let one_f =
                            binop::<F>(Op::Add(0, 1), MODELS[selector / 2], Val::f64(1.0), a);
                        store::<F>(
                            Val::Ext(F::scale(&one_f.to_ext(), &u.to_ext(), CW)),
                            selector % 2 != 0,
                        )
                    } else {
                        binop::<F>(Op::Add(0, 1), MODELS[selector - 6], Val::f64(1.0), em)
                    }
                } else {
                    match selector {
                        0 => u,
                        1 => store::<F>(u, true),
                        2..=4 => binop::<F>(Op::Add(0, 1), MODELS[selector - 2], Val::f64(1.0), em),
                        _ => unreachable!(),
                    }
                };
                let got = outcome::<F>(if precondition.is_some() {
                    prefix_value::<F>(row, g, em, combine, code, interest_models[im])
                } else {
                    crate::annuity::pmt_growth_value::<F>(row, g, em, combine, code)
                });
                evaluations += 1;
                if got == row.expected() {
                    true
                } else {
                    rejected.entry(got).or_default().push(id);
                    false
                }
            });
            for (got, ids) in rejected {
                serde_json::to_writer(&mut kills,&json!({"candidate_ids":ids,"case":idx,"witness":row,"expected":row.expected(),"got":got})).unwrap();
                writeln!(kills).unwrap();
            }
        }
        let rec = json!({"case":idx,"id":row.raw["id"],"killed":before-alive.len(),"remaining":alive.len()});
        serde_json::to_writer(&mut stats, &rec).unwrap();
        writeln!(stats).unwrap();
        if before != alive.len() {
            println!("{rec}");
            killing.push(rec);
            kills.flush().unwrap();
            stats.flush().unwrap()
        }
    }
    json_write(root.join("survivors.json"), &alive);
    let summary = json!({"programs":count,"survivors":alive.len(),"scoped_rows":rows.len(),"scope_counts":counts,"evaluations":evaluations,"first_kill_rows":killing,"direct_F2XM1":direct,"earlier_interest_prefix":precondition.is_some(),"complete":true,"claim":"Exact continuous-log/coupled-growth PMT exclusions or scoped survivors, not product matches or identification","FYL2XP1_policy":"Native measured leaf in both arithmetic backends; not a pure software replay of that instruction"});
    json_write(root.join("summary.json"), &summary);
    println!("{summary}");
}

fn backward_interest<F: Fpu>(p: Val, em: Val, rate: Val, shape: usize, code: usize) -> Val {
    let m = [
        MODELS[code % 3],
        MODELS[(code / 3) % 3],
        MODELS[(code / 9) % 3],
    ];
    let b = |op, a, b, model| binop::<F>(op, model, a, b);
    let value = match shape {
        0 => b(
            Op::Mul(0, 1),
            b(Op::Div(0, 1), b(Op::Mul(0, 1), p, em, m[0]), rate, m[1]),
            rate,
            m[2],
        ),
        1 => b(
            Op::Mul(0, 1),
            b(Op::Mul(0, 1), p, b(Op::Div(0, 1), em, rate, m[0]), m[1]),
            rate,
            m[2],
        ),
        2 => b(
            Op::Div(0, 1),
            b(Op::Mul(0, 1), b(Op::Mul(0, 1), p, rate, m[0]), em, m[1]),
            rate,
            m[2],
        ),
        3 => b(Op::Mul(0, 1), p, em, m[0]),
        _ => unreachable!(),
    };
    boundary::neg(value)
}

/// Every Ext80 value in a negative ordinary binary64 publication cell that lies
/// within one extended binade, with a 4096-significand margin from both edges.
/// Used as an existential domain, never a fitted value.
pub(crate) fn publication_candidates<F: Fpu>(p_bits: u64) -> Vec<Val> {
    let published = f64::from_bits(p_bits);
    assert!(published.is_normal() && published < 0.0);
    let center = Val::F64(p_bits).to_ext();
    let sig = u64::from_le_bytes(center.0[..8].try_into().unwrap());
    assert!(sig > (1u64 << 63) + 4096 && sig < u64::MAX - 4096);
    let mut latent = vec![];
    for s in ((sig - 2049)..=(sig + 2049)).rev() {
        let mut e = center;
        e.0[..8].copy_from_slice(&s.to_le_bytes());
        if F::store(&e, CW).to_bits() == p_bits {
            latent.push(Val::Ext(e));
        }
    }
    assert!((2047..=2049).contains(&latent.len()));
    assert!(latent.windows(2).all(|p| {
        u64::from_le_bytes(p[0].to_ext().0[..8].try_into().unwrap())
            > u64::from_le_bytes(p[1].to_ext().0[..8].try_into().unwrap())
    }));
    latent
}

pub fn loan_backward<F: Fpu>(input: &str, out: &str, joint_pv_fv: Option<&str>) {
    loan_backward_impl::<F>(input, out, joint_pv_fv, false)
}

pub fn loan_helper_certificate<F: Fpu>(input: &str, out: &str) {
    loan_backward_impl::<F>(input, out, None, true)
}

fn loan_backward_impl<F: Fpu>(input: &str, out: &str, joint_pv_fv: Option<&str>, helpers_only: bool) {
    let original: Vec<serde_json::Value> =
        serde_json::from_slice(&fs::read(input).unwrap()).unwrap();
    assert!(!original.is_empty(), "a recorded loan and its observed periods are required");
    fs::create_dir_all(out).unwrap();
    let root = Path::new(out);
    let raw_p = &original[0]["pmt"][0];
    assert_eq!(raw_p["function"], "PMT", "loan payment function identity");
    assert_eq!(raw_p["args"].as_array().unwrap().len(), 5, "complete payment arguments");
    assert_eq!(crate::annuity::number(&raw_p["args"][3]), 0.0, "zero final value required");
    let nper = crate::annuity::number(&raw_p["args"][1]);
    assert!(nper >= 1.0 && nper.fract() == 0.0, "positive integer period count required");
    let p_bits = u64::from_str_radix(
        raw_p["expected"].as_str().unwrap().trim_start_matches("0x"),
        16,
    )
    .unwrap();
    let rate = crate::annuity::number(&raw_p["args"][0]);
    assert!(rate > 0.0 && rate <= 0.25 && f64::from_bits(p_bits) < 0.0);
    let beginning = crate::annuity::number(&raw_p["args"][4]) == 1.0;
    assert!(beginning || crate::annuity::number(&raw_p["args"][4]) == 0.0);
    let mut periods = vec![];
    let mut first_beginning = vec![];
    let mut ip_targets = vec![];
    let mut pp_targets = vec![];
    for row in &original {
        assert_eq!(&row["pmt"][0], raw_p);
        assert_eq!(row["ppmt"]["function"], "PPMT", "principal function identity");
        assert_eq!(row["ipmt"].as_array().unwrap().len(), 1, "one interest observation required");
        assert_eq!(row["ipmt"][0]["function"], "IPMT", "interest function identity");
        let a = row["ppmt"]["args"].as_array().unwrap();
        assert_eq!(a.len(), 6, "complete principal arguments");
        assert_eq!(a[2], raw_p["args"][1], "payment/principal period count differs");
        assert_eq!(a[3], raw_p["args"][2], "payment/principal present value differs");
        assert_eq!(a[4], raw_p["args"][3], "payment/principal final value differs");
        assert_eq!(a[5], raw_p["args"][4], "payment/principal timing differs");
        let period = crate::annuity::number(&a[1]);
        assert!(period >= 1.0 && period <= nper && period.fract() == 0.0,
            "observed period outside the loan");
        assert_eq!(crate::annuity::number(&a[0]), rate);
        assert_eq!(crate::annuity::number(&a[4]), 0.0);
        assert_eq!(crate::annuity::number(&a[5]), if beginning { 1.0 } else { 0.0 });
        assert_eq!(&row["ipmt"][0]["args"], &row["ppmt"]["args"]);
        assert_eq!(&row["ipmt"][0]["reading"], &raw_p["reading"]);
        assert_eq!(&row["ppmt"]["reading"], &raw_p["reading"]);
        let remaining = crate::annuity::number(&a[2]) - crate::annuity::number(&a[1]) + 1.0;
        assert!(remaining >= 1.0 && remaining.fract() == 0.0);
        periods.push(remaining);
        first_beginning.push(beginning && crate::annuity::number(&a[1]) == 1.0);
        let bits = |v: &serde_json::Value| {
            u64::from_str_radix(v.as_str().unwrap().trim_start_matches("0x"), 16).unwrap()
        };
        ip_targets.push(bits(&row["ipmt"][0]["expected"]));
        pp_targets.push(bits(&row["ppmt"]["expected"]));
    }
    let latent = publication_candidates::<F>(p_bits);
    let prior =
        joint_pv_fv.map(|p| serde_json::from_slice::<Vec<usize>>(&fs::read(p).unwrap()).unwrap());
    let growth_ids: Vec<usize> = prior
        .as_ref()
        .map(|ps| {
            ps.iter()
                .map(|&p| (p / 13) / (3 * 6561))
                .collect::<std::collections::BTreeSet<_>>()
                .into_iter()
                .collect()
        })
        .unwrap_or_default();
    if prior.is_some() {
        assert!(!growth_ids.is_empty());
    }
    let log_count = if prior.is_some() { growth_ids.len() } else { 5 };
    let hs = boundary::helpers();
    let ls = logs::<F>(rate, excel_log1p(rate).to_bits());
    let helper_count = if prior.is_some() { 3 } else { hs.len() + 162 };
    let components: Vec<Vec<Vec<Val>>> = (0..log_count)
        .map(|lp| {
            (0..helper_count)
                .map(|h| {
                    periods
                        .iter()
                        .enumerate()
                        .map(|(index, &n)| {
                            // A payment at time zero has no preceding interest.
                            if first_beginning[index] { return Val::f64(0.0); }
                            if prior.is_some() {
                                let g = crate::annuity::loan_growth::<F>(growth_ids[lp], rate, -n);
                                binop::<F>(Op::Add(0, 1), MODELS[h], g, Val::f64(-1.0))
                            } else if h < hs.len() {
                                boundary::helper_components::<F>(&hs[h], n, ls[lp]).2
                            } else {
                                direct_components::<F>(h - hs.len(), -n, ls[lp]).2
                            }
                        })
                        .collect()
                })
                .collect()
        })
        .collect();
    assert!(
        components
            .iter()
            .flatten()
            .flatten()
            .all(|e| e.to_f64::<F>().is_finite() && e.to_f64::<F>() <= 0.0)
    );
    let profiles: Vec<(usize, usize)> = (0..4)
        .flat_map(|shape| (0..if shape == 3 { 3 } else { 27 }).map(move |code| (shape, code)))
        .collect();
    assert_eq!(profiles.len(), 84);
    json_write(root.join("observations.json"), &original);
    json_write(
        root.join("grammar.json"),
        &json!({"role":"implementer","log_producer_count":log_count,"helpers":hs,"root_profiles":profiles,
        "IPMT_roots":["-(((P*em)/rate)*rate)","-((P*(em/rate))*rate)","-(((P*rate)*em)/rate)","-(P*em)"],
        "PPMT_root":"P-IPMT_internal, each of three models; IPMT publication occurs independently and does not overwrite its internal result",
        "models":MODELS,"latent_P_values":latent.iter().map(|p|p.exact_encoding()).collect::<Vec<_>>(),
        "helper":"same log provider and negative-exponent helper for every period; em=expm1(-remaining*log1p(rate))",
        "helper_ids":"0..1979 are the serialized difference/correction helpers;1980..2141 are the162 direct F2XM1 helpers defined by direct_components, with negative remaining periods",
        "component_layout":"(producer*helper_count+helper)*84+root_profile_index","helper_count":helper_count,"program_layout":"component*3+PPMT_subtraction_model",
        "component_count":log_count*helper_count*84,"program_count":log_count*helper_count*84*3,
        "joint_PV_FV_hypotheses":prior,"joint_growth_ids":growth_ids,
        "joint_growth_policy":"When prior is present, producer selects its integer growth ID, helper selects one of three G-1 models, and the frozen PV/FV negative-integer growth programme supplies G. No log/expm1 helper is used. Other helper descriptions apply only when prior is absent.",
        "proof":"IPMT root is monotone nondecreasing in finite P: rounding is monotone and the nonpositive em plus final negation give nonnegative slope. Exact ordered Ext80 binary searches intersect all observed IPMT targets. Every remaining P is then checked exactly against all observed PPMT targets.",
        "scope":"One original positive-rate FV=0 loan, canonical beginning/end timing. Beginning period one has zero interest. Unknown internal PMT is any finite Ext80 value publishing to the recorded PMT, shared across every observed period.",
        "observed_periods":original.len(),"first_beginning":first_beginning,
        "zero_interest_publication":"P is negative, rate positive and the beginning-period-one em is positive zero; every declared root returns positive zero. Checked for native/software backends and all84 root profiles.",
        "limitation":"Conditional partial programme only: the PMT-producing programme is unspecified, and latent values are constraints, never fitted constants or predictions for a new loan.",
        "instruction_policy":"FYL2XP1 measured natively in both arithmetic modes; all other operations follow declared Fpu"}),
    );
    if helpers_only {
        assert!(prior.is_none());
        let mut traces = Vec::new();
        let mut interned = std::collections::BTreeMap::new();
        let mut mappings = Vec::new();
        for lp in 0..log_count {
            for h in 0..helper_count {
                let mut ids = Vec::new();
                for (index, &n) in periods.iter().enumerate() {
                    let (em, trace) = if first_beginning[index] {
                        (Val::f64(0.0), json!({"kind":"beginning_zero","em":Val::f64(0.0).exact_encoding()}))
                    } else if h < hs.len() {
                        let (em, mut trace) = boundary::helper_trace::<F>(&hs[h], n, ls[lp]);
                        trace["kind"] = json!("kahan");
                        (em, trace)
                    } else {
                        let nodes = direct_component_details::<F>(h - hs.len(), -n, ls[lp]);
                        (nodes[9], json!({"kind":"direct","nodes":nodes.map(Val::exact_encoding),"em":nodes[9].exact_encoding()}))
                    };
                    assert_eq!(em.exact_encoding(), components[lp][h][index].exact_encoding());
                    let key = serde_json::to_string(&trace).unwrap();
                    let id = *interned.entry(key).or_insert_with(|| {
                        let id = traces.len();
                        traces.push(trace);
                        id
                    });
                    ids.push(id);
                }
                mappings.push(json!({"log_provider":lp,"helper":h,"traces":ids}));
            }
        }
        json_write(root.join("helper-traces.json"), &traces);
        json_write(root.join("helper-mappings.json"), &mappings);
        json_write(root.join("log-inputs.json"), &ls.map(Val::exact_encoding));
        json_write(root.join("certificate-scope.json"), &json!({"complete":true,
            "helper_profiles":log_count*helper_count,"periods":original.len(),"distinct_helper_traces":traces.len(),
            "purpose":"Full-width helper arithmetic for independent conditional loan replay; no new Excel observations or fitted intermediate.",
            "elementary_leaf_policy":"EXP and LN raw values are explicit shared hypotheses from the cleared elementary chains. FYL2XP1 remains a native measured leaf. No mathematical transcendental or general CPU equivalence is claimed."}));
        println!("{} helper profiles, {} distinct traces", mappings.len(), traces.len());
        return;
    }
    let mut results =
        BufWriter::new(fs::File::create(root.join("component-results.jsonl")).unwrap());
    let mut survivors = BufWriter::new(fs::File::create(root.join("survivors.jsonl")).unwrap());
    let mut evals = 0u64;
    let mut component_count = 0;
    let mut ip_kills = vec![0usize; original.len()];
    let mut pp_kills = vec![0usize; original.len()];
    let mut surviving_programs = 0;
    for lp in 0..log_count {
        for h in 0..helper_count {
            for (ri, &(shape, code)) in profiles.iter().enumerate() {
                let component = (lp * helper_count + h) * 84 + ri;
                component_count += 1;
                let mut low = 0;
                let mut high = latent.len();
                let mut kill = None;
                let mut kill_boundaries = vec![];
                let mut previous = (low, high);
                for i in 0..original.len() {
                    previous = (low, high);
                    let mut value = |index: usize| {
                        evals += 1;
                        backward_interest::<F>(
                            latent[index],
                            components[lp][h][i],
                            Val::f64(rate),
                            shape,
                            code,
                        )
                        .to_f64::<F>()
                    };
                    let target = f64::from_bits(ip_targets[i]);
                    let bound =
                        |strict: bool,
                         mut lo: usize,
                         mut hi: usize,
                         value: &mut dyn FnMut(usize) -> f64| {
                            while lo < hi {
                                let mid = lo + (hi - lo) / 2;
                                let y = value(mid);
                                assert!(y.is_finite());
                                if if strict { y > target } else { y >= target } {
                                    hi = mid
                                } else {
                                    lo = mid + 1
                                }
                            }
                            lo
                        };
                    let left = bound(false, low, high, &mut value);
                    let right = bound(true, left, high, &mut value);
                    low = left;
                    high = right;
                    if low == high {
                        let mut indices = vec![];
                        if left > previous.0 {
                            indices.push(left - 1);
                        }
                        if left < previous.1 {
                            indices.push(left);
                        }
                        assert!(!indices.is_empty());
                        for index in indices {
                            let got = backward_interest::<F>(
                                latent[index],
                                components[lp][h][i],
                                Val::f64(rate),
                                shape,
                                code,
                            );
                            evals += 1;
                            kill_boundaries.push(json!({"latent_P_index":index,"internal_IPMT":got.exact_encoding(),
                                "published_IPMT":format!("0x{:016x}",got.to_f64::<F>().to_bits()),"expected":format!("0x{:016x}",ip_targets[i])}));
                        }
                        kill = Some(i);
                        ip_kills[i] += 3;
                        break;
                    }
                }
                let mut pp_details = vec![];
                if kill.is_none() {
                    for sub in 0..3 {
                        let mut allowed: Vec<usize> = (low..high).collect();
                        let mut killed = None;
                        let mut last_partitions =
                            std::collections::BTreeMap::<String, Vec<usize>>::new();
                        for i in 0..original.len() {
                            let mut rejected =
                                std::collections::BTreeMap::<String, Vec<usize>>::new();
                            allowed.retain(|&index| {
                                evals += 1;
                                let interest = backward_interest::<F>(
                                    latent[index],
                                    components[lp][h][i],
                                    Val::f64(rate),
                                    shape,
                                    code,
                                );
                                let got = binop::<F>(
                                    Op::Add(0, 1),
                                    MODELS[sub],
                                    latent[index],
                                    boundary::neg(interest),
                                )
                                .to_f64::<F>()
                                .to_bits();
                                if got == pp_targets[i] {
                                    true
                                } else {
                                    rejected
                                        .entry(format!("0x{got:016x}"))
                                        .or_default()
                                        .push(index);
                                    false
                                }
                            });
                            if allowed.is_empty() {
                                killed = Some(i);
                                pp_kills[i] += 1;
                                last_partitions = rejected;
                                break;
                            }
                        }
                        if !allowed.is_empty() {
                            surviving_programs += 1;
                            serde_json::to_writer(&mut survivors,&json!({"program":component*3+sub,"component":component,"subtraction_model":sub,"latent_P_indices":allowed})).unwrap();
                            writeln!(survivors).unwrap();
                        }
                        pp_details.push(json!({"subtraction_model":sub,"first_PPMT_contradiction":killed,"latent_P_count":allowed.len(),"last_kill_prediction_partitions":last_partitions}));
                    }
                }
                serde_json::to_writer(&mut results,&json!({"component":component,"first_IPMT_contradiction":kill,
            "latent_P_interval_before_last_IPMT":[previous.0,previous.1],"latent_P_interval_after_IPMT":[low,high],"IPMT_kill_boundary_predictions":kill_boundaries,"PPMT_profiles":pp_details})).unwrap();
                writeln!(results).unwrap();
            }
        }
    }
    assert_eq!(component_count, log_count * helper_count * 84);
    assert_eq!(
        component_count * 3,
        ip_kills.iter().sum::<usize>() + pp_kills.iter().sum::<usize>() + surviving_programs
    );
    let summary = json!({"components":component_count,"programs":component_count*3,"survivors":surviving_programs,
        "joint_PV_FV_hypotheses":prior.as_ref().map(Vec::len),"joint_partial_programs":prior.as_ref().map(|p|p.len()*helper_count*84*3),"joint_growth_ids":growth_ids,
        "latent_P_values":latent.len(),"evaluations":evals,"IPMT_first_kill_counts":ip_kills,"PPMT_first_kill_counts":pp_kills,
        "complete":true,"observed_periods":original.len(),"scope":"One recorded loan, all supplied IPMT/PPMT periods and PMT publication, same latent PMT across every period",
        "claim":"Exact conditional joint partial-program constraints; no fitted PMT and no identified full application programme"});
    json_write(root.join("summary.json"), &summary);
    println!("{summary}");
}

#[cfg(test)]
mod loan_publication_tests {
    use super::*;
    use crate::ported::excel_numeric::{Hard, Soft};

    #[test]
    fn beginning_interest_publishes_positive_zero_for_every_declared_root() {
        let latent = publication_candidates::<Hard>((-1.5_f64).to_bits());
        for &p in latent.iter().step_by(1024) {
            for shape in 0..4 {
                for code in 0..if shape == 3 { 3 } else { 27 } {
                    let hard = backward_interest::<Hard>(p, Val::f64(0.0), Val::f64(0.01), shape, code);
                    let soft = backward_interest::<Soft>(p, Val::f64(0.0), Val::f64(0.01), shape, code);
                    assert_eq!(hard.to_f64::<Hard>().to_bits(), 0);
                    assert_eq!(soft.to_f64::<Soft>().to_bits(), 0);
                }
            }
        }
    }
}

fn nper_profile<F: Fpu>(a: [f64; 5], cash_model: EvalModel) -> String {
    let [r, p, pv, fv, t] = a;
    let stored = EvalModel::StoredPc64;
    if a.iter().any(|x| !x.is_finite()) {
        return "error:Value".into();
    }
    let bin = |op, a, b| binop::<F>(op, stored, a, b);
    if r == 0.0 {
        if p == 0.0 {
            return "error:Div0".into();
        }
        return outcome::<F>(bin(
            Op::Div(0, 1),
            boundary::neg(bin(Op::Add(0, 1), Val::f64(fv), Val::f64(pv))),
            Val::f64(p),
        ));
    }
    let tf = if t.trunc() == 0.0 {
        Val::f64(1.0)
    } else {
        bin(Op::Add(0, 1), Val::f64(1.0), Val::f64(r))
    };
    let tfp = bin(Op::Mul(0, 1), tf, Val::f64(p));
    let fr = binop::<F>(Op::Mul(0, 1), cash_model, Val::f64(fv), Val::f64(r));
    let pr = binop::<F>(Op::Mul(0, 1), cash_model, Val::f64(pv), Val::f64(r));
    let numerator = bin(Op::Add(0, 1), tfp, boundary::neg(fr));
    let denominator = bin(Op::Add(0, 1), tfp, pr);
    let ratio = bin(Op::Div(0, 1), numerator, denominator);
    let rr = ratio.to_f64::<F>();
    if rr <= 0.0 || !rr.is_finite() {
        return "error:Num".into();
    }
    let base = bin(Op::Add(0, 1), Val::f64(1.0), Val::f64(r));
    if base.to_f64::<F>() <= 0.0 {
        return "error:Num".into();
    }
    let lnbase = store::<F>(Val::Ext(research_log::<F>(&base.to_ext())), true);
    if lnbase.to_f64::<F>() == 0.0 {
        return "error:Div0".into();
    }
    let lnratio = store::<F>(Val::Ext(research_log::<F>(&ratio.to_ext())), true);
    outcome::<F>(bin(Op::Div(0, 1), lnratio, lnbase))
}

pub fn nper_product_profiles(input: &str, out: &str, full_five: bool) {
    let rows = crate::lines::<serde_json::Value>(input);
    let arithmetic = if full_five {
        vec![
            EvalModel::Strict,
            EvalModel::StoredPc64,
            EvalModel::ResidentPc64,
            EvalModel::StoredPc53,
            EvalModel::ResidentPc53,
        ]
    } else {
        MODELS.to_vec()
    };
    let mut alive: Vec<usize> = (0..arithmetic.len()).collect();
    let mut first = vec![];
    let mut checks = vec![0usize; arithmetic.len()];
    for (idx, row) in rows.iter().enumerate() {
        assert_eq!(row["function"], "NPER");
        assert_eq!(row["args"].as_array().unwrap().len(), 5);
        let a: [f64; 5] = std::array::from_fn(|j| {
            let v = calc_verdict::decode_argument(&row["args"][j], "NPER raw bits").unwrap();
            match v.core() {
                crate::value::CoreValue::Number(x) => *x,
                _ => panic!("NPER typed control outside declared numeric bank"), // ubs:ignore — fail closed when a declared numeric control has another type
            }
        });
        let got = nper_profile::<Hard>(a, EvalModel::StoredPc64);
        assert_eq!(
            got,
            row["expected"].as_str().unwrap(),
            "stored baseline must reproduce every original application reading, {}",
            row["id"]
        );
        alive.retain(|&id|{checks[id]+=1;let got=nper_profile::<Hard>(a,arithmetic[id]);
            if got==row["expected"].as_str().unwrap(){true}else{first.push(json!({"model":arithmetic[id],"case":idx,"witness":row,"expected":row["expected"],"got":got}));false}
        });
    }
    let allowed: Vec<_> = alive.iter().map(|&i| arithmetic[i]).collect();
    let result = json!({"rows":rows.len(),"baseline_application_trace_matches":rows.len(),"cash_product_models":arithmetic,"allowed_model_indices":alive,"allowed_models":allowed,"first_kills":first,"evaluations_per_model":checks,"backend":"native Fpu, including existing x87 logarithms","sharing":"Only PV*rate and FV*rate change model; all other NPER sites retain the existing registered graph. The same interest-product model is imposed on the PMT I=PV*rate hypothesis.","claim":"Exact conditional joint constraint, not uniqueness of the NPER programme or a product gain"});
    json_write(out, &result);
    println!("{result}");
}

fn interest_value<F: Fpu>(row: &Row, em: Val, mut code: usize) -> Val {
    let m: [EvalModel; 5] = std::array::from_fn(|_| {
        let v = MODELS[code % 3];
        code /= 3;
        v
    });
    let [rate, pv, _, timing, _] = row.args();
    let i = binop::<F>(Op::Mul(0, 1), m[0], Val::f64(pv), Val::f64(rate));
    let tf = if timing == 0.0 {
        Val::f64(1.0)
    } else {
        binop::<F>(Op::Add(0, 1), m[1], Val::f64(1.0), Val::f64(rate))
    };
    let amort = binop::<F>(Op::Div(0, 1), m[2], i, em);
    let total = binop::<F>(Op::Add(0, 1), m[3], i, amort);
    boundary::neg(binop::<F>(Op::Div(0, 1), m[4], total, tf))
}
pub fn interest_search<F: Fpu>(input: &str, nper_profiles: &str, out: &str) {
    fs::create_dir_all(out).unwrap();
    let root = Path::new(out);
    let hs = boundary::helpers();
    let (rows, counts) = scoped_rows(input, root);
    let precondition: serde_json::Value =
        serde_json::from_slice(&fs::read(nper_profiles).unwrap()).unwrap();
    let allowed: Vec<usize> =
        serde_json::from_value(precondition["allowed_model_indices"].clone()).unwrap();
    assert!(!allowed.is_empty());
    let mut alive: Vec<usize> = (0..5 * hs.len() * 243)
        .filter(|id| allowed.contains(&(id % 3)))
        .collect();
    let count = alive.len();
    let mut evaluations = 0u64;
    json_write(
        root.join("grammar.json"),
        &json!({"log_providers":["frozen_binary64_log1p","residentFYL2XP1","storedFYL2XP1","residentDLMF4.6.6_PC64_unchanged_sum","storedDLMF4.6.6_PC64_unchanged_sum"],"positive_expm1_helpers":hs,
        "NPER_precondition":precondition,"shared_product":"I=PV*rate, constrained by the same rate-weighted-cashflow product model in NPER",
        "programme":"I=PV*rate; amort=I/em; total=I+amort; output=-total/tf","sharing":"I is computed once and reused unchanged on both edges; implicit strict input stores remain local to each consumer",
        "sites":["I product","tf addition","I/em","I+amort","total/tf"],"models":MODELS,
        "layout":"id=(log_provider*1980+helper)*243+little_endian_base3_site_code; only NPER-allowed first digits admitted",
        "programs":count,"scope_counts":counts,"FYL2XP1_policy":"native leaf in both arithmetic modes, no pure software instruction emulation claim",
        "source":"Annuity decomposition -(PV*rate+(PV+FV)*rate/expm1(n*log1p(rate)))/tf; FV=0 arm uses shared I. This explains the observed opposing-balance identity without selecting answer residuals."}),
    );
    let mut kills = BufWriter::new(fs::File::create(root.join("first-kills.jsonl")).unwrap());
    let mut stats = BufWriter::new(fs::File::create(root.join("witness-kills.jsonl")).unwrap());
    let mut killing = vec![];
    for (idx, row) in rows.iter().enumerate() {
        let before = alive.len();
        let mut rejected = std::collections::BTreeMap::<String, Vec<usize>>::new();
        if before > 0 {
            let l = logs::<F>(row.args()[0], row.log1p);
            let n = nper(row);
            let em: Vec<Vec<_>> = l
                .iter()
                .map(|&log| {
                    hs.iter()
                        .map(|h| boundary::helper_components::<F>(h, -n, log).2)
                        .collect()
                })
                .collect();
            alive.retain(|&id| {
                let lp = id / (hs.len() * 243);
                let h = (id / 243) % hs.len();
                let got = outcome::<F>(interest_value::<F>(row, em[lp][h], id % 243));
                evaluations += 1;
                if got == row.expected() {
                    true
                } else {
                    rejected.entry(got).or_default().push(id);
                    false
                }
            });
            for (got, ids) in rejected {
                serde_json::to_writer(&mut kills,&json!({"candidate_ids":ids,"case":idx,"witness":row,"expected":row.expected(),"got":got})).unwrap();
                writeln!(kills).unwrap();
            }
        }
        let rec = json!({"case":idx,"id":row.raw["id"],"killed":before-alive.len(),"remaining":alive.len()});
        serde_json::to_writer(&mut stats, &rec).unwrap();
        writeln!(stats).unwrap();
        if before != alive.len() {
            println!("{rec}");
            killing.push(rec);
            kills.flush().unwrap();
            stats.flush().unwrap()
        }
    }
    json_write(root.join("survivors.json"), &alive);
    let summary = json!({"programs":count,"survivors":alive.len(),"scoped_rows":rows.len(),"scope_counts":counts,"evaluations":evaluations,"first_kill_rows":killing,"complete":true,"claim":"Exact NPER/PMT interest-product joint constraint and FV=0 decomposition search, not identification or a product pass count"});
    json_write(root.join("summary.json"), &summary);
    println!("{summary}");
}
