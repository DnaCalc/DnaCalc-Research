"""Own finite weighted false-position bracket programs, no fitted parameter."""
import sys,json,math
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer')
from fingerprint import bits,value,write,sha
from x87_programs import Native
from x87 import load64
root=Path('/home/ubuntu/codex-runs/r35');native=Native(root/'erfc-plateau/native.so')
j=json.loads((root/'yield-map/result.json').read_text())
cases=[(c,a)for c,a in zip(j['cases'],j['answers']['YIELD'])if c['coupon']==0 and c['frequency']==1 and c['price']<100]
def calc(a,b,kind,mode):
 if mode=='strict':return {'add':lambda:a+b,'sub':lambda:a-b,'mul':lambda:a*b,'div':lambda:a/b}[kind]()
 return value(f'{native.publish(native.leaf(kind,load64(int(bits(a),16)),load64(int(bits(b),16)),0x133f)):016x}')
programs=[]
for mode in ('strict','stored_pc64'):
 for low in (0.,-.5):
  for high in (.05,.1,.5,1.):
   for method in ('half_repeated','half_always','pegasus','anderson'):
    for tol in (1e-10,1e-8):
     for stop in ('width','step','f'):
      for returned in ('current','before','lower'):
       first=None
       for c,a in cases:
        def op(x,y,k):return calc(x,y,k,mode)
        def f(y):
         q=op(1.,y,'add');power=1.;n=c['n'];term=q
         while n:
          if n&1:power=op(power,term,'mul')
          n>>=1
          if n:term=op(term,term,'mul')
         return op(op(100.,power,'div'),c['price'],'sub')
        upper=high
        for i in range(20):
         if f(upper)<0:break
         upper*=2
        l,h=low,upper;fl,fh=f(l),f(h);old=None;x=l;trace=[];answer=None
        for iteration in range(100):
         before=x
         x=op(h,op(op(fh,op(h,l,'sub'),'mul'),op(fh,fl,'sub'),'div'),'sub')
         if not l<x<h:x=(l+h)/2
         fx=f(x);trace.append(dict(x=bits(x),f=bits(fx),low=bits(l),high=bits(h)))
         if fx==0:answer=x;break
         side=1 if fx>0 else -1
         if fx>0:
          previous=fl;l,fl=x,fx
          factor=.5 if method=='half_always'or method=='half_repeated'and old==side else 1.
          if method=='pegasus':factor=op(previous,op(previous,fx,'add'),'div')
          if method=='anderson':factor=1.-fx/previous;factor=factor if factor>0 else .5
          fh=op(fh,factor,'mul')
         else:
          previous=fh;h,fh=x,fx
          factor=.5 if method=='half_always'or method=='half_repeated'and old==side else 1.
          if method=='pegasus':factor=op(previous,op(previous,fx,'add'),'div')
          if method=='anderson':factor=1.-fx/previous;factor=factor if factor>0 else .5
          fl=op(fl,factor,'mul')
         old=side
         if (h-l<tol if stop=='width'else abs(x-before)<tol if stop=='step'else abs(fx)<tol):
          answer={'current':x,'before':before,'lower':l}[returned];break
        if answer is None or bits(answer)!=a.get('bits'):
         first=dict(case_id=c['id'],expected=a,prediction=None if answer is None else bits(answer),trace=trace);break
       programs.append(dict(mode=mode,low=low,high=high,method=method,tol=tol,stop=stop,returned=returned,first_contradiction=first))
write(root/'yield-weighted-secant.json',dict(format='dnacalc-yield-weighted-secant/1',complete=True,programs=programs,source_sha256=sha(__file__)))
print(len(programs),'programs',sum(p['first_contradiction']is None for p in programs),'survivors',flush=True)
