"""Verify negative-power sum refutations with independent rational arithmetic."""
from pathlib import Path
import sys,json,hashlib
research=Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research');sys.path.insert(0,str(research/'checker'))
from x87 import Exact,published_bits
root=Path('/home/ubuntu/codex-runs/r35');source=root/'duration-negative-powers/result.json';d=json.loads(source.read_text());rows=json.loads((root/'duration-settlement-mapping/observations.json').read_text())['records'];checker=Exact(None);checked=0
for p in d['programs']:
 first=p['first_contradiction'];assert first is not None
 got=f'{published_bits(checker.graph(first["graph"],[int(v,16)for v in first["inputs"]],0x133f,1,inner_cw=0x123f)[:10]):016x}'
 assert got==first['prediction']and got!=rows[first['index']]['answer']['bits'];checked+=1
result=dict(complete=True,exact_refutations=checked,input_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in(source,root/'duration-settlement-mapping/observations.json',Path(__file__))},limits='Independent exact arithmetic verifies each declared complete program has its recorded contradiction; public negative POWER remains a conditional leaf.')
(root/'duration-negative-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
