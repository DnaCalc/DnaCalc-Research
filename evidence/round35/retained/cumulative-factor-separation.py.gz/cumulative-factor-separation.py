"""Use new power-rate controls to separate the two previously surviving factors."""
import sys,json,numpy as np
from pathlib import Path
sys.path[:0]=['/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer','/home/ubuntu/projects/DnaCalc/DnaCalc-Research/checker']
from fingerprint import bits,value,write,sha
from x87_programs import Builder,Native
root=Path('/home/ubuntu/codex-runs/r35');d=json.loads((root/'cumulative-power-rate-read.json').read_text());native=Native(root/'erfc-plateau/native.so');programs=[]
for logarithm in d['records'][0]['predictions']:
 rows=d['records'];inputs=np.array([[int(bits(-value(r['predictions'][logarithm]['bits'])),16),int(bits(d['selected'][r['loan']]['rate']),16),int(bits(-1.),16)]for r in rows],dtype=np.uint64)
 for factor in ('rate','due_reciprocal','due_direct'):
  g=Builder(3);f=1
  if factor=='due_reciprocal':f=g.op('div',g.one,g.op('add',g.one,g.op('div',g.one,f)))
  elif factor=='due_direct':f=g.op('div',f,g.op('add',g.one,f))
  out=g.op('mul',g.op('div',2,f),g.op('mul',0,f));graph=g.graph(out,out)
  for model,cw,mask in [('strict',0x123f,(1<<g.sites)-1),('stored_pc64',0x133f,(1<<g.sites)-1),('resident_pc64',0x133f,0)]:
   out=native.grid(graph,inputs,cw,mask)[:,0];first=None
   for i,(r,a)in enumerate(zip(rows,out)):
    if int(a)!=int(r['answer']['bits'],16):first=dict(index=i,original=r,prediction=f'{int(a):016x}');break
   programs.append(dict(logarithm=logarithm,factor=factor,model=model,first_contradiction=first))
write(root/'cumulative-factor-separation.json',dict(complete=True,programs=programs,survivors=[p for p in programs if p['first_contradiction']is None],source_bindings={str(p):sha(p)for p in(Path(__file__),root/'cumulative-power-rate-read.json')},
 limits='Whole previously surviving cancellation trees, now on rates whose1+rate is not a power of two. This is discovery after seeing the normalized-leaf contradictions; no numeric adoption or fresh-validation claim.'))
print('programs',len(programs),'survivors',[p for p in programs if p['first_contradiction']is None],flush=True)
