import sys,json,math,struct
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer')
from fingerprint import bits,value,write,sha
from x87_programs import Native
from x87 import load64
from scipy.optimize import brentq,brenth,ridder,bisect,toms748
import scipy
root=Path('/home/ubuntu/codex-runs/r35');native=Native(root/'erfc-plateau/native.so')
j=json.loads((root/'yield-map/result.json').read_text())
cases=[(c,a)for c,a in zip(j['cases'],j['answers']['YIELD'])if c['coupon']==0 and c['frequency']==1 and c['price']<100]
def op(k,a,b):return value(f'{native.publish(native.leaf(k,load64(int(bits(a),16)),load64(int(bits(b),16)),0x133f)):016x}')
def power(q,n):
 a=1.
 while n:
  if n&1:a=op('mul',a,q)
  n>>=1
  if n:q=op('mul',q,q)
 return a
programs=[]
for method in (brentq,brenth,ridder,bisect,toms748):
 for high in (1.,.1,.05):
  for tol in (1e-10,2e-10):
   for returned in ('returned','lower'):
    first=None
    for c,a in cases:
     seen=[]
     def f(y):
      result=op('sub',op('div',100.,power(op('add',1.,y),c['n'])),c['price'])
      seen.append((y,result));return result
     upper=high
     for k in range(20):
      if f(upper)<0:break
      upper*=2
     try:res=method(f,0.,upper,xtol=tol,rtol=4*2.**-52,maxiter=100)
     except (ValueError,RuntimeError):res=None
     if returned=='lower'and res is not None:res=max(x for x,fx in seen if fx>=0)
     expected=a.get('bits')
     if res is None or bits(res)!=expected:
      first=dict(case=c,expected=a,prediction=None if res is None else bits(res),trace=[dict(x=bits(x),f=bits(fx))for x,fx in seen]);break
    programs.append(dict(method=method.__name__,high=high,tol=tol,returned=returned,first_contradiction=first))
write(root/'yield-brent-trial.json',dict(format='dnacalc-yield-brent-trial/1',complete=True,scipy=scipy.__version__,programs=programs,source_sha256=sha(__file__)))
print(len(programs),'programs',sum(p['first_contradiction']is None for p in programs),'survivors',flush=True)
