import sys,json,math
from pathlib import Path
from decimal import Decimal as D,localcontext
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer')
from fingerprint import CachedService,load_service,bits,value,write,sha
root=Path('/home/ubuntu/codex-runs/r35')
client,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc')
s=CachedService(client.Client(timeout=180),root/'cache')
rows=[]
for n,maturity in [(2,46037.),(4,46767.),(8,48228.)]:
 # Reuse dates from the original mapped, audited on-coupon cohorts.
 cases=json.loads((root/'yield-map/result.json').read_text())['cases']
 template=next(c for c in cases if c['n']==n and c['frequency']==1 and c['coupon']==0)
 for i in range(1001):
  price=70.+i*.07
  a=template['args'].copy();a[3]=client.number(price)
  rows.append(dict(n=n,price=price,args=a))
write(root/'yield-dense-questions.json',dict(rows=rows,source_sha256=sha(__file__)))
ans=s.ask_rows('YIELD',[r['args']for r in rows])
errors=[]
with localcontext()as ctx:
 ctx.prec=80
 for r,a in zip(rows,ans):
  if a['type']!='number':errors.append(dict(**r,answer=a));continue
  exact=(D(100)/D(r['price'])).__pow__(1/D(r['n']))-1
  err=D(value(a['bits']))-exact
  errors.append(dict(n=r['n'],price=r['price'],answer=a,exact=str(exact),error=str(err)))
write(root/'yield-dense.json',dict(format='dnacalc-yield-dense/1',complete=True,records=errors,receipts=s.receipts,source_sha256=sha(__file__)))
for n in (2,4,8):
 es=[D(e['error'])for e in errors if e['n']==n and 'error'in e]
 print(n,len(es),'min/max',float(min(es)),float(max(es)),'negative',sum(e<0 for e in es),'errors>1e-10',sum(abs(e)>D('1e-10')for e in es),flush=True)
