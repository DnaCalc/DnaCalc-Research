"""Fixed DURATION settlement mapping; on-coupon outputs are conditional public leaves."""
from pathlib import Path
import sys,json,datetime as dt,itertools,collections,hashlib
from fractions import Fraction as Q
research=Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research');sys.path.insert(0,str(research));sys.path.insert(0,str(research/'checker'))
from racer.fingerprint import CachedService,load_service,write,bits,value
from exact import BINARY64 as B,EXTENDED64 as E
root=Path('/home/ubuntu/codex-runs/r35');output=root/'duration-settlement-mapping'
output.mkdir(exist_ok=False)
client,_=load_service(research.parent/'DnaCalc');service=CachedService(client.Client(timeout=300),root/'cache')
epoch=dt.date(1899,12,30);start=dt.date(2020,1,1)
offsets=(0,1,2,7,14,29,30,31,32,59,60,61,62,89,90,91,92,119,120,121,122,149,150,151,152,159,160,161,169,170,171,172)
schedules=[];cases=[]
for years in (1,2,4):
 maturity=(dt.date(2020+years,1,1)-epoch).days
 for off in offsets:
  settlement=(start+dt.timedelta(days=off)-epoch).days
  schedules.append(dict(years=years,offset=off,settlement=settlement,maturity=maturity))
  for q in (1.03125,1.125,1.5):
   for coupon in (0.,.0625,.125):cases.append(dict(years=years,offset=off,settlement=settlement,maturity=maturity,base=bits(q),yield_bits=bits((q-1.)*2.),coupon=bits(coupon)))
profiles=[dict(tree=t,words=list(w))for t in range(6)for w in itertools.product(('strict','stored_pc64'),repeat=3)]
write(output/'questions.json',dict(format='dnacalc-duration-settlement-questions/1',complete=True,cases=cases,schedules=schedules,profiles=profiles,
 sites=['multiplication','division','subtraction'],
 trees=['D-A/E/f','D-A/(E*f)','(D*f-A/E)/f','(D*(E*f)-A)/(E*f)','D-A/360','(D*360-A)/360'],
 selection='Fixed32 settlement offsets within one semiannual period, three maturities, three discount bases and three coupons. Public on-coupon DURATION is a conditional leaf. No output-dependent input, degree or piece selection.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
factor_args=[[client.number(s[k])for k in ('settlement','maturity')]+[client.number(2.),client.number(0.)]for s in schedules]
factors={name:service.ask_rows(name,factor_args)for name in ('COUPDAYBS','COUPDAYS','COUPNUM')}
args=[[client.number(c[k])for k in ('settlement','maturity','coupon','yield_bits')]+[client.number(2.),client.number(0.)]for c in cases]
answers=service.ask_rows('DURATION',args)
if any(r.get('type')!='number'for r in answers):raise ValueError('nonnumeric duration control')
lookup={}
for c,a in zip(cases,answers):
 if c['offset']==0:lookup[c['years'],c['base'],c['coupon']]=a
factor_lookup={}
for i,s in enumerate(schedules):
 row={name:rows[i]for name,rows in factors.items()}
 if any(v.get('type')!='number'for v in row.values()):raise ValueError('nonnumeric coupon factor')
 assert value(row['COUPNUM']['bits'])==2*s['years']
 assert value(row['COUPDAYS']['bits'])==180.
 factor_lookup[s['years'],s['offset']]=row
write(output/'observations.json',dict(format='dnacalc-duration-settlement-observations/1',complete=True,
 records=[dict(case=c,answer=a,on_coupon=lookup[c['years'],c['base'],c['coupon']],factors=factor_lookup[c['years'],c['offset']])for c,a in zip(cases,answers)],receipts=service.receipts))
def arithmetic(kind,a,b,word):
 a,b=Q(a),Q(b);r={'add':lambda:a+b,'sub':lambda:a-b,'mul':lambda:a*b,'div':lambda:a/b}[kind]()
 return float(B.round(E.round(r)if word=='stored_pc64'else r))
results=[]
for profile in profiles:
 wm,wd,ws=profile['words'];mul=lambda a,b:arithmetic('mul',a,b,wm);div=lambda a,b:arithmetic('div',a,b,wd);sub=lambda a,b:arithmetic('sub',a,b,ws)
 first=None;counts=collections.Counter();changes=collections.Counter()
 for i,(c,a)in enumerate(zip(cases,answers)):
  d=value(lookup[c['years'],c['base'],c['coupon']]['bits']);factor=factor_lookup[c['years'],c['offset']];aa=value(factor['COUPDAYBS']['bits']);ee=value(factor['COUPDAYS']['bits']);f=2.
  tree=profile['tree']
  if tree==0:pred=sub(d,div(div(aa,ee),f))
  elif tree==1:pred=sub(d,div(aa,mul(ee,f)))
  elif tree==2:pred=div(sub(mul(d,f),div(aa,ee)),f)
  elif tree==3:den=mul(ee,f);pred=div(sub(mul(d,den),aa),den)
  elif tree==4:pred=sub(d,div(aa,360.))
  else:pred=div(sub(mul(d,360.),aa),360.)
  same=bits(pred)==a['bits'];group='zero_coupon'if value(c['coupon'])==0 else'positive_coupon';counts[group+'_rows']+=1;counts[group+'_matched']+=same
  if not same and first is None:first=dict(index=i,case=c,predicted=bits(pred),answer=a)
 results.append(dict(profile,counts=counts,first_contradiction=first))
write(output/'result.json',dict(format='dnacalc-duration-settlement-mapping/1',complete=True,rows=len(cases),profiles=results,
 survivors=[r for r in results if r['first_contradiction']is None],
 positive_coupon_survivors=[r for r in results if r['counts']['positive_coupon_rows']==r['counts']['positive_coupon_matched']],
 zero_coupon_survivors=[r for r in results if r['counts']['zero_coupon_rows']==r['counts']['zero_coupon_matched']],
 limits='The48 fixed simple settlement-subtraction trees are tested exactly, conditioned on independent public on-coupon DURATION and coupon factors. This does not identify a discount routine or all possible closed forms. Labels can duplicate physical computations. No product change.',
 input_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in (output/'questions.json',output/'observations.json',Path(__file__))}))
print(json.dumps(dict(rows=len(cases),profiles=len(results),whole_survivors=sum(r['first_contradiction']is None for r in results),positive_coupon_survivors=sum(r['counts']['positive_coupon_rows']==r['counts']['positive_coupon_matched']for r in results),zero_coupon_survivors=sum(r['counts']['zero_coupon_rows']==r['counts']['zero_coupon_matched']for r in results))),flush=True)
