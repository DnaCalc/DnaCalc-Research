"""Retain small R35 evidence, with raw and archive hashes; exclude bulk corpus and binaries."""
from pathlib import Path
import json,gzip,hashlib,shutil
root=Path('/home/ubuntu/codex-runs/r35');destination=Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research/evidence/round35')
destination.mkdir(parents=True,exist_ok=True)
records=[];excluded=[]
def digest(data):return hashlib.sha256(data).hexdigest()
for source in sorted(root.rglob('*')):
 if not source.is_file():continue
 relative=source.relative_to(root);parts=relative.parts
 if parts[0]=='tmp':continue
 if '__pycache__'in parts:continue
 if parts[0].endswith('-corpus')or parts[0]=='corpus-cases':
  if source.name not in ('summary.json','summary.md'):continue
 if parts[0].startswith('problems-')and'-run'in parts[0]:
  if source.name not in ('receipt.json','summary.json','table.json','bank-counts.json','bank.log'):continue
 data=source.read_bytes()
 if data[:4]==b'\x7fELF'or source.suffix in('.so','.dll','.exe'):
  excluded.append(dict(original=str(source),bytes=len(data),sha256=digest(data),reason='Compiled binary remains outside Git; source and build/readout logs retained.'));continue
 if source.suffix not in('.gz','.json','.jsonl','.log','.py','.patch','.txt','.bits','.md'):continue
 if source.suffix=='.gz':
  archive=Path('scalar-cache')/relative.name if parts[0]=='cache'else Path('retained')/relative
  packed=data
 else:
  archive=Path('retained')/Path(str(relative)+'.gz');packed=gzip.compress(data,compresslevel=9,mtime=0)
 target=destination/archive;target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(packed)
 records.append(dict(original=str(source),archive=str(archive),original_bytes=len(data),sha256=digest(data),archive_sha256=digest(packed),compressed=source.suffix!='.gz'))
(destination/'artifacts.json').write_text(json.dumps(records,indent=2)+'\n')
(destination/'excluded-binaries.json').write_text(json.dumps(excluded,indent=2)+'\n')
print(json.dumps(dict(artifacts=len(records),archive_bytes=sum((destination/r['archive']).stat().st_size for r in records),excluded_binaries=len(excluded))),flush=True)
