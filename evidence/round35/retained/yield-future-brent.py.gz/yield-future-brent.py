"""Own transcription of Brent's published interpolation/bisection mathematics.
No implementation source read. Conditional local PRICE arithmetic; discovery.
"""
import sys,json,math
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer')
from fingerprint import bits,value,write,sha
from x87_programs import Native
from x87 import load64
root=Path('/home/ubuntu/codex-runs/r35');native=Native(root/'erfc-plateau/native.so')
j=json.loads((root/'yield-map/result.json').read_text())
cases=[(c,a)for c,a in zip(j['cases'],j['answers']['YIELD'])if c['coupon']==0 and c['frequency']==1 and c['price']<100]
def calc(a,b,kind,mode):
 if mode=='strict':return {'add':lambda:a+b,'sub':lambda:a-b,'mul':lambda:a*b,'div':lambda:a/b}[kind]()
 return value(f'{native.publish(native.leaf(kind,load64(int(bits(a),16)),load64(int(bits(b),16)),0x133f)):016x}')
def root_brent(f,low,high,tol,relative,mode,ret):
 add=lambda a,b:calc(a,b,'add',mode);sub=lambda a,b:calc(a,b,'sub',mode)
 mul=lambda a,b:calc(a,b,'mul',mode);div=lambda a,b:calc(a,b,'div',mode)
 a,b=low,high;fa,fb=f(a),f(b);c=b;fc=fb;d=e=sub(b,a)
 if fa*fb>0:raise ValueError('no bracket')
 trace=[]
 for i in range(100):
  if fb*fc>0:
   c=a;fc=fa;d=e=sub(b,a)
  if abs(fc)<abs(fb):
   a=b;fa=fb;b=c;fb=fc;c=a;fc=fa
  tolerance=add(tol,mul(relative,abs(b)));half=mul(.5,sub(c,b))
  trace.append(dict(i=i,a=bits(a),b=bits(b),c=bits(c),fa=bits(fa),fb=bits(fb),fc=bits(fc)))
  if abs(half)<=tolerance or fb==0:
   return (b if ret=='b'or fb==0 else min(b,c)),trace
  if abs(e)>=tolerance and abs(fa)>abs(fb):
   s=div(fb,fa)
   if a==c:p=mul(mul(2.,half),s);q=sub(1.,s)
   else:
    q=div(fa,fc);r=div(fb,fc)
    p=mul(s,sub(mul(mul(mul(2.,half),q),sub(q,r)),mul(sub(b,a),sub(r,1.))))
    q=mul(mul(sub(q,1.),sub(r,1.)),sub(s,1.))
   if p>0:q=-q
   else:p=-p
   previous=e;e=d
   if mul(2.,p)<min(sub(mul(mul(3.,half),q),abs(mul(tolerance,q))),abs(mul(previous,q))):d=div(p,q)
   else:d=e=half
  else:d=e=half
  a=b;fa=fb
  b=add(b,d if abs(d)>tolerance else math.copysign(tolerance,half));fb=f(b)
 raise RuntimeError('iteration limit')
programs=[]
for equation in ('future_raw','future_normalized'):
 for mode in ('strict','stored_pc64'):
  for low in (0.,-.5,-.9):
   for high in (.05,.1,.5,1.,2.):
    for tol in (5e-11,1e-10):
     for relative in (0.,2*2.**-52):
      for returned in ('b','lower'):
       first=None
       for c,a in cases:
        def op(x,y,k):return calc(x,y,k,mode)
        def f(y):
         q=op(1.,y,'add');power=1.;n=c['n'];term=q
         while n:
          if n&1:power=op(power,term,'mul')
          n>>=1
          if n:term=op(term,term,'mul')
         return op(op(c['price'],power,'mul'),100.,'sub')if equation=='future_raw'else op(op(op(c['price'],100.,'div'),power,'mul'),1.,'sub')
        upper=high
        for i in range(20):
         if f(upper)<0:break
         upper*=2
        try:res,trace=root_brent(f,low,upper,tol,relative,mode,returned)
        except (ValueError,ZeroDivisionError,RuntimeError):res=None;trace=[]
        if res is None or bits(res)!=a.get('bits'):
         first=dict(case_id=c['id'],price=c['price'],expected=a,prediction=None if res is None else bits(res),trace=trace);break
       programs.append(dict(equation=equation,mode=mode,low=low,high=high,tol=tol,relative=relative,returned=returned,first_contradiction=first))
write(root/'yield-future-brent.json',dict(format='dnacalc-yield-future-brent/1',complete=True,programs=programs,source_sha256=sha(__file__)))
print(len(programs),'programs',sum(p['first_contradiction']is None for p in programs),'survivors',flush=True)
for p in programs:
 if p['first_contradiction']is None:print(p,flush=True)
