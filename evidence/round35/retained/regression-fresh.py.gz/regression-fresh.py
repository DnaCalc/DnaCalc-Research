import sys,json,random,subprocess,math
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer')
from fingerprint import CachedService,load_service,bits,write,sha
root=Path('/home/ubuntu/codex-runs/r35');out=root/'regression-fresh';out.mkdir(exist_ok=False)
client,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');s=CachedService(client.Client(timeout=180),root/'cache')
rng=random.Random(35001);cases=[]
for i in range(240):
 n=(4,7,12,24)[i%4];p=(1,2,3)[i%3];offset=(0.,1.,1000.,-1.)[(i//4)%4];scale=(.125,1.,8.,128.)[(i//16)%4]
 x=[[offset+scale*rng.uniform(-1,1) for j in range(p)]for k in range(n)]
 y=[[rng.uniform(1,10)+sum((j+1)*r[j]for j in range(p))]for r in x]
 # LOGEST's response stays positive independently of its log rounding.
 yl=[[math.exp(v[0]/(scale*(p+1)+abs(offset)*(p+1)+10))]for v in y]
 cases.append(dict(id=str(i),x=x,y=y,yl=yl,p=p,n=n,offset=offset,scale=scale))
write(out/'questions.json',dict(cases=cases,seed=35001,source_sha256=sha(__file__)))
raw=[]
for function in ('LINEST','LOGEST'):
 rows=[];answers=[]
 for p in (1,2,3):
  selected=[c for c in cases if c['p']==p]
  args=[[client.number_array(c['y'if function=='LINEST'else'yl']),client.number_array(c['x']),client.boolean(True),client.boolean(True)]for c in selected]
  for index in ((2,p+1),(3,2),(2,1)):
   ans=s.ask_rows(function,args,result_index=index)
   for c,a in zip(selected,ans):
    def matrix(m):return [['0x'+bits(x)for x in r]for r in m]
    argument=[matrix(c['y'if function=='LINEST'else'yl']),matrix(c['x']),True,True]
    q=dict(id=f"{function}-{c['id']}-{index[0]}-{index[1]}",args=argument,result_index=list(index))
    rows.append(q);answers.append(a)
 write(out/(function+'-inputs.json'),dict(function=function,witnesses=rows))
 exe='/home/ubuntu/projects/DnaCalc/DnaCalc-Research/target/release/symbolic-racer'
 subprocess.run([exe,'invoke-inputs',str(out/(function+'-inputs.json')),str(out/(function+'-predictions.jsonl'))],check=True,timeout=180)
 actual=[json.loads(l)for l in(out/(function+'-predictions.jsonl')).read_text().splitlines()]
 for q,a,got in zip(rows,answers,actual):
  if got['id']!=q['id']or got['args']!=q['args']or got['result_index']!=q['result_index']:raise ValueError('identity changed')
  expect='0x'+a['bits']if a['type']=='number'else'error:'+a['code'].strip('#!')
  raw.append(dict(q,function=function,expected=expect,actual=got['calc_func_prediction'],answer=a))
with(out/'inputs.jsonl').open('x')as f:
 for r in raw:f.write(json.dumps(r,separators=(',',':'))+'\n')
write(out/'result.json',dict(format='dnacalc-regression-fresh/1',complete=True,calls=len(raw),records=raw,receipts=s.receipts,source_sha256=sha(__file__)))
for function in ('LINEST','LOGEST'):
 for role in ('se_b','se_y','se_slope'):
  selected=[r for r in raw if r['function']==function and ('se_y'if r['result_index'][0]==3 else 'se_slope'if r['result_index'][1]==1 else 'se_b')==role]
  print(function,role,len(selected),sum(r['expected']==r['actual']for r in selected),flush=True)
subprocess.run([exe,'regression-stat-leaves',str(out/'inputs.jsonl'),str(out/'leaves')],check=True,timeout=180)
