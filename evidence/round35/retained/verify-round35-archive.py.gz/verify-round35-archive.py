"""Verify the retained R35 bytes, cached question identities and final source unit."""
from pathlib import Path
import collections,gzip,hashlib,json,subprocess,sys
root=Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
destination=root/'evidence/round35'
sys.path.insert(0,str(root))
from racer.fingerprint import accept
sha=lambda data:hashlib.sha256(data).hexdigest()
records=json.loads((destination/'artifacts.json').read_text());counts=collections.Counter()
paths=set()
for row in records:
 p=destination/row['archive'];assert p.resolve().is_relative_to(destination.resolve())
 assert row['archive']not in paths;paths.add(row['archive'])
 packed=p.read_bytes();assert sha(packed)==row['archive_sha256']
 original=gzip.decompress(packed)if row['compressed']else packed
 assert len(original)==row['original_bytes']and sha(original)==row['sha256']
 assert Path(row['original']).read_bytes()==original
 counts['artifacts']+=1;counts['archive_bytes']+=len(packed)
 if row['archive'].startswith('scalar-cache/'):
  doc=json.loads(gzip.decompress(original));request,reply=doc['request'],doc['reply']
  identity=sha(json.dumps(request,sort_keys=True,separators=(',',':')).encode())
  assert p.name.startswith(identity)
  counts['cached_requests']+=1;counts['requested_rows_in_batches']+=len(request['rows'])
  if reply.get('ok'):
   accept(reply,request['function'],request['rows']);counts['successful_batches']+=1
  else:
   assert reply.get('ok')is False;counts['failed_batches']+=1
unit=json.loads((root/'round35-final-unit.json').read_text())
assert not unit['application_working_blobs']
for name,h in unit['source_sha256'].items():
 assert sha((root/name).read_bytes())==h;counts['source_hashes']+=1
compiled=json.loads(subprocess.check_output([str(root/'target/release/symbolic-racer'),'provenance'],text=True))
features=compiled.pop('compiled_features');assert compiled==unit
print(json.dumps(dict(complete=True,counts=counts,application_revision=unit['application_revision'],compiled_features=features,
 artifact_manifest_sha256=sha((destination/'artifacts.json').read_bytes()),
 unit_sha256=sha((root/'round35-final-unit.json').read_bytes()),
 limits='Cached requests are distinct batches, not counts of unique formula calls. Readbacks and worker metadata checked by the existing accept route. Service-side receipt file paths and hashes are retained as metadata; their remote bytes are not rehashed locally.'),indent=2))
