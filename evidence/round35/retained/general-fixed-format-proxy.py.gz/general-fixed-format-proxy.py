"""Check an explicit TEXT format against scalar CONCATENATE's numeric rounding."""
from pathlib import Path
from fractions import Fraction as Q
import sys,json,collections,hashlib
research=Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research');sys.path.insert(0,str(research))
from racer.fingerprint import CachedService,load_service,write
root=Path('/home/ubuntu/codex-runs/r35');source=root/'general-midpoint-mapping/observations.json';data=json.loads(source.read_text());cases=data['cases'];output=root/'general-fixed-format-proxy';output.mkdir(exist_ok=False)
client,_=load_service(research.parent/'DnaCalc');service=CachedService(client.Client(timeout=300),root/'cache');args=[];formats=[];control_formats=iter(['0.00','0','0.00','0.000','0.00000000000000E+00'])
for c in cases:
 if c['scope']=='exact_midpoint_window':places=max(0,14-c['exponent']);fmt='0'+('.'+'0'*places if places else'')
 else:
  if c['step']==-1:current=next(control_formats)
  fmt=current
 formats.append(fmt);args.append([client.number(c['bits']),client.text(fmt)])
write(output/'questions.json',dict(format='dnacalc-general-fixed-format-questions/1',complete=True,formats=formats,
 selection='Explicit decimal positions match the15-significant-digit unit for each region; known controls use their corpus precision. The General format is separately retained and exposes only six digits in these TEXT readings.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
answers=service.ask_rows('TEXT',args);counts=collections.Counter();first=None
for i,(c,a,b)in enumerate(zip(cases,answers,data['answers']['CONCATENATE'])):
 good=False
 if a.get('type')=='text'and b.get('type')=='text':
  try:good=Q(a['value'])==Q(b['value'])
  except ValueError:pass
 counts['rows']+=1;counts['equal_numeric_text']+=good;counts['different_or_unavailable']+=not good
 if not good and first is None:first=dict(index=i,case=c,format=formats[i],text=a,concatenate=b)
write(output/'result.json',dict(format='dnacalc-general-fixed-format-proxy/1',complete=True,counts=counts,first_difference=first,answers=answers,receipts=service.receipts,
 limits='Original scalar alias/format observations. Equality here concerns the numeric value spelled by text; fixed trailing zeros and display notation may differ. It does not identify an internal shared helper, scaling constants or an operator implementation.',
 input_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in(source,output/'questions.json',Path(__file__))}))
print(json.dumps(counts),flush=True)
