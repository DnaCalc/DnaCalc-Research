"""Fresh mathematical mapping around coupon-rate roots, without a solver fit."""
import sys,json,datetime
from pathlib import Path
from decimal import Decimal as D,localcontext
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer')
from fingerprint import CachedService,load_service,bits,value,write,sha
root=Path('/home/ubuntu/codex-runs/r35');client,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');service=CachedService(client.Client(timeout=180),root/'cache')
serial=lambda y:float((datetime.date(y,1,15)-datetime.date(1899,12,30)).days)
rows=[]
with localcontext()as ctx:
 ctx.prec=90
 for n in (2,3,4,5,8,16):
  for coupon in (0.,.0625,.125):
   for shift in range(3,10):
    for sign in (-1,1):
     r=D(coupon)+D(sign)*D(2)**-shift;factor=1+r
     price=100/factor**n+100*D(coupon)*sum(1/factor**k for k in range(1,n+1))
     price=float(price);x=r
     for _ in range(20):
      f=100/(1+x)**n+100*D(coupon)*sum(1/(1+x)**k for k in range(1,n+1))-D(price)
      derivative=-100*n/(1+x)**(n+1)-100*D(coupon)*sum(D(k)/(1+x)**(k+1)for k in range(1,n+1))
      change=f/derivative;x-=change
      if abs(change)<D('1e-80'):break
     args=[serial(2024),serial(2024+n),coupon,price,100.,1.,0.]
     rows.append(dict(n=n,coupon=bits(coupon),shift=shift,sign=sign,price=bits(price),mathematical_root=str(x),
                      args=[client.number(a)for a in args]))
frozen=sha(__file__);write(root/'yield-distance-questions.json',dict(rows=rows,source_sha256=frozen,selection='Fixed integer maturities2,3,4,5,8,16; coupons0,1/16,1/8; positive/negative power-of-two distances2^-3through2^-9. Price rounded once to Value2; mathematical root recomputed for that exact input.'))
answers=service.ask_rows('YIELD',[r['args']for r in rows])
with localcontext()as ctx:
 ctx.prec=90
 for row,a in zip(rows,answers):
  row['answer']=a
  if a['type']=='number':row['error']=str(D(value(a['bits']))-D(row['mathematical_root']))
assert frozen==sha(__file__)
write(root/'yield-distance-map.json',dict(format='dnacalc-yield-coupon-distance-mapping/1',complete=True,records=rows,receipts=service.receipts,source_sha256=frozen,
 limits='Mapping only. Mathematical roots quantify the output error; they are never supplied to the application. Power-law regimes and jumps do not identify a unique iteration, derivative or stopping program.'))
print('rows',len(rows),'numeric',sum(a['type']=='number'for a in answers),flush=True)
for n in (2,3,4,5,8,16):
 for coupon in (0.,.0625,.125):
  selected=[r for r in rows if r['n']==n and r['coupon']==bits(coupon)and r['sign']==1]
  print(n,coupon,[(r['shift'],r.get('error',r['answer']))for r in selected],flush=True)
