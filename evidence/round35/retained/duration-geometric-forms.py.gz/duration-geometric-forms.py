"""Fixed compact/geometric duration trees; measured positive integer POWER is conditional."""
from pathlib import Path
import sys,json,itertools,collections,hashlib
research=Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research');sys.path.insert(0,str(research))
from racer.fingerprint import CachedService,load_service,write,bits,value
from racer.x87_programs import Builder,Native
root=Path('/home/ubuntu/codex-runs/r35');source=root/'duration-settlement-mapping/observations.json';data=json.loads(source.read_text());rows=data['records'];output=root/'duration-geometric-forms';output.mkdir(exist_ok=False)
client,_=load_service(research.parent/'DnaCalc');service=CachedService(client.Client(timeout=300),root/'cache')
requests={}
for r in rows:
 c=r['case'];n=r['factors']['COUPNUM']['bits'];requests.setdefault((c['base'],n),[client.number(c['base']),client.number(n)])
keys=list(requests);profiles=[dict(tree=t,face=face,words=list(w))for t in ('compact','geometric_sum')for face in (1.,100.)for w in itertools.product(('strict','stored_pc64'),repeat=4)]
write(output/'questions.json',dict(format='dnacalc-duration-geometric-questions/1',complete=True,profiles=profiles,sites=['add','sub','mul','div'],power_requests=list(requests.values()),
 selection='Two standard finite geometric identities, face1 or100, four independent coherent stored operation words. Fixed before reading these POWER answers. Existing864 settlement observations are discovery controls, not a new holdout.',
 formulas=['q/y - (face*q+n*(C-face*y))/(C*(q^n-1)+face*y)','(C*(q*(1-q^-n)-n*y*q^-n)/y^2+n*face*q^-n)/(C*(1-q^-n)/y+face*q^-n)'],
 source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
answers=service.ask_rows('POWER',list(requests.values()));powers=dict(zip(keys,answers))
if any(a.get('type')!='number'for a in answers):raise ValueError('nonnumeric integer POWER')
write(output/'powers.json',dict(format='dnacalc-duration-geometric-powers/1',complete=True,records=[dict(base=k[0],n=k[1],answer=a)for k,a in zip(keys,answers)],receipts=service.receipts))
native=Native(root/'erfc-plateau-reviewed/native.so');programs=[]
for profile in profiles:
 g=Builder(7);one=g.constant(bits(1.));face=g.constant(bits(profile['face']));word=dict(zip(('add','sub','mul','div'),profile['words']))
 def op(kind,a,b):
  at=g.op(kind,a,b,store=False);g.nodes[at].update(site=0,phase=int(word[kind]=='strict'));return at
 add=lambda a,b:op('add',a,b);sub=lambda a,b:op('sub',a,b);mul=lambda a,b:op('mul',a,b);div=lambda a,b:op('div',a,b)
 # Inputs: annual coupon,annual yield,frequency,accrued days,period days,n,q^n.
 y=div(1,2);q=add(one,y);coupon=div(mul(face,0),2)
 if profile['tree']=='compact':
  middle=div(add(mul(face,q),mul(5,sub(coupon,mul(face,y)))),add(mul(coupon,sub(6,one)),mul(face,y)))
  period=sub(div(q,y),middle)
 else:
  invp=div(one,6);s0=div(sub(one,invp),y)
  s1=div(sub(mul(q,sub(one,invp)),mul(mul(5,y),invp)),mul(y,y))
  price=add(mul(coupon,s0),mul(face,invp));weighted=add(mul(coupon,s1),mul(mul(5,face),invp));period=div(weighted,price)
 out=div(sub(period,div(3,4)),2);g.sites=1;graph=g.graph(out,out);first=None;counts=collections.Counter()
 for i,r in enumerate(rows):
  c=r['case'];f=r['factors'];p=powers[c['base'],f['COUPNUM']['bits']]
  inputs=[int(x,16)for x in(c['coupon'],c['yield_bits'],bits(2.),f['COUPDAYBS']['bits'],f['COUPDAYS']['bits'],f['COUPNUM']['bits'],p['bits'])]
  result=native.evaluate(graph,inputs,0x133f,1,inner_cw=0x123f);pred=f'{native.publish(result[:10]):016x}'
  same=pred==r['answer']['bits'];group='zero_coupon'if value(c['coupon'])==0 else'positive_coupon';counts[group+'_rows']+=1;counts[group+'_matched']+=same
  if not same and first is None:first=dict(index=i,case=c,prediction=pred,answer=r['answer'])
 programs.append(dict(profile,counts=counts,first_contradiction=first,graph=graph))
write(output/'result.json',dict(format='dnacalc-duration-geometric-forms/1',complete=True,rows=len(rows),programs=programs,survivors=[p for p in programs if p['first_contradiction']is None],
 limits='Finite fixed stored arithmetic trees with public positive integer POWER as a conditional leaf. All864 DURATION observations were known before this hypothesis. No holdout or private power equivalence claimed; labels may duplicate computations. No product change.',
 input_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in(source,output/'questions.json',output/'powers.json',Path(__file__),root/'erfc-plateau-reviewed/native.so')}))
zero=collections.defaultdict(list)
for r in rows:
 c=r['case']
 if value(c['coupon'])==0:zero[c['years'],c['offset']].append(dict(base=c['base'],answer=r['answer']))
unequal=[dict(years=k[0],offset=k[1],values=v)for k,v in zero.items()if len({r['answer']['bits']for r in v})>1]
write(output/'zero-coupon-yield-mapping.json',dict(format='dnacalc-duration-zero-yield-mapping/1',complete=True,groups=len(zero),unequal_groups=len(unequal),examples=unequal[:12],source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
 limits='Different yields can change the published duration even for zero coupons; these are recorded floating results, not mathematical yield sensitivity or an identified private discount routine.'))
print(json.dumps(dict(rows=len(rows),profiles=len(programs),survivors=sum(p['first_contradiction']is None for p in programs),zero_coupon_groups=len(zero),unequal_zero_coupon_groups=len(unequal))),flush=True)
