"""Replay every complete geometric-tree refutation with independent rational arithmetic."""
from pathlib import Path
import sys,json,collections,hashlib
research=Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research');sys.path.insert(0,str(research/'checker'));sys.path.insert(0,str(research))
from x87 import Exact,published_bits
from racer.fingerprint import bits,value
root=Path('/home/ubuntu/codex-runs/r35');source=root/'duration-geometric-forms/result.json';d=json.loads(source.read_text());observations=json.loads((root/'duration-settlement-mapping/observations.json').read_text())['records'];powers=json.loads((root/'duration-geometric-forms/powers.json').read_text())['records'];powers={(p['base'],p['n']):p['answer']for p in powers};check=Exact(None);checked=0
for program in d['programs']:
 first=program['first_contradiction'];assert first is not None
 row=observations[first['index']];c,f=row['case'],row['factors'];power=powers[c['base'],f['COUPNUM']['bits']]
 inputs=[int(x,16)for x in(c['coupon'],c['yield_bits'],bits(2.),f['COUPDAYBS']['bits'],f['COUPDAYS']['bits'],f['COUPNUM']['bits'],power['bits'])]
 got=f'{published_bits(check.graph(program["graph"],inputs,0x133f,1,inner_cw=0x123f)[:10]):016x}'
 assert got==first['prediction']and got!=row['answer']['bits'];checked+=1
app=[json.loads(s)for s in(root/'duration-settlement-app-outputs.jsonl').read_text().splitlines()];assert len(app)==len(observations)
counts=collections.Counter()
for i,(row,prediction)in enumerate(zip(observations,app)):
 assert prediction['id']==str(i)
 expected_args=['0x'+a for a in(bits(float(row['case']['settlement'])),bits(float(row['case']['maturity'])),row['case']['coupon'],row['case']['yield_bits'],bits(2.),bits(0.))]
 assert prediction['args']==expected_args
 good=prediction['calc_func_prediction']=='0x'+row['answer']['bits'];counts['rows']+=1;counts['matched']+=good;counts['failed']+=not good
 group='zero_coupon'if value(row['case']['coupon'])==0 else'positive_coupon';counts[group+'_rows']+=1;counts[group+'_matched']+=good
result=dict(complete=True,exact_rational_geometric_refutations=checked,application=counts,pass_rate=counts['matched']/counts['rows'],
 input_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in(source,root/'duration-settlement-mapping/observations.json',root/'duration-geometric-forms/powers.json',root/'duration-settlement-app-inputs.json',root/'duration-settlement-app-outputs.jsonl',Path(__file__))},
 limits='All64 declared geometric-tree first contradictions replay independently. Application controls call the registered function with original typed numeric operands; no Excel output is supplied as an application operand. These864 calls are a separate cohort, not added to bank/corpus totals.')
(root/'duration-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
