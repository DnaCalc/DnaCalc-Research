"""Fixed small cancelled-rate trees on independently read discount leaves."""
import sys,json,numpy as np
from pathlib import Path
sys.path[:0]=['/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer','/home/ubuntu/projects/DnaCalc/DnaCalc-Research/checker']
from fingerprint import bits,value,write,sha
from x87_programs import Builder,Native
root=Path('/home/ubuntu/codex-runs/r35');d=json.loads((root/'cumulative-dyadic-read.json').read_text());rows=d['records'];native=Native(root/'erfc-plateau/native.so')
inputs=[]
for r in rows:
 l=value(d['logs'][(1.,3.,7.).index(r['rate'])]['bits']);e=d['exp_leaves'][bits(-r['gap']*l)]['bits']
 inputs.append([int(e,16),int(bits(r['rate']),16),int(r['payment']['bits'],16)])
inputs=np.array(inputs,dtype=np.uint64);programs=[]
for factor in ('rate','reciprocal_rate','1+rate','1+1/rate','reciprocal_1+1/rate'):
 for form in ('none','E/f*f','E*f/f','P/f*(E*f)','P*f*(E/f)','P*E/f*f','P*E*f/f'):
  g=Builder(3);one=g.one;f=1
  if factor=='reciprocal_rate':f=g.op('div',one,f)
  elif factor=='1+rate':f=g.op('add',one,f)
  elif factor.endswith('1/rate'):
   f=g.op('add',one,g.op('div',one,f))
   if factor.startswith('reciprocal'):f=g.op('div',one,f)
  if form=='none':s=g.op('mul',2,0)
  elif form=='E/f*f':s=g.op('mul',2,g.op('mul',g.op('div',0,f),f))
  elif form=='E*f/f':s=g.op('mul',2,g.op('div',g.op('mul',0,f),f))
  elif form=='P/f*(E*f)':s=g.op('mul',g.op('div',2,f),g.op('mul',0,f))
  elif form=='P*f*(E/f)':s=g.op('mul',g.op('mul',2,f),g.op('div',0,f))
  elif form=='P*E/f*f':s=g.op('mul',g.op('div',g.op('mul',2,0),f),f)
  else:s=g.op('div',g.op('mul',g.op('mul',2,0),f),f)
  graph=g.graph(s,s)
  for model,cw,mask in [('strict',0x123f,(1<<g.sites)-1),('stored_pc64',0x133f,(1<<g.sites)-1),('resident_pc64',0x133f,0)]:
   out=native.grid(graph,inputs,cw,mask)[:,0];first=None
   for i,(r,a)in enumerate(zip(rows,out)):
    if int(a)!=int(r['principal']['bits'],16):first=dict(index=i,original=r,prediction=f'{int(a):016x}');break
   programs.append(dict(factor=factor,form=form,model=model,first_contradiction=first))
result=dict(complete=True,programs=programs,survivors=[p for p in programs if p['first_contradiction']is None],source_bindings={str(p):sha(p)for p in(Path(__file__),root/'cumulative-dyadic-read.json')},limits='Fixed cancelled-factor expressions suggested by exact power-of-two PMT scaling. Public EXP and LN remain conditional. No tree selected by a match count; fresh answers required for any survivor.')
write(root/'cumulative-cancel-trees.json',result);print('programs',len(programs),'survivors',result['survivors'],flush=True)
