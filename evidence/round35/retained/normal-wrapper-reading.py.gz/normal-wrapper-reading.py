"""Read confidence and lognormal-inverse wrappers using public quantile leaves."""
import sys,json,itertools,math,random
from pathlib import Path
from fractions import Fraction as Q
sys.path[:0]=['/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer','/home/ubuntu/projects/DnaCalc/DnaCalc-Research/checker']
from fingerprint import CachedService,load_service,bits,value,write,sha
sys.path.insert(0,"/home/ubuntu/projects/DnaCalc/DnaCalc-Research")
from racer.bessel import operation
from exact import BINARY64 as B
root=Path('/home/ubuntu/codex-runs/r35');client,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');service=CachedService(client.Client(timeout=180),root/'cache');rng=random.Random(35106)
confidence=[dict(alpha=.05,sigma=2.5,n=50.)]
confidence += [dict(alpha=alpha,sigma=sigma,n=n)for alpha,sigma,n in itertools.product((.013,.17,.375),(1.3,2.75),(7.,51.,129.5))]
lognormal=[dict(p=.04,mean=3.5,sigma=1.2)]
lognormal += [dict(p=p,mean=m,sigma=s)for p,m,s in itertools.product((.013,.17,.375,.975),(-1.3,.1,3.25),(.7,1.75))]
quantile_queries={bits(p):[client.number(p)]for p in [v for r in confidence for v in(1-r['alpha']/2,r['alpha']/2)]+[r['p']for r in lognormal]}
zreply=service.ask_rows('NORM.S.INV',list(quantile_queries.values()));z=dict(zip(quantile_queries,zreply));sqrt=service.ask_rows('SQRT',[[client.number(math.trunc(r['n']))]for r in confidence])
if any(a['type']!='number'for a in zreply+sqrt):raise ValueError('finite primitive controls required')
profiles=[(q,form,word)for q in('upper','negative_lower')for form in('mul_div','div_mul','inner_div','reciprocal_product')for word in('strict','stored_pc64','resident_pc64')]
confidence_predictions=[]
for r,sq in zip(confidence,sqrt):
 candidates={};s=Q(r['sigma']);rootq=Q(value(sq['bits']))
 for quantile,form,word in profiles:
  zz=Q(value(z[bits(1-r['alpha']/2 if quantile=='upper'else r['alpha']/2)]['bits']))
  if quantile=='negative_lower':zz=-zz
  op=lambda k,a,b:operation(k,word,a,b)
  y=op('div',op('mul',zz,s),rootq)if form=='mul_div'else op('mul',op('div',zz,rootq),s)if form=='div_mul'else op('mul',zz,op('div',s,rootq))if form=='inner_div'else op('mul',op('div',Q(1),rootq),op('mul',zz,s))
  candidates['/'.join((quantile,form,word))]=bits(float(B.round(y)))
 confidence_predictions.append(dict(inputs=r,sqrt=sq,candidates=candidates))
normal_inv=service.ask_rows('NORM.INV',[[client.number(r[k])for k in('p','mean','sigma')]for r in lognormal])
queries={};log_predictions=[]
for r,ni in zip(lognormal,normal_inv):
 if ni['type']!='number':raise ValueError('finite affine normal expected')
 candidates={'public_NORM.INV':ni['bits']};zz=Q(value(z[bits(r['p'])]['bits']))
 for word in('strict','stored_pc64','resident_pc64'):
  y=operation('add',word,Q(r['mean']),operation('mul',word,Q(r['sigma']),zz));candidates[word]=bits(float(B.round(y)))
 for raw in candidates.values():queries.setdefault(raw,[client.number(raw)])
 log_predictions.append(dict(inputs=r,normal_inv=ni,exponents=candidates))
exp=service.ask_rows('EXP',list(queries.values()));exps=dict(zip(queries,exp))
for r in log_predictions:r['predictions']={key:exps[raw]for key,raw in r['exponents'].items()}
frozen=sha(__file__);write(root/'normal-wrapper-predictions.json',dict(confidence=confidence_predictions,lognormal=log_predictions,quantiles=z,exp=exps,receipts=service.receipts.copy(),source_sha256=frozen))
ca=service.ask_rows('CONFIDENCE.NORM',[[client.number(r[k])for k in('alpha','sigma','n')]for r in confidence]);la=service.ask_rows('LOGNORM.INV',[[client.number(r[k])for k in('p','mean','sigma')]for r in lognormal])
for r,a in zip(confidence_predictions,ca):r['answer']=a
for r,a in zip(log_predictions,la):r['answer']=a
conf_survivors=[key for key in confidence_predictions[0]['candidates']if all(r['answer']==dict(type='number',bits=r['candidates'][key])for r in confidence_predictions)]
log_survivors=[key for key in log_predictions[0]['predictions']if all(r['answer']==r['predictions'][key]for r in log_predictions)]
assert frozen==sha(__file__)
write(root/'normal-wrapper-reading.json',dict(complete=True,confidence=confidence_predictions,lognormal=log_predictions,confidence_survivors=conf_survivors,lognormal_survivors=log_survivors,receipts=service.receipts,source_sha256=frozen,
 limits='Fixed ordinary scalar controls, original public quantiles/SQRT/EXP and frozen wrapper predictions. Conditional leaves do not identify the private inverse-normal program or validate a changed product helper. Surviving word ambiguities remain undetermined.'))
print('confidence',len(ca),conf_survivors,'lognormal',len(la),log_survivors,flush=True)
