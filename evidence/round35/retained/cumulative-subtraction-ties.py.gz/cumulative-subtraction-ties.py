"""Fresh count-one controls separate subtraction words without a product ambiguity."""
import sys,json,itertools,math
from pathlib import Path
from fractions import Fraction as Q
sys.path[:0]=['/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer','/home/ubuntu/projects/DnaCalc/DnaCalc-Research/checker']
from fingerprint import CachedService,load_service,bits,value,write,sha
from exact import BINARY64 as B,EXTENDED64 as E
root=Path('/home/ubuntu/codex-runs/r35');client,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');service=CachedService(client.Client(timeout=180),root/'cache');rows=[]
for exponent,ns in [(1,(55,57,60)),(2,(28,29,30,31)),(3,(25,26,27,29)),(6,(10,12,14)),(9,(7,8,10))]:
 rate=float((1<<exponent)-1);gap=54//exponent
 for n,offset in itertools.product(ns,(-1,0,1)):
  pv=float(Q((1<<exponent)**n-1,int(rate)));pv=math.nextafter(pv,math.inf if offset>0 else 0.)if offset else pv
  period=n-gap+1;rows.append(dict(rate=rate,n=n,pv=pv,period=period,offset=offset,args=[client.number(v)for v in(rate,float(n),pv,float(period),float(period),0.)]))
# Read the two operands independently, without observing the interest result.
pmts=service.ask_rows('PMT',[[client.number(v)for v in(r['rate'],float(r['n']),r['pv'],0.,0.)]for r in rows]);principals=service.ask_rows('CUMPRINC',[r['args']for r in rows]);selected=[]
for r,p,c in zip(rows,pmts,principals):
 if any(a['type']!='number'for a in(p,c)):raise ValueError('finite subtraction operands required')
 exact=Q(value(p['bits']))-Q(value(c['bits']));strict=bits(float(B.round(exact)));stored=bits(float(B.round(E.round(exact))));r.update(payment=p,principal=c,strict=strict,stored_pc64=stored)
 if strict!=stored:selected.append(r)
if not selected:raise ValueError('no fresh subtraction discriminants')
frozen=sha(__file__);write(root/'cumulative-subtraction-tie-predictions.json',dict(all_operands=rows,selected=selected,receipts=service.receipts.copy(),source_sha256=frozen,selection='Fixed power-of-two bases and periods, three adjacent PVs; count=1. Select only from independently observed PMT/CUMPRINC operands whose exact subtraction distinguishes RN53 from RN53(RN64). No CUMIPMT answer inspected.'))
answers=service.ask_rows('CUMIPMT',[r['args']for r in selected]);counts={w:0 for w in('strict','stored_pc64')}
for r,a in zip(selected,answers):
 r['interest']=a
 for w in counts:counts[w]+=a==dict(type='number',bits=r[w])
assert frozen==sha(__file__)
write(root/'cumulative-subtraction-ties.json',dict(complete=True,rows=selected,counts=counts,receipts=service.receipts,source_sha256=frozen,
 limits='Count-one removes count-product rounding. The independent public principal/payment leaves remain conditional; this identifies the finish word on new controls and does not identify principal production.'))
print('operand rows',len(rows),'discriminants',len(selected),'counts',counts,flush=True)
