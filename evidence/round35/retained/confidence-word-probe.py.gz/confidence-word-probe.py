"""Fresh discriminants for the two surviving confidence inner-division words."""
import sys,json,itertools,math,numpy as np
from pathlib import Path
sys.path[:0]=['/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer','/home/ubuntu/projects/DnaCalc/DnaCalc-Research/checker']
from fingerprint import CachedService,load_service,bits,value,write,sha
from x87_programs import Builder,Native
root=Path('/home/ubuntu/codex-runs/r35');client,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');service=CachedService(client.Client(timeout=180),root/'cache');native=Native(root/'erfc-plateau/native.so')
pairs=list(itertools.product((.013,.05,.333),(2.,3.,17.,50.)))
z=service.ask_rows('NORM.S.INV',[[client.number(1-a/2)]for a,n in pairs]);sq=service.ask_rows('SQRT',[[client.number(n)]for a,n in pairs]);g=Builder(3);out=g.op('mul',0,g.op('div',1,2));graph=g.graph(out,out);rows=[]
for (alpha,n),zz,ss in zip(pairs,z,sq):
 count=32768;inputs=np.empty((count,3),dtype=np.uint64);inputs[:,0]=int(zz['bits'],16);inputs[:,1]=np.arange(int(bits(1.3),16),int(bits(1.3),16)+count,dtype=np.uint64);inputs[:,2]=int(ss['bits'],16)
 strict=native.grid(graph,inputs,0x123f,(1<<g.sites)-1)[:,0];stored=native.grid(graph,inputs,0x133f,(1<<g.sites)-1)[:,0]
 indexes=np.flatnonzero(strict!=stored)
 for i in indexes[:4]:rows.append(dict(alpha=bits(alpha),n=bits(n),sigma=f'{int(inputs[i,1]):016x}',z=zz,sqrt=ss,strict=f'{int(strict[i]):016x}',stored_pc64=f'{int(stored[i]):016x}',selection='whole-output word discriminant'))
 # Also keep one predeclared ordinary control per pair.
 sigma=2.75;input=np.array([[int(zz['bits'],16),int(bits(sigma),16),int(ss['bits'],16)]],dtype=np.uint64)
 rows.append(dict(alpha=bits(alpha),n=bits(n),sigma=bits(sigma),z=zz,sqrt=ss,strict=f'{int(native.grid(graph,input,0x123f,3)[0,0]):016x}',stored_pc64=f'{int(native.grid(graph,input,0x133f,3)[0,0]):016x}',selection='ordinary control'))
if not any(r['strict']!=r['stored_pc64']for r in rows):raise ValueError('no whole output separators')
frozen=sha(__file__);write(root/'confidence-word-predictions.json',dict(rows=rows,source_sha256=frozen,receipts=service.receipts.copy(),shape=graph,selection='First four native word-discriminants in32768 consecutive sigmas starting1.3 per fixed(alpha,n), plus fixed sigma2.75 controls. No confidence answer inspected before freezing predictions.'))
answers=service.ask_rows('CONFIDENCE.NORM',[[client.number(r[k])for k in('alpha','sigma','n')]for r in rows]);counts={word:0 for word in('strict','stored_pc64')}
for r,a in zip(rows,answers):
 r['answer']=a
 for word in counts:counts[word]+=a==dict(type='number',bits=r[word])
assert frozen==sha(__file__)
write(root/'confidence-word-probe.json',dict(complete=True,rows=rows,counts=counts,receipts=service.receipts,source_sha256=frozen,limits='Conditional public quantile and SQRT leaves. Separators distinguish whole strict/stored64 inner-division/multiplication programs, not their individual instructions; neither match would refute the shared-leaf/word premise. No product change on a percentage.'))
print('rows',len(rows),'discriminants',sum(r['strict']!=r['stored_pc64']for r in rows),'counts',counts,flush=True)
