"""Fixed stable geometric-span trees, using separately observed payment-core leaves."""
import sys,json,itertools
from pathlib import Path
from fractions import Fraction as Q
sys.path[:0]=['/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer','/home/ubuntu/projects/DnaCalc/DnaCalc-Research/checker','/home/ubuntu/projects/DnaCalc/DnaCalc-Research']
from bessel import operation
from exact import BINARY64 as B,binary64
from fingerprint import bits,write,sha
from racer.cumulative_projection import MODELS,validate_sum_observations
root=Path('/home/ubuntu/codex-runs/r35');docs={}
for name in ('cumulative-sums','cumulative-dyadic'):
 q=json.loads((root/name/'questions.json').read_text());a=json.loads((root/name/'answers.json').read_text());validate_sum_observations(q,a)
 parts=json.loads((root/(name+'-span-parts.json')).read_text());assert len(parts)==len(q['loans']);docs[name]=(q,a,parts)
programs=[];survivors=[]
for sign,span_leaf,association,outer,product,finish in itertools.product(('positive','negative'),('expm1','exp_minus_one'),range(3),MODELS,MODELS,MODELS):
 first=None;checked=0
 for name,(q,a,parts)in docs.items():
  for index,(r,p)in enumerate(zip(q['ranges'],a['CUMPRINC'])):
   loan=q['loans'][r['loan']];n=loan['periods'];rate=Q(loan['rate']);payment=binary64(a['PMT'][r['loan']]['bits']);read=parts[r['loan']]
   direct=payment if loan['timing']and r['start']==1 else Q(0)
   start=max(2,r['start'])if loan['timing']else r['start'];end=r['end'];length=end-start+1
   if length<=0:total=direct
   else:
    factor=operation('div',outer,payment,rate)
    if span_leaf=='expm1':span=binary64(read['span_expm1_'+sign][length-1])
    else:
     leaf=binary64(read['span_exp_positive'][length-1])if sign=='positive'else binary64(read['discounts'][n-length])
     span=operation('add',product,leaf,-Q(1))
    if sign=='negative':span=-span
    period=start if sign=='positive'else end+1
    discount=Q(1)if period==n+1 else binary64(read['discounts'][period-1])
    if association==0:total=operation('mul',finish,factor,operation('mul',product,span,discount))
    elif association==1:total=operation('mul',finish,operation('mul',product,factor,span),discount)
    else:total=operation('mul',finish,operation('mul',product,factor,discount),span)
    if direct:total=operation('add',finish,total,direct)
   got=bits(float(B.round(total)));checked+=1
   if got!=p['bits']:first=dict(source=name,index=index,request=r,expected=p,prediction=got);break
  if first:break
 profile=dict(id=len(programs),sign=sign,span_leaf=span_leaf,association=association,outer=outer,product=product,finish=finish,checked=checked,first_contradiction=first)
 if not first:survivors.append(profile)
 programs.append(profile)
result=dict(complete=True,programs=programs,survivors=survivors,source_bindings={str(p):sha(p)for p in(Path(__file__),*(root/(n+'-span-parts.json')for n in docs))},
 limits='Stable positive/negative geometric-span forms motivated by new exact normalized singleton observations. Public PMT and the known PMT logarithm/EXP/internal EXPM1 are explicit conditional leaves. These are discovery answers; no complete program is chosen by a match count. The earlier direct-exp/geometric programs remain refuted.')
write(root/'cumulative-span-models.json',result);print('programs',len(programs),'survivors',survivors,flush=True)
