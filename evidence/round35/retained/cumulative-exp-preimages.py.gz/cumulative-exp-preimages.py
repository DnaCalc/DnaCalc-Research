"""Check whether exposed singleton values are attainable from a binary64 EXP input."""
import sys,json
from pathlib import Path
from decimal import Decimal as D,localcontext
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer')
from fingerprint import CachedService,load_service,bits,value,write,sha
root=Path('/home/ubuntu/codex-runs/r35');d=json.loads((root/'cumulative-power-rate-read.json').read_text());client,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');service=CachedService(client.Client(timeout=180),root/'cache')
chosen={}
for row in d['records']:
 rate=d['selected'][row['loan']]['rate']
 if row['answer']!=row['predictions']['PMT_log']:chosen.setdefault((rate,row['gap']),row)
rows=[]
with localcontext()as ctx:
 ctx.prec=90
 for(rate,gap),row in chosen.items():
  x=float(-D(gap)*(1+D(rate)).ln());raw=int(bits(x),16)
  rows.append(dict(rate=rate,gap=gap,target=bits(-value(row['answer']['bits'])),
                   exponents=[f'{raw+i:016x}'for i in range(-4,5)]))
queries={x:[client.number(x)]for r in rows for x in r['exponents']};answers=service.ask_rows('EXP',list(queries.values()));exp=dict(zip(queries,answers))
counts={}
for row in rows:
 row['preimages']=[x for x in row['exponents']if exp[x]==dict(type='number',bits=row['target'])]
 c=counts.setdefault(str(row['rate']),dict(rows=0,with_preimage=0,without_preimage=0));c['rows']+=1;c['with_preimage']+=bool(row['preimages']);c['without_preimage']+=not row['preimages']
write(root/'cumulative-exp-preimages.json',dict(complete=True,rows=rows,counts=counts,exp_leaves=exp,receipts=service.receipts,source_sha256=sha(__file__),
 limits='Nine consecutive EXP input doubles around the mathematical exponent. A missing preimage with the target bracketed by monotone endpoint outputs refutes a binary64 input to this public EXP under the public-PMT/cancelled-rate premise; it does not uniquely identify a resident exponent or a different private exponential.'))
print(counts,flush=True)
