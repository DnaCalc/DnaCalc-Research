"""Separate every neighbouring small-rate logarithm load on fresh large gaps."""
import sys,json,math
from pathlib import Path
from decimal import Decimal as D,localcontext
from fractions import Fraction as Q
sys.path[:0]=['/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer','/home/ubuntu/projects/DnaCalc/DnaCalc-Research/checker']
from fingerprint import CachedService,load_service,bits,value,write,sha
from exact import BINARY64 as B,EXTENDED64 as E
root=Path('/home/ubuntu/codex-runs/r35');old=json.loads((root/'cumulative-log-constants.json').read_text());cs=[r['constant']for r in old['survivors']];rate=2.**-16
if len(cs)<2:raise ValueError('at least two neighbouring surviving loads required')
client,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');service=CachedService(client.Client(timeout=180),root/'cache')
selected=set();proposals=[]
for a,b in zip(cs,cs[1:]):
 points=[]
 for gap in range(60000,71001):
  if bits(math.exp(-gap*value(a)))!=bits(math.exp(-gap*value(b))):points.append(gap)
  if len(points)==4:break
 if not points:raise ValueError('no host proposal between neighbouring loads')
 selected.update(points);proposals.append(dict(lower=a,upper=b,gaps=points))
selected=sorted(selected);pmts=[];loans=[]
with localcontext()as ctx:
 ctx.prec=100;log=(D(1)+D(rate)).ln()
 for gap in selected:
  pv=float((1-(-D(gap)*log).exp())/D(rate));center=int(bits(pv),16);choices=[]
  for off in(-2,-1,0,1,2):
   p=value(f'{center+off:016x}');choices.append(dict(offset=off,pv=bits(p)));pmts.append([client.number(rate),client.number(float(gap)),client.number(p),client.number(0.),client.number(0.)])
  loans.append(dict(gap=gap,choices=choices))
answers=service.ask_rows('PMT',pmts);rows=[]
for i,l in enumerate(loans):
 for c,a in zip(l['choices'],answers[i*5:i*5+5]):c['payment']=a
 choices=[c for c in l['choices']if c['payment']==dict(type='number',bits=bits(-1.))]
 if choices:
  c=min(choices,key=lambda x:abs(x['offset']));rows.append(dict(gap=l['gap'],pv=c['pv'],args=[client.number(v)for v in(rate,float(l['gap']),value(c['pv']),1.,1.,0.)]))
if not rows:raise ValueError('no unit payment discriminants')
queries={}
for row in rows:
 row['exponents']={}
 for c in cs:
  for word in ('strict','stored_pc64'):
   product=-Q(row['gap'])*Q(value(c));raw=bits(float(B.round(E.round(product)if word=='stored_pc64'else product)))
   row['exponents'][c+'/'+word]=raw;queries.setdefault(raw,[client.number(raw)])
exp=service.ask_rows('EXP',list(queries.values()));exps=dict(zip(queries,exp))
for row in rows:row['predictions']={key:dict(type='number',bits=bits(-value(exps[x]['bits'])))for key,x in row['exponents'].items()}
for p in proposals:p['public_separators']=[r['gap']for r in rows if r['predictions'][p['lower']+'/stored_pc64']!=r['predictions'][p['upper']+'/stored_pc64']]
frozen=sha(__file__);write(root/'cumulative-log-plateau-predictions.json',dict(proposals=proposals,loans=loans,rows=rows,exp_leaves=exps,receipts=service.receipts.copy(),source_sha256=frozen,
 selection='First four host-EXP proposals per adjacent surviving load in the fixed integer gap interval60000..71000, confirmed with independently read public EXP before cumulative predictions freeze. PMT=-1 selection uses no cumulative answer.'))
observed=service.ask_rows('CUMPRINC',[r['args']for r in rows]);profiles=[]
for r,a in zip(rows,observed):r['answer']=a
for key in rows[0]['predictions']:
 first=next((dict(gap=r['gap'],answer=r['answer'],prediction=r['predictions'][key])for r in rows if r['answer']!=r['predictions'][key]),None)
 profiles.append(dict(key=key,first_contradiction=first))
assert frozen==sha(__file__)
result=dict(complete=True,rows=rows,profiles=profiles,survivors=[p for p in profiles if p['first_contradiction']is None],proposals=proposals,receipts=service.receipts,source_sha256=frozen,
 limits='Separates neighbouring loads under the declared natural-exponential and public-payment premise. All models use one whole constant and word; a fresh failure refutes that shape/premise rather than justifying another coefficient. No uniqueness beyond the considered loads/domain is claimed.')
write(root/'cumulative-log-plateau.json',result);print('rows',len(rows),'survivors',result['survivors'],'public separators',[len(p['public_separators'])for p in proposals],flush=True)
