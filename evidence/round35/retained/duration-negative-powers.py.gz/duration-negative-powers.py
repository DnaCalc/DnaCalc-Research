"""Fixed negative-POWER duration sum trees; original public leaves remain conditional."""
from pathlib import Path
from fractions import Fraction as Q
import sys,json,itertools,collections,hashlib
research=Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research');sys.path.insert(0,str(research));sys.path.insert(0,str(research/'checker'))
from racer.fingerprint import CachedService,load_service,write,bits,value
from racer.x87_programs import Builder,Native
from exact import BINARY64 as B,EXTENDED64 as E
root=Path('/home/ubuntu/codex-runs/r35');source=root/'duration-settlement-mapping/observations.json';rows=json.loads(source.read_text())['records'];output=root/'duration-negative-powers';output.mkdir(exist_ok=False)
client,_=load_service(research.parent/'DnaCalc');service=CachedService(client.Client(timeout=300),root/'cache');requests={};times={}
def div(a,b,stored):
 x=Q(a)/Q(b);return float(B.round(E.round(x)if stored else x))
for row in rows:
 c=row['case'];fac=row['factors'];a=value(fac['COUPDAYBS']['bits']);e=value(fac['COUPDAYS']['bits']);n=int(value(fac['COUPNUM']['bits']))
 for form in ('offset_strict','offset_stored64','days_strict','days_stored64'):
  ts=[]
  for k in range(n):
   stored=form.endswith('stored64')
   t=div(e-a+k*e,e,stored)if form.startswith('days')else div(e-a,e,stored)+k
   raw=bits(t);ts.append(raw);requests.setdefault((c['base'],bits(-t)),[client.number(c['base']),client.number(-t)])
  times[c['years'],c['offset'],form]=ts
profiles=[dict(time=form,words=list(w))for form in ('offset_strict','offset_stored64','days_strict','days_stored64')for w in itertools.product(('strict','stored_pc64'),repeat=6)]
write(output/'questions.json',dict(format='dnacalc-duration-negative-power-questions/1',complete=True,profiles=profiles,requests=list(requests.values()),
 sites=['weighted coupon product','discount multiplication','numerator sum','denominator sum','redemption multiplication','final ratio'],
 selection='Four predeclared time computations, negative public POWER and sequential cashflow sums. Coupon C=100*rate/f is exact for all three dyadic coupons. Redemption t*100 and final /frequency retain the previously tested strict words. Each other declared site varies independently; no candidate selected by match percentage.',
 source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
answers=service.ask_rows('POWER',list(requests.values()));powers=dict(zip(requests,answers))
if any(v.get('type')!='number'for v in answers):raise ValueError('nonnumeric negative POWER')
write(output/'powers.json',dict(format='dnacalc-duration-negative-powers/1',complete=True,records=[dict(base=k[0],exponent=k[1],answer=v)for k,v in powers.items()],receipts=service.receipts))
native=Native(root/'erfc-plateau-reviewed/native.so');programs=[]
for profile in profiles:
 wm,dm,na,da,rm,fd=profile['words'];graphs={};first=None;counts=collections.Counter()
 for n in (2,4,8):
  g=Builder(1+2*n);hundred=g.constant(bits(100.));two=g.constant(bits(2.));zero=g.constant(bits(0.));num=den=zero
  def op(kind,a,b,word):
   at=g.op(kind,a,b,store=False);g.nodes[at].update(site=0,phase=int(word=='strict'));return at
  for k in range(n):
   t,d=1+2*k,2+2*k
   num=op('add',num,op('mul',op('mul',t,0,wm),d,dm),na)
   den=op('add',den,op('mul',0,d,dm),da)
   if k+1==n:
    num=op('add',num,op('mul',op('mul',t,hundred,'strict'),d,rm),na)
    den=op('add',den,op('mul',hundred,d,rm),da)
  result=op('div',op('div',num,den,fd),two,'strict');g.sites=1;graphs[n]=g.graph(result,result)
 for i,row in enumerate(rows):
  c=row['case'];n=int(value(row['factors']['COUPNUM']['bits']));operands=[int(bits(100.*value(c['coupon'])/2.),16)]
  for t in times[c['years'],c['offset'],profile['time']]:operands.extend((int(t,16),int(powers[c['base'],bits(-value(t))]['bits'],16)))
  result=native.evaluate(graphs[n],operands,0x133f,1,inner_cw=0x123f);pred=f'{native.publish(result[:10]):016x}'
  same=pred==row['answer']['bits'];group='zero_coupon'if value(c['coupon'])==0 else'positive_coupon';counts[group+'_rows']+=1;counts[group+'_matched']+=same
  if not same and first is None:first=dict(index=i,prediction=pred,answer=row['answer'],inputs=[f'{v:016x}'for v in operands],graph=graphs[n])
 programs.append(dict(profile,counts=counts,first_contradiction=first))
write(output/'result.json',dict(format='dnacalc-duration-negative-power-sums/1',complete=True,rows=len(rows),programs=programs,survivors=[p for p in programs if p['first_contradiction']is None],
 limits='Original864 settlement answers are discovery data for these256 labelled programs. Negative public POWER is an independently measured conditional input. All declared intermediate results are stored binary64; resident sum models and other private powers remain open. No product change.',
 input_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in(source,output/'questions.json',output/'powers.json',Path(__file__),root/'erfc-plateau-reviewed/native.so')}))
print(json.dumps(dict(rows=len(rows),power_questions=len(requests),profiles=len(programs),survivors=sum(p['first_contradiction']is None for p in programs))),flush=True)
