"""Fixed natural-exponential residency hypotheses on exposed singleton controls."""
import sys,json
from pathlib import Path
from fractions import Fraction as Q
from decimal import Decimal as D,localcontext
sys.path[:0]=['/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer','/home/ubuntu/projects/DnaCalc/DnaCalc-Research/checker']
from fingerprint import bits,value,write,sha
from exact import BINARY64 as B,EXTENDED64 as E
root=Path('/home/ubuntu/codex-runs/r35');d=json.loads((root/'cumulative-power-rate-read.json').read_text());groups={}
for r in d['records']:groups[d['selected'][r['loan']]['rate'],r['gap']]=r
programs=[]
with localcontext()as ctx:
 ctx.prec=100
 for logarithm in ('PMT_log','public_LN_base','rounded_math_log53','rounded_math_log64'):
  for exponent_word in ('binary64','extended64'):
   for result_word in ('binary64','extended64_then_binary64'):
    first=None;checked=0
    for(rate,gap),r in groups.items():
     if logarithm.startswith('rounded_math'):
      l=Q((D(1)+D(rate)).ln());l=B.round(l)if logarithm.endswith('53')else E.round(l)
     else:l=-Q(value(r['exponents'][logarithm]))/gap
     x=-gap*l;x=B.round(x)if exponent_word=='binary64'else E.round(x)
     e=Q((D(x.numerator)/D(x.denominator)).exp())
     pred=B.round(e if result_word=='binary64'else E.round(e));raw=bits(-float(pred));checked+=1
     if raw!=r['answer']['bits']:first=dict(rate=rate,gap=gap,expected=r['answer'],prediction=raw);break
    programs.append(dict(logarithm=logarithm,exponent_word=exponent_word,result_word=result_word,checked=checked,first_contradiction=first))
result=dict(complete=True,programs=programs,survivors=[p for p in programs if p['first_contradiction']is None],source_bindings={str(p):sha(p)for p in(Path(__file__),root/'cumulative-power-rate-read.json')},
 limits='Exploratory100-digit Decimal mathematical exponential, with explicit53/64-bit logarithm/exponent/result stores. Public stored-exponent rows are only controls; no claimed private instruction, CPU equivalence or exact numerical proof. A survivor would require directed MPFR confirmation and fresh service answers before adoption.')
write(root/'cumulative-resident-exp.json',result);print('programs',len(programs),'survivors',result['survivors'],flush=True)
