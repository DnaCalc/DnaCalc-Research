import sys,json,math
from pathlib import Path
from decimal import Decimal as D,localcontext
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer')
from fingerprint import CachedService,load_service,bits,value,write,sha
root=Path('/home/ubuntu/codex-runs/r35');client,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc')
s=CachedService(client.Client(timeout=180),root/'cache')
records=json.loads((root/'yield-dense.json').read_text())['records']
template=json.loads((root/'yield-map/result.json').read_text())['cases'][0]['args']
def kind(price,answer):
 if answer['type']!='number':raise ValueError('numeric control became an error')
 with localcontext()as c:
  c.prec=80;exact=(D(100)/D(price)).sqrt()-1
  error=D(value(answer['bits']))-exact
 return abs(error)<D('1e-14'),str(error)
edges=[]
rs=[r for r in records if r['n']==2]
for left,right in zip(rs,rs[1:]):
 if 'error'not in left or 'error'not in right:continue
 if (abs(D(left['error']))<D('1e-14'))==(abs(D(right['error']))<D('1e-14')):continue
 if max(abs(D(left['error'])),abs(D(right['error'])))<D('8e-11'):continue
 edges.append(dict(low=int(bits(left['price']),16),high=int(bits(right['price']),16),
   low_answer=left['answer'],high_answer=right['answer'],low_kind=abs(D(left['error']))<D('1e-14')))
 if len(edges)==8:break
write(root/'yield-edge-selection.json',dict(edges=edges,source_sha256=sha(__file__),purpose='Bisect observed transitions from fully converged to large below-root error, not a fit to a match count.'))
for iteration in range(60):
 active=[e for e in edges if e['high']-e['low']>1]
 if not active:break
 mids=[(e['low']+e['high'])//2 for e in active]
 asks=[]
 for m in mids:
  row=template.copy();row[3]=client.number(f'{m:016x}');asks.append(row)
 answers=s.ask('YIELD',asks)['rows']
 for e,m,a in zip(active,mids,answers):
  k,err=kind(value(f'{m:016x}'),a)
  if k==e['low_kind']:e['low']=m;e['low_answer']=a
  else:e['high']=m;e['high_answer']=a
for e in edges:
 e['low_error']=kind(value(f"{e['low']:016x}"),e['low_answer'])[1]
 e['high_error']=kind(value(f"{e['high']:016x}"),e['high_answer'])[1]
 e['jump']=value(e['high_answer']['bits'])-value(e['low_answer']['bits'])
 e['low']=f"{e['low']:016x}";e['high']=f"{e['high']:016x}"
 print(e,flush=True)
write(root/'yield-edges.json',dict(format='dnacalc-yield-edges/1',complete=True,edges=edges,receipts=s.receipts,source_sha256=sha(__file__)))
