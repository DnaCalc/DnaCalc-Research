"""Test division by separately read positive growth instead of negative EXP."""
import sys,json
from pathlib import Path
from fractions import Fraction as Q
sys.path[:0]=['/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer','/home/ubuntu/projects/DnaCalc/DnaCalc-Research/checker']
from fingerprint import CachedService,load_service,bits,value,write,sha
from exact import BINARY64 as B,EXTENDED64 as E
root=Path('/home/ubuntu/codex-runs/r35');d=json.loads((root/'cumulative-power-rate-read.json').read_text());client,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');service=CachedService(client.Client(timeout=180),root/'cache')
queries={bits(-value(x)):[client.number(bits(-value(x)))]for r in d['records']for x in r['exponents'].values()};answers=service.ask_rows('EXP',list(queries.values()));exps=dict(zip(queries,answers));programs=[]
for logarithm in d['records'][0]['exponents']:
 for word in ('strict','stored_pc64'):
  first=None
  for index,r in enumerate(d['records']):
   x=bits(-value(r['exponents'][logarithm]));a=exps[x]
   if a['type']!='number':raise ValueError('positive growth should remain finite')
   quotient=-Q(1)/Q(value(a['bits']));prediction=bits(float(B.round(quotient if word=='strict'else E.round(quotient))))
   if prediction!=r['answer']['bits']:first=dict(index=index,original=r,growth=a,prediction=prediction);break
  programs.append(dict(logarithm=logarithm,word=word,first_contradiction=first))
write(root/'cumulative-positive-growth.json',dict(complete=True,programs=programs,survivors=[p for p in programs if p['first_contradiction']is None],exp_leaves=exps,receipts=service.receipts,
 source_bindings={str(p):sha(p)for p in(Path(__file__),root/'cumulative-power-rate-read.json')},limits='Fixed positive-growth division counterpart to the refuted negative-EXP singleton premise. Independent public positive EXP leaves, no fitted coefficients or per-row selector. Discovery; no summation or complete cumulative implementation claimed.'))
print('programs',len(programs),'survivors',[p for p in programs if p['first_contradiction']is None],flush=True)
