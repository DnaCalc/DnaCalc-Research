"""Fixed15-digit extraction loops with standard neighbouring power-of-ten loads."""
from pathlib import Path
from fractions import Fraction as Q
import sys,json,math,itertools,hashlib
research=Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research');sys.path.insert(0,str(research));sys.path.insert(0,str(research/'checker'))
from racer.fingerprint import value,write
from exact import BINARY64 as B,EXTENDED64 as E,exponent_of,two
root=Path('/home/ubuntu/codex-runs/r35');source=root/'general-midpoint-mapping/observations.json';data=json.loads(source.read_text());rows=[]
for c,answer in zip(data['cases'],data['answers']['CONCATENATE']):
 assert answer['type']=='text';x=abs(Q(value(c['bits'])));e=math.floor(math.log10(float(x)));unit=Q(10)**(e-14)
 assert Q(10)**e<=x<Q(10)**(e+1)
 target=abs(Q(answer['value']))/unit;assert target.denominator==1
 rows.append((x,e,int(target)))
profiles=[dict(normalize=op,coefficient_precision=p,coefficient_step=step,word=word,tie=tie)for op in('mul','div')for p in(53,64)for step in(-1,0,1)for word in('strict','stored_pc64','resident_pc64')for tie in('up','down','even')]
# These standard power tables and fixed extraction loops are chosen before evaluating profiles.
result=[]
for profile in profiles:
 def rounded(x):
  if profile['word']=='strict':return B.round(x)
  return B.round(E.round(x))if profile['word']=='stored_pc64'else E.round(x)
 table={}
 for e in set(e for _,e,_ in rows):
  exact=Q(10)**(-e if profile['normalize']=='mul'else e);base=(B if profile['coefficient_precision']==53 else E).round(exact)
  table[e]=base+profile['coefficient_step']*two(exponent_of(base)-(profile['coefficient_precision']-1))
 first=None;checked=0
 for i,(x,e,target)in enumerate(rows):
  a=rounded(x*table[e]if profile['normalize']=='mul'else x/table[e]);n=0
  for _ in range(15):
   digit=math.floor(a);n=10*n+digit;a=rounded(rounded(a-digit)*10)
  up=a>5 or(a==5 and(profile['tie']=='up'or(profile['tie']=='even'and n%2)))
  got=n+int(up);checked+=1
  if got!=target:first=dict(index=i,case=data['cases'][i],predicted_digits=str(got),expected_digits=str(target),residue=str(a));break
 result.append(dict(profile,checked=checked,first_contradiction=first))
write(root/'general-digit-loops-v2.json',dict(format='dnacalc-general-digit-loops/1',complete=True,rows=len(rows),programs=result,survivors=[p for p in result if p['first_contradiction']is None],
 limits='Fixed15-digit normalization/extraction programs with standard RN53/RN64 power-of-ten loads and their immediate neighbours. All1935 answers were discovery data for these108 labelled programs. No all-constant recovery, other coefficient tables, private normalizer or universal conversion-family refutation claimed. No implementation change.',
 input_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in(source,Path(__file__),research/'checker/exact.py')}))
print(json.dumps(dict(rows=len(rows),profiles=len(result),survivors=sum(p['first_contradiction']is None for p in result))),flush=True)
