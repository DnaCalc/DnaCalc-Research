"""Integer-count product ties isolate the cumulative-interest finish."""
import sys,json,math
from pathlib import Path
from fractions import Fraction as Q
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer')
from fingerprint import CachedService,load_service,bits,value,write,sha
from exact import operation,binary64
root=Path('/home/ubuntu/codex-runs/r35');client,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc')
s=CachedService(client.Client(timeout=180),root/'cache')
loans=[]
for rate in (2.**-14,.0001,.0003):
 for pv in (1.,math.nextafter(1000.,math.inf),1234.56789,math.nextafter(1.,0.)):
  for timing in (0.,1.):loans.append(dict(rate=rate,n=16384.,pv=pv,timing=timing))
pays=s.ask_rows('PMT',[[client.number(l[k])for k in('rate','n','pv')]+[client.number(0.),client.number(l['timing'])]for l in loans])
def rounded_integer(p,precision):
 shift=p.bit_length()-precision
 if shift<=0:return p
 q,r=divmod(p,1<<shift);half=1<<(shift-1)
 return (q+(r>half or r==half and q&1))<<shift
rows=[]
for l,pay in zip(loans,pays):
 if pay['type']!='number':raise ValueError('loan PMT must calculate')
 raw=int(pay['bits'],16);m=(raw&((1<<52)-1))+(1<<52);counts=[]
 for count in range(2049,8192):
  p=m*count
  if rounded_integer(p,53)!=rounded_integer(rounded_integer(p,64),53):counts.append(count)
  if len(counts)==3:break
 for count in counts:
  start=2 if l['timing']else 1;end=start+count-1
  rows.append(dict(loan=l,payment=pay,start=start,end=end,count=count,args=[client.number(x)for x in(l['rate'],l['n'],l['pv'],float(start),float(end),l['timing'])]))
write(root/'cumulative-long-questions.json',dict(rows=rows,receipts=s.receipts.copy(),source_sha256=sha(__file__),selection='Counts selected only for strict versus stored-PC64 product separation on an independently observed PMT; no cumulative answer inspected.'))
answers={name:s.ask_rows(name,[r['args']for r in rows],chunk_size=100)for name in('CUMPRINC','CUMIPMT')}
records=[];counts={}
for row,p,i in zip(rows,answers['CUMPRINC'],answers['CUMIPMT']):
 if p['type']!=i['type']or p['type']!='number':raise ValueError('cumulative controls must calculate')
 predictions={}
 for model in ('strict','stored_pc64','resident_pc64'):
  total=operation(row['count'],binary64(row['payment']['bits']),'mul',model)
  out=operation(total,-binary64(p['bits']),'add','strict')
  predictions[model]=bits(float(out));counts[model]=counts.get(model,0)+(predictions[model]==i['bits'])
 records.append(dict(row,principal=p,interest=i,predictions=predictions))
write(root/'cumulative-long-finish.json',dict(format='dnacalc-cumulative-long-finish/1',complete=True,records=records,counts=counts,receipts=s.receipts,source_sha256=sha(__file__),limits='Product-word discrimination conditioned on public PMT and adjusted public CUMPRINC as the stored finish operands. No principal producer or summation structure identified.'))
print(len(rows),counts,flush=True)
