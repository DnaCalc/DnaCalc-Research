"""Independent rational replay of the frozen R35 polynomial neighbour questions."""
from pathlib import Path
import sys,json,copy,hashlib
root=Path('/home/ubuntu/codex-runs/r35');research=Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
sys.path[:0]=[str(research/'racer'),str(research/'checker')]
from x87 import Exact,published_bits
from fingerprint import integer_gamma_polynomial_graph
checker=Exact(None);counts={};bindings={}
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def evaluate(graph,inputs):
 return f'{published_bits(checker.graph(graph,[int(x,16)for x in inputs],0x133f,(1<<graph["sites"])-1)[:10]):016x}'
for name in ('integer-gamma-coefficients-fresh.json','integer-gamma-shape20-holdout.json'):
 p=root/name;d=json.loads(p.read_text());bindings[str(p)]=digest(p);tested=0;neighbors=0
 observed={(r['count'],r['mean']):r['answers']['POISSON']['bits']for r in d['records']}
 for row in d['records']:
  if row['scope']!='interior':continue
  graph=integer_gamma_polynomial_graph(row['count'],'factorial_coefficients')
  got=evaluate(graph,[row['mean'],row['public_exp']['bits']]);assert got==row['answers']['POISSON']['bits'];tested+=1
 for c in d['coefficient_probes']:
  for neighbor in c['neighbors']:
   for row in neighbor['examples']:
    graph=integer_gamma_polynomial_graph(c['count'],'factorial_coefficients')
    got=evaluate(graph,row['inputs']);assert got==row['baseline']==observed[c['count'],row['inputs'][0]]
    graph['nodes'][graph['coefficient_nodes'][c['name']]]['bits']=neighbor['bits']
    got=evaluate(graph,row['inputs']);assert got==row['alternative']and got!=row['baseline'];neighbors+=1
 counts[name]=dict(fresh_rows=tested,neighbor_examples=neighbors)
p=root/'erfc-plateau-final/result.json';d=json.loads(p.read_text());shape=json.loads((p.parent/'shape.json').read_text());bindings[str(p)]=digest(p);bindings[str(p.parent/'shape.json')]=digest(p.parent/'shape.json')
observed={r['input']:r['answer']['bits']for r in d['observations']};tested=0
for c in d['fresh_comparison']:
 for neighbor in c['neighbors']:
  for row in neighbor['examples']:
   graph=copy.deepcopy(shape['graph']);got=evaluate(graph,row['inputs']);assert got==row['baseline']==observed[row['inputs'][0]]
   graph['nodes'][shape['constants'][c['name']]]['bits']=neighbor['bits'];got=evaluate(graph,row['inputs'])
   assert got==row['alternative']and got!=row['baseline'];tested+=1
counts['erfc']=dict(original_observations=len(observed),neighbor_examples=tested)
for p in (Path(__file__),research/'racer/fingerprint.py',research/'checker/x87.py',research/'checker/exact.py'):
 bindings[str(p)]=digest(p)
result=dict(complete=True,counts=counts,operation_counts=checker.counts,source_bindings=bindings,
 limits='Independent rational arithmetic interprets the frozen shape graphs. Measured EXP remains a conditional binary64 input. Neighbours move one at a time; no joint uniqueness claim. This verifies frozen questions and predictions, not an inverse kernel or the parked product change.')
(root/'independent-stage-arithmetic.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(counts),flush=True)
