"""Read normalized singleton leaves where the observed PMT is a power of two."""
import sys,json,struct,collections,math
from fractions import Fraction as Q
from pathlib import Path
sys.path[:0]=['/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer','/home/ubuntu/projects/DnaCalc/DnaCalc-Research/checker']
from fingerprint import CachedService,load_service,bits,value,write,sha
from exact import EXTENDED64 as E,BINARY64 as B
root=Path('/home/ubuntu/codex-runs/r35');source=root/'cumulative-dyadic';q=json.loads((source/'questions.json').read_text());a=json.loads((source/'answers.json').read_text())
client,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');service=CachedService(client.Client(timeout=180),root/'cache')
records=[];groups=collections.defaultdict(set);excluded=collections.Counter()
for r,p in zip(q['ranges'],a['CUMPRINC']):
 if r['start']!=r['end']:continue
 loan=q['loans'][r['loan']];n=loan['periods'];period=r['start'];payment=a['PMT'][r['loan']]
 if p['type']!='number'or payment['type']!='number':raise ValueError('finite controls required')
 v=value(payment['bits']);m,e=math.frexp(abs(v))
 if m!=.5:excluded['PMT_not_power_of_two']+=1;continue
 if loan['timing']and period==1:excluded['first_beginning_payment']+=1;continue
 leaf=Q(value(p['bits']))/Q(v)
 if B.round(leaf)!=leaf:raise ValueError('power-of-two scaling should be exact')
 raw=bits(float(leaf));g=n-period+1;key=(loan['rate'],g)
 groups[key].add(raw)
 records.append(dict(loan=r['loan'],rate=loan['rate'],n=n,period=period,timing=loan['timing'],gap=g,private_leaf=raw,payment=payment,principal=p))
logs=service.ask_rows('LN',[[client.number(b)]for b in(2.,4.,8.)]);queries={}
for rate,log in zip((1.,3.,7.),logs):
 if log['type']!='number':raise ValueError('finite LN required')
 for gap in range(1,81):
  for word in ('strict','stored_pc64','resident_pc64'):
   product=-Q(gap)*Q(value(log['bits']));exponent=bits(float(B.round(E.round(product)if word!='strict'else product)))
   queries.setdefault(exponent,[client.number(exponent)])
exp=service.ask_rows('EXP',list(queries.values()));expmap=dict(zip(queries,exp))
programs=[]
for association in ('gap_product','two_products_difference'):
 for word in ('strict','stored_pc64'):
  c=collections.Counter();first=None
  for r in records:
   log=Q(value(logs[(1.,3.,7.).index(r['rate'])]['bits']));rn=lambda x:B.round(E.round(x)if word=='stored_pc64'else x)
   x=rn(-r['gap']*log)if association=='gap_product'else rn(rn((r['period']-1)*log)-rn(r['n']*log))
   raw=bits(float(x))
   if raw not in expmap:queries.setdefault(raw,[client.number(raw)]);continue
   got=expmap[raw];ok=got==dict(type='number',bits=r['private_leaf']);c['checked']+=1;c['equal']+=ok
   if not ok and first is None:first=dict(original=r,exponent=raw,public_exp=got)
  programs.append(dict(association=association,word=word,counts=c,first_contradiction=first))
# A second independent EXP batch completes the non-collapsed associations.
missing=[raw for raw in queries if raw not in expmap]
if missing:expmap.update(zip(missing,service.ask_rows('EXP',[queries[raw]for raw in missing])))
for p in programs:
 c=collections.Counter();first=None
 for r in records:
  log=Q(value(logs[(1.,3.,7.).index(r['rate'])]['bits']));rn=lambda x:B.round(E.round(x)if p['word']=='stored_pc64'else x)
  x=rn(-r['gap']*log)if p['association']=='gap_product'else rn(rn((r['period']-1)*log)-rn(r['n']*log))
  got=expmap[bits(float(x))];ok=got==dict(type='number',bits=r['private_leaf']);c['checked']+=1;c['equal']+=ok
  if not ok and first is None:first=dict(original=r,exponent=bits(float(x)),public_exp=got)
 p.update(counts=c,first_contradiction=first)
result=dict(format='dnacalc-cumulative-dyadic-singleton-reading/1',complete=True,records=records,programs=programs,
 groups=[dict(rate=k[0],gap=k[1],leaves=sorted(v))for k,v in sorted(groups.items())],excluded=excluded,logs=logs,exp_leaves=expmap,receipts=service.receipts,
 source_bindings={str(p):sha(p)for p in(Path(__file__),source/'questions.json',source/'answers.json')},
 limits='An observed PMT with exactly one significand bit makes scaling its singleton principal an exact binary64 operation. These are observable normalized leaves, not assumed EXP results. Public LN and EXP are independent conditional helper readings. Cross-loan equal gaps test collapsing the exponent; no shared term or summation program is assumed.')
write(root/'cumulative-dyadic-read.json',result)
print('singletons',len(records),'equal-gap groups',len(groups),'groups with different leaves',sum(len(v)>1 for v in groups.values()),flush=True)
print([(p['association'],p['word'],dict(p['counts']))for p in programs],flush=True)
for g,v in groups.items():
 if len(v)>1:print('first different group',g,sorted(v));break
