"""Map15-digit number-to-text midpoint decisions; no conversion program is inferred."""
from pathlib import Path
from fractions import Fraction as Q
import sys,json,math,random,collections,hashlib
research=Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research');sys.path.insert(0,str(research))
from racer.fingerprint import CachedService,load_service,write,bits,value,CachedRefusal
root=Path('/home/ubuntu/codex-runs/r35');output=root/'general-midpoint-mapping';output.mkdir(exist_ok=False)
client,_=load_service(research.parent/'DnaCalc');service=CachedService(client.Client(timeout=300),root/'cache');rng=random.Random(35);cases=[]
for exponent in (11,12,13,14,15):
 d=max(0,14-exponent);factor=5**d;unit=Q(10)**(exponent-14);seen=set();attempts=0
 while len(seen)<128:
  attempts+=1
  if attempts>100000:raise ValueError('unable to generate bounded exact midpoint population')
  low=(2*10**14+1+factor-1)//factor;high=(2*10**15-1)//factor
  k=2*rng.randrange((low+1)//2,(high+1)//2)+1;n=(factor*k-1)//2
  if not 10**14<=n<10**15 or n in seen:continue
  exact=(Q(n)+Q(1,2))*unit;x=float(exact)
  if Q(x)!=exact:continue
  seen.add(n)
  for step in (-1,0,1):
   v=math.nextafter(x,-math.inf)if step<0 else math.nextafter(x,math.inf)if step>0 else x
   cases.append(dict(scope='exact_midpoint_window',exponent=exponent,n=str(n),unit=str(unit),step=step,bits=bits(v)))
for x in(5758361573115.375,521310271410497.5,-6278515587045.875,543212677140.0625,5.248519552626765e-6):
 for step in(-1,0,1):
  v=math.nextafter(x,-math.inf)if step<0 else math.nextafter(x,math.inf)if step>0 else x
  cases.append(dict(scope='known_corpus_control',step=step,bits=bits(v)))
write(output/'questions.json',dict(format='dnacalc-general-midpoint-questions/1',complete=True,seed=35,cases=cases,
 selection='Five decimal exponent regions,128 exact15-digit midpoints per region, immediate predecessor/midpoint/successor. Five existing corpus controls have their own separate scope. Exact representability is checked before asking. No outputs used to choose inputs.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
answers={};refusals=[]
for function in ('CONCATENATE','TEXT'):
 args=[[client.number(c['bits'])]+([client.text('General')]if function=='TEXT'else[])for c in cases]
 try:answers[function]=service.ask_rows(function,args)
 except(RuntimeError,CachedRefusal)as error:refusals.append(dict(function=function,error=str(error)))
write(output/'observations.json',dict(format='dnacalc-general-midpoint-observations/1',complete=True,cases=cases,answers=answers,refusals=refusals,receipts=service.receipts))
counts=collections.Counter();decisions=[]
for i,c in enumerate(cases):
 if c['scope']!='exact_midpoint_window':continue
 n=int(c['n']);unit=Q(c['unit']);record=dict(case=c,answers={})
 for function,rows in answers.items():
  answer=rows[i];decision='other';text=answer.get('value')if answer.get('type')=='text'else None
  if text is not None:
   try:q=Q(text);decision='lower'if q==n*unit else'upper'if q==(n+1)*unit else'other'
   except(ValueError,ZeroDivisionError):pass
  key=f'{function}:e{c["exponent"]}:step{c["step"]}:{decision}';counts[key]+=1;record['answers'][function]=dict(answer=answer,decision=decision)
 decisions.append(record)
alias_exact=sum(answers['CONCATENATE'][i]==answers['TEXT'][i]for i in range(len(cases)))if len(answers)==2 else None
write(output/'result.json',dict(format='dnacalc-general-midpoint-mapping/1',complete=True,rows=len(cases),counts=counts,alias_exact=alias_exact,records=decisions,
 limits='A mapping of original scalar number-to-text answers. Midpoint decisions do not identify scaling constants, a conversion routine or a tolerance. TEXT and CONCATENATE aliases are compared separately; no model is chosen by match count. Known corpus controls are excluded from random midpoint totals.',
 input_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in(output/'questions.json',output/'observations.json',Path(__file__))}))
print(json.dumps(dict(rows=len(cases),answered_functions=list(answers),refusals=len(refusals),alias_exact=alias_exact,counts=counts)),flush=True)
