"""Recur the inner discount or rate-discount before the final payment quotient."""
import sys,json,itertools
from pathlib import Path
from fractions import Fraction as Q
sys.path[:0]=['/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer','/home/ubuntu/projects/DnaCalc/DnaCalc-Research/checker','/home/ubuntu/projects/DnaCalc/DnaCalc-Research']
from bessel import operation
from exact import BINARY64 as B,binary64
from fingerprint import bits,write,sha
from racer.cumulative_projection import MODELS,validate_sum_observations
root=Path('/home/ubuntu/codex-runs/r35');docs={}
for name in ('cumulative-sums','cumulative-dyadic'):
 q=json.loads((root/name/'questions.json').read_text());a=json.loads((root/name/'answers.json').read_text());validate_sum_observations(q,a)
 parts=json.loads((root/(name+'-parts.json')).read_text());docs[name]=(q,a,parts)
programs=[];survivors=[]
for direction,kind,frame,recurrence,summation in itertools.product(('forward','reverse'),('discount','rate_discount'),MODELS,MODELS,MODELS):
 first=None;checked=0
 for name,(q,a,parts)in docs.items():
  for index,(r,p)in enumerate(zip(q['ranges'],a['CUMPRINC'])):
   loan=q['loans'][r['loan']];rate=Q(loan['rate']);base=B.round(1+rate);payment=binary64(a['PMT'][r['loan']]['bits']);factor=operation('div',frame,payment,rate)
   direct=payment if loan['timing']and r['start']==1 else Q(0)
   start=max(2,r['start'])if loan['timing']else r['start'];end=r['end'];total=Q(0)
   if start<=end:
    initial=start if direction=='forward'else end;state=binary64(parts[r['loan']]['discounts'][initial-1])
    if kind=='rate_discount':state=operation('mul',frame,rate,state)
    for k in range(end-start+1):
     term=operation('mul',frame,rate,state)if kind=='discount'else state
     total=operation('add',summation,total,term)
     if k<end-start:state=operation('mul'if direction=='forward'else'div',recurrence,state,base)
    total=operation('mul',frame,factor,total)
   if direct:total=operation('add',frame,total,direct)
   got=bits(float(B.round(total)));checked+=1
   if got!=p['bits']:first=dict(source=name,index=index,request=r,expected=p,prediction=got);break
  if first:break
 profile=dict(id=len(programs),direction=direction,kind=kind,frame=frame,recurrence=recurrence,summation=summation,checked=checked,first_contradiction=first)
 if not first:survivors.append(profile)
 programs.append(profile)
write(root/'cumulative-inner-recurrence.json',dict(complete=True,programs=programs,survivors=survivors,
 source_bindings={str(p):sha(p)for p in(Path(__file__),*(root/(n+'-parts.json')for n in docs))},
 limits='Unlike the refuted principal recurrences, the recurrence here acts on the inner discount or rate-discount, followed by a separate payment/rate factor after summation. This fixed structure follows the new exact normalized singleton cancellation. Public PMT, known PMT logarithm and EXP are conditional. No earlier refutation is revoked; fresh answers required for any survivor.'))
print('programs',len(programs),'survivors',survivors,flush=True)
