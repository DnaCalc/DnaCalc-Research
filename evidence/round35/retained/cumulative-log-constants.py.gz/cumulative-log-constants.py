"""Fit whole logarithm loads to all exposed cumulative power-rate singleton leaves."""
import sys,json,struct
from pathlib import Path
from decimal import Decimal as D,localcontext
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer')
from fingerprint import CachedService,load_service,bits,value,write,sha
root=Path('/home/ubuntu/codex-runs/r35');d=json.loads((root/'cumulative-power-rate-read.json').read_text());client,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');service=CachedService(client.Client(timeout=180),root/'cache')
groups={}
for r in d['records']:
 rate=d['selected'][r['loan']]['rate'];key=(rate,r['gap']);got=bits(-value(r['answer']['bits']))
 if key in groups and groups[key]!=got:raise ValueError('inconsistent equal-gap reading')
 groups[key]=got
constants={};queries={}
with localcontext()as ctx:
 ctx.prec=90
 for rate,gap in groups:
  if rate in constants:continue
  center=int(bits(float((D(1)+D(rate)).ln())),16)
  constants[rate]=[f'{center+i:016x}'for i in range(-4,5)]
for(rate,gap),got in groups.items():
 for raw in constants[rate]:
  exponent=bits(-gap*value(raw));queries.setdefault(exponent,[client.number(exponent)])
write(root/'cumulative-log-constant-questions.json',dict(constants=constants,exponents=list(queries),source_sha256=sha(__file__),selection='Nine adjacent binary64 logarithm loads around mathematical LN(1+r), tested on every known exposed gap; no per-row constant or match ranking.'))
answers=service.ask_rows('EXP',list(queries.values()));exp=dict(zip(queries,answers));profiles=[]
for rate,cs in constants.items():
 for raw in cs:
  first=None
  for(r,gap),wanted in groups.items():
   if r!=rate:continue
   exponent=bits(-gap*value(raw));a=exp[exponent]
   if a!=dict(type='number',bits=wanted):first=dict(rate=rate,gap=gap,expected=wanted,exponent=exponent,public_exp=a);break
  profiles.append(dict(rate=rate,constant=raw,first_contradiction=first))
result=dict(complete=True,profiles=profiles,survivors=[p for p in profiles if p['first_contradiction']is None],exp_leaves=exp,receipts=service.receipts,
 source_bindings={str(p):sha(p)for p in(Path(__file__),root/'cumulative-power-rate-read.json')},limits='Conditional collapsed natural-exponential shape with a stored binary64 logarithm and exponent. Every constant must fit every exposed gap for that rate; no percentage-ranked or per-case load. If all fail, the shape or residency/public-helper premise is refuted; no logarithm is installed.')
write(root/'cumulative-log-constants.json',result);print('constants',len(profiles),'survivors',result['survivors'],flush=True)
