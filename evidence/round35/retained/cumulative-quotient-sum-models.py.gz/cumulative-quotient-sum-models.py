"""Fixed sum-of-rate-times-discount programs suggested by dyadic operand reading."""
import sys,json,itertools,struct
from pathlib import Path
from fractions import Fraction as Q
sys.path[:0]=['/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer','/home/ubuntu/projects/DnaCalc/DnaCalc-Research/checker']
from bessel import operation
from exact import BINARY64 as B,binary64
from fingerprint import bits,write,sha
sys.path.insert(0,"/home/ubuntu/projects/DnaCalc/DnaCalc-Research")
from racer.cumulative_projection import MODELS,validate_sum_observations
root=Path('/home/ubuntu/codex-runs/r35');docs={}
for name in ('cumulative-sums','cumulative-dyadic'):
 q=json.loads((root/name/'questions.json').read_text());a=json.loads((root/name/'answers.json').read_text());validate_sum_observations(q,a)
 parts=json.loads((root/(name+'-parts.json')).read_text());assert len(parts)==len(q['loans'])
 docs[name]=(q,a,parts)
profiles=[];survivors=[]
def reduce(terms,model,order):
 if order=='balanced'and len(terms)>1:
  k=len(terms)//2;return operation('add',model,reduce(terms[:k],model,order),reduce(terms[k:],model,order))
 x=Q(0)
 for t in terms[::-1]if order=='reverse'else terms:x=operation('add',model,x,t)
 return x
for placement,first_rule,outer,product,summation,finish,order in itertools.product(('outside','inside'),('direct_payment','rate_seed'),MODELS,MODELS,MODELS,MODELS,('forward','reverse','balanced')):
 first=None;checked=0
 for name,(q,a,parts)in docs.items():
  for index,(r,p)in enumerate(zip(q['ranges'],a['CUMPRINC'])):
   loan=q['loans'][r['loan']];rate=Q(loan['rate']);payment=binary64(a['PMT'][r['loan']]['bits']);factor=binary64(parts[r['loan']]['quotient']);terms=[];direct=Q(0)
   if loan['timing']:
    reciprocal=operation('div','stored_pc64',Q(1),rate)
    coefficient=operation('div','stored_pc64',Q(1),operation('add','stored_pc64',Q(1),reciprocal))
   else:coefficient=rate
   for period in range(r['start'],r['end']+1):
    isfirst=loan['timing']and period==1
    if isfirst and first_rule=='direct_payment':
     if placement=='inside':terms.append(payment)
     else:direct=payment
     continue
    term=coefficient if isfirst else operation('mul',product,coefficient,binary64(parts[r['loan']]['discounts'][period-1]))
    if placement=='inside':term=operation('mul',finish,factor,term)
    terms.append(term)
   total=reduce(terms,summation,order)
   if placement=='outside':total=operation('mul',finish,factor,total)
   if direct:total=operation('add',finish,total,direct)
   got=bits(float(B.round(total)));checked+=1
   if got!=p['bits']:first=dict(source=name,index=index,request=r,expected=p,prediction=got);break
  if first:break
 profile=dict(id=len(profiles),placement=placement,first_rule=first_rule,outer=outer,product=product,summation=summation,finish=finish,order=order,checked=checked,first_contradiction=first)
 if not first:survivors.append(profile)
 profiles.append(profile)
result=dict(complete=True,programs=profiles,survivors=survivors,source_bindings={str(p):sha(p)for p in(Path(__file__),*(root/(n+'-parts.json')for n in docs))},
 limits='Fixed cancelled-rate sum structure from exact dyadic PMT singleton readings. The existing independently researched PMT logarithm and public EXP are conditional leaves. Original cumulative answers are discovery; surviving entire programs need new frozen predictions and fresh answers. No arithmetic model selected by a match percentage.')
write(root/'cumulative-quotient-sum-models.json',result);print('programs',len(profiles),'survivors',survivors,flush=True)
