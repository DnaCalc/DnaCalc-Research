"""Power-of-two rates and independently selected unit-PMT loans expose CUM leaves."""
import sys,json,math,subprocess
from pathlib import Path
from fractions import Fraction as Q
sys.path[:0]=['/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer','/home/ubuntu/projects/DnaCalc/DnaCalc-Research/checker']
from fingerprint import CachedService,load_service,bits,value,write,sha
from exact import EXTENDED64 as E,BINARY64 as B
root=Path('/home/ubuntu/codex-runs/r35');research=Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research');client,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');service=CachedService(client.Client(timeout=180),root/'cache')
loans=[];pmts=[]
for shift in (1,2,5,8,10,16):
 rate=2.**-shift
 for n in (5,8,17,80,128):
  exact=(1-Q(1+rate)**-n)/Q(rate);pv=float(exact);center=int(bits(pv),16);options=[]
  for offset in (-2,-1,0,1,2):
   v=value(f'{center+offset:016x}');options.append(dict(pv=bits(v),offset=offset));pmts.append([client.number(rate),client.number(float(n)),client.number(v),client.number(0.),client.number(0.)])
  loans.append(dict(id=len(loans),rate=rate,periods=n,options=options))
answers=service.ask_rows('PMT',pmts);selected=[]
for index,l in enumerate(loans):
 for choice,a in zip(l['options'],answers[index*5:index*5+5]):choice['answer']=a
 options=[c for c in l['options']if c['answer']==dict(type='number',bits=bits(-1.))]
 if options:
  choice=min(options,key=lambda c:abs(c['offset']));selected.append(dict(id=len(selected),source_loan=l['id'],rate=l['rate'],periods=l['periods'],pv=value(choice['pv']),timing=0,payment=choice['answer']))
if not selected:raise ValueError('no unit-PMT reading controls')
loan_path=root/'cumulative-power-rate-parts-inputs.jsonl';loan_path.write_text(''.join(json.dumps(dict(loan=l,args=['0x'+bits(l[k])for k in('rate','periods','pv')]))+'\n'for l in selected))
parts_path=root/'cumulative-power-rate-parts.json';subprocess.run([str(research/'target/release/symbolic-racer'),'cumulative-discount-parts',str(loan_path),str(parts_path)],check=True)
parts=json.loads(parts_path.read_text());logs={}
for l in selected:
 rate=l['rate'];base=float(1.+rate);q=float(B.round(E.round(1/Q(base))))
 logs[rate]=(base,q)
flat=[x for pair in logs.values()for x in pair];log_answers=service.ask_rows('LN',[[client.number(x)]for x in flat]);log_candidates={}
for index,rate in enumerate(logs):
 base,q=log_answers[2*index:2*index+2];log_candidates[rate]=dict(public_LN_base=base['bits'],negative_public_LN_reciprocal=bits(-value(q['bits'])))
rows=[];exp_queries={}
for l,part in zip(selected,parts):
 if part.get('outside_observation_scope'):raise ValueError('missing payment log operand')
 choices=dict(log_candidates[l['rate']],PMT_log=part['log'].removeprefix('0x'))
 for period in range(1,l['periods']+1):
  gap=l['periods']-period+1;inputs={k:bits(-float(B.round(E.round(Q(gap)*Q(value(log))))))for k,log in choices.items()}
  for raw in inputs.values():exp_queries.setdefault(raw,[client.number(raw)])
  rows.append(dict(loan=l['id'],gap=gap,period=period,exponents=inputs,args=[client.number(v)for v in(l['rate'],float(l['periods']),l['pv'],float(period),float(period),0.)]))
exp=service.ask_rows('EXP',list(exp_queries.values()));exps=dict(zip(exp_queries,exp))
for r in rows:r['predictions']={k:dict(type='number',bits=bits(-value(exps[x]['bits'])))for k,x in r['exponents'].items()}
frozen={str(p):sha(p)for p in(Path(__file__),research/'target/release/symbolic-racer',parts_path)}
write(root/'cumulative-power-rate-predictions.json',dict(loans=loans,selected=selected,rows=rows,log_candidates=log_candidates,exp_leaves=exps,receipts=service.receipts.copy(),source_bindings=frozen,
 selection='Select PV only by independently observed PMT=-1 among five fixed adjacent PV inputs. No CUMPRINC answer inspected. Powers-of-two rates make cancelled rate scaling exact under normal finite arithmetic. Freeze all conditional EXP predictions before cumulative singleton answers.'))
observed=service.ask_rows('CUMPRINC',[r['args']for r in rows]);counts={k:0 for k in rows[0]['predictions']};groups={}
for r,a in zip(rows,observed):
 if a['type']!='number':raise ValueError('finite singleton required')
 r['answer']=a
 for k,v in r['predictions'].items():counts[k]+=a==v
 l=selected[r['loan']];groups.setdefault((l['rate'],r['gap']),set()).add(a['bits'])
if frozen!={p:sha(p)for p in frozen}:raise ValueError('power-rate source changed')
result=dict(format='dnacalc-cumulative-power-rate-singletons/1',complete=True,loans=loans,selected=selected,records=rows,counts=counts,receipts=service.receipts,source_bindings=frozen,
 equal_gap_groups=len(groups),different_equal_gap_groups=sum(len(g)>1 for g in groups.values()),
 limits='PMT selection is an independent operand control, not selection by cumulative match. Public PMT=-1 and a power-of-two rate remove the two rate-scaling roundings under the cancelled-rate hypothesis. Logarithm candidates are whole structural rules, not selected per input; public EXP is independently read. No summation algorithm is identified.')
write(root/'cumulative-power-rate-read.json',result);print('selected loans',len(selected),'rows',len(rows),'counts',counts,'different equal gaps',result['different_equal_gap_groups'],flush=True)
