import sys,json,random,time,math
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.fingerprint import CachedService,AuditedClientMixin,load_service,bits,value,write,sha
from racer.ets import CHECKOUT
OUT=Path('/home/ubuntu/codex-runs/r46')
c,_=load_service(CHECKOUT)
class Timed(AuditedClientMixin,c.Client):
 def ask(self,*a,**kw):
  t=time.monotonic()
  try:return super().ask(*a,**kw)
  finally:
   with (OUT/'times.jsonl').open('a') as f:f.write(json.dumps(dict(function=a[0],calls=len(a[1]),seconds=time.monotonic()-t))+'\n')
s=CachedService(Timed(timeout=60),OUT/'service-cache',priority='interactive')
if __name__=='__main__':
 rng=random.Random(460101);cases=[]
 for n in range(2,17):
  for kind in range(18):
   if kind<4:y=[float((j%2)*2-1) for j in range(n)]
   elif kind<8:y=[float([2,7,-1,4][j%4]) for j in range(n)]
   elif kind<12:y=[float(rng.randrange(-1024,1025)) for j in range(n)]
   elif kind<15:y=[float((j==kind-11)*10)for j in range(n)]
   else:y=[float(j*j)for j in range(n)]
   e=[-400,0,400][kind%3];y=[math.ldexp(v,e)for v in y]
   cases.append(dict(n=n,kind=kind,y=y))
 write(OUT/'detection-short-frozen.json',dict(cases=cases,source_sha256=sha(__file__)))
 rows=[[c.number_array([[v]for v in z['y']]),c.number_array([[float(j+1)]for j in range(z['n'])])]for z in cases]
 a=s.ask_rows('FORECAST.ETS.SEASONALITY',rows,chunk_size=90)
 write(OUT/'detection-short-result.json',dict(answers=a,receipts=s.receipts))
 for n in range(2,17):print(n,[(z['kind'],r)for z,r in zip(cases,a)if z['n']==n],flush=True)
