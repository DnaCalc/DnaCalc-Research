from discovery import *
from datetime import date
serial=lambda year:float((date(year,1,15)-date(1899,12,30)).days)
cases=[];rows=[]
# Fixed roots and exact dyadic cash ratios, so private fractional powers do not
# enter the root's definition. Coupon dates isolate solver initialization.
for n,f,base in [(2,1,2.),(4,1,2.),(2,2,2.),(4,2,2.),(2,1,1.5)]:
 p=100./base**n
 for e in range(-500,501):
  row=[serial(2024),serial(2024+n//f),0.,math.ldexp(p,e),math.ldexp(100.,e),float(f),0.]
  cases.append(dict(n=n,frequency=f,base=base,exponent=e,args=[bits(v)for v in row],root=f*(base-1.)))
  rows.append([c.number(v)for v in row])
write(OUT/'yield-map-frozen.json',dict(cases=cases,source_sha256=sha(__file__)))
ans=s.ask_rows('YIELD',rows,chunk_size=1000)
write(OUT/'yield-map-result.json',dict(answers=ans,receipts=s.receipts.copy()))
for n,f,base in [(2,1,2.),(4,1,2.),(2,2,2.),(4,2,2.),(2,1,1.5)]:
 z=[(q['exponent'],r)for q,r in zip(cases,ans)if(q['n'],q['frequency'],q['base'])==(n,f,base)]
 runs=[]
 for e,r in z:
  if runs and runs[-1]['answer']==r:runs[-1]['last']=e
  else:runs.append(dict(first=e,last=e,answer=r))
 print(n,f,base,'runs',len(runs),runs[:30],flush=True)
write(OUT/'yield-map-runs.json',dict(runs_by_design=[dict(n=n,frequency=f,base=base,runs=[(q['exponent'],r)for q,r in zip(cases,ans)if(q['n'],q['frequency'],q['base'])==(n,f,base)])for n,f,base in [(2,1,2.),(4,1,2.),(2,2,2.),(4,2,2.),(2,1,1.5)]]))
