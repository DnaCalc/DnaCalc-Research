"""R46 uses the existing compact evidence retention route; raw reports go to R2."""
from pathlib import Path
import datetime,gzip,hashlib,json,subprocess,sys,tarfile
ROOT=Path('/home/ubuntu/codex-runs/r46')
RESEARCH=Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
MAIN=RESEARCH.parent/'DnaCalc'
sys.path.insert(0,str(RESEARCH))
from racer.retain_evidence import retain
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def archive_raw():
 raw=ROOT/'raw-evidence';raw.mkdir(exist_ok=True)
 folders=['problems-before/corpus','corpus-candidate','problems-after/corpus',
          'census-r38','census-r39','census-r39-seasonal',
          'problems-before/classification','problems-after/classification']
 files=[p for name in folders for p in sorted((ROOT/name).rglob('*'))if p.is_file()]
 members=[dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=digest(p))for p in files]
 index=raw/'members.json';index.write_text(json.dumps(members,indent=2)+'\n')
 dest=raw/'corpus-r46.tar.gz'
 if dest.exists():raise FileExistsError(dest)
 with tarfile.open(dest,'w:gz')as stream:
  for p in files:stream.add(p,arcname=str(p.relative_to(ROOT)),recursive=False)
 checked=0
 with tarfile.open(dest,'r:gz')as stream:
  for info,record in zip(stream,members,strict=True):
   if info.name!=record['path']:raise ValueError('archive member changed')
   data=stream.extractfile(info).read()
   if len(data)!=record['bytes']or hashlib.sha256(data).hexdigest()!=record['sha256']:raise ValueError('archive bytes changed')
   checked+=1
 prefix='dnacalc-evidence/research/round46/'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-dna-firehorse'
 base=['rclone','--config','/home/ubuntu/.config/dnacalc/rclone.conf']
 for command,extra in [('copy',['--checksum']),('check',['--one-way'])]:
  with (ROOT/('r2-'+command+'.log')).open('a')as log:
   subprocess.run(base+[command,str(raw),'r2:'+prefix]+extra,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
 records=[dict(path=p.name,bytes=p.stat().st_size,sha256=digest(p))for p in sorted(raw.iterdir())]
 receipt=dict(prefix=prefix,files=records,file_count=len(records),bytes=sum(x['bytes']for x in records),
              archived_members=checked,raw_bytes=sum(r['bytes']for r in members),
              checksum_copy=True,one_way_check_exit=0,verified_archive_members=True)
 (ROOT/'r2-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
def retain_small():
 sources=ROOT/'sources';sources.mkdir(exist_ok=True)
 for p in [MAIN/'crates/calc-func/src/catalogue/statistics/ets.rs',MAIN/'crates/calc-func/tests/f1_stats.rs',RESEARCH/'round46-unit.json']:
  (sources/p.name).write_bytes(p.read_bytes())
 inputs=[p for p in ROOT.iterdir()if p.is_file()and p.suffix in ['.py','.json','.jsonl','.log','.tsv','.rs']]
 for folder in ['service-cache','sources','application-before','application-candidate','application-final','application-retained','application-published',
                'binomial-cdf-study','problems-before/classification','problems-before/corpus-functions',
                'problems-after/classification','problems-after/corpus-functions']:
  # Full row classifiers stay in the raw archive; their small summaries suffice here.
  inputs += [p for p in (ROOT/folder).rglob('*')if p.is_file()and p.name!='cells.jsonl']
 for folder in ['problems-before','problems-after']:
  inputs += [ROOT/folder/name for name in ['bank.log','bank-stream-counts.json']if(ROOT/folder/name).exists()]
  inputs += [ROOT/folder/'corpus/summary.json']
 print(retain(ROOT,RESEARCH/'evidence/round46',inputs),flush=True)
if __name__=='__main__':
 if sys.argv[1]=='raw':archive_raw()
 elif sys.argv[1]=='small':retain_small()
 else:raise ValueError('raw or small required')
