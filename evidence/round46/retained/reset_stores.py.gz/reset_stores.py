from reset_analysis import *
T=np.longdouble
def reset_moments(y,a,b,mask,order=0):
 ts,_=trends(y,a,b);w=len(y)if len(y)<=10 else len(y)//2;count=w-1
 def store(v,site):return T(float(v))if mask&(1<<site)else v
 total=T(0);squares=T(0)
 for t in ts:
  t=T(t);total=store(total+t,0);squares=store(squares+store(t*t,1),2)
 mean=store(total/T(count),3)
 var=store(store(squares/T(count),4)-store(mean*mean,5),6)
 if var<=0:return False
 sd=store(np.sqrt(var),7)
 if order==0:bound=store(store(sd*T(w),8)/T(count),9)
 elif order==1:bound=store(sd*store(T(w)/T(count),8),9)
 elif order==2:return store(abs(mean)/sd,8)<store(T(w)/T(count),9)
 return abs(mean)<bound
if __name__=='__main__':
 cc=list(cases());targets=[z for z in cc if z['path']==17];survive=[]
 for order,mask in itertools.product(range(3),range(1024)):
  if all(reset_moments(z['y'],.333333,.166667,mask,order)==(z['answer'][1]==bits(.001))for z in targets):survive.append((mask,order))
 print('two-side arithmetic survivors',len(survive),survive[:25],flush=True)
 full=[]
 for mask,order in survive:
  if all(any([bits(pool[i][0]),bits(.001 if reset_moments(z['y'],*pool[i],mask,order)else pool[i][1]),bits(2.**-52)]==z['answer']for i in z['minimum'])for z in cc):full.append((mask,order))
 print('all retained survivors',len(full),full[:25],flush=True)
 (OUT/'reset-stores-result.json').write_text(json.dumps(dict(profiles=full,targets=len(cc),source_sha256=__import__('hashlib').sha256(Path(__file__).read_bytes()).hexdigest()))+'\n')
