from discovery import *
from reset_analysis import pool
from reset_stores import reset_moments
from racer.ets_optimizer import objective
from racer.ets_round40 import fit_with_trend
from racer.ets import initial_trend
rng=random.Random(460404);cases=[];pred=[]
for i in range(512):
 n=rng.randrange(8,33);e=rng.randrange(-100,101)
 y=[math.ldexp(rng.randrange(-128,129)/32+rng.choice([0.,.125,-.125])*j,e)for j in range(n)]
 a,b=min(pool,key=lambda p:objective(y,*p));reset=reset_moments(y,a,b,1023,0)
 cases.append(dict(y=y,raw_pair=[a,b]));pred.append([bits(a),bits(.001 if reset else b),bits(2.**-52)])
write(OUT/'reset-fresh-frozen.json',dict(cases=cases,predictions=pred,source_sha256=sha(__file__),candidate='Fixed retained25 pool, raw moments, floor-half divisor but ceil-half tail. Strict binary64 arithmetic first; precision unresolved.'))
rows=[]
for z in cases:
 y=c.number_array([[v]for v in z['y']]);t=c.number_array([[float(j+1)]for j in range(len(z['y']))])
 for k in [1,2,3]:rows.append([y,t,c.number(k),c.number(0)])
ans=s.ask_rows('FORECAST.ETS.STAT',rows,chunk_size=90)
actual=[[r.get('bits',r)for r in ans[j:j+3]]for j in range(0,len(ans),3)]
bad=[dict(case=i,prediction=p,answer=a)for i,(p,a)in enumerate(zip(pred,actual))if p!=a]
write(OUT/'reset-fresh-result.json',dict(answers=ans,failures=bad,receipts=s.receipts.copy()))
print('fresh triples',len(cases),'contradictions',len(bad),bad[:8],flush=True)
