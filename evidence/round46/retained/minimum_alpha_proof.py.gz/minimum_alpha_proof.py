from discovery import *
from reset_analysis import pool
from reset_stores import reset_moments
from racer.ets import initial_trend
from racer.ets_optimizer import objective
from racer.ets_round40 import fit_with_trend
import numpy as np
rng=random.Random(460611);cases=[];pred=[];attempt=0
while len(cases)<128 and attempt<20000:
 attempt+=1;n=rng.randrange(11,33);e=rng.randrange(-80,81)
 y=[math.ldexp(rng.randrange(-128,129)/8,e)for j in range(n)]
 a,b=min(pool,key=lambda p:objective(y,*p))
 if a!=.002 or not reset_moments(y,a,b,1023):continue
 l,t,se,_,_=fit_with_trend(y,a,b,initial_trend(y));l=y[-1]-se[(n-1)%2];t=initial_trend(y);m=(se[0]+se[1])/2;l+=m;se=[v-m for v in se]
 cases.append(dict(y=y,raw_pair=[a,b]))
 for h in [0,1,2,7]:pred.append(bits(float(np.longdouble(l+h*t)+np.longdouble(se[(n-1+h)%2]))))
write(OUT/'minimum-alpha-proof-frozen.json',dict(cases=cases,predictions=pred,attempts=attempt,seed=460611,source_sha256=sha(__file__),scope='raw minimum alpha and raw-moment reset true, fresh independent random histories; no Excel answer selects inputs.'))
rows=[]
for z in cases:
 y=c.number_array([[v]for v in z['y']]);t=c.number_array([[float(j+1)]for j in range(len(z['y']))])
 for h in [0,1,2,7]:rows.append([c.number(len(z['y'])+h),y,t,c.number(0)])
ans=s.ask_rows('FORECAST.ETS',rows,chunk_size=90);bad=[dict(case=i//4,h=[0,1,2,7][i%4],prediction=p,answer=a)for i,(p,a)in enumerate(zip(pred,ans))if p!=a.get('bits')]
write(OUT/'minimum-alpha-proof-result.json',dict(answers=ans,failures=bad,receipts=s.receipts.copy()))
print('minimum alpha fresh',len(cases),'histories',len(ans),'answers','contradictions',len(bad),bad[:10],flush=True)
