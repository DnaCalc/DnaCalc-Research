from discovery import *
from collections import Counter
cells=[json.loads(l)for l in(OUT/'problems-before/classification/cells.jsonl').read_text().splitlines()]
poisson=[z for z in cells if z['function']=='POISSON.DIST'and z['category']=='gross_or_unavailable'and z['cause']=='numeric_value']
cases=[]
for z in poisson:
 import re
 k=int(re.search(r'POISSON.DIST\((\d+),',z['formula'])[1]);reads=z['original_verdict']['difference']['reads'];mean=reads[0]['runs'][0]['number'];raw=int(mean,16)
 for offset in range(-64,65):cases.append(dict(k=k,mean=f'{raw+offset:016x}',source=z['formula'],offset=offset))
write(OUT/'poisson-large-frozen.json',dict(cases=cases,source_sha256=sha(__file__),relation='Poisson CDF(k,lambda) and CHISQ.DIST.RT(2*lambda,2*(k+1)); x=2*lambda is exact.'))
pp=s.ask_rows('POISSON.DIST',[[c.number(z['k']),c.number(z['mean']),c.boolean(True)]for z in cases],chunk_size=90)
cc=s.ask_rows('CHISQ.DIST.RT',[[c.number(2*value(z['mean'])),c.number(2*(z['k']+1))]for z in cases],chunk_size=90)
write(OUT/'poisson-large-result.json',dict(poisson=pp,chi=cc,receipts=s.receipts.copy(),contradictions=[i for i,(p,q)in enumerate(zip(pp,cc))if p!=q]))
print('Poisson larger windows',len(cases),'public-chi contradictions',sum(p!=q for p,q in zip(pp,cc)),flush=True)
# Binomial larger differences are cumulative; read their public beta coupling.
# The dyadic-probability controls avoid unknown 1-p cancellation.
cases=[]
for n,k,p in [(60,1,.75),(60,30,.75),(1000,1,.5),(1000,333,.5),(100,1,.3),(1000,1,.02)]:
 for offset in range(-64,65):cases.append(dict(n=n,k=k,p=f'{int(bits(p),16)+offset:016x}',offset=offset))
write(OUT/'binomial-large-frozen.json',dict(cases=cases,source_sha256=sha(__file__),relation='BINOM.DIST(k,n,p,TRUE) vs BETA.DIST(binary64(1-p),n-k,k+1,TRUE), conditional on stored complement.'))
bb=s.ask_rows('BINOM.DIST',[[c.number(z['k']),c.number(z['n']),c.number(z['p']),c.boolean(True)]for z in cases],chunk_size=90)
be=s.ask_rows('BETA.DIST',[[c.number(1-value(z['p'])),c.number(z['n']-z['k']),c.number(z['k']+1),c.boolean(True)]for z in cases],chunk_size=90)
write(OUT/'binomial-large-result.json',dict(binomial=bb,beta=be,receipts=s.receipts.copy(),contradictions=[i for i,(p,q)in enumerate(zip(bb,be))if p!=q]))
print('Binomial larger windows',len(cases),'public-beta contradictions',sum(p!=q for p,q in zip(bb,be)),flush=True)
