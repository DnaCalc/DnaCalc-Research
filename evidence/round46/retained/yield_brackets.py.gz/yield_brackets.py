from yield_candidates import cohort,seed,names,OUT,write,sha,bits,value,math
from itertools import product
result=[]
for high_name,method,expand in product(names,range(5),['double','add_one','double_plus_one']):
 first=None
 for z,a in cohort:
  n=z['n'];f=z['frequency'];p=value(z['args'][3]);r=value(z['args'][4]);target=value(a['bits']);lo=0.;hi=max(.1,seed(z,high_name));seen=[]
  def residual(x):return r/(1+x/f)**n-p
  try:
   fl=residual(lo);fh=residual(hi)
   for _ in range(100):
    seen.extend([lo,hi])
    if fl*fh<=0:break
    hi=2*hi if expand=='double'else hi+1 if expand=='add_one'else 2*hi+1;fh=residual(hi)
   for iteration in range(100):
    if method==0 or method==1 and iteration%2==0 or method==2 and iteration%2==1:x=lo+(hi-lo)/2
    else:x=hi-fh*(hi-lo)/(fh-fl)
    seen.append(x);fx=residual(x)
    if fx==0:break
    if fx>0:lo,fl=x,fx
    else:hi,fh=x,fx
    if method==4:
     if fx>0:fh/=2
     else:fl/=2
  except (ZeroDivisionError,OverflowError):pass
  if not any(math.isfinite(x)and abs(x-target)<=16*math.ulp(target)for x in seen):
   first=dict(case=z,answer=a,trace=[bits(x)for x in seen if math.isfinite(x)]);break
 result.append(dict(upper_seed=high_name,method=method,expansion=expand,first_contradiction=first))
survivors=[{k:v for k,v in z.items()if k!='first_contradiction'}for z in result if z['first_contradiction']is None]
write(OUT/'yield-brackets-result.json',dict(programs=result,survivors=survivors,source_sha256=sha(__file__),methods=['bisect','bisect/secant','secant/bisect','regula_falsi','Illinois'],limits='Necessary iterate membership within16ULP of exact observed answer, not a relaxed verdict. Fixed100-step brackets/iterations and cash-dependent seeds; no fitted tolerance. Analytic dyadic zero-coupon price is conditional.'))
print('cash-dependent bracket programs',len(result),'survivors',survivors,flush=True)
