"""Correct the unimplemented short-seasonal candidate's phase distance offline.

Original replies and first predictions remain immutable. This recheck uses
only the frozen history/true dyadic trend and never adjusts an Excel answer.
"""
from pathlib import Path
from fractions import Fraction as Q
import hashlib,json,struct
ROOT=Path('/home/ubuntu/codex-runs/r46')
bits=lambda v:struct.pack('>d',float(v)).hex()
frozen=ROOT/'short-seasonal-frozen.json'
cases=json.loads(frozen.read_text())['cases']
path=ROOT/'short-seasonal-FORECAST.ETS.json'
original=json.loads(path.read_text());predictions=[]
for z in cases:
 y=z['y'];trend=z['trend']
 for horizon in [0,1,2,7]:
  index=3+horizon;phase=index%2;distance=index-phase
  exact=Q(y[phase])+distance*Q(trend)
  value=y[phase]+distance*trend
  assert Q(value)==exact, 'chosen model output is exactly represented'
  if horizon==0:assert value==y[-1], 'zero horizon preserves last observation'
  predictions.append(bits(value))
failures=[dict(case=i//4,horizon=[0,1,2,7][i%4],prediction=p,answer=a)
          for i,(p,a)in enumerate(zip(predictions,original['answers'],strict=True))
          if p!=a.get('bits')]
result=dict(source='Original frozen dyadic affine-plus-alternating model; exact rational phase-distance derivation.',
 correction='Original diagnostic added2 extra trend steps. Correct distance is index-phase. No model parameter, input or answer changed.',
 original_contradictions=len(original['failures']),corrected_contradictions=len(failures),
 selections=len(predictions),predictions=predictions,failures=failures,
 inputs_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in [frozen,path,Path(__file__)]},
 limits='The candidate is still refuted. It was never implemented. Product/test expectations and measured application counts are unchanged.')
(ROOT/'short-seasonal-corrected-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print('original',result['original_contradictions'],'corrected',len(failures),'of',len(predictions))
