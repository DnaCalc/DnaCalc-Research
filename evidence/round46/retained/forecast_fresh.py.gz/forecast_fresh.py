from discovery import *
from racer.ets import initial_trend
from racer.ets_round40 import fit_with_trend
from racer.ets_optimizer import objective
from reset_analysis import pool
from reset_stores import reset_moments
cases=json.loads((OUT/'reset-fresh-frozen.json').read_text())['cases']
# Question every newly admitted minimum-alpha forecast in the fresh cohort,
# and the retained symmetric counterexample that motivated its old refusal.
selected=[]
for z in cases:
 y=z['y'];a,b=z['raw_pair'];old=fit_with_trend(y,a,b,initial_trend(y))[-1]
 if a==.002 and len(y)>10 and old:selected.append(z)
selected.append(dict(y=[-2.,8.,-13.,10.,-14.,12.,-17.,-11.,-29.,27.,30.,27.,-29.,-11.,-17.,12.,-14.,10.,-13.,8.,-2.],raw_pair=[.002,.001]))
write(OUT/'forecast-fresh-frozen.json',dict(cases=selected,source_sha256=sha(__file__),method='Every minimum-alpha,old-reset fresh512 case; no answer-based pruning. Horizon0,1,2,5.'))
rows=[]
for z in selected:
 y=c.number_array([[v]for v in z['y']]);t=c.number_array([[float(j+1)]for j in range(len(z['y']))])
 for h in [0,1,2,5]:rows.append([c.number(len(z['y'])+h),y,t,c.number(0)])
a=s.ask_rows('FORECAST.ETS',rows,chunk_size=90)
write(OUT/'forecast-fresh-result.json',dict(answers=a,receipts=s.receipts.copy()))
print('formerly refused fresh forecasts',len(a),flush=True)
