from discovery import *
from reset_analysis import cases,pool,trends
from racer.ets_optimizer import objective
from racer.ets import initial_trend
rng=random.Random(460203);bases=[]
for n in [8,12,16,24,32]:
 for attempt in range(100):
  y=[float(rng.randrange(-64,65))/64 for j in range(n)]
  pair=min(pool,key=lambda p:objective(y,*p))
  if pair[1]>.001:break
 bases.append(dict(y=y,raw_pair=pair))
bases.append(dict(y=[z['y']for z in cases()if z['path']==17][1],raw_pair=[.333333,.166667]))
def query(qq):
 rows=[]
 for z in qq:
  n=len(z['y']);y=c.number_array([[v]for v in z['y']]);t=c.number_array([[float(j+1)]for j in range(n)])
  for k in [1,2]:rows.append([y,t,c.number(k),c.number(0)])
 ans=s.ask_rows('FORECAST.ETS.STAT',rows,chunk_size=90)
 return [[a.get('bits',a)for a in ans[j:j+2]]for j in range(0,len(ans),2)]
write(OUT/'reset-map-frozen.json',dict(bases=bases,source_sha256=sha(__file__),method='Add a linear trend: innovations/objective invariant over reals. Read both endpoints of reset region; parameters remain checked at every call.'))
coarse=[]
for i,z in enumerate(bases):
 for j in range(-32,33):
  shift=j/16;coarse.append(dict(base=i,shift=shift,y=[v+k*shift for k,v in enumerate(z['y'])]))
ans=query(coarse);write(OUT/'reset-map-coarse.json',dict(cases=coarse,answers=ans,receipts=s.receipts.copy()))
edges=[]
for i,z in enumerate(bases):
 yy=[(q,a)for q,a in zip(coarse,ans)if q['base']==i]
 for (lo,a),(hi,b)in zip(yy,yy[1:]):
  if (a[1]==bits(.001))!=(b[1]==bits(.001)):
   edges.append(dict(base=i,lo=lo['shift'],hi=hi['shift'],left=a,right=b))
for iteration in range(42):
 qq=[dict(base=e['base'],shift=(e['lo']+e['hi'])/2,y=[v+j*((e['lo']+e['hi'])/2)for j,v in enumerate(bases[e['base']]['y'])])for e in edges]
 aa=query(qq)
 for e,q,a in zip(edges,qq,aa):
  if a==e['left']:e['lo']=q['shift']
  elif a==e['right']:e['hi']=q['shift']
  else:raise ValueError(('third parameter outcome',e,q,a))
write(OUT/'reset-map-result.json',dict(edges=edges,receipts=s.receipts))
for i,z in enumerate(bases):
 ee=[e for e in edges if e['base']==i];ts,w=trends(z['y'],*z['raw_pair']);m=sum(ts)/len(ts);sd=math.sqrt(sum((t-m)**2 for t in ts)/len(ts));print(i,len(z['y']),z['raw_pair'],'edges',ee,'mean',m,'sd',sd,'ratios',[(e['lo']+m)/sd for e in ee],flush=True)
