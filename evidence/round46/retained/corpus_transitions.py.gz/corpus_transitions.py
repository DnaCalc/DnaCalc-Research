from pathlib import Path
import json,sys,collections,hashlib
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.corpus_cases import workbook_directory
root=Path('/home/ubuntu/codex-runs/r46')
roots=[root/'problems-before/corpus',root/'problems-after/corpus']
summaries=[json.loads((p/'summary.json').read_text())for p in roots]
books=[{w['name']:w for w in s['workbooks']}for s in summaries]
assert books[0].keys()==books[1].keys()
changed=[];count=collections.Counter()
read=lambda p,k:json.loads(p.read_text())[k]
key=lambda r:(r['sheet'],r['row'],r['column'])
for name in books[0]:
 a,b=[books[i][name]for i in range(2)]
 assert a['sha256']==b['sha256']
 ds=[workbook_directory(roots[i],books[i][name],summaries[i].get('version',1))for i in range(2)]
 caps=list(ds[0].glob('*.capture.json'))
 parts=[p.name.removesuffix('.capture.json')for p in caps]if caps else ['']
 for part in parts:
  dirs=[d/part if part else d for d in ds]
  if not (dirs[0]/'evaluations.json').exists():
   assert not (dirs[1]/'evaluations.json').exists()
   assert a['counts']['awaiting_capture']==b['counts']['awaiting_capture']>0
   count['pending_without_evaluation']+=a['counts']['awaiting_capture']
   continue
  ee=[{key(r):r['returned']for r in read(d/'evaluations.json','evaluations')}for d in dirs]
  vv=[{key(r):r['verdict']for r in read(d/'triage.json','cells')}for d in dirs]
  assert ee[0].keys()==ee[1].keys()and vv[0].keys()==vv[1].keys()
  for k in ee[0]:
   # Prefix metadata/pending formula entries have no Excel verdict. They
   # remain outside match, but their calculated values are still compared.
   old,new=[v.get(k,'not_compared')for v in vv]
   count['compared_values']+=1
   if old!='matched'and new=='matched':count['gained']+=1
   if old=='matched'and new!='matched':count['lost']+=1
   if ee[0][k]!=ee[1][k]:
    changed.append(dict(workbook=name,cell=k,before=ee[0][k],after=ee[1][k],old_verdict=old,new_verdict=new))
    count['changed_values']+=1
assert count.get('lost',0)==0 and count['gained']==87 and count['changed_values']==87
assert all(r['old_verdict']=='not_modeled'and r['new_verdict']=='matched'for r in changed)
doc=dict(counts=count,changed=changed,
 inputs={str(p/'summary.json'):hashlib.sha256((p/'summary.json').read_bytes()).hexdigest()for p in roots},
 rule='All published evaluations/verdicts, matching workbook SHA and sheet/row/column. Every changed value was refused and now matches original Excel. Other returned values are unchanged; pending cells stay outside match.')
(root/'corpus-transitions.json').write_text(json.dumps(doc,indent=2)+'\n')
print(dict(count))
