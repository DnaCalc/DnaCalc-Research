from discovery import *
import itertools
rng=random.Random(460301);cases=[];rows=[]
# Fresh detector proof, including all ternary vectors and exponent edges.
for n in [2,3,4]:
 for y in itertools.product([-1.,0.,1.],repeat=n):cases.append(dict(y=list(y),kind='ternary'))
 for i in range(512):
  e=rng.choice([-400,-399,-100,-1,0,1,100,399,400]);base=rng.choice([0.,1.,-1.])
  y=[math.ldexp(base+math.ldexp(rng.randrange(-1024,1025),-52 if i%2 else -10),e)for j in range(n)]
  cases.append(dict(y=y,kind='adjacent_or_exponent'))
write(OUT/'short-detector-proof-frozen.json',dict(cases=cases,prediction=bits(0.),source_sha256=sha(__file__)))
rows=[[c.number_array([[v]for v in z['y']]),c.number_array([[float(j+1)]for j in range(len(z['y']))])]for z in cases]
a=s.ask_rows('FORECAST.ETS.SEASONALITY',rows,chunk_size=90)
write(OUT/'short-detector-proof-result.json',dict(answers=a,receipts=s.receipts.copy(),failures=[i for i,r in enumerate(a)if r!={'type':'number','bits':bits(0.)}]))
print('detector',len(a),'failures',sum(r!={'type':'number','bits':bits(0.)}for r in a),flush=True)
# Exact affine-plus-alternating histories at two cycles: frozen math outputs.
cases=[]
for i in range(96):
 e=rng.randrange(-90,91);level=rng.randrange(-256,257)/8;trend=rng.randrange(-32,33)/16;season=rng.randrange(-64,65)/16
 y=[math.ldexp(level+trend*j+(-1 if j%2 else 1)*season,e)for j in range(4)]
 cases.append(dict(y=y,trend=math.ldexp(trend,e),season=2))
write(OUT/'short-seasonal-frozen.json',dict(cases=cases,source_sha256=sha(__file__),forecast_rule='last observation + (h+1)*trend + alternating phase difference',confidence_rule='zero',parameter_rule=[.751,.001,.001]))
for function,variants in [('FORECAST.ETS.STAT',[1,2,3,4,5,6,7]),('FORECAST.ETS',[0,1,2,7]),('FORECAST.ETS.CONFINT',[1,2,7])]:
 rows=[];pred=[]
 for z in cases:
  y=c.number_array([[v]for v in z['y']]);t=c.number_array([[float(j+1)]for j in range(4)])
  for k in variants:
   if function.endswith('STAT'):a=[y,t,c.number(k),c.number(2)];v=[.751,.001,.001,0.,0.,0.,0.][k-1]
   elif function.endswith('CONFINT'):a=[c.number(4+k),y,t,c.number(.95),c.number(2)];v=0.
   else:a=[c.number(4+k),y,t,c.number(2)];v=z['y'][(3+k)%2]+(2+((3+k)//2)*2)*z['trend']
   rows.append(a);pred.append(bits(v))
 ans=s.ask_rows(function,rows,chunk_size=90)
 write(OUT/('short-seasonal-'+function+'.json'),dict(answers=ans,predictions=pred,receipts=s.receipts.copy(),failures=[i for i,(r,p)in enumerate(zip(ans,pred))if r.get('bits')!=p]))
 print(function,len(ans),'failures',sum(r.get('bits')!=p for r,p in zip(ans,pred)),flush=True)
