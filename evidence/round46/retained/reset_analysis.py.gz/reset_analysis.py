import sys,itertools,json,math
from pathlib import Path
import numpy as np
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.ets import read,bits,value,initial_trend,sequential_total
from racer.round41 import vector_path
from racer.ets_optimizer import objective
OUT=Path('/home/ubuntu/codex-runs/r46');OLD=OUT.parent/'round41'
pool=read(OLD/'ets-search-frozen.json')['tables']['nonreset25']
def trends(y,a,b):
 t=initial_trend(y);l=y[0];s=[0.,0.];ts=[]
 for j,v in enumerate(y[1:],1):
  q=j%2;e=v-((l+t)+s[q]);l+=t+a*e;t+=b*e;s[q]+=2.**-52*e;ts.append(t)
 w=len(y)if len(y)<=10 else(len(y)+1)//2
 return ts[-(w-1):],w
def decision(y,a,b,profile):
 mode,precision,compare=profile;ts,w=trends(y,a,b);T=float if precision=='binary64'else np.longdouble
 ts=list(map(T,ts));N=T(len(ts));W=T(w)
 total=T(0.)
 for t in ts:total+=t
 mean=total/N;sq=T(0.)
 for t in ts:sq+=(t-mean)*(t-mean)if mode=='centered'else t*t
 var=sq/N if mode=='centered'else sq/N-mean*mean
 if var<0:return False
 sqrt=lambda x:math.sqrt(x)if precision=='binary64'else np.sqrt(x)
 sd=sqrt(var)
 if compare==0:return abs(mean)<sd*W/N
 if compare==1:return abs(mean)<sd*(W/N)
 if compare==2:return abs(mean)/sd<W/N if sd else False
 if compare==3:return mean*mean<var*(W/N)*(W/N)
 if compare==4:return (mean*N)*(mean*N)<var*W*W
 if compare==5:return abs(total)<sd*W
 if compare==6:return abs(mean)/W<sd/N
 if compare==7:return abs(mean)*N<sd*W
 if compare==8:return abs(mean)/sqrt(var/N)<W/sqrt(N)if var else False
profiles=list(itertools.product(['centered','moments'],['binary64','extended64'],range(9)))
def cases():
 design=read(OLD/'ets-prior-boundaries-frozen.json');mapped=read(OLD/'ets-prior-boundaries-result.json')
 for path in mapped['paths']:
  if path['focused_edge'] is None:continue
  z=design['paths'][path['path']];right=z['right']if not path.get('anchor')else z['alternatives'][path['anchor']-1]
  obs=dict(path['observations'])
  for index in path['focused_edge']:
   y=vector_path(z['left'],right,index);scores=[objective(y,*p)for p in pool];ids=[i for i,v in enumerate(scores)if v==min(scores)]
   yield dict(path=path['path'],index=index,y=y,answer=obs[index],minimum=ids)
if __name__=='__main__':
 cc=list(cases());res=[]
 for p in profiles:
  failures=[]
  for z in cc:
   pred=[[bits(pool[i][0]),bits(.001 if decision(z['y'],*pool[i],p)else pool[i][1]),bits(2.**-52)]for i in z['minimum']]
   if z['answer']not in pred:failures.append(dict(path=z['path'],index=z['index'],pred=pred,answer=z['answer']))
  res.append(dict(profile=p,failures=failures));print(p,len(failures),[(f['path'],f['index'])for f in failures])
 (OUT/'reset-analysis.json').write_text(json.dumps(dict(profiles=res,cases=cc),indent=2)+'\n')
