from discovery import *
from reset_analysis import cases,pool
from racer.ets import initial_trend
from racer.ets_optimizer import objective
cc=[z for z in cases()if z['path']==17]
# Re-read each side, repeated, with neighboring paths and exact money scales.
qs=[]
for e in [-100,0,100]:
 for z in cc:
  for rep in range(3):qs.append(dict(y=[math.ldexp(v,e)for v in z['y']],side=z['index'],scale=e,repeat=rep))
write(OUT/'reset-repeat-frozen.json',dict(cases=qs,source_sha256=sha(__file__)))
for f,variants in [('FORECAST.ETS.STAT',[1,2,3,6,7]),('FORECAST.ETS',[0,1,2])]:
 rows=[]
 for z in qs:
  y=c.number_array([[v]for v in z['y']]);t=c.number_array([[float(j+1)]for j in range(len(z['y']))])
  for k in variants:rows.append([y,t,c.number(k),c.number(0)]if f.endswith('STAT')else[c.number(len(z['y'])+k),y,t,c.number(0)])
 a=s.ask_rows(f,rows,chunk_size=90)
 write(OUT/('reset-repeat-'+f+'.json'),dict(answers=a,receipts=s.receipts))
 print(f,[[r.get('bits',r)for r in a[j:j+len(variants)]]for j in range(0,len(a),len(variants))],flush=True)
