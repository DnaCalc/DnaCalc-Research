from discovery import *
from itertools import product
q=read=None
qq=json.loads((OUT/'yield-map-frozen.json').read_text())['cases'];aa=json.loads((OUT/'yield-map-result.json').read_text())['answers']
cohort=[(z,r)for z,r in zip(qq,aa)if z['exponent']in [-100,0,100]and z['base']==2.]
names=['zero','tenth','half','linear_face','average_face','average_cash','face_gain','price_gain','one','cash_over_face']
def seed(z,name):
 n=z['n'];f=z['frequency'];p=value(z['args'][3]);r=value(z['args'][4])
 return dict(zero=0.,tenth=.1,half=.5,one=1.,linear_face=(r-p)*f/(100*n),average_face=2*(r-p)*f/((100+p)*n),average_cash=2*(r-p)*f/((r+p)*n),face_gain=(100-p)*f/(p*n),price_gain=(r-p)*f/(p*n),cash_over_face=r/100)[name]
def trace(z,method,name,other):
 n=z['n'];f=z['frequency'];p=value(z['args'][3]);r=value(z['args'][4]);x=seed(z,name);last=seed(z,other)
 def price(x):return r/(1+x/f)**n
 out=[]
 try:
  for i in range(100):
   px=price(x);fx=px-p;out.append((x,fx))
   if fx==0:break
   if method=='newton':y=x+fx*(f+x)/(n*px)
   else:
    fl=price(last)-p;y=x-fx*(x-last)/(fx-fl)
   if not math.isfinite(y)or y<=-f:break
   last,x=x,y
 except (OverflowError,ZeroDivisionError):pass
 return out
result=[]
for method,name,other in product(['newton','secant'],names,names):
 if method=='newton'and other!='zero':continue
 if method=='secant'and name==other:continue
 first=None
 for z,a in cohort:
  target=value(a['bits']);tt=trace(z,method,name,other)
  # This generous necessary condition tolerates local pricing-store effects;
  # failure still rules out an iterate-stop explanation for the declared seed.
  near=[i for i,(x,fx)in enumerate(tt)if abs(x-target)<=16*math.ulp(target)]
  if not near:first=dict(case=z,predictions=[[bits(x),bits(fx)]for x,fx in tt],answer=a);break
 result.append(dict(method=method,seed=name,other_seed=other,first_contradiction=first))
survivors=[{k:v for k,v in r.items()if k!='first_contradiction'}for r in result if r['first_contradiction']is None]
write(OUT/'yield-candidates-result.json',dict(cohort=[z for z,a in cohort],programs=result,survivors=survivors,source_sha256=sha(__file__),limits='Necessary iterate membership, within16ULP to permit small arithmetic-leaf differences. No tolerance or stopping criterion is selected. Analytic zero-coupon price conditional; original service answers remain exact.'))
print('cash-dependent seed programs',len(result),'survivors',survivors,flush=True)
