import gzip, hashlib, json, math, pathlib, struct, sys, time
import numpy as np
sys.path.insert(0, '/home/ubuntu/projects/DnaCalc/DnaCalc/tools/excel-service')
from client import Client, number
ROOT = pathlib.Path('/home/ubuntu/codex-runs/r44')
def bits(x): return struct.pack('>d', float(x)).hex()
def val(s): return struct.unpack('>d', bytes.fromhex(s))[0]
def ask(fn, rows, name):
    request = dict(function=fn, rows=rows, priority='interactive')
    raw = json.dumps(request, separators=(',', ':')).encode()
    (ROOT/(name+'.questions.json.gz')).write_bytes(gzip.compress(raw, mtime=0))
    start=time.monotonic(); reply=Client(timeout=90).ask(fn, rows, priority='interactive')
    elapsed=time.monotonic()-start
    with (ROOT/'waits.tsv').open('a') as f:
        if elapsed>3: f.write(f'{name}\t{len(rows)}\t{elapsed:.6f}\n')
    (ROOT/(name+'.replies.json.gz')).write_bytes(gzip.compress(json.dumps(reply,separators=(',',':')).encode(),mtime=0))
    print(name,len(rows),elapsed,reply.get('excel_build'),flush=True)
    return reply
if __name__=='__main__':
    centers=[.5,.7,.75,.875,1.,1.125,1.375,1.5,1.625,1.75,1.875,2.,2.25,2.5,2.75,3.,3.5,4.,5.,7.,8.,8.5,10.,12.,16.,32.,64.,128.,256.,1024.,2.**20,2.**26,2.**52]
    windows=[]; xs=[]
    for c in centers:
        start=int(bits(c),16)-256
        windows.append(dict(center=bits(c),offset=len(xs),count=512))
        xs.extend(f'{start+k:016x}' for k in range(512))
    edges=[]
    for e in [-1022,-1000,-100,-54,-53,-52,-30,-10,0,1,2,3,10,50,100,500,1000]:
        for step in [-1,0,1]:
            b=int(bits(2.**e),16)+step; edges.append(f'{b:016x}')
    grid=[bits(x) for x in np.arange(.125,171,.125)]
    xs+=edges+grid
    (ROOT/'gamma-map.json').write_text(json.dumps(dict(windows=windows,xs=xs)))
    rows=[[number(x)] for x in xs]
    for fn in ['GAMMALN','GAMMALN.PRECISE','LN']:
        ask(fn,rows,fn+'.map')
