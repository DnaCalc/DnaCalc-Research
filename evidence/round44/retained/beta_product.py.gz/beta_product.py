from map_gamma import *
import numpy as np,collections
def run():
    d=json.loads((ROOT/'beta-prefactor.json').read_text());c=json.loads((ROOT/'beta-prefactors.candidates.json').read_text())['records'];y=json.loads(gzip.decompress((ROOT/'BETA.DIST.prefactor.replies.json.gz').read_bytes()))['rows']
    r=ask('EXP',[[number(z['start'])] for z in c]+[[number(-val(z['normalizer']))] for z in c],'EXP.beta-product')['rows'];n=len(c);ee=[val(z['bits']) for z in r[:n]];nn=[val(z['bits']) for z in r[n:]];ld=np.longdouble
    predictions=[]
    for (x,a,b),e,norm in zip(d['rows'],ee,nn):
        mul=lambda x,y:float(ld(x)*ld(y));div=lambda x,y:float(ld(x)/ld(y))
        predictions.append(dict(product_div=bits(div(mul(e,norm),a)),product_recip=bits(mul(mul(e,norm),div(1.,a))),scaled_norm=bits(mul(e,div(norm,a)))))
    out=[]
    for g in d['groups']:
        g=[i for i in g if d['rows'][i][0]<=2**-60];a,b=d['rows'][g[0]][1:];ratio=[val(y[i]['bits'])/ee[i] for i in g];center=sum(ratio)/len(ratio);raw=int(bits(center),16);survivors=[]
        for j in range(-8,9):
            C=val(f'{raw+j:016x}')
            if all(bits(float(ld(ee[i])*ld(C)))==y[i]['bits'] for i in g):survivors.append(bits(C))
        out.append(dict(a=a,b=b,rows=len(g),shared_multiplier=survivors))
    counts={k:sum(v[k]==r.get('bits') for v,r in zip(predictions,y)) for k in predictions[0]};doc=dict(counts=counts,groups=out,predictions=predictions);(ROOT/'beta-product.results.json').write_text(json.dumps(doc,indent=2));print(json.dumps(dict(counts=counts,groups=out),indent=2))
if __name__=='__main__':run()
