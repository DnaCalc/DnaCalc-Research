import sys,random,pathlib,subprocess
import numpy as np
from stirling_edges import *
RACER='/home/ubuntu/projects/DnaCalc/DnaCalc-Research/target/release/symbolic-racer'
def logs(xs,label):
    p=ROOT/(label+'.inputs');o=ROOT/(label+'.outputs');p.write_text(''.join('LN '+h+'\n' for h in xs));subprocess.run([RACER,'invoke-rows',str(p),str(o)],check=True)
    return np.array([val(s.strip().removeprefix('0x')) for s in o.read_text().splitlines()])
def proof():
    rng=random.Random(44002);xs=[]
    for i in range(4000):xs.append(bits(2**rng.uniform(3,8)))
    for i in range(512):xs.append(bits(2**rng.uniform(8,1000)))
    for a,b in [(8,12),(12,16),(16,24),(24,32),(32,64),(64,128)]:
        for k in range(32):
            x=rng.uniform(a,b);u=mp.mpf(math.ulp(math.lgamma(x)));target=(mp.floor(corr(x)/u)+mp.mpf('.5'))*u
            root=mp.findroot(lambda z:mp.loggamma(z)-(z-mp.mpf('.5'))*mp.log(z)+z-mp.log(2*mp.pi)/2-target,(mp.mpf(x)*mp.mpf('.999999999'),mp.mpf(x)*mp.mpf('1.000000001')))
            center=int(bits(root),16);xs.extend(f'{center+j:016x}' for j in range(-12,13))
    for c in [8,16,32,64,128]:
        center=int(bits(c),16);xs.extend(f'{center+j:016x}' for j in range(-100,100) if val(f'{center+j:016x}')>=8)
    x=np.array([val(h) for h in xs]);l=logs(xs,'stirling-proof-LN');ps={k:[bits(v) for v in calculate(x,l,k)] for k in ['fd','double','resident']}
    frozen=dict(xs=xs,predictions=ps,coefficients=[bits(v) for v in bern],model='Stored binary64 reciprocal, square, Horner products and sums, correction product; PC64 stored main expression and final sum.',application_revision='c7b8ed51',racer_sha256=__import__('hashlib').sha256(pathlib.Path(RACER).read_bytes()).hexdigest())
    raw=json.dumps(frozen,separators=(',',':')).encode();(ROOT/'stirling-proof.frozen.json.gz').write_bytes(gzip.compress(raw,mtime=0));print('frozen',__import__('hashlib').sha256(raw).hexdigest(),flush=True)
    r=ask('GAMMALN',[[number(h)] for h in xs],'GAMMALN.stirling-proof');ys=[a.get('bits') for a in r['rows']];print({k:sum(a==b for a,b in zip(p,ys)) for k,p in ps.items()},len(ys),flush=True)
def plateau():
    sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer')
    from plateau_probe import probe
    from x87_programs import Builder,Native,build_library
    lib=ROOT/'x87.so';build_library(lib);native=Native(lib);g=Builder(2);cn={}
    def c(name,v):
        p=g.constant(bits(v));cn[name]=p;return p
    q=g.op('mul',g.op('sub',0,c('half',.5)),1);q=g.op('sub',q,0);q=g.op('add',q,c('LS2PI',val('3fed67f1c864beb5')))
    z=g.op('div',g.one,0);t=g.op('mul',z,z);w=c('C9',bern[-1])
    for i in range(8,-1,-1):w=g.op('add',g.op('mul',w,t),c('C'+str(i),bern[i]))
    out=g.op('add',q,g.op('mul',z,w));shape=dict(function='GAMMALN',argument_inputs=[0],constants={k:v for k,v in cn.items() if k!='half'},graph=g.graph(out,out),mask=(1<<g.sites)-1,cw=0x133f)
    d=json.loads((ROOT/'stirling-edges.json').read_text());xs=d['xs'];l=logs(xs,'stirling-plateau-LN');ins=np.array([[int(h,16),int(bits(v),16)] for h,v in zip(xs,l)],dtype=np.uint64);result=probe(shape,ins,native)
    (ROOT/'stirling-plateau.json').write_text(json.dumps(dict(shape=shape,constants=result)))
if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='plateau':plateau()
    else:proof()
