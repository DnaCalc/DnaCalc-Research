import sys,json,gzip,math,random
import mpmath as mp, numpy as np
from stirling import *
def corr(x):
    xx=mp.mpf(float(x))
    return mp.loggamma(xx)-(xx-mp.mpf('.5'))*mp.log(xx)+xx-mp.log(2*mp.pi)/2
def make():
    rng=random.Random(44001);xs=[];edges=[]
    for a,b in [(8,12),(12,16),(16,24),(24,32),(32,64),(64,128)]:
        for k in range(32):
            x=rng.uniform(a,b); u=mp.mpf(math.ulp(math.lgamma(x))); target=(mp.floor(corr(x)/u)+mp.mpf('.5'))*u
            root=mp.findroot(lambda z:mp.loggamma(z)-(z-mp.mpf('.5'))*mp.log(z)+z-mp.log(2*mp.pi)/2-target,(mp.mpf(x)*mp.mpf('.999999999'),mp.mpf(x)*mp.mpf('1.000000001')))
            center=int(bits(root),16);off=len(xs);xs.extend(f'{center+j:016x}' for j in range(-24,25));edges.append(dict(center=bits(root),offset=off,count=49,target=str(target),bin=[a,b]))
    (ROOT/'stirling-edges.json').write_text(json.dumps(dict(xs=xs,edges=edges)))
    for fn in ['LN','GAMMALN']:ask(fn,[[number(h)] for h in xs],fn+'.stirling-edges')
def analyse():
    d=json.loads((ROOT/'stirling-edges.json').read_text());x=np.array([val(h) for h in d['xs']]);
    l=np.array([val(r['bits']) for r in json.loads(gzip.decompress((ROOT/'LN.stirling-edges.replies.json.gz').read_bytes()))['rows']]);y=np.array([val(r['bits']) for r in json.loads(gzip.decompress((ROOT/'GAMMALN.stirling-edges.replies.json.gz').read_bytes()))['rows']]);
    ps={k:calculate(x,l,k) for k in ['fd','double','resident']}
    for a,b in [(8,12),(12,16),(16,24),(24,32),(32,64),(64,128)]:
        ix=(x>=a)&(x<b);print(a,b,int(sum(ix)),{k:int(sum(v[ix]==y[ix])) for k,v in ps.items()})
    (ROOT/'stirling-edges.predictions.json.gz').write_bytes(gzip.compress(json.dumps({k:[bits(v) for v in p] for k,p in ps.items()}).encode(),mtime=0))
if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='analyse':analyse()
    else:make();analyse()
