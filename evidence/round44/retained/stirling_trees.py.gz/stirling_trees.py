from stirling_proof import *
def candidates(x,l):
    q=(ld(x-.5)*ld(l)).astype(float);q=(ld(q)-ld(x)).astype(float);q=(ld(q)+ld(val('3fed67f1c864beb5'))).astype(float)
    hart=[.08333333333333333331554247,-.002777777777777681622553,.000793650793500350248,-.0005952379913043012,.00084171387781295,-.001910444077728,.0057083835261]
    out={}
    for name,cs in [('B8',bern[:8]),('B10',bern),('Hart',hart)]:
        for coordinate in ['recip_square','square_recip','divide']:
            for finish in ['mul','div']:
                for stores in ['double','pc64']:
                    def op(a,b,kind):
                        if stores=='pc64':a,b=ld(a),ld(b)
                        return np.asarray({'mul':lambda:a*b,'div':lambda:a/b,'add':lambda:a+b}[kind](),dtype=float)
                    z=op(1.,x,'div');xs=op(x,x,'mul')
                    t=op(z,z,'mul') if coordinate=='recip_square' else op(1.,xs,'div')
                    w=np.full(len(x),cs[-1])
                    for c in cs[-2::-1]:w=op(op(w,xs,'div') if coordinate=='divide' else op(w,t,'mul'),c,'add')
                    c=op(w,z,'mul') if finish=='mul' else op(w,x,'div')
                    out[(name,coordinate,finish,stores)]=(ld(q)+ld(c)).astype(float)
    return out
if __name__=='__main__':
    d=json.loads(gzip.decompress((ROOT/'stirling-proof.frozen.json.gz').read_bytes()));x=np.array([val(h) for h in d['xs']]);l=logs(d['xs'],'stirling-tree-LN');y=np.array([val(r['bits']) for r in json.loads(gzip.decompress((ROOT/'GAMMALN.stirling-proof.replies.json.gz').read_bytes()))['rows']]);ix=x<1000
    # The family is fixed by reciprocal-vs-division evaluation of the same
    # asymptotic correction. No degree or coefficient is fitted here.
    out=candidates(x[ix],l[ix]);
    result={str(k):dict(contradictions=int(sum(v!=y[ix])),examples=[bits(a) for a in x[ix][v!=y[ix]][:4]]) for k,v in out.items()};(ROOT/'stirling-tree-results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
