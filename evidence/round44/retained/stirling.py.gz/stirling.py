import sys, gzip, json, re, collections, math
import numpy as np, mpmath as mp
from map_gamma import ROOT,bits,val,ask,number
ld=np.longdouble
mp.mp.dps=70
bern=[float(mp.bernpoly(2*i,0)/(2*i*(2*i-1))) for i in range(1,11)]
source=open('/home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/src/ported/excel_numeric/gammaln.rs').read()
fd=[val(m.replace('_','')) for m in re.findall(r'const W\d:.*?0x(.*?)\)',source)]
def calculate(xx,ll,kind):
    q=(ld(xx-.5)*ld(ll)).astype(float)
    q=(ld(q)-ld(xx)).astype(float)
    q=(ld(q)+ld(val('3fed67f1c864beb5'))).astype(float)
    if kind=='pc64':
        z=(1/ld(xx)).astype(float);t=(ld(z)*ld(z)).astype(float);w=np.full(len(xx),bern[-1])
        for c in bern[-2::-1]:w=(ld((ld(w)*ld(t)).astype(float))+ld(c)).astype(float)
        v=(ld(z)*ld(w)).astype(float)
    elif kind=='fd':
        z=1/xx;t=z*z;w=np.full(len(xx),fd[-1])
        for c in fd[-2::-1]:w=w*t+c
        v=z*w
    else:
        if kind=='resident':
            t=1/(ld(xx)*ld(xx));w=np.full(len(xx),bern[-1],dtype=ld)
            for c in bern[-2::-1]:w=w*t+ld(c)
            v=(w/ld(xx)).astype(float)
        else:
            z=1/xx;t=z*z;w=np.full(len(xx),bern[-1])
            for c in bern[-2::-1]:w=w*t+c
            v=z*w
    return (ld(q)+ld(v)).astype(float)
if __name__=='__main__':
    d=json.loads((ROOT/'gamma-map.json').read_text());idx=[i for i,h in enumerate(d['xs']) if 8<=val(h)<1e300]
    lnrows=json.loads(gzip.decompress((ROOT/'LN.map.replies.json.gz').read_bytes()))['rows']; yrows=json.loads(gzip.decompress((ROOT/'GAMMALN.map.replies.json.gz').read_bytes()))['rows']
    xx=np.array([val(d['xs'][i]) for i in idx]);ll=np.array([val(lnrows[i]['bits']) for i in idx]);yy=np.array([val(yrows[i]['bits']) for i in idx])
    for k in ['fd','double','resident']:
        a=calculate(xx,ll,k);print(k,np.sum(a==yy),'misses',[(bits(x),bits(y),bits(v)) for x,y,v in zip(xx,yy,a) if y!=v][:20])
