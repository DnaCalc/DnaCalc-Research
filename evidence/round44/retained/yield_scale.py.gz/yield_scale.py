import datetime,math,json,sys,mpmath as mp
from map_gamma import *
mp.mp.dps=70
def run():
    cases=[];rows=[]
    serial=lambda y:float((datetime.date(y,1,15)-datetime.date(1899,12,30)).days)
    scales=[-400,-200,-100,-50,-30,-20,-10,-5,0,5,10,20,30,50,100,200,400]
    for f in [1,2,4]:
        for years in [2,4,8]:
            for base in [1.001,1.05,1.25,1.5,2.0]:
                n=years*f;price=float(mp.mpf(100)/mp.mpf(base)**n);true=mp.mpf(f)*((mp.mpf(100)/mp.mpf(price))**(mp.mpf(1)/n)-1)
                case=dict(n=n,frequency=f,years=years,price=bits(price),true=str(true),offset=len(rows),scales=scales);cases.append(case)
                for e in scales:rows.append([serial(2024),serial(2024+years),0.,math.ldexp(price,e),math.ldexp(100.,e),float(f),0.])
    frozen=dict(cases=cases,rows=[[bits(v) for v in r] for r in rows],hypotheses=['absolute price residual stop changes under exact joint scale','relative residual or yield-step stop and normalization preserve joint scale'],selection='Zero coupons on coupon dates; exact powers of two scale both requested price and redemption. All recurrence price operations scale exactly, absent range limits. No private PRICE implementation is assumed.')
    (ROOT/'yield-scale.frozen.json').write_text(json.dumps(frozen));ans=ask('YIELD',[[number(v) for v in r] for r in rows],'YIELD.scale');out=[]
    for case in cases:
        rr=ans['rows'][case['offset']:case['offset']+len(scales)];numeric=[r['bits'] for r in rr if r['type']=='number'];vals=[val(h) for h in numeric];out.append(dict(case=case,answers=rr,unique=len(set(numeric)),error=[float(mp.mpf(v)-mp.mpf(case['true'])) for v in vals]))
    (ROOT/'yield-scale.results.json').write_text(json.dumps(out));print('cases',len(cases),'invariant',sum(r['unique']==1 for r in out),'changing',[(r['case']['n'],r['case']['price'],r['unique']) for r in out if r['unique']!=1],flush=True)
if __name__=='__main__':run()
