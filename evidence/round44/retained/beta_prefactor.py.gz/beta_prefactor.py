import sys,math,random,gzip,json,numpy as np,subprocess
from map_gamma import *
def questions():
    rng=random.Random(44004);groups=[];rows=[]
    for a,b in [(2,3),(3,2),(4,7),(8,9),(9,8),(10,11),(11,10),(8.5,9.5),(9.5,8.5),(8,8),(12,12),(1.5,2.5),(2.5,1.5)]:
        group=[]
        for e in range(55,76):
            x=2.**-e;group.append(len(rows));rows.append([x,a,b])
        groups.append(group)
    for k in range(1200):
        a=rng.uniform(8,12);b=rng.uniform(8,12);x=2**rng.uniform(-74,-54);rows.append([x,a,b])
    (ROOT/'beta-prefactor.json').write_text(json.dumps(dict(rows=rows,groups=groups)))
    ask('BETA.DIST',[[number(x),number(a),number(b),dict(type='boolean',value=True)] for x,a,b in rows],'BETA.DIST.prefactor')
    leaves={fn:[] for fn in ['GAMMALN','GAMMA','POWER','LN']}
    leaves['GAMMALN']=[[number(v)] for x,a,b in rows for v in [a,b,a+b]]
    leaves['GAMMA']=leaves['GAMMALN']
    leaves['POWER']=[[number(x),number(a)] for x,a,b in rows]
    leaves['LN']=[[number(x)] for x,a,b in rows]
    for fn,rr in leaves.items():ask(fn,rr,fn+'.beta-prefactor')
def analyse():
    d=json.loads((ROOT/'beta-prefactor.json').read_text());rr=d['rows'];r={fn:json.loads(gzip.decompress((ROOT/(fn+'.beta-prefactor.replies.json.gz')).read_bytes()))['rows'] for fn in ['GAMMALN','GAMMA','POWER','LN']};y=json.loads(gzip.decompress((ROOT/'BETA.DIST.prefactor.replies.json.gz').read_bytes()))['rows']
    for group in d['groups']:
        x,a,b=rr[group[0]];v=[math.ldexp(val(y[i]['bits']),int(round(-math.log2(rr[i][0])*a))) for i in group];print('dyadic',a,b,'unique scaled',len(set(v)),[bits(w) for w in v[:8]])
    # Each family is tested with independently measured public leaves. No
    # inaccurate application GAMMALN answer enters this comparison.
    ld=np.longdouble;mul=lambda a,b:float(ld(a)*ld(b));div=lambda a,b:float(ld(a)/ld(b));sub=lambda a,b:float(ld(a)-ld(b));add=lambda a,b:float(ld(a)+ld(b))
    pref={};expargs=[];cases=[]
    for i,(x,a,b) in enumerate(rr):
        la,lb,ls=[val(v['bits']) for v in r['GAMMALN'][i*3:i*3+3]];ga,gb,gs=[val(v['bits']) for v in r['GAMMA'][i*3:i*3+3]];power=val(r['POWER'][i]['bits']);lx=val(r['LN'][i]['bits']);cases.append(dict(i=i,expected=y[i],predictions={}))
        # Six natural evaluation orders of the beta normaliser.
        bt=[sub(add(la,lb),ls),add(la,sub(lb,ls)),add(lb,sub(la,ls))]
        for j,bet in enumerate(bt):
            for k,ax in enumerate([a*lx,mul(a,lx)]):
                expargs.append(sub(ax,bet));pref.setdefault('exp'+str(j)+str(k),[]).append(len(expargs)-1)
            expargs.append(-bet);pref.setdefault('power-exp'+str(j),[]).append(len(expargs)-1)
        for j,v in enumerate([div(mul(power,gs),mul(mul(ga,gb),a)),div(mul(div(power,ga),gs),mul(gb,a)),mul(power,div(gs,mul(mul(ga,gb),a)))]):cases[i]['predictions']['gamma'+str(j)]=bits(v)
    ans=ask('EXP',[[number(v)] for v in expargs],'EXP.beta-prefactor')
    for name,ix in pref.items():
        for i,j in enumerate(ix):
            x,a,b=rr[i];v=val(ans['rows'][j]['bits']);power=val(r['POWER'][i]['bits']);v=div(mul(power,v),a) if name.startswith('power') else div(v,a);cases[i]['predictions'][name]=bits(v)
    counts={name:sum(c['predictions'][name]==c['expected'].get('bits') for c in cases) for name in cases[0]['predictions']};print('counts',counts,'/',len(cases));(ROOT/'beta-prefactor.results.json.gz').write_bytes(gzip.compress(json.dumps(dict(counts=counts,cases=cases)).encode(),mtime=0))
if __name__=='__main__':
    if len(sys.argv)==1:questions()
    analyse()
