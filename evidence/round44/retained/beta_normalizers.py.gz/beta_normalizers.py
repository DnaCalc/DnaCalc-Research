from map_gamma import *
import subprocess,collections
def run():
    d=json.loads((ROOT/'beta-prefactor.json').read_text());c=json.loads((ROOT/'beta-prefactors.candidates.json').read_text());ans=json.loads(gzip.decompress((ROOT/'BETA.DIST.prefactor.replies.json.gz').read_bytes()))['rows']
    p=ROOT/'beta-normalizers.inputs.jsonl';o=ROOT/'beta-normalizers.outputs.json';rows=[]
    for gi,g in enumerate(d['groups']):
        center=int(c['records'][g[0]]['normalizer'],16)
        for delta in range(-64,65):
            for i in g:rows.append(dict(id=i,group=gi,delta=delta,args=[bits(v) for v in d['rows'][i]],normalizer=f'{center+delta:016x}'))
    p.write_text(''.join(json.dumps(r,separators=(',',':'))+'\n' for r in rows));subprocess.run(['/home/ubuntu/projects/DnaCalc/DnaCalc-Research/target/release/symbolic-racer','beta-prefactors',str(p),str(o)],check=True)
    counts=collections.Counter();doc=json.loads(o.read_text())
    for r in doc['records']:
        v=r['original'];want=ans[v['id']]['bits']
        for k,value in r['predictions'].items():counts[v['group'],v['delta'],k]+=value==want
    summary=[]
    for gi,g in enumerate(d['groups']):
        a,b=d['rows'][g[0]][1:];rec=dict(a=a,b=b,rows=len(g),feasible={k:[delta for delta in range(-64,65) if counts[gi,delta,k]==len(g)] for k in ['stored','compensated','running','resident']});summary.append(rec)
    (ROOT/'beta-normalizers.summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
    for f in [p,o]:
        f.with_suffix(f.suffix+'.gz').write_bytes(gzip.compress(f.read_bytes(),mtime=0));f.unlink()
if __name__=='__main__':run()
