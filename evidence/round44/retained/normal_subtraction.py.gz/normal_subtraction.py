import sys,json,numpy as np,math,gzip
from map_gamma import *
def run():
    windows=[];xs=[]
    for t in [.52,.58,.64,.70,.706]:
        c=int(bits(.5+t/2),16)-512;windows.append(dict(t=t,offset=len(xs),count=1024));xs.extend(f'{c+j:016x}' for j in range(1024))
    frozen=dict(windows=windows,xs=xs,exponents=list(range(-54,-45)),hypothesis='y=stored(t*(C-stored(R(t)))), x=stored(sqrt2*y); cancelling C and R share a binade or C is in the next larger one, so C-R is an exact multiple of ulp(R). Test the necessary output lattice without fitting C or R.')
    (ROOT/'normal-subtraction.frozen.json').write_text(json.dumps(frozen));r=ask('NORM.S.INV',[[number(h)] for h in xs],'NORM.S.INV.subtraction');yy=np.array([val(v['bits']) for v in r['rows']]);t=np.array([2*(val(h)-.5) for h in xs]);ld=np.longdouble;s2=math.sqrt(2);out=[]
    for w in windows:
        sl=slice(w['offset'],w['offset']+w['count']);xx=yy[sl];tt=t[sl];u0=np.asarray(ld(xx)/(ld(s2)*ld(tt)),dtype=float);counts={}
        for e in frozen['exponents']:
            delta=2.**e;center=np.rint(u0/delta);ok=np.zeros(len(xx),dtype=bool)
            for k in range(-3,4):
                u=(center+k)*delta;y=np.asarray(ld(tt)*ld(u),dtype=float);x=np.asarray(ld(y)*ld(s2),dtype=float);ok|=x==xx
            counts[str(e)]=int(sum(ok))
        out.append(dict(window=w,necessary_matches=counts,rows=len(xx)))
    (ROOT/'normal-subtraction.results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
if __name__=='__main__':run()
