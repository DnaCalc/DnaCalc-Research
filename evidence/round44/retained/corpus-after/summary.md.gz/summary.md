# Corpus summary

Pass = matched live Excel from calculated workbook inputs. Fail includes mismatches, refusals, failed or missing results, external link caches, circular held caches and awaiting captures. The pass rate includes every inventoried formula cell. Files with unknown inventories are reported separately.

- cache: C:\Work\DnaCalc\corpus\captures-cache
- command: cargo xtask corpus --oracle --no-capture --out /home/ubuntu/codex-runs/r44/corpus-after
- compare_process: this xtask-harness (debug)
- comparison_timeout_s: 10800
- corpus_inventory_sha256: a974d66243aaf7b3cc906ca773661dea22fc57a2229b6914b0da422af4feacd4
- dna_only_fallback: false
- excel_build: not read (no capture needed it)
- executable_sha256: ca3fbd67591d63c62ebc974a0516eb222d0fc1bdecd451e2aebd5d301f7cbd3d
- execution_route: captured-policy-or-disabled-inventory
- finished_utc: 2026-11-09T08:38:07Z
- inventory: inventory.json
- listing_failures: []
- repository: c7b8ed51b96e8ffb8496f8b35cc93e71b92c465a+dirty
- resume: false
- resumed_stage_times: from the verified original comparison
- saved_excel_provenance_sha256: null
- shard: null
- trusted_code_sha256: null
- wall_time_s: 137.956360291

## Totals

- workbooks: 62 (62 compared, 0 not compared; 0 compared with the whole run failed)
- formula cells (known inventories): 76957; pass 75050; external links 73; circular rule 14; awaiting capture 108; fail 1907 (mismatched 600, refused 1111, failed or missing 1)
- pass rate over all formula cells: 97.52%
- agreed rejections (in pass: Excel and DNA Calc both refuse the entry): 8
- failed or missing by verdict: not_run 1
- wall time (s): open 30.810, recalculation 68.618, project 0.862, judge 1.843, compare processes 123.390, captures -

## Workbooks

| Workbook | Formula cells | Pass | External links | Circular rule | Awaiting capture | Fail | Mismatched | Refused | Failed or missing | Pass rate | Open s | Recalc s | Judge s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| calc-engine/dc_10y/oracle.xlsx | 1436 | 1436 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.192 | 0.378 | 0.025 |
| calc-engine/dc_10y_iteration/oracle.xlsx | 17 | 17 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.007 | 0.063 | 0.000 |
| calc-engine/dc_86f/oracle.xlsx | 22 | 22 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.012 | 0.005 | 0.000 |
| calc-engine/dc_y2o/oracle.xlsx | 17 | 3 | 0 | 14 | 0 | 14 | 0 | 0 | 0 | 17.64% | 0.006 | 0.004 | 0.000 |
| calc-engine/eng14-raw-nonfinite/oracle.xlsx | 21 | 21 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.006 | 0.007 | 0.000 |
| calc-engine/eng15-overflow/oracle.xlsx | 94 | 94 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.010 | 0.026 | 0.001 |
| calc-engine/l3/oracle.xlsx | 112 | 112 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.025 | 0.028 | 0.001 |
| calc-fml/dc_51ka/oracle.xlsx | 183 | 183 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.059 | 0.328 | 0.003 |
| calc-fml/dc_ibp2/oracle.xlsx | 83 | 83 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.011 | 0.020 | 0.001 |
| calc-fml/dc_l10u/oracle.xlsx | 57 | 57 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.013 | 0.358 | 0.001 |
| calc-func/catalogue/oracle.xlsx | 14553 | 14269 | 0 | 0 | 0 | 284 | 284 | 0 | 0 | 98.04% | 11.891 | 35.364 | 0.484 |
| calc-func/cdoc_jpha/oracle.xlsx | 1526 | 1526 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.157 | 0.609 | 0.033 |
| calc-func/cfunc_m1_2/oracle.xlsx | 234 | 234 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.034 | 0.337 | 0.004 |
| calc-func/cfunc_m3_2/oracle.xlsx | 218 | 218 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.022 | 0.053 | 0.003 |
| calc-func/cfunc_m3_4/oracle.xlsx | 112 | 112 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.016 | 0.031 | 0.002 |
| calc-func/cfunc_m3_5/oracle.xlsx | 136 | 136 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.019 | 0.347 | 0.002 |
| calc-func/cfunc_m3_6/oracle.xlsx | 596 | 596 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.073 | 0.467 | 0.010 |
| calc-func/dc_e00t/oracle.xlsx | 1144 | 1144 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.098 | 0.436 | 0.020 |
| calc-func/dc_fwpz/oracle.xlsx | 115 | 115 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.023 | 0.043 | 0.002 |
| calc-func/dc_nzpw/oracle.xlsx | 186 | 185 | 0 | 0 | 0 | 1 | 0 | 0 | 1 | 99.46% | 0.019 | 0.038 | 0.002 |
| calc-func/dc_q9rb/oracle.xlsx | 86 | 81 | 0 | 0 | 0 | 5 | 5 | 0 | 0 | 94.18% | 0.010 | 0.013 | 0.001 |
| calc-func/dc_xrxb/oracle.xlsx | 167 | 167 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.021 | 0.357 | 0.002 |
| calc-func/dcj9k_r21/oracle.xlsx | 204 | 204 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.049 | 0.090 | 0.003 |
| calc-func/dcj9k_r22/oracle.xlsx | 105 | 105 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.029 | 0.050 | 0.001 |
| calc-func/dcj9k_r25_bessel/oracle.xlsx | 310 | 309 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 99.67% | 0.026 | 0.039 | 0.005 |
| calc-func/dcj9k_r25_discrete/oracle.xlsx | 233 | 196 | 0 | 0 | 0 | 37 | 37 | 0 | 0 | 84.12% | 0.027 | 0.039 | 0.004 |
| calc-func/dcj9k_r25_geomean/oracle.xlsx | 292 | 292 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.030 | 0.039 | 0.003 |
| calc-func/dcj9k_r25_guard_transfer/oracle.xlsx | 400 | 400 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.036 | 0.067 | 0.009 |
| calc-func/dcj9k_r25_qr_stores/oracle.xlsx | 100 | 100 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.016 | 0.045 | 0.001 |
| calc-func/dcj9k_r25_regression/oracle.xlsx | 2280 | 2280 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.227 | 0.369 | 0.049 |
| calc-func/dcj9k_r25_variance/oracle.xlsx | 732 | 732 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.076 | 0.159 | 0.015 |
| calc-func/dcj9k_r26_regression/oracle.xlsx | 3984 | 3984 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.458 | 0.907 | 0.093 |
| calc-func/dcj9k_r26_root_transfer/oracle.xlsx | 3136 | 3136 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.229 | 0.339 | 0.057 |
| calc-func/dcj9k_r26_scalar/oracle.xlsx | 2571 | 2571 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.212 | 0.690 | 0.062 |
| calc-func/dcj9k_r38_ets/oracle.xlsx | 3928 | 2984 | 0 | 0 | 8 | 944 | 20 | 916 | 0 | 75.96% | 1.011 | 1.980 | 0.077 |
| calc-func/dcj9k_r39_ets/oracle.xlsx | 880 | 693 | 0 | 0 | 0 | 187 | 11 | 176 | 0 | 78.75% | 0.312 | 0.666 | 0.013 |
| calc-func/dcj9k_r39_seasonal/oracle.xlsx | 440 | 421 | 0 | 0 | 0 | 19 | 0 | 19 | 0 | 95.68% | 0.157 | 0.338 | 0.004 |
| calc-func/dcztvv_r23/oracle.xlsx | 968 | 920 | 0 | 0 | 0 | 48 | 48 | 0 | 0 | 95.04% | 0.121 | 0.255 | 0.014 |
| calc-func/dcztvv_r24/oracle.xlsx | 4047 | 3965 | 0 | 0 | 0 | 82 | 82 | 0 | 0 | 97.97% | 0.748 | 0.953 | 0.096 |
| calc-func/fn10_sort_cycle/oracle.xlsx | 100 | 0 | 0 | 0 | 100 | 100 | 0 | 0 | 0 | 0.00% | - | - | - |
| calc-func/fn2_questions/oracle.xlsx | 956 | 956 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.556 | 0.923 | 0.016 |
| calc-func/fn3_questions/oracle.xlsx | 491 | 491 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.066 | 0.406 | 0.007 |
| calc-func/fn5_dates_1900/oracle.xlsx | 320 | 320 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.059 | 0.101 | 0.005 |
| calc-func/fn5_digits_zero/oracle.xlsx | 432 | 432 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.077 | 0.125 | 0.008 |
| calc-func/fn5_helper_boundaries/oracle.xlsx | 526 | 526 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.099 | 0.189 | 0.010 |
| calc-func/fn5_regex_results/oracle.xlsx | 160 | 160 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.038 | 0.059 | 0.003 |
| calc-func/fn5_selection_boundaries/oracle.xlsx | 408 | 408 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.079 | 0.138 | 0.008 |
| calc-func/fn6_iteration_primary/oracle.xlsx | 1200 | 1200 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.219 | 0.621 | 0.026 |
| calc-func/fn6_jamo_suffix/oracle.xlsx | 480 | 480 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.086 | 0.423 | 0.009 |
| calc-func/fn6_utf16_needles/oracle.xlsx | 320 | 320 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.061 | 0.094 | 0.005 |
| calc-func/fn6_utf16_needles_compat1/oracle.xlsx | 320 | 320 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.074 | 0.119 | 0.006 |
| calc-func/fn6_utf16_needles_compat2/oracle.xlsx | 320 | 320 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.070 | 0.104 | 0.005 |
| calc-func/fn7_argument_origins/oracle.xlsx | 480 | 480 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.085 | 0.141 | 0.008 |
| calc-func/fn7_collation_context/oracle.xlsx | 4648 | 4635 | 0 | 0 | 0 | 13 | 13 | 0 | 0 | 99.72% | 0.782 | 1.686 | 0.096 |
| calc-func/fn7_collation_contractions/oracle.xlsx | 2392 | 2392 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.394 | 1.045 | 0.051 |
| calc-func/fn7_date_argument_origins/oracle.xlsx | 480 | 480 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.090 | 0.140 | 0.008 |
| calc-func/fn7_format_context/oracle.xlsx | 160 | 140 | 0 | 0 | 0 | 20 | 20 | 0 | 0 | 87.50% | 0.035 | 0.065 | 0.002 |
| calc-func/jnt/oracle.xlsx | 16661 | 16582 | 0 | 0 | 0 | 79 | 79 | 0 | 0 | 99.52% | 11.236 | 15.454 | 0.459 |
| calc-host/dc_ylr/oracle.xlsx | 74 | 1 | 73 | 0 | 0 | 73 | 0 | 0 | 0 | 1.35% | 0.020 | 0.026 | 0.001 |
| calc-host/eng13_legacy/oracle.xlsx | 50 | 50 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.039 | 0.027 | 0.001 |
| calc-host/pivot_cube/oracle.xlsx | 131 | 131 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.050 | 0.050 | 0.002 |
| calc-host/pivot_getpivotdata/oracle.xlsx | 123 | 123 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 100.00% | 0.110 | 0.343 | 0.002 |
| **Total** | 76957 | 75050 | 73 | 14 | 108 | 1907 | 600 | 1111 | 1 | 97.52% | 30.810 | 68.618 | 1.843 |

### Captures

- calc-engine/dc_10y/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-engine/tests/captures/dc_10y/oracle.capture.json
- calc-engine/dc_10y_iteration/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-engine/tests/captures/dc_10y_iteration/oracle.capture.json
- calc-engine/dc_86f/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-engine/tests/captures/dc_86f/oracle.capture.json
- calc-engine/dc_y2o/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-engine/tests/captures/dc_y2o/oracle.capture.json
- calc-engine/eng14-raw-nonfinite/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-engine/tests/captures/eng14-raw-nonfinite/oracle.capture.json
- calc-engine/eng15-overflow/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-engine/tests/captures/eng15-overflow/oracle.capture.json
- calc-engine/l3/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-engine/tests/captures/l3/oracle.capture.json
- calc-fml/dc_51ka/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-fml/tests/captures/dc_51ka/oracle.capture.json
- calc-fml/dc_ibp2/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-fml/tests/captures/dc_ibp2/oracle.capture.json
- calc-fml/dc_l10u/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-fml/tests/captures/dc_l10u/oracle.capture.json
- calc-func/catalogue/oracle.xlsx: 25 committed section records in 5 comparison group(s): 5 with workbook sessions, 0 with scalar question mappings; 0 section(s) awaiting capture
- calc-func/cdoc_jpha/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/cdoc_jpha/oracle.capture.json
- calc-func/cfunc_m1_2/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/cfunc_m1_2/oracle.capture.json
- calc-func/cfunc_m3_2/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/cfunc_m3_2/oracle.capture.json
- calc-func/cfunc_m3_4/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/cfunc_m3_4/oracle.capture.json
- calc-func/cfunc_m3_5/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/cfunc_m3_5/oracle.capture.json
- calc-func/cfunc_m3_6/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/cfunc_m3_6/oracle.capture.json
- calc-func/dc_e00t/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dc_e00t/oracle.capture.json
- calc-func/dc_fwpz/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dc_fwpz/oracle.capture.json
- calc-func/dc_nzpw/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dc_nzpw/oracle.capture.json
- calc-func/dc_q9rb/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dc_q9rb/oracle.capture.json
- calc-func/dc_xrxb/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dc_xrxb/oracle.capture.json
- calc-func/dcj9k_r21/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r21/oracle.capture.json
- calc-func/dcj9k_r22/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r22/oracle.capture.json
- calc-func/dcj9k_r25_bessel/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r25_bessel/oracle.capture.json
- calc-func/dcj9k_r25_discrete/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r25_discrete/oracle.capture.json
- calc-func/dcj9k_r25_geomean/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r25_geomean/oracle.capture.json
- calc-func/dcj9k_r25_guard_transfer/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r25_guard_transfer/oracle.capture.json
- calc-func/dcj9k_r25_qr_stores/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r25_qr_stores/oracle.capture.json
- calc-func/dcj9k_r25_regression/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r25_regression/oracle.capture.json
- calc-func/dcj9k_r25_variance/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r25_variance/oracle.capture.json
- calc-func/dcj9k_r26_regression/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r26_regression/oracle.capture.json
- calc-func/dcj9k_r26_root_transfer/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r26_root_transfer/oracle.capture.json
- calc-func/dcj9k_r26_scalar/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcj9k_r26_scalar/oracle.capture.json
- calc-func/dcj9k_r38_ets/oracle.xlsx: 1 committed section records in 1 comparison group(s): 0 with workbook sessions, 1 with scalar question mappings; 1 section(s) awaiting capture: prefix_metadata (8 cells)
- calc-func/dcj9k_r39_ets/oracle.xlsx: 1 committed section records in 1 comparison group(s): 0 with workbook sessions, 1 with scalar question mappings; 0 section(s) awaiting capture
- calc-func/dcj9k_r39_seasonal/oracle.xlsx: 1 committed section records in 1 comparison group(s): 0 with workbook sessions, 1 with scalar question mappings; 0 section(s) awaiting capture
- calc-func/dcztvv_r23/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcztvv_r23/oracle.capture.json
- calc-func/dcztvv_r24/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/dcztvv_r24/oracle.capture.json
- calc-func/fn10_sort_cycle/oracle.xlsx: awaiting capture: no committed capture
- calc-func/fn2_questions/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn2_questions/oracle.capture.json
- calc-func/fn3_questions/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn3_questions/oracle.capture.json
- calc-func/fn5_dates_1900/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn5_dates_1900/oracle.capture.json
- calc-func/fn5_digits_zero/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn5_digits_zero/oracle.capture.json
- calc-func/fn5_helper_boundaries/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn5_helper_boundaries/oracle.capture.json
- calc-func/fn5_regex_results/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn5_regex_results/oracle.capture.json
- calc-func/fn5_selection_boundaries/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn5_selection_boundaries/oracle.capture.json
- calc-func/fn6_iteration_primary/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn6_iteration_primary/oracle.capture.json
- calc-func/fn6_jamo_suffix/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn6_jamo_suffix/oracle.capture.json
- calc-func/fn6_utf16_needles/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn6_utf16_needles/oracle.capture.json
- calc-func/fn6_utf16_needles_compat1/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn6_utf16_needles_compat1/oracle.capture.json
- calc-func/fn6_utf16_needles_compat2/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn6_utf16_needles_compat2/oracle.capture.json
- calc-func/fn7_argument_origins/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn7_argument_origins/oracle.capture.json
- calc-func/fn7_collation_context/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn7_collation_context/oracle.capture.json
- calc-func/fn7_collation_contractions/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn7_collation_contractions/oracle.capture.json
- calc-func/fn7_date_argument_origins/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn7_date_argument_origins/oracle.capture.json
- calc-func/fn7_format_context/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-func/tests/captures/fn7_format_context/oracle.capture.json
- calc-func/jnt/oracle.xlsx: 5 committed section records in 5 comparison group(s): 0 with workbook sessions, 5 with scalar question mappings; 0 section(s) awaiting capture
- calc-host/dc_ylr/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-host/tests/captures/dc_ylr/oracle.capture.json
- calc-host/eng13_legacy/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-host/tests/captures/eng13_legacy/oracle.capture.json
- calc-host/pivot_cube/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-host/tests/captures/pivot_cube/oracle.capture.json
- calc-host/pivot_getpivotdata/oracle.xlsx: committed capture /home/ubuntu/projects/DnaCalc/DnaCalc/crates/calc-host/tests/captures/pivot_getpivotdata/oracle.capture.json

## Failures by root cause

### Refusals (not modelled), by owner and reason

4 causes, 1111 roots, 1111 cells.

| Owner | Reason | Roots | Downstream | Whole workbook | Cells | Workbooks |
|---|---|---:|---:|---:|---:|---:|
| dc-j9k | not-modelled FORECAST.ETS.SEASONALITY | 455 | 0 | 0 | 455 | 3 |
| dc-j9k | not-modelled FORECAST.ETS | 292 | 0 | 0 | 292 | 2 |
| dc-j9k | not-modelled FORECAST.ETS.CONFINT | 292 | 0 | 0 | 292 | 2 |
| dc-j9k | not-modelled FORECAST.ETS.STAT | 72 | 0 | 0 | 72 | 1 |

### Mismatches, by function and shape at the root

83 causes, 598 roots, 600 cells.

| Function | Shape | Roots | Downstream | Whole workbook | Cells | Workbooks |
|---|---|---:|---:|---:|---:|---:|
| CUMPRINC | number, 1 ulp apart | 68 | 0 | 0 | 68 | 1 |
| CUMPRINC | number, 2 to 16 ulp apart | 61 | 0 | 0 | 61 | 2 |
| DATE | error Num expected, number returned; observed reads: number | 47 | 0 | 0 | 47 | 1 |
| CUMPRINC | number, differs within 15 significant digits | 36 | 0 | 0 | 36 | 2 |
| CUMIPMT | number, 2 to 16 ulp apart | 26 | 0 | 0 | 26 | 2 |
| YIELD | number, differs within 15 significant digits | 24 | 0 | 0 | 24 | 3 |
| INDEX | text expected, text returned; observed reads: text | 23 | 0 | 0 | 23 | 2 |
| ODDFYIELD | number, differs within 15 significant digits | 23 | 0 | 0 | 23 | 3 |
| POISSON.DIST | number, 1 ulp apart; observed reads: number | 23 | 0 | 0 | 23 | 2 |
| BINOM.DIST | number, differs within 15 significant digits | 17 | 0 | 0 | 17 | 2 |
| CUMIPMT | number, 1 ulp apart | 16 | 0 | 0 | 16 | 2 |
| POISSON.DIST | number, 2 to 16 ulp apart; observed reads: number | 16 | 0 | 0 | 16 | 2 |
| INDEX | number, 1 ulp apart | 15 | 0 | 0 | 15 | 2 |
| INDEX | number, differs within 15 significant digits | 14 | 0 | 0 | 14 | 2 |
| BINOM.DIST | number, differs within 15 significant digits; observed reads: number | 12 | 0 | 0 | 12 | 2 |
| FORECAST.ETS | number, 1 ulp apart | 10 | 0 | 0 | 10 | 1 |
| FORECAST.ETS.CONFINT | number, 1 ulp apart | 10 | 0 | 0 | 10 | 1 |
| BINOM.DIST | number, 2 to 16 ulp apart | 9 | 0 | 0 | 9 | 1 |
| POISSON.DIST | number, differs within 15 significant digits; observed reads: number | 9 | 0 | 0 | 9 | 2 |
| BETADIST | number, differs within 15 significant digits | 8 | 0 | 0 | 8 | 2 |
| CUMIPMT | number, differs within 15 significant digits | 8 | 0 | 0 | 8 | 2 |
| BINOM.DIST | number, 1 ulp apart | 6 | 0 | 0 | 6 | 2 |
| ODDFYIELD | number, differs within 15 significant digits; observed reads: number | 6 | 0 | 0 | 6 | 2 |
| YIELD | number, differs within 15 significant digits; observed reads: number | 6 | 0 | 0 | 6 | 2 |
| BINOM.DIST | number, 2 to 16 ulp apart; observed reads: number | 5 | 0 | 0 | 5 | 1 |
| FORECAST.ETS.STAT | number, differs within 15 significant digits | 5 | 0 | 0 | 5 | 1 |
| HSTACK | array expected, array returned; observed reads: number | 5 | 0 | 0 | 5 | 1 |
| Infix & | text expected, text returned; observed reads: number | 5 | 0 | 0 | 5 | 1 |
| SORT | array expected, array returned; observed reads: text | 3 | 2 | 0 | 5 | 1 |
| Infix & | text expected, text returned | 4 | 0 | 0 | 4 | 1 |
| FORECAST.ETS.STAT | number, 2 to 16 ulp apart | 3 | 0 | 0 | 3 | 1 |
| HYPGEOM.DIST | number, differs within 15 significant digits | 3 | 0 | 0 | 3 | 1 |
| IRR | number, differs within 15 significant digits | 3 | 0 | 0 | 3 | 1 |
| YIELD | number, 2 to 16 ulp apart | 3 | 0 | 0 | 3 | 1 |
| BETADIST | number, differs within 15 significant digits; observed reads: number | 2 | 0 | 0 | 2 | 1 |
| BETAINV | number, 2 to 16 ulp apart | 2 | 0 | 0 | 2 | 1 |
| BINOM.DIST | number, 1 ulp apart; observed reads: number | 2 | 0 | 0 | 2 | 1 |
| CHIDIST | number, 2 to 16 ulp apart | 2 | 0 | 0 | 2 | 1 |
| CUMIPMT | number, 2 to 16 ulp apart; observed reads: number | 2 | 0 | 0 | 2 | 1 |
| CUMPRINC | number, differs within 15 significant digits; observed reads: number | 2 | 0 | 0 | 2 | 1 |

and 43 more in summary.json

### Other failures, by class and key

4 causes, 88 roots, 196 cells.

| Class | Key | Roots | Downstream | Whole workbook | Cells | Workbooks |
|---|---|---:|---:|---:|---:|---:|
| capture | awaiting capture | 0 | 0 | 108 | 108 | 2 |
| provenance | external link cache (dc-ylr) | 73 | 0 | 0 | 73 | 1 |
| provenance | circular held cache (dc-y2o.1) | 14 | 0 | 0 | 14 | 1 |
| capture | capture failure at stage value | 1 | 0 | 0 | 1 | 1 |

