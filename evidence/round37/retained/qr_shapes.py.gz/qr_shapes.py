import sys,math,json,collections,itertools
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/codex-runs/round37')
from qr_probe import bits,val,native,ext

def qr(x,y,algorithm,arithmetic):
 def op(k,a,b):
  if arithmetic=='strict':return {'add':lambda:a+b,'sub':lambda:a-b,'mul':lambda:a*b,'div':lambda:a/b}[k]()
  return val(f'{native.publish(native.leaf(k,ext(a),ext(b),0x133f)):016x}')
 def sumprod(a,b):
  s=0.
  for aa,bb in zip(a,b):s=op('add',s,op('mul',aa,bb))
  return s
 n=len(x); xm=sum(x)/n;ym=sum(y)/n
 cols=[[1.]*n,[v-xm for v in x]];yy=[v-ym for v in y];R=[]
 for j in range(2):
  c=cols[j];v=c[j:];scale=1.
  if algorithm.startswith('l1'):scale=sum(map(abs,v))
  elif algorithm.startswith('max'):scale=max(map(abs,v))
  if scale!=1.:v=[op('div',z,scale)for z in v]
  norm=math.sqrt(sumprod(v,v));alpha=-math.copysign(norm,v[0]);old=v[0];v[0]=op('sub',old,alpha)
  if algorithm.endswith('normalized'):
   vn=[1.]+[op('div',z,v[0])for z in v[1:]];tau=op('div',op('sub',alpha,old),alpha)
  for z in cols[j+1:]+[yy]:
   tail=z[j:]
   if algorithm.endswith('normalized'):
    t=tail[0]
    for vi,zi in zip(vn[1:],tail[1:]):t=op('add',t,op('mul',vi,zi))
    f=op('mul',tau,t);new=[op('sub',zi,op('mul',f,vi))for zi,vi in zip(tail,vn)]
   else:
    dot=sumprod(v,tail)
    if algorithm.endswith('nr'): f=op('div',dot,op('sub',op('mul',old,alpha),op('mul',norm,norm)))
    elif algorithm.endswith('product'): f=op('div',dot,op('mul',alpha,v[0]))
    else:f=op('div',op('mul',2.,dot),op('add',sumprod(v[1:],v[1:]),op('mul',v[0],v[0])))
    new=[op('add'if algorithm.endswith(('nr','product'))else'sub',zi,op('mul',f,vi))for zi,vi in zip(tail,v)]
   z[j:]=new
  R.append(op('mul',alpha,scale))
 ss=sum(t*t for t in yy[2:]);slope=yy[1]/R[1];intercept=ym-slope*xm
 return dict(ss=bits(ss),slope=bits(slope),intercept=bits(intercept),sy=bits(math.sqrt(ss/(n-2))))

p=Path('/home/ubuntu/codex-runs/round37/regression-residual');cases=json.load(open(p/'questions.json'))['cases'];rr=collections.defaultdict(dict)
for r in map(json.loads,open(p/'observations.jsonl')):
 if r['function']=='LINEST':rr[r['case']][tuple(r['result_index'])]=r['answer']
profiles=list(itertools.product(['plain_full','plain_product','plain_nr','plain_normalized','l1_full','l1_nr','l1_normalized','max_full','max_nr','max_normalized'],['strict','pc64']))
records=[]
for algorithm,arithmetic in profiles:
 first={};counts=collections.Counter()
 for c in cases:
  got=qr([v[0]for v in c['x']],[v[0]for v in c['y']],algorithm,arithmetic)
  for key,index in [('slope',(1,1)),('intercept',(1,2)),('ss',(5,2)),('sy',(3,2))]:
   want=rr[c['id']][index]['bits'];same=got[key]==want;counts[key]+=same
   if not same:first.setdefault(key,dict(case=c['id'],expected=want,got=got[key]))
 records.append(dict(algorithm=algorithm,arithmetic=arithmetic,rows=len(cases),counts=counts,first=first))
result=dict(profiles=records,survivors=[r for r in records if not r['first']],limits='Fixed textbook Householder representations and sum-absolute/max scale choices. Strict means, centering and residual sums; coherent strict/stored64 reflector operations. All complete published stages compared, no program selected by partial count.')
Path('/home/ubuntu/codex-runs/round37/qr_shapes.json').write_text(json.dumps(result,indent=2)+'\n')
for r in records:print(r['algorithm'],r['arithmetic'],dict(r['counts']))
print('survivors',len(result['survivors']))
