import sys,json,math,itertools,random,struct,collections
from pathlib import Path
import numpy as np
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.fingerprint import CachedService,load_service,write,bits,value,sha
root=Path('/home/ubuntu/codex-runs/round37');out=root/'duration-separators';out.mkdir();prior=root/'duration-holdout';cases=json.load(open(prior/'predictions.json'))['cases'];pw=json.load(open(prior/'powers.json'));powers={tuple(k):value(a['bits'])for k,a in zip(pw['keys'],pw['answers'])}
profiles=list(itertools.product((False,True),repeat=5))
def calc(z,p):
 na,da,wm,pd,fd=p;num=den=0.;coupon=100*z['rate']/z['frequency']
 add=lambda a,b,wide:float(np.longdouble(a)+np.longdouble(b))if wide else a+b
 mul=lambda a,b:float(np.longdouble(a)*np.longdouble(b))if wm else a*b
 div=lambda a,b,wide:float(np.longdouble(a)/np.longdouble(b))if wide else a/b
 for k in range(1,z['n']+1):
  d=powers[bits(z['base']),bits(k)];pv=div(coupon,d,pd);num=add(num,mul(k,pv),na);den=add(den,pv,da)
 d=powers[bits(z['base']),bits(z['n'])];num=add(num,div(z['n']*100.,d,True),na);den=add(den,div(100.,d,True),da)
 return bits(div(num,den,fd)/z['frequency'])
rng=random.Random(370302);chosen=[];axis_counts=[0]*5;reference=(True,True,False,False,False);seen=set()
# Preserve a complete single-bit-stepped neighborhood of the separating rate.
edge=cases[270]
for delta in range(-32,33):
 z=dict(edge,rate=value(f'{int(bits(edge["rate"]),16)+delta:016x}'),origin='consecutive',step=delta);chosen.append(z)
# Select inputs by disagreement between fixed arithmetic words, before Excel answers.
for j in range(30000):
 z=dict(cases[rng.randrange(len(cases))]);z['rate']=math.ldexp(1+rng.random(),rng.choice((-60,-40,-20,-5,0,20,40)));z['origin']='word_separator';z['draw']=j
 baseline=calc(z,reference)
 accepted=[]
 for axis in range(5):
  if axis_counts[axis]>=3:continue
  p=list(reference);p[axis]=not p[axis]
  if calc(z,tuple(p))!=baseline:accepted.append(axis)
 if accepted:
  for a in accepted:axis_counts[a]+=1
  chosen.append(z)
 if min(axis_counts)>=3:break
for i,z in enumerate(chosen):z['id']=str(i)
# Freeze every complete program prediction before any new DURATION answer.
predictions=[[calc(z,p)for p in profiles]for z in chosen]
write(out/'questions.json',dict(cases=chosen,profiles=profiles,predictions=predictions,axes=['numerator_add','denominator_add','coupon_weight_multiply','coupon_divide','final_divide'],word_separator_counts=axis_counts,draws=j+1,producer_sha256=sha(__file__)))
c,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');s=CachedService(c.Client(timeout=300),root/'service-cache');rows=[[c.number(z[k])for k in ('settlement','maturity','rate','yield_','frequency')]+[c.number(0.)]for z in chosen];a=s.ask_rows('DURATION',rows)
records=[]
for j,p in enumerate(profiles):
 fail=[dict(case=z['id'],expected=w,prediction=pred[j])for z,w,pred in zip(chosen,a,predictions)if w.get('bits')!=pred[j]]
 records.append(dict(profile=p,matched=len(chosen)-len(fail),failures=fail))
write(out/'result.json',dict(answers=a,receipts=s.receipts,rows=len(chosen),programs=records,survivors=[r for r in records if not r['failures']],producer_sha256=sha(__file__),limits='Fresh same-region adjacent rates and fixed word-separating questions. Conditional measured integer POWER leaves. No threshold/constant fitted; only programs matching every answer survive.'))
print('rows',len(chosen),'axis_counts',axis_counts,'survivors',[(r['profile'],r['matched'])for r in records if not r['failures']],flush=True)
