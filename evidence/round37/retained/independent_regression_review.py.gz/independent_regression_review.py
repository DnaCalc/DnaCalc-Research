from pathlib import Path
from fractions import Fraction as Q
from collections import defaultdict,Counter
import json,math,struct
root=Path('/home/ubuntu/codex-runs/round37');value=lambda b:struct.unpack('>d',bytes.fromhex(b))[0]
def sqrt_cell(x,y):
 prev,follow=math.nextafter(y,-math.inf),math.nextafter(y,math.inf);lo=((Q(prev)+Q(y))/2)**2;hi=((Q(y)+Q(follow))/2)**2;even=int(struct.pack('>d',y).hex(),16)%2==0
 return (Q(x)>lo or even and Q(x)==lo)and(Q(x)<hi or even and Q(x)==hi)
counts=Counter()
rows=defaultdict(dict);cases=json.load(open(root/'regression-residual-positive/questions.json'))['cases']
for r in map(json.loads,open(root/'regression-residual-positive/observations.jsonl')):rows[r['function'],int(r['case'])][tuple(r['result_index'])]=r['answer']
records=[]
for (f,i),r in rows.items():records.append((f,cases[i],r[(2,2)],r[(5,2)],r[(4,2)]))
d=json.load(open(root/'regression-proof/result.json'));cases=json.load(open(root/'regression-proof/questions.json'))['cases'];rows=defaultdict(dict)
for r in d['observations']:rows[r['function']][tuple(r['selection'])]=r
for f,r in rows.items():
 for i,c in enumerate(cases):records.append((f,c,r[(2,2)]['answers'][i],r[(5,2)]['answers'][i],r[(4,2)]['answers'][i]))
for f,c,a,s,d in records:
 xs=[v[0]for v in c['x']];assert sum(map(Q,xs))==0
 n=len(xs);r=math.sqrt(n);assert sqrt_cell(n,r)
 inv=float(1/Q(r));cov=float(Q(inv)*Q(inv));ss=value(s['bits']);df=value(d['bits']);pre_root=float(Q(float(Q(ss)*Q(cov)))/Q(df));assert sqrt_cell(pre_root,value(a['bits']))
 old_pre_root=float(Q(float(Q(ss)/Q(df)))*Q(cov));counts[f+':old_association_disagrees']+=not sqrt_cell(old_pre_root,value(a['bits']));counts[f+':verified']+=1
print('Independent exact-rational multiply/divide and square-root cell checks:',dict(counts))
