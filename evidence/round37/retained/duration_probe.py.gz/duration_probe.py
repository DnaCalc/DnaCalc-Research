import sys,json,math,itertools,datetime as dt
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.fingerprint import CachedService,load_service,write,bits,sha
root=Path('/home/ubuntu/codex-runs/round37');out=root/'duration';out.mkdir()
c,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');s=CachedService(c.Client(timeout=300),root/'service-cache')
cases=[]
for n,f,base,coupon,offset in itertools.product((2,3,7,19),(1,2,4),(1.03125,1.125,1.5,3.),(0.,.0625,.03125),(0,1,17)):
 maturity_month=2020*12+n*(12//f);year,month=divmod(maturity_month,12)
 maturity=(dt.date(year,month+1,1)-dt.date(1899,12,30)).days
 cases.append(dict(id=str(len(cases)),n=n,frequency=f,base=base,rate=coupon,yield_=(base-1)*f,settlement=43831+offset,maturity=maturity,offset=offset))
# Small adjacent-yield runs cross a base-formation binade and general discounts.
for j in range(-8,9):
 y=float.fromhex('0x1.0000000000000p-3');u=int(bits(y),16)+j
 import struct
 y=struct.unpack('>d',bytes.fromhex(f'{u:016x}'))[0]
 cases.append(dict(id=str(len(cases)),n=7,frequency=2,base=1+y/2,rate=.0625,yield_=y,settlement=43848,maturity=(dt.date(2023,7,1)-dt.date(1899,12,30)).days,offset=17,adjacent=j))
rows=[[c.number(z[k])for k in ('settlement','maturity','rate','yield_','frequency')]+[c.number(0.)]for z in cases]
write(out/'questions.json',dict(cases=cases,rows=rows,producer_sha256=sha(__file__),selection='Fixed coupon counts, frequencies, exact yields/coupons, and settlement offsets. Adjacent yield run chosen before answers.'))
records=[]
for f in ('DURATION','MDURATION'):
 a=s.ask_rows(f,rows,chunk_size=300)
 records.extend(dict(case=z['id'],function=f,args=q,answer=v)for z,q,v in zip(cases,rows,a))
 print(f,len(a),flush=True)
# Observe schedule and positive powers as conditional leaves, never substitute answers for a calculation.
factors={}
for f in ('COUPDAYS','COUPDAYBS','COUPNUM'):
 q=[[c.number(z[k])for k in ('settlement','maturity','frequency')]+[c.number(0.)]for z in cases]
 factors[f]=s.ask_rows(f,q,chunk_size=300)
 print(f,len(q),flush=True)
write(out/'observations.json',dict(cases=cases,records=records,factors=factors,receipts=s.receipts,producer_sha256=sha(__file__),limits='General/fractional discount observations. All power/schedule equivalence remains conditional until tested.'))
