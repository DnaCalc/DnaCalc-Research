import sys,json,math,itertools,collections
import numpy as np
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/codex-runs/round37')
from qr_probe import bits,val,native,ext

def qr(x,y,p):
 normwide,dotwide,vvwide,updatewide,center=p
 def op(k,a,b):return float({'add':lambda:np.longdouble(a)+np.longdouble(b),'sub':lambda:np.longdouble(a)-np.longdouble(b),'mul':lambda:np.longdouble(a)*np.longdouble(b),'div':lambda:np.longdouble(a)/np.longdouble(b)}[k]())
 def sp(a,b,wide):
  s=0.
  for x,y in zip(a,b):s=float(np.longdouble(s)+np.longdouble(x)*np.longdouble(y))if wide else op('add',s,op('mul',x,y))
  return s
 n=len(y);xm=sum(x)/n;ym=sum(y)/n;cols=[[1.]*n,[v-xm for v in x]];yy=[v-ym for v in y]if center else y.copy();R=[]
 for j in range(2):
  c=cols[j];a=-math.copysign(math.sqrt(sp(c[j:],c[j:],normwide)),c[j]);v=c[j:];v[0]=op('sub',v[0],a)
  rest=sp(c[j+1:],c[j+1:],normwide);vv=float(np.longdouble(rest)+np.longdouble(v[0])*np.longdouble(v[0]))if vvwide else op('add',rest,op('mul',v[0],v[0]))
  for z in cols[j+1:]+[yy]:
   dot=sp(v,z[j:],dotwide);f=op('div',op('mul',2.,dot),vv)
   for k,vi in enumerate(v,j):z[k]=float(np.longdouble(z[k])-np.longdouble(f)*np.longdouble(vi))if updatewide else op('sub',z[k],op('mul',f,vi))
  R.append(a)
 ss=sum(t*t for t in yy[2:]);slope=yy[1]/R[1];intercept=ym-slope*xm
 return dict(ss=bits(ss),slope=bits(slope),intercept=bits(intercept),sy=bits(math.sqrt(ss/(n-2)))),dict(qty=yy,r=R)

p=Path('/home/ubuntu/codex-runs/round37/regression-residual');cases=json.load(open(p/'questions.json'))['cases'];rr=collections.defaultdict(dict)
for r in map(json.loads,open(p/'observations.jsonl')):
 if r['function']=='LINEST':rr[r['case']][tuple(r['result_index'])]=r['answer']
records=[]
for profile in itertools.product((False,True),repeat=5):
 first={};counts=collections.Counter()
 for c in cases:
  got,_=qr([v[0]for v in c['x']],[v[0]for v in c['y']],profile)
  for key,index in [('slope',(1,1)),('intercept',(1,2)),('ss',(5,2)),('sy',(3,2))]:
   want=rr[c['id']][index]['bits'];same=got[key]==want;counts[key]+=same
   if not same:first.setdefault(key,dict(case=c['id'],expected=want,got=got[key]))
 records.append(dict(profile=profile,rows=len(cases),counts=counts,first=first))
r=dict(axes=['norm_product_in_sum','dot_product_in_sum','vv_product_in_sum','update_product_in_subtraction','center_y'],profiles=records,survivors=[r for r in records if not r['first']],limits='Original reflector formula only; products retained at PC64 through their enclosing sum or subtraction. Array and named scalar writes remain binary64. Fixed32 profiles, no threshold/coefficient fitted; private inverse and publication consumers remain outside this study.')
Path('/home/ubuntu/codex-runs/round37/qr_resident.json').write_text(json.dumps(r,indent=2)+'\n');print('survivors',r['survivors']);print('SS survivors',[r['profile']for r in records if 'ss'not in r['first']])
