import sys,json,itertools,collections,subprocess
from pathlib import Path
import numpy as np
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.fingerprint import CachedService,load_service,write,bits,value,sha
root=Path('/home/ubuntu/codex-runs/round37');out=root/'hypergeom-components';out.mkdir();c,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');s=CachedService(c.Client(timeout=300),root/'service-cache')
cases=[dict(s=10.,n=20.,k=10.,N=50.,answer='3ef2dc0c835e2ed2'),dict(s=60.,n=200.,k=300.,N=1000.,answer='3fb19709a9b0281c'),dict(s=1.,n=3.,k=8.,N=20.,answer='3fdda46102b1da46')]
rows=[]
for z in cases:
 p=z['n']/z['N']
 for x,n in ((z['s'],z['k']),(z['n']-z['s'],z['N']-z['k']),(z['n'],z['N'])):rows.append([c.number(x),c.number(n),c.number(p),c.boolean(False)])
write(out/'questions.json',dict(cases=cases,rows=rows,producer_sha256=sha(__file__),source='Three unchanged corpus mass observations; only their public binomial components are fresh questions.'))
a=s.ask_rows('BINOM.DIST',rows);pred=[]
for i,z in enumerate(cases):
 aa,bb,cc=[value(t['bits'])for t in a[i*3:i*3+3]];p={}
 for mode,ass in itertools.product(('strict','pc64','resident_pc64'),range(3)):
  def op(k,a,b):
   if mode=='strict':return a*b if k=='mul'else a/b
   v=np.longdouble(a)*np.longdouble(b)if k=='mul'else np.longdouble(a)/np.longdouble(b)
   return float(v)if mode=='pc64'else v
  p[str((mode,ass))]=bits(op('mul',op('div',aa,cc),bb)if ass==0 else op('div',op('mul',aa,bb),cc)if ass==1 else op('mul',aa,op('div',bb,cc)))
 pred.append(dict(case=z,components=a[i*3:i*3+3],predictions=p,matching=[k for k,v in p.items()if v==z['answer']]))
write(out/'result.json',dict(records=pred,receipts=s.receipts,producer_sha256=sha(__file__),limits='Public binomial leaves, fixed three associations and three words. Original corpus HYPGEOM answers are retained; this does not equate every private component with its public counterpart.'))
qs=[dict(id=str(i),args=['0x'+v['bits']if v['type']=='number'else v['value']for v in r],expected='0x'+v['bits'])for i,(r,v)in enumerate(zip(rows,a))];write(out/'inputs.json',dict(function='BINOM.DIST',witnesses=qs));subprocess.run(['/home/ubuntu/projects/DnaCalc/DnaCalc-Research/target/release/symbolic-racer','invoke-inputs',str(out/'inputs.json'),str(out/'actual.jsonl')],check=True)
actual=[json.loads(l)for l in open(out/'actual.jsonl')]
for i,r in enumerate(pred):print(i,'matching',r['matching'],'binomial parts',[(q['expected'],t['calc_func_prediction'])for q,t in zip(qs[i*3:i*3+3],actual[i*3:i*3+3])],flush=True)
