import sys,json,math,itertools,struct,collections
import numpy as np
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer')
from x87_programs import Native,Ext
native=Native('/home/ubuntu/codex-runs/round37/libx87.so')
def ext(v):return bytes(np.longdouble(v).tobytes()[:10])
def val(b):return struct.unpack('>d',bytes.fromhex(b.removeprefix('0x')))[0]
def bits(v):return struct.pack('>d',float(v)).hex()
def qr(x,y,mode='strict',root='strict',target_mode=None):
 def op(kind,a,b=0.):
  if mode=='strict':return {'add':lambda:a+b,'sub':lambda:a-b,'mul':lambda:a*b,'div':lambda:a/b}[kind]()
  return val(f'{native.publish(native.leaf(kind,ext(a),ext(b),0x133f)):016x}')
 def sqrt(a):
  return math.sqrt(a) if root=='strict' else val(f'{native.publish(native.leaf("sqrt",ext(a),ext(0.),0x133f)):016x}')
 def ss(v):
  s=0.
  for z in v:s=op('add',s,op('mul',z,z))
  return s
 n=len(y); xm=sum(x)/n;ym=sum(y)/n
 cols=[[1.]*n,[v-xm for v in x]]; yy=[v-ym for v in y];r=[]
 for j in range(2):
  c=cols[j]; a=-math.copysign(sqrt(ss(c[j:])),c[j]); v=c[j:];v[0]=op('sub',v[0],a)
  vv=op('add',ss(c[j+1:]),op('mul',v[0],v[0]))
  for z in cols[j+1:]+[yy]:
   t=0.
   for vi,zi in zip(v,z[j:]):t=op('add',t,op('mul',vi,zi))
   f=op('div',op('mul',2.,t),vv)
   for k,vi in enumerate(v,j):z[k]=op('sub',z[k],op('mul',f,vi))
  r.append(a)
 return dict(r=r,qty=yy,mean=xm,offdiag=cols[1][0])
if __name__=='__main__':
 p=Path('/home/ubuntu/codex-runs/round37/regression-residual')
 cases=json.load(open(p/'questions.json'))['cases'];rr=collections.defaultdict(dict)
 for z in map(json.loads,open(p/'observations.jsonl')):
  if z['function']=='LINEST':rr[z['case']][tuple(z['result_index'])]=z['answer']
 profiles=list(itertools.product(('strict','pc64'),('strict','pc64'),('strict','stored_sum','resident_sum'),range(4)))
 scores=collections.Counter();kills={};records=[]
 for c in cases:
  r=rr[c['id']]
  if (5,2)not in r:continue
  want=r[(2,2)]['bits'];n=len(c['x']);x=[z[0] for z in c['x']];y=[z[0] for z in c['y']]
  for mode,root,accum,association in profiles:
   q=qr(x,y,mode,root)
   if accum=='strict':ss=sum(t*t for t in q['qty'][2:])
   elif accum=='stored_sum':
    ss=0.
    for t in q['qty'][2:]:ss=val(f'{native.publish(native.leaf("add",ext(ss),native.leaf("mul",ext(t),ext(t),0x133f),0x133f)):016x}')
   else:ss=sum((np.longdouble(t)*np.longdouble(t) for t in q['qty'][2:]),np.longdouble(0))
   inv=1./q['r'][0];cov=inv*inv
   if association==0:v=ss/(n-2)*cov
   elif association==1:v=ss*cov/(n-2)
   elif association==2:v=(np.sqrt(ss/(n-2))*inv)**2
   else:v=ss/(n-2)/n
   got=bits(np.sqrt(v));key=str((mode,root,accum,association));scores[key]+=want==got
   if want!=got:kills.setdefault(key,dict(case=c['id'],expected=want,got=got,public_ss=r[(5,2)]['bits'],qty=[bits(t)for t in q['qty']],qr_ss=bits(ss)))
  records.append(dict(case=c['id'],public={str(k):v for k,v in r.items()}))
 result=dict(rows=len(records),profiles=len(profiles),scores=dict(scores),first_failures=kills,survivors=[k for k,v in scores.items()if v==len(records)],limits='Fixed original Householder formula with strict or stored PC64 reflector operations and private tail sums. Means and centred inputs retain strict arithmetic. No coefficients fitted; non-survivors are refuted on these complete outputs.')
 Path('/home/ubuntu/codex-runs/round37/qr_analysis.json').write_text(json.dumps(result,indent=2)+'\n')
 print('rows',len(records),'survivors',result['survivors']);print(sorted(scores.items(),key=lambda kv:-kv[1])[:8])
