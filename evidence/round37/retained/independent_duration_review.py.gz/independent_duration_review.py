from pathlib import Path
from fractions import Fraction as Q
import math,json,gzip,struct,hashlib,collections
root=Path('/home/ubuntu/codex-runs/round37')
bits=lambda x:struct.pack('>d',float(x)).hex()
val=lambda x:struct.unpack('>d',bytes.fromhex(x))[0]
def rn64(q):
 if not q:return Q(0)
 sign=-1 if q<0 else 1;q=abs(q);e=q.numerator.bit_length()-q.denominator.bit_length()
 pow2=lambda k:Q(2**k)if k>=0 else Q(1,2**(-k))
 if q<pow2(e):e-=1
 scaled=q/pow2(e-63);n,r=divmod(scaled.numerator,scaled.denominator)
 if 2*r>scaled.denominator or 2*r==scaled.denominator and n%2:n+=1
 return sign*n*pow2(e-63)
def add(a,b):return float(rn64(Q(a)+Q(b)))
def div(a,b):return float(rn64(Q(a)/Q(b)))
qs=json.load(open(root/'duration-proof/predictions.json'))['cases'];pw=json.load(open(root/'duration-proof/powers.json'));powers={tuple(k):val(a['bits'])for k,a in zip(pw['keys'],pw['answers'])};answers={f:json.load(open(root/'duration-proof'/f'{f}.json'))['answers']for f in ('DURATION','MDURATION')};counts=collections.Counter()
for i,z in enumerate(qs):
 c=100.*z['rate']/z['frequency'];numerator=denominator=0.
 for k in range(1,z['n']+1):
  d=powers[bits(z['base']),bits(k)];pv=div(c,d);numerator=add(numerator,k*pv);denominator=add(denominator,pv)
 numerator=add(numerator,div(z['n']*100.,d));denominator=add(denominator,div(100.,d));duration=div(numerator,denominator)/z['frequency'];modified=div(duration,z['base'])
 for f,v in (('DURATION',duration),('MDURATION',modified)):
  assert bits(v)==answers[f][i]['bits'],(f,i,bits(v),answers[f][i]);counts[f]+=1
print('Independent exact-rational RN64 then binary64 replay:',dict(counts))
def canonical(a):
 if isinstance(a,list):return [canonical(v)for v in a]
 if not isinstance(a,dict):return a
 return {k:canonical(v)for k,v in a.items()if k!='mode'}
files=list((root/'service-cache').glob('*.json.gz'));requests={};total=collections.Counter();hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in files}
for p in files:
 d=json.load(gzip.open(p));q,r=d['request'],d['reply'];assert r['ok'] and len(q['rows'])==len(r['rows'])==len(r['inputs']),p
 assert canonical(q['rows'])==canonical(r['inputs']),p
 assert r['excel_build']=='20527',p
 ident=r['id'];assert ident not in requests or requests[ident]==d,p
 requests[ident]=d;total[q['function']]+=len(r['rows'])
print('Raw audited reply files:',len(files),'unique requests:',len(requests),'selections:',sum(total.values()),'per function:',dict(total))
verified=0
for p in root.rglob('*.json'):
 if 'service-cache' in p.parts:continue
 try:d=json.load(open(p))
 except (json.JSONDecodeError,UnicodeDecodeError):continue
 if not isinstance(d,dict):continue
 for r in d.get('receipts',[]):
  if not isinstance(r,dict)or 'file'not in r:continue
  assert hashes[r['file']]==r['sha256'],(p,r['file']);verified+=1
print('Retained receipt digest references verified:',verified)
