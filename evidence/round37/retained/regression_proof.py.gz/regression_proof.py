import sys,json,math,itertools,random,collections
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.fingerprint import CachedService,load_service,write,bits,value,sha
root=Path('/home/ubuntu/codex-runs/round37');out=root/'regression-proof';out.mkdir();rng=random.Random(370201);c,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');s=CachedService(c.Client(timeout=300),root/'service-cache');cases=[]
for n,scale,reverse,response in itertools.product((6,7,10,12,15,25),(-40,0,40),(False,True),range(4)):
 x=[[math.ldexp(float(2*i-n+1),scale)]for i in range(n)];y=[[rng.uniform(-3,3)]for _ in range(n)]
 if reverse:x.reverse();y.reverse()
 cases.append(dict(id=str(len(cases)),x=x,y=y,n=n,scale=scale,reverse=reverse,response=response))
write(out/'questions.json',dict(cases=cases,seed=370201,formula='sqrt((public_ss_residual * (binary64(1 / sqrt(n)) squared)) / public_df)',producer_sha256=sha(__file__),limits='Conditional consumer proof on zero-mean single predictors; private residuals and inverse off-diagonals are not claimed. No consumer/word is fitted after these answers.'))
observations=[];results={}
for function in ('LINEST','LOGEST'):
 rows=[[c.number_array([[2.**v[0]]for v in z['y']]if function=='LOGEST'else z['y']),c.number_array(z['x']),c.boolean(True),c.boolean(True)]for z in cases];outputs={}
 for selection in ((2,2),(5,2),(4,2)):
  a=s.ask_rows(function,rows,result_index=selection);outputs[selection]=a;observations.append(dict(function=function,selection=selection,rows=rows,answers=a));print(function,selection,len(a),flush=True)
 failed=[]
 for i,z in enumerate(cases):
  a=outputs[(2,2)][i];ss=value(outputs[(5,2)][i]['bits']);df=value(outputs[(4,2)][i]['bits']);inv=1./math.sqrt(z['n']);got=bits(math.sqrt((ss*(inv*inv))/df))
  if a.get('bits')!=got:failed.append(dict(case=z['id'],expected=a,prediction=got))
 results[function]=dict(rows=len(cases),matched=len(cases)-len(failed),failures=failed)
write(out/'result.json',dict(observations=observations,results=results,receipts=s.receipts,producer_sha256=sha(__file__),limits='Fresh conditional consumer proof. Public SSR and df are independently read from the same fit; a full private QR implementation still needs separate evidence.'))
print(results,flush=True)
