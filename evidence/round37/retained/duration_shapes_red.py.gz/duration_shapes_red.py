import sys,json,itertools,math,collections
from pathlib import Path
import numpy as np
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.fingerprint import CachedService,load_service,write,bits,value,sha
root=Path('/home/ubuntu/codex-runs/round37');data=json.load(open(root/'duration/observations.json'));cases=data['cases'];obs=[r for r in data['records']if r['function']=='DURATION'];fac=data['factors']
c,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');s=CachedService(c.Client(timeout=300),root/'service-cache')
def div(a,b,mode):return float(np.longdouble(a)/np.longdouble(b))if mode=='pc64'else float(a)/float(b)
requests={};times={}
for i,z in enumerate(cases):
 e=value(fac['COUPDAYS'][i]['bits']);a=value(fac['COUPDAYBS'][i]['bits']);n=int(value(fac['COUPNUM'][i]['bits']))
 for form in ('offset','day_numerator','complement'):
  t=[(e-a+k*e)/e if form=='day_numerator'else 1-a/e+k if form=='complement'else(e-a)/e+k for k in range(n)]
  times[i,form]=t
  for v in t:requests.setdefault((bits(z['base']),bits(v)),[c.number(z['base']),c.number(v)])
profiles=[dict(time=t,weighted=w,division=d,addition=a,redemption=r,final=f,red_weight=rw)for t,w,d,a,r,f,rw in itertools.product(('offset','day_numerator','complement'),('weight_first','pv_first'),('strict','pc64'),('strict','stored_pc64','resident_pc64'),('strict','pc64'),('strict','pc64'),('weight_first','pv_first'))]
write(root/'duration/power-questions-red.json',dict(profiles=profiles,requests=list(requests.values()),producer_sha256=sha(__file__),limits='Fixed positive-POWER cashflow programs; no score selects a program. Private power equivalence is conditional.'))
ans=s.ask_rows('POWER',list(requests.values()),chunk_size=500);powers=dict(zip(requests,[value(a['bits'])for a in ans]));write(root/'duration/powers-red.json',dict(keys=list(requests),answers=ans,receipts=s.receipts))
records=[]
for p in profiles:
 counts=collections.Counter();first={}
 for i,z in enumerate(cases):
  num=den=0.;coupon=100*z['rate']/z['frequency'];tt=times[i,p['time']]
  def add(a,b):
   if p['addition']=='strict':return float(a)+float(b)
   q=np.longdouble(a)+np.longdouble(b)
   return float(q) if p['addition']=='stored_pc64' else q
  for t in tt:
   disc=powers[bits(z['base']),bits(t)];pv=div(coupon,disc,p['division'])
   num=add(num,div(t*coupon,disc,p['division'])if p['weighted']=='weight_first'else t*pv);den=add(den,pv)
  t=tt[-1];disc=powers[bits(z['base']),bits(t)];redpv=div(100.,disc,p['redemption']);num=add(num,div(t*100,disc,p['redemption'])if p['red_weight']=='weight_first'else t*redpv);den=add(den,redpv)
  pred=bits(div(float(num),float(den),p['final'])/z['frequency']);target=obs[i]['answer']['bits'];same=pred==target
  group='coupon_date'if z['offset']==0 else'fractional';counts[group+'_rows']+=1;counts[group+'_matched']+=same
  if not same:first.setdefault(group,dict(case=z['id'],expected=target,got=pred))
 records.append(dict(profile=p,counts=counts,first=first))
result=dict(profiles=records,survivors=[r for r in records if not r['first']],coupon_date_survivors=[r for r in records if 'coupon_date'not in r['first']],limits='Fixed measured positive-POWER leaf and three time expressions; sequential weighted coupons, redemption last. Four stage words with coherent sum policies. Resident sums are explicitly stored before the final ratio. All failures stay recorded. No product gain or private power identification.')
write(root/'duration/shapes-red.json',result);print('profiles',len(profiles),'survivors',len(result['survivors']),'on coupon',len(result['coupon_date_survivors']),flush=True)
