import sys,json,math,itertools,datetime as dt,random
from pathlib import Path
import numpy as np
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.fingerprint import CachedService,load_service,write,bits,value,sha
root=Path('/home/ubuntu/codex-runs/round37');out=root/'duration-proof';out.mkdir();rng=random.Random(370303)
c,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');s=CachedService(c.Client(timeout=300),root/'service-cache');cases=[];requests={}
for n,f,base,exponent in itertools.product((2,4,6,11,23,37),(1,2,4),(1.+19./2048.,1.07,1.625,3.5),(-50,-10,-1,30)):
 rate=math.ldexp(1.+rng.random(),exponent);yield_=(base-1.)*f
 mo=2020*12+n*(12//f);year,month=divmod(mo,12);maturity=(dt.date(year,month+1,1)-dt.date(1899,12,30)).days
 cases.append(dict(id=str(len(cases)),n=n,frequency=f,base=base,rate=rate,yield_=yield_,settlement=43831,maturity=maturity))
 for k in range(1,n+1):requests.setdefault((bits(base),bits(k)),[c.number(base),c.number(float(k))])
write(out/'questions.json',dict(cases=cases,power_requests=list(requests.values()),seed=370303,producer_sha256=sha(__file__),formula='Coupon PV = C/disc; numerator += k*PV; denominator += PV, in forward order. Redemption (k*100)/disc and 100/disc store PC64 quotients, last. Stored PC64 coupon quotients, numerator and denominator additions, and final ratio; exact frequency division. No fit.'))
a=s.ask_rows('POWER',list(requests.values()),chunk_size=500);powers=dict(zip(requests,[value(v['bits'])for v in a]));write(out/'powers.json',dict(keys=list(requests),answers=a,receipts=s.receipts))
def div64(a,b):return float(np.longdouble(a)/np.longdouble(b))
for z in cases:
 coupon=100*z['rate']/z['frequency'];num=den=0.
 for k in range(1,z['n']+1):
  disc=powers[bits(z['base']),bits(k)];pv=div64(coupon,disc);num=float(np.longdouble(num)+np.longdouble(k*pv));den=float(np.longdouble(den)+np.longdouble(pv))
 disc=powers[bits(z['base']),bits(z['n'])];num=float(np.longdouble(num)+np.longdouble(div64(z['n']*100.,disc)));den=float(np.longdouble(den)+np.longdouble(div64(100.,disc)))
 z['prediction']=bits(div64(num,den)/z['frequency']);z['md_prediction']=bits(div64(value(z['prediction']),z['base']))
write(out/'predictions.json',dict(cases=cases,producer_sha256=sha(__file__)))
rows=[[c.number(z[k])for k in ('settlement','maturity','rate','yield_','frequency')]+[c.number(0.)]for z in cases]
for function,key in (('DURATION','prediction'),('MDURATION','md_prediction')):
 a=s.ask_rows(function,rows,chunk_size=300);fails=[dict(case=z['id'],expected=v,prediction=z[key])for z,v in zip(cases,a)if v.get('bits')!=z[key]]
 write(out/(function+'.json'),dict(answers=a,receipts=s.receipts,rows=len(cases),matched=len(cases)-len(fails),failures=fails,producer_sha256=sha(__file__),limits='Fresh actual function answers; public POWER remains a conditional leaf. Every numeric mismatch is counted.'))
 print(function,'matched',len(cases)-len(fails),'/',len(cases),'first',fails[:1],flush=True)
