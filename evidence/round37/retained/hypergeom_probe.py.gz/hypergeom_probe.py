import sys,json,itertools,collections,math
from pathlib import Path
import numpy as np
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.fingerprint import CachedService,load_service,write,bits,value,sha
root=Path('/home/ubuntu/codex-runs/round37');out=root/'hypergeom';out.mkdir();c,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');s=CachedService(c.Client(timeout=300),root/'service-cache');cases=[];requests={}
for N in (8,16,32,256,1024,65536):
 for k,success in itertools.product(sorted(set((1,2,3,N//3,N//2,N-3,N-2,N-1))),(0,1)):
  p=1./N
  for x,n in ((success,k),(1-success,N-k),(1,N)):requests.setdefault((bits(x),bits(n),bits(p)),[c.number(float(x)),c.number(float(n)),c.number(p),c.boolean(False)])
  cases.append(dict(id=str(len(cases)),N=N,k=k,success=success,p=p,quotient=bits((k if success else N-k)/N)))
write(out/'questions.json',dict(cases=cases,binomial_requests=list(requests.values()),producer_sha256=sha(__file__),selection='Single-draw hypergeometric mapping at exact dyadic sampling probabilities; both complementary masses, population exponent edges and varied success populations.'))
a=s.ask_rows('BINOM.DIST',list(requests.values()));leaves=dict(zip(requests,[value(z['bits'])for z in a]));write(out/'binomial.json',dict(keys=list(requests),answers=a,receipts=s.receipts))
profiles=list(itertools.product(('strict','pc64','resident_pc64'),range(3)));predictions=[]
for z in cases:
 aa,bb,cc=[leaves[bits(x),bits(n),bits(z['p'])]for x,n in ((z['success'],z['k']),(1-z['success'],z['N']-z['k']),(1,z['N']))]
 pred=[]
 for mode,association in profiles:
  def mul(a,b):
   if mode=='strict':return float(a)*float(b)
   r=np.longdouble(a)*np.longdouble(b);return float(r)if mode=='pc64'else r
  def div(a,b):
   if mode=='strict':return float(a)/float(b)
   r=np.longdouble(a)/np.longdouble(b);return float(r)if mode=='pc64'else r
  pred.append(bits(mul(div(aa,cc),bb)if association==0 else div(mul(aa,bb),cc)if association==1 else mul(aa,div(bb,cc))))
 predictions.append(pred)
write(out/'predictions.json',dict(profiles=profiles,predictions=predictions,producer_sha256=sha(__file__)))
a=s.ask_rows('HYPGEOM.DIST',[[c.number(z['success']),c.number(1.),c.number(z['k']),c.number(z['N']),c.boolean(False)]for z in cases]);records=[]
for j,p in enumerate(profiles):
 fails=[dict(case=z['id'],expected=w,prediction=q[j])for z,w,q in zip(cases,a,predictions)if w.get('bits')!=q[j]]
 records.append(dict(profile=p,matched=len(cases)-len(fails),failures=fails))
write(out/'result.json',dict(cases=cases,answers=a,receipts=s.receipts,rows=len(cases),programs=records,survivors=[r for r in records if not r['failures']],strict_quotient_matches=sum(w.get('bits')==z['quotient']for z,w in zip(cases,a)),producer_sha256=sha(__file__),limits='Public BINOM.DIST masses are conditional leaves. Sampling probability and its complement are exact on this dyadic domain. No claim that private binomial leaves equal public outputs elsewhere. No coefficient/selector fitted.'))
print('rows',len(cases),'quotient',sum(w.get('bits')==z['quotient']for z,w in zip(cases,a)),'survivors',[(r['profile'],r['matched'])for r in records if not r['failures']],flush=True)
