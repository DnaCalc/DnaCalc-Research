from pathlib import Path
import json,gzip,hashlib
root=Path('/home/ubuntu/codex-runs/round37')
repo=Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
out=repo/'evidence/round37';dest=out/'retained';dest.mkdir(exist_ok=True)
files=[]
for p in sorted(root.rglob('*')):
 if not p.is_file()or p.suffix not in ('.json','.jsonl','.py','.log','.txt','.md','.gz','.c'):continue
 rel=p.relative_to(root)
 if any(x in rel.parts for x in ('__pycache__','classification')):continue
 if rel.parts[0]=='baseline-receipt'and p.name not in ('receipt.json','bank-counts.json','bank.log'):continue
 if p.name in ('ubs-main.json','ubs-main.stderr.txt'):continue
 raw=p.read_bytes();packed=gzip.compress(raw,compresslevel=9,mtime=0);target=dest/(str(rel)+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(packed)
 files.append(dict(path=str(target.relative_to(repo)),source_sha256=hashlib.sha256(raw).hexdigest(),gzip_sha256=hashlib.sha256(packed).hexdigest(),bytes=len(raw),compressed_bytes=len(packed)))
(out/'files.json').write_text(json.dumps(files,indent=2)+'\n')
# Verify every published compressed byte and its original contents.
for r in files:
 p=repo/r['path'];packed=p.read_bytes();raw=gzip.decompress(packed)
 assert hashlib.sha256(packed).hexdigest()==r['gzip_sha256']and hashlib.sha256(raw).hexdigest()==r['source_sha256']
print(dict(files=len(files),compressed_bytes=sum(r['compressed_bytes']for r in files),uncompressed_bytes=sum(r['bytes']for r in files)))
