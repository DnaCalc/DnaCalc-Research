import sys,json,math,itertools,collections
from pathlib import Path
import numpy as np
from fractions import Fraction
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.fingerprint import CachedService,load_service,write,bits,value,sha,integer_gamma_polynomial_graph
from racer.x87_programs import Native
root=Path('/home/ubuntu/codex-runs/round37');out=root/'poisson-mapping-v2';out.mkdir();c,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');s=CachedService(c.Client(timeout=300),root/'service-cache');native=Native(root/'libx87.so');cases=[]
for count in (1,2,3,9,18,19,20,21,29,30,31,39,63,100):
 a=count+1.
 means=sorted(set([a*.5,a,a+1.,a+5.,a*1.5]+[value(f'{int(bits(edge),16)+j:016x}')for edge in (a,30.,31.)for j in (-2,-1,0,1,2)]))
 for mean in means:cases.append(dict(id=str(len(cases)),count=count,mean=bits(mean)))
write(out/'questions.json',dict(cases=cases,producer_sha256=sha(__file__),selection='Shape mapping at integer shape, relative mean and consecutive inputs around a,30,31. The previously identified reciprocal-factorial Horner shape is fixed; degree follows the distribution count, never the residual.'))
e=s.ask_rows('EXP',[[c.number(bits(-value(z['mean'])))]for z in cases]);predictions=[]
for z,exp in zip(cases,e):
 g=integer_gamma_polynomial_graph(z['count'],'factorial_coefficients')
 for n in g['nodes']:
  if n.get('site',-1)>=0:n['site']=0
 g['sites']=1
 args=[int(z['mean'],16),int(exp['bits'],16)];pred={}
 for label,cw in (('strict',0x123f),('pc64',0x133f)):
  def ext(v):return np.longdouble(v).tobytes()[:10]
  def operation(kind,a,b):return value(f'{native.publish(native.leaf(kind,ext(a),ext(b),cw),cw):016x}')
  xx=value(z['mean']);k=z['count'];v=float(Fraction(1,math.factorial(k)))
  for j in range(k-1,-1,-1):v=operation('add',operation('mul',v,xx),float(Fraction(1,math.factorial(j))))
  calculated=bits(operation('mul',value(exp['bits']),v))
  if len(g['nodes'])<=128:
   r=native.evaluate(g,args,cw,1)
   if calculated!=f'{native.publish(r[:10],cw):016x}':raise ValueError('leaf/Horner graph disagreement')
  pred[label]=calculated
 predictions.append(dict(z,exp=exp,predictions=pred))
write(out/'predictions.json',dict(records=predictions,producer_sha256=sha(__file__)))
answers={}
for name in ('POISSON.DIST','CHISQ.DIST.RT','GAMMA.DIST'):
 if name=='POISSON.DIST':rows=[[c.number(z['count']),c.number(z['mean']),c.boolean(True)]for z in cases]
 elif name=='CHISQ.DIST.RT':rows=[[c.number(2*value(z['mean'])),c.number(2*(z['count']+1.))]for z in cases]
 else:rows=[[c.number(z['mean']),c.number(z['count']+1.),c.number(1.),c.boolean(True)]for z in cases]
 answers[name]=s.ask_rows(name,rows);print(name,len(rows),flush=True)
records=[];groups=collections.defaultdict(collections.Counter)
for i,z in enumerate(predictions):
 a={k:v[i]for k,v in answers.items()};count=z['count'];g=groups[str(count)];g['rows']+=1;g['poisson_chisq_equal']+=a['POISSON.DIST']==a['CHISQ.DIST.RT'];g['one_minus_gamma_equal']+=a['POISSON.DIST'].get('bits')==bits(1-value(a['GAMMA.DIST']['bits']));g['pc64_polynomial']+=a['POISSON.DIST'].get('bits')==z['predictions']['pc64'];g['strict_polynomial']+=a['POISSON.DIST'].get('bits')==z['predictions']['strict'];records.append(dict(z,answers=a))
write(out/'result.json',dict(records=records,groups=groups,receipts=s.receipts,producer_sha256=sha(__file__),limits='Mapping beyond the previously measured finite polynomial region. Every discrepancy remains; failed whole shapes are not extended with a corrective piece. Independently observed EXP is a conditional leaf. No inverse algorithm or application improvement follows from these observations.'))
print(json.dumps(groups),flush=True)
