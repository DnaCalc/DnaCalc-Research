import sys,json,math,collections,subprocess
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.fingerprint import CachedService,load_service,write,bits,sha
r=Path('/home/ubuntu/codex-runs/round38');out=r/'ets-horizon-fresh';out.mkdir(exist_ok=False)
c,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');s=CachedService(c.Client(timeout=300),r/'horizon-fresh-cache');cases=[]
for origin,step in ((-73.,.25),(12345.,4.),(-512.,32.),(0.,2.**-20)):
 for a,b,scale in ((-17,5,-200),(31,-7,0),(0,0,200)):
  for h in (2**31-3,2**31-1,2**31,2**31+3,2**32):
   cases.append(dict(y=[math.ldexp(a+i*b,scale)for i in range(5)],t=[origin+i*step for i in range(5)],target=origin+(4+h)*step,h=h))
q=collections.defaultdict(list)
for z in cases:
 y=c.number_array([[v]for v in z['y']]);t=c.number_array([[v]for v in z['t']]);base=[c.number(z['target']),y,t]
 q['FORECAST.ETS'].append(base+[c.number(0.)])
 for p in (0.,.875):q['FORECAST.ETS.CONFINT'].append(base+[c.number(p),c.number(0.)])
write(out/'questions.json',dict(cases=cases,questions=q,producer_sha256=sha(__file__),limits='Independent translated/scaled timelines and signed affine histories, frozen after the integer horizon shape and final exact-arithmetic admission were chosen.'))
exe=Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research/target/release/symbolic-racer');pred={}
def decode(a):return '0x'+a['bits']if a['type']=='number'else[[decode(v)for v in row]for row in a['values']]
for name,rows in q.items():
 inp=out/(name+'.input.json');o=out/(name+'.prediction.jsonl');write(inp,dict(function=name,witnesses=[dict(id=str(i),args=list(map(decode,row)))for i,row in enumerate(rows)]));subprocess.run([str(exe),'invoke-inputs',str(inp),str(o)],check=True,timeout=120);pred[name]=[json.loads(line)['calc_func_prediction']for line in o.read_text().splitlines()]
write(out/'prediction-binding.json',dict(predictions=pred,executable_sha256=sha(exe),producer_sha256=sha(__file__)))
results={}
for name,rows in q.items():
 ans=s.ask_rows(name,rows,chunk_size=80);fail=[]
 for i,(p,a)in enumerate(zip(pred[name],ans)):
  expected='0x'+a['bits']if a['type']=='number'else'error:'+{'#NUM!':'Num'}[a['code']]
  if p!=expected:fail.append(dict(index=i,prediction=p,answer=a))
 results[name]=dict(rows=len(rows),matched=len(rows)-len(fail),failures=fail,answers=ans)
write(out/'result.json',dict(functions=results,receipts=s.receipts,producer_sha256=sha(__file__)));print({k:(v['matched'],v['rows'])for k,v in results.items()},flush=True)
