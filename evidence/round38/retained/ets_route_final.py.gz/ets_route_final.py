import sys,json,gzip,collections,subprocess,hashlib
from pathlib import Path
r=Path('/home/ubuntu/codex-runs/round38');exe=Path(sys.argv[1]).resolve();out=r/sys.argv[2];out.mkdir(exist_ok=False)
def decode(a):
 if a['type']=='number':return '0x'+a['bits']
 if a['type']=='array':return [[decode(v)for v in row]for row in a['values']]
 if a['type']=='boolean':return a['value']
 raise ValueError(a)
def answer(a):
 if a['type']=='number':return '0x'+a['bits']
 if a['type']=='error':return 'error:'+{'#NUM!':'Num','#N/A':'NA','#DIV/0!':'Div0','#VALUE!':'Value'}[a['code']]
 raise ValueError(a)
groups=collections.defaultdict(list);bindings={};seen=set()
for folder in sorted(p.name for p in r.glob('*cache') if p.is_dir()):
 for p in sorted((r/folder).glob('*.json.gz')):
  if '.refusal-'in p.name:continue
  d=json.load(gzip.open(p,'rt'));req,rep=d['request'],d['reply']
  if not req['function'].startswith('FORECAST.ETS') or not rep.get('ok'):continue
  if rep['id']in seen:continue
  seen.add(rep['id']);bindings[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
  for i,(a,v)in enumerate(zip(req['rows'],rep['rows'])):groups[req['function']].append(dict(id=rep['id']+':'+str(i),args=list(map(decode,a)),expected=answer(v),source=folder))
summary={};incorrect=[]
for name,rows in groups.items():
 q=out/(name+'.inputs.json');q.write_text(json.dumps(dict(function=name,witnesses=rows),separators=(',',':'))+'\n');p=out/(name+'.predictions.jsonl');subprocess.run([str(exe),'invoke-inputs',str(q),str(p)],check=True,timeout=300)
 a=[json.loads(z)for z in p.read_text().splitlines()];assert len(a)==len(rows);counts=collections.Counter();by=collections.defaultdict(collections.Counter)
 for row,z in zip(rows,a):
  assert row['id']==z['id'];pred=z['calc_func_prediction'];kind='matched'if pred==row['expected']else'refused'if pred.startswith('fault:')else'mismatched';counts[kind]+=1;by[row['source']][kind]+=1
  if kind=='mismatched':incorrect.append(dict(function=name,**row,prediction=pred))
 summary[name]=dict(rows=len(rows),counts=counts,by_source=by)
 q.with_suffix(q.suffix+'.gz').write_bytes(gzip.compress(q.read_bytes(),mtime=0));q.unlink();p.with_suffix(p.suffix+'.gz').write_bytes(gzip.compress(p.read_bytes(),mtime=0));p.unlink()
result=dict(executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),sources=bindings,functions=summary,incorrect=incorrect,limits='Actual registered CalcFunc invocation on audited original typed arrays. A refusal is a failure; matched includes typed worksheet errors. No predicted value is treated as an Excel answer.')
(out/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(summary));print('incorrect',len(incorrect),incorrect[:5])
