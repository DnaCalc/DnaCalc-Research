import json,re,hashlib
from pathlib import Path
def ets_catalogue(checkout, design, cache, output, executable=None):
    """Map audited ETS scalar replies into the existing catalogue/verdict route.

    First writes the section and its immutable call-to-reply map. After the
    repository generator runs, a second invocation with executable audits all
    numeric literals through Workbook::enter and writes the canonical section
    record. These are function questions, never a claimed workbook round trip.
    """
    import gzip
    import subprocess
    from fingerprint import accept, bits, value, sha, write
    checkout, design, cache, output = map(lambda p: Path(p).resolve(), (checkout, design, cache, output))
    sheet = 'dcj9k_r38_ets'
    prepared = output/'prepared.json'
    import sys
    sys.path.insert(0, str(checkout/'tools/excel-service'))
    from client import number, number_array
    leaves = {}
    def expression(arg):
        if arg['type'] == 'array':
            return '{'+';'.join(','.join(expression(v) for v in row) for row in arg['values'])+'}'
        if arg['type'] != 'number':
            raise ValueError('only audited numeric vectors are admitted')
        v = value(arg['bits'])
        if not __import__('math').isfinite(v):
            raise ValueError('nonfinite numeric literal')
        text = format(v, '.15g')
        if bits(float(text)) != arg['bits']:
            raise ValueError('numeric operand has no admitted 15-digit literal spelling')
        leaves[text] = '0x'+arg['bits']
        return text
    def selected_calls(z):
        y = number_array([[v] for v in z['y']]); t = number_array([[float(v)] for v in z['timeline']])
        tail = [number(float(z[k])) for k in ('seasonality','data_completion','aggregation')]
        target = number(float(max(z['timeline'])+1))
        return [('FORECAST.ETS', [target,y,t]+tail),
            ('FORECAST.ETS.CONFINT', [target,y,t,number(.95)]+tail),
            ('FORECAST.ETS.SEASONALITY', [y,t]+tail[1:]),
            ('FORECAST.ETS.STAT', [y,t,number(8.)]+tail)]
    if executable is None:
        output.mkdir(parents=True, exist_ok=False)
        observed = {}
        def identity(name, args):
            return json.dumps(dict(function=name, rows=[args]), sort_keys=True, separators=(',', ':'))
        for path in sorted(cache.glob('*.json.gz')):
            if '.refusal-' in path.name:
                continue
            doc = json.load(gzip.open(path, 'rt'))
            request, reply = doc['request'], doc['reply']
            if request['function'] not in ('FORECAST.ETS','FORECAST.ETS.CONFINT','FORECAST.ETS.SEASONALITY','FORECAST.ETS.STAT'):
                continue
            accept(reply, request['function'], request['rows'])
            for index, (args, answer) in enumerate(zip(request['rows'], reply['rows'])):
                key = identity(request['function'], args)
                row = dict(answer=answer, request_id=reply['id'], index=index,
                    raw_file=path.name, raw_sha256=sha(path), environment=reply.get('calculation_settings'),
                    excel_file_version=reply.get('excel_file_version'), excel_build=reply.get('excel_build'))
                if key in observed and observed[key]['answer'] != answer:
                    raise ValueError('inconsistent repeated ETS question')
                observed[key] = row
        rows = []
        cases = json.loads(design.read_text())['cases']
        if len(cases) != 980:
            raise ValueError('the retained design changed')
        for case, z in enumerate(cases):
            calls = selected_calls(z)
            for name, args in calls:
                observation = observed.get(identity(name, args))
                if observation is None:
                    raise ValueError(f'unanswered {case} {name}; keep the partial raw replies')
                formula = '_xlfn.'+name+'('+','.join(map(expression,args))+')'
                rows.append(dict(case=case,row=len(rows)+1,column=4,function=name,args=args,
                    formula=formula,**observation))
        section = output/('sheet-'+sheet+'.txt')
        section.write_text('# dc-j9k R38: four measured ETS surfaces per retained design case.\n'+
                           '\n'.join(z['formula'] for z in rows)+'\n')
        write(prepared, dict(sheet=sheet,rows=rows,leaves=leaves,design_sha256=sha(design),
            section_sha256=sha(section),producer_sha256=sha(__file__),
            selection='One next-step forecast, .95 confidence, detected period and step statistic for every retained design case, without answer-dependent selection.'))
        print('prepared',len(rows),'measured cells; literals',len(leaves))
        return
    executable = Path(executable).resolve()
    doc = json.loads(prepared.read_text())
    cases = json.loads(design.read_text())['cases']
    if sha(design) != doc['design_sha256'] or len(cases) != 980 or len(doc['rows']) != 4*len(cases):
        raise ValueError('the frozen design or prepared selection changed')
    raw = {}
    for index, z in enumerate(doc['rows']):
        name, args = selected_calls(cases[index//4])[index%4]
        if z['case'] != index//4 or z['row'] != index+1 or z['column'] != 4 or z['function'] != name or z['args'] != args:
            raise ValueError('prepared call differs from the retained design')
        file = z['raw_file']
        if re.fullmatch(r'[0-9a-f]{64}\.json\.gz',file) is None:
            raise ValueError('invalid raw cache basename')
        if file not in raw:
            if sha(cache/file) != z['raw_sha256']:
                raise ValueError('original reply changed')
            raw[file] = json.load(gzip.open(cache/file,'rt'))
            accept(raw[file]['reply'],raw[file]['request']['function'],raw[file]['request']['rows'])
        original = raw[file]; request, reply = original['request'], original['reply']; slot = z['index']
        if (request.get('result_index') is not None or request['function'] != name or
            not isinstance(slot,int) or slot < 0 or slot >= len(request['rows']) or
            request['rows'][slot] != args or reply['id'] != z['request_id'] or
            reply['rows'][slot] != z['answer'] or reply.get('calculation_settings') != z['environment'] or
            reply.get('excel_file_version') != z['excel_file_version'] or reply.get('excel_build') != z['excel_build']):
            raise ValueError('prepared cell is not the original audited reply')
        formula = '_xlfn.'+name+'('+','.join(map(expression,args))+')'
        if z['formula'] != formula:
            raise ValueError('formula differs from its audited numeric call')
    if leaves != doc['leaves']:
        raise ValueError('prepared operand-echo inventory changed')
    fixture = checkout/'crates/calc-func/tests/fixtures'/sheet/'oracle.xlsx'
    keys = json.loads(subprocess.check_output([str(executable),'oracle-section-keys',str(fixture)], timeout=120))  # ubs:ignore — operator-selected local research executable, fixed argv, bounded runtime, no shell
    section = next(z for z in keys if z['sheet'] == sheet)
    if section['formula_cells'] != len(doc['rows']):
        raise ValueError('catalogue section cell count changed')
    # Check the actual generated worksheet, independently of its section text.
    from zipfile import ZipFile
    import xml.etree.ElementTree as ET
    ns = {'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
    with ZipFile(fixture) as package:
        workbook = ET.fromstring(package.read('xl/workbook.xml'))
        names = [s.attrib['name'] for s in workbook.find('m:sheets',ns)]
        worksheet = ET.fromstring(package.read(f'xl/worksheets/sheet{names.index(sheet)+1}.xml'))
        formulas = {cell.attrib['r']:cell.find('m:f',ns).text for cell in worksheet.findall('.//m:c',ns) if cell.find('m:f',ns) is not None}
    if formulas != {f"D{z['row']}":z['formula'] for z in doc['rows']}:
        raise ValueError('generated formulas differ from audited calls')
    echo = output/'operand-echo-questions.json'
    echo.write_text(json.dumps(dict(questions=[dict(id=str(i),row=i+1,column=4,formula=literal)
        for i,literal in enumerate(doc['leaves'])]),indent=2)+'\n')
    predictions = output/'operand-echo-predictions.jsonl'
    subprocess.run([str(executable),'sheet-predictions',str(echo),str(predictions)],check=True,timeout=180)  # ubs:ignore — operator-selected local research executable, fixed argv and bounded runtime, no shell
    actual = [json.loads(line) for line in predictions.read_text().splitlines()]
    if len(actual) != len(doc['leaves']):
        raise ValueError('missing operand echoes')
    for row, expected in zip(actual, doc['leaves'].values()):
        if row['prediction_provenance'] != 'calculated' or row['calc_func_prediction'] != expected:
            raise ValueError('formula parsing changes a numeric operand')
    sources = {z['raw_file']:z['raw_sha256'] for z in doc['rows']}
    for file, digest in sources.items():
        if sha(cache/file) != digest:
            raise ValueError('original reply changed')
    mapping = dict(format='dnacalc-function-question-map/1',sheet=sheet,section_key=section['key'],
        package_sha256=sha(fixture),prepared_sha256=sha(prepared),operand_echo_sha256=sha(predictions),
        executable_sha256=sha(executable),raw_replies=sources,
        cells=[dict(cell=f"D{z['row']}",request_id=z['request_id'],index=z['index'],raw_file=z['raw_file'],
                    formula=z['formula'],args=z['args'],answer=z['answer'],environment=z['environment'])for z in doc['rows']],
        limits='Original raw Value2 questions and audited numeric operands. The committed workbook was not opened, saved or reopened in Excel. Formula values still run through the ordinary application evaluator and canonical verdict.')
    mapping_path = output/'mapping.json.gz'
    mapping_path.write_bytes(gzip.compress(json.dumps(mapping,separators=(',',':')).encode(),mtime=0))
    error_names={'#NUM!':'num','#N/A':'na','#DIV/0!':'div0','#VALUE!':'value'}
    observations=[]
    for z in doc['rows']:
        answer=z['answer'];raw=({'number':answer['bits']} if answer['type']=='number' else
                              {'error':error_names[answer['code']]})
        observations.append(dict(sheet=sheet,row=z['row'],column=4,excel_raw=raw))
    # Version three explicitly records scalar questions without an invented
    # workbook session. Corpus's independent evaluation record still proves returns.
    record=dict(format='dnacalc-capture-record',version=3,case=sheet+'__'+sheet,source=section['key'],
        acquisition=dict(kind='function_questions',entry='DnaCalc-Research/evidence/round38/ets-catalogue/mapping.json.gz;sha256:'+sha(mapping_path)),
        environment=None,sheets=[dict(name=sheet,visibility='visible')],
        formulas=[dict(sheet=sheet,row=z['row'],column=4,kind='ordinary',formula='='+z['formula'])for z in doc['rows']],observations=observations)
    destination=checkout/'crates/calc-func/tests/captures'/sheet/'sections'/f'{sheet}.capture.json'
    destination.parent.mkdir(parents=True, exist_ok=True)
    authored = output/'capture-input.json'
    with authored.open('x') as stream:
        json.dump(record,stream,indent=2);stream.write('\n')
    subprocess.run([str(executable),'encode-capture',str(authored),str(destination)],check=True,timeout=120)  # ubs:ignore — frozen local codec executable and explicit argv; create-new output, bounded runtime, no shell
    write(output/'receipt.json',dict(cells=len(observations),capture_sha256=sha(destination),mapping_sha256=sha(mapping_path),
        source=section['key'],raw_reply_files=len(sources),operand_literals=len(actual),producer_sha256=sha(__file__)))
    print('imported',len(observations),'function observations;',len(actual),'literal echoes verified')
