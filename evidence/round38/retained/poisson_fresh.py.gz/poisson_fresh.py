import sys,json,itertools,math,collections
from pathlib import Path
from fractions import Fraction
import numpy as np
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.fingerprint import CachedService,load_service,write,bits,value,sha
r=Path('/home/ubuntu/codex-runs/round38');out=r/'poisson-fresh';out.mkdir(exist_ok=False)
c,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');s=CachedService(c.Client(timeout=300),r/'later-cache');cases=[]
for k in (1,2,3,9,18,19,20,29,30,100):
 for edge in (float(k+1),31.):
  for j in (-3,-1,0,1,3):cases.append(dict(count=k,mean=bits(value(f'{int(bits(edge),16)+j:016x}'))))
 for factor in (.5,1.5):cases.append(dict(count=k,mean=bits((k+1)*factor)))
write(out/'questions.json',dict(cases=cases,producer_sha256=sha(__file__),limits='Fresh single-bit and exponent-boundary controls around integer-shape and x=31 dispatch boundaries. Polynomial degree remains exactly the Poisson count; no corrective pieces fitted.'))
exps=s.ask_rows('EXP',[[c.number(-value(z['mean']))]for z in cases]);pred=[]
for z,e in zip(cases,exps):
 v=float(Fraction(1,math.factorial(z['count'])));x=value(z['mean'])
 for j in range(z['count']-1,-1,-1):v=float(np.longdouble(float(np.longdouble(v)*np.longdouble(x)))+np.longdouble(float(Fraction(1,math.factorial(j)))))
 pred.append(bits(float(np.longdouble(value(e['bits']))*np.longdouble(v))))
write(out/'predictions.json',dict(predictions=pred,exponentials=exps,producer_sha256=sha(__file__)))
answers={}
for name in ('POISSON.DIST','CHISQ.DIST.RT','GAMMA.DIST'):
 if name=='POISSON.DIST':rows=[[c.number(float(z['count'])),c.number(z['mean']),c.boolean(True)]for z in cases]
 elif name=='CHISQ.DIST.RT':rows=[[c.number(2*value(z['mean'])),c.number(2.*(z['count']+1))]for z in cases]
 else:rows=[[c.number(z['mean']),c.number(float(z['count']+1)),c.number(1.),c.boolean(True)]for z in cases]
 answers[name]=s.ask_rows(name,rows,chunk_size=300);print(name,len(rows),flush=True)
counts=collections.Counter();first={}
for i,z in enumerate(cases):
 a=answers['POISSON.DIST'][i];counts['rows']+=1;counts['poisson_chisq_equal']+=a==answers['CHISQ.DIST.RT'][i];same=a.get('bits')==pred[i];counts['polynomial_matched']+=same
 interior=z['count']+1<20 and z['count']+1<=value(z['mean'])<31;counts['interior_rows'if interior else'outside_rows']+=1;counts['interior_matched'if interior else'outside_matched']+=same
 if not same:first.setdefault('polynomial',dict(case=i,input=z,answer=a,prediction=pred[i]))
quantiles=[dict(shape=float(k+1),p=p)for k,p in itertools.product((1,5,18,19,20,100),(.03125,.125,.375,.5,.875,.96875))]
write(out/'inverse-questions.json',dict(cases=quantiles,producer_sha256=sha(__file__),premise='The published inverse is the least binary64 x whose public CDF is at least p. This premise is tested, not assumed.'))
inv=s.ask_rows('GAMMA.INV',[[c.number(z['p']),c.number(z['shape']),c.number(1.)]for z in quantiles]);rows=[]
for z,v in zip(quantiles,inv):
 for step in (-1,0,1):rows.append([c.number(f"{int(v['bits'],16)+step:016x}"),c.number(z['shape']),c.number(1.),c.boolean(True)])
cdf=s.ask_rows('GAMMA.DIST',rows);inverse=[]
for i,(z,v)in enumerate(zip(quantiles,inv)):
 vals=[value(a['bits'])for a in cdf[i*3:(i+1)*3]];inverse.append(dict(z,inverse=v,neighbors=cdf[i*3:(i+1)*3],ceiling=vals[0]<z['p']<=vals[1]))
write(out/'result.json',dict(cases=cases,answers=answers,counts=counts,first_failures=first,inverse=inverse,inverse_ceiling_matched=sum(z['ceiling']for z in inverse),receipts=s.receipts,producer_sha256=sha(__file__),limits='Public-function relationships and fixed complete-program contradictions. Inverse and outside-region failures remain; no count-selected kernel or distribution-specific inverse branch is installed.'))
print(dict(counts),'inverse ceiling',sum(z['ceiling']for z in inverse),'/',len(inverse),flush=True)
