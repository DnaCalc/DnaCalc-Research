import sys
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.fingerprint import CachedService,load_service,write,sha
r=Path('/home/ubuntu/codex-runs/round38');c,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');s=CachedService(c.Client(timeout=300),r/'period-edge-cache');periods=[8761.,2147483646.,2147483647.,2147483648.,4294967295.,4294967296.,2.**52,2.**53,1e20,1e100];y=c.number_array([[v]for v in (2.,5.,8.,11.)]);t=c.number_array([[v]for v in (1.,2.,3.,4.)]);q={}
for name in ('FORECAST.ETS','FORECAST.ETS.CONFINT','FORECAST.ETS.STAT'):
 q[name]=[[c.number(5.),y,t,c.number(p)]if name=='FORECAST.ETS'else[c.number(5.),y,t,c.number(.95),c.number(p)]if name=='FORECAST.ETS.CONFINT'else[y,t,c.number(8.),c.number(p)]for p in periods]
write(r/'ets-period-edge-questions.json',dict(periods=periods,questions=q,producer_sha256=sha(__file__),limits='Fixed integer conversion and exponent boundaries; unknown conversions remain an owning-package refusal.'))
for name,rows in q.items():
 a=s.ask_rows(name,rows);write(r/('ets-period-edge-'+name+'.json'),dict(answers=a,receipts=s.receipts,producer_sha256=sha(__file__)));print(name,list(zip(periods,a)),flush=True)
