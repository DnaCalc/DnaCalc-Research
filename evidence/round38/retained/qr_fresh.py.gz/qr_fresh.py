import sys,json,itertools,math,collections,subprocess
from pathlib import Path
from fractions import Fraction as Q
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.fingerprint import CachedService,load_service,write,bits,value,sha
r=Path('/home/ubuntu/codex-runs/round38');out=r/'qr-fresh';out.mkdir(exist_ok=False)
c,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');s=CachedService(c.Client(timeout=300),r/'later-cache');cases=[]
for n,constant,scale,power,zero in itertools.product((4,8,16),(False,True),(-20,0,20),(None,19,20,21,22,24),(False,True)):
 x1=[math.ldexp(float(2*i-n+1),scale)for i in range(n)];delta=0. if power is None else 2.**(scale-power);x=[[v,2*v+delta*(-1 if i&1 else 1)]+([0.]if zero else[])for i,v in enumerate(x1)];y=[[float(1+(i*i+3*i)%11)]for i in range(n)];cases.append(dict(id=len(cases),x=x,y=y,constant=constant,scale=scale,power=power,zero=zero,n=n))
# Keep the full Cartesian design: exact duplicates, nearly collinear columns,
# zero columns, both intercept choices and scale controls. No tolerance fitted.
selections=((1,1),(1,2),(2,1),(3,2),(4,2),(5,2))
write(out/'questions.json',dict(cases=cases,selections=selections,producer_sha256=sha(__file__),limits='Fixed rank-deficient and adjacent-scale design. Original application QR/rank policy is the frozen candidate; no degree, rank threshold or residual correction selected by partial agreement.'))
exe=Path('/home/ubuntu/codex-runs/round38/before-racer');pred={};allrows={}
for name in ('LINEST','LOGEST'):
 rows=[];service_rows=[]
 for z in cases:
  yy=z['y']if name=='LINEST'else[[2.**(v[0]/8)]for v in z['y']]
  args=[[[ '0x'+bits(v)for v in row]for row in yy],[[ '0x'+bits(v)for v in row]for row in z['x']],z['constant'],True]
  for selection in selections:rows.append(dict(id=f"{z['id']}:{selection[0]}:{selection[1]}",args=args,result_index=selection))
  service_rows.append([c.number_array(yy),c.number_array(z['x']),c.boolean(z['constant']),c.boolean(True)])
 q=out/(name+'.inputs.json');q.write_text(json.dumps(dict(function=name,witnesses=rows),separators=(',',':')));p=out/(name+'.predictions.jsonl');subprocess.run([str(exe),'invoke-inputs',str(q),str(p)],check=True,timeout=300);pred[name]=[json.loads(line)['calc_func_prediction']for line in p.read_text().splitlines()];allrows[name]=service_rows
write(out/'prediction-binding.json',dict(executable_sha256=sha(exe),predictions=pred,producer_sha256=sha(__file__)))
records=[];counts=collections.defaultdict(collections.Counter)
for name in ('LINEST','LOGEST'):
 for j,selection in enumerate(selections):
  a=s.ask_rows(name,allrows[name],chunk_size=80,result_index=selection)
  for i,(z,v)in enumerate(zip(cases,a)):
   p=pred[name][i*len(selections)+j];want='0x'+v['bits']if v['type']=='number'else'error:'+{'#NUM!':'Num','#DIV/0!':'Div0','#N/A':'NA','#VALUE!':'Value'}[v['code']];counts[name]['rows']+=1;counts[name]['matched']+=p==want
   counts[name]['df_rows'if selection==(4,2)else'other_rows']+=1
   if selection==(4,2):counts[name]['df_matched']+=p==want
   records.append(dict(function=name,case=z['id'],selection=selection,answer=v,prediction=p,matched=p==want))
  write(out/(name+f'-{selection[0]}-{selection[1]}.json'),dict(answers=a,receipts=s.receipts,producer_sha256=sha(__file__)));print(name,selection,len(a),flush=True)
write(out/'result.json',dict(records=records,counts=counts,receipts=s.receipts,producer_sha256=sha(__file__),limits='Every coefficient/statistic mismatch remains a failure; df agreement alone does not identify private QR/residual arithmetic.'))
print(dict(counts),flush=True)
