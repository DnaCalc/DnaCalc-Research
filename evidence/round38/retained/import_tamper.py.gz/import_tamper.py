import sys,json,tempfile,copy,hashlib
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research/racer')
from corpus_cases import ets_catalogue
r=Path('/home/ubuntu/codex-runs/round38');doc=json.loads((r/'ets-catalogue/prepared.json').read_text());results=[]
for kind in ('answer','argument','formula','slot'):
 d=copy.deepcopy(doc);z=d['rows'][0]
 if kind=='answer':z['answer']={'type':'number','bits':'4000000000000000'}
 elif kind=='argument':z['args'][0]['bits']='4000000000000000'
 elif kind=='formula':z['formula']='1+1'
 else:z['index']=999999
 with tempfile.TemporaryDirectory(dir='/home/ubuntu/codex-runs/tmp38')as tmp:
  out=Path(tmp);(out/'prepared.json').write_text(json.dumps(d))
  try:ets_catalogue('/home/ubuntu/projects/DnaCalc/DnaCalc','/home/ubuntu/codex-runs/round37/ets-design.json',r/'service-cache',out,'/bin/false')
  except ValueError as e:results.append(dict(change=kind,rejected=str(e)))
  else:raise AssertionError(kind+' accepted')
(r/'ets-import-tamper-results.json').write_text(json.dumps(dict(results=results,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),indent=2)+'\n');print(results)
