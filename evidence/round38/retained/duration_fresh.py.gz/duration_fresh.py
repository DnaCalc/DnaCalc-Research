import sys,json,itertools,math,datetime,collections
from pathlib import Path
import numpy as np
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.fingerprint import CachedService,load_service,write,bits,value,sha
r=Path('/home/ubuntu/codex-runs/round38');out=r/'duration-fresh';out.mkdir(exist_ok=False)
c,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');s=CachedService(c.Client(timeout=300),r/'later-cache');cases=[];requests={}
for n,f,offset,base,j,coupon in itertools.product((2,5,11),(1,2,4),(17,41),(1.03125,1.125,2.,3.5),(-1,0,1),(0.,.0625)):
 base=value(f'{int(bits(base),16)+j:016x}');mo=2020*12+n*(12//f);year,month=divmod(mo,12);maturity=(datetime.date(year,month+1,1)-datetime.date(1899,12,30)).days;settlement=43831+(17 if offset==17 else 42);e=360./f;off=(e-offset)/e
 z=dict(id=len(cases),n=n,frequency=f,offset=offset,base=base,coupon=coupon,yield_=(base-1)*f,settlement=settlement,maturity=maturity);cases.append(z)
 for form in ('offset','day_numerator','complement'):
  for k in range(n):
   t=off+k if form=='offset'else(e-offset+k*e)/e if form=='day_numerator'else 1-offset/e+k;requests.setdefault((bits(base),bits(t)),[c.number(base),c.number(t)])
profiles=list(itertools.product(('public','math','factored_public','factored_math'),('offset','day_numerator','complement')))
write(out/'questions.json',dict(cases=cases,powers=list(requests.values()),profiles=profiles,producer_sha256=sha(__file__),limits='New fractional schedules, exact yield/base construction and single-bit steps at base/exponent boundaries. Fixed simple private-power families; no coefficient or piece fitted.'))
p=s.ask_rows('POWER',list(requests.values()),chunk_size=400);pw={k:value(v['bits'])for k,v in zip(requests,p)};write(out/'powers.json',dict(keys=list(requests),answers=p,receipts=s.receipts))
predictions={}
for shape,form in profiles:
 a=[]
 for z in cases:
  n=z['n'];f=z['frequency'];e=360./f;off=(e-z['offset'])/e if form!='complement'else 1-z['offset']/e;base=z['base'];num=den=0.;div=lambda a,b:float(np.longdouble(a)/np.longdouble(b));add=lambda a,b:float(np.longdouble(a)+np.longdouble(b));coupon=100*z['coupon']/f
  for k in range(n):
   t=off+k if form!='day_numerator'else(e-z['offset']+k*e)/e
   if shape=='public':disc=pw[bits(base),bits(t)]
   elif shape=='math':disc=math.pow(base,t)
   elif shape=='factored_public':disc=math.pow(base,k)*pw[bits(base),bits(off)]
   else:disc=math.pow(base,k)*math.pow(base,off)
   pv=div(coupon,disc);num=add(num,t*pv);den=add(den,pv)
   if k==n-1:num=add(num,div(t*100.,disc));den=add(den,div(100.,disc))
  duration=div(num,den)/f;a.append(dict(duration=bits(duration),modified=bits(div(duration,base))))
 predictions[str((shape,form))]=a
write(out/'predictions.json',dict(predictions=predictions,producer_sha256=sha(__file__),limits='Frozen before target answers. Public POWER is a conditional independent leaf, not injected into the application.'))
rows=[[c.number(z[k])for k in ('settlement','maturity','coupon','yield_','frequency')]+[c.number(0.)]for z in cases];answers={}
for name in ('DURATION','MDURATION'):
 answers[name]=s.ask_rows(name,rows,chunk_size=300);print(name,len(rows),flush=True)
results=[]
for label,pred in predictions.items():
 first={};counts=collections.Counter()
 for name,key in (('DURATION','duration'),('MDURATION','modified')):
  for i,(p,v)in enumerate(zip(pred,answers[name])):
   counts[name+'_rows']+=1;counts[name+'_matched']+=p[key]==v.get('bits')
   if p[key]!=v.get('bits'):first.setdefault(name,dict(case=i,expected=v,prediction=p[key]))
 results.append(dict(label=label,counts=counts,first_failures=first))
write(out/'result.json',dict(answers=answers,profiles=results,survivors=[z for z in results if not z['first_failures']],receipts=s.receipts,producer_sha256=sha(__file__)));print('survivors',[z['label']for z in results if not z['first_failures']],flush=True)
