import sys
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.fingerprint import CachedService,load_service,write,sha
r=Path('/home/ubuntu/codex-runs/round38');c,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');s=CachedService(c.Client(timeout=300),r/'period-bound-cache');y=c.number_array([[v]for v in (2.,5.,8.,11.)]);t=c.number_array([[v]for v in (1.,2.,3.,4.)]);periods=[10000,16383,16384,32767,32768,65535,65536,10**6,2**20-1,2**20,2**24-1,2**24,2**30];rows=lambda ps:[[c.number(5.),y,t,c.number(float(p))]for p in ps]
write(r/'ets-period-bounds-questions.json',dict(periods=periods,producer_sha256=sha(__file__),method='Fixed integer exponent edges, then bisection on the numeric/error mapping. No fit is selected by match counts.'))
a=s.ask_rows('FORECAST.ETS',rows(periods));steps=list(zip(periods,a));print(steps,flush=True);lo=8761;hi=2**31-2
for p,v in steps:
 if v['type']=='number':lo=max(lo,p)
 elif v.get('code')=='#NUM!':hi=min(hi,p)
 else:raise ValueError(v)
assert lo<hi
while hi-lo>1:
 p=(lo+hi)//2;v=s.ask_rows('FORECAST.ETS',rows([p]))[0];steps.append((p,v));print('bisect',p,v,flush=True)
 if v['type']=='number':lo=p
 elif v.get('code')=='#NUM!':hi=p
 else:raise ValueError(v)
write(r/'ets-period-bound-result.json',dict(last_numeric=lo,first_num_error=hi,steps=steps,receipts=s.receipts,producer_sha256=sha(__file__)));print('boundary',lo,hi,flush=True)
