import sys,json,itertools,math,collections
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.fingerprint import CachedService,load_service,write,bits,value,sha
r=Path('/home/ubuntu/codex-runs/round38');c,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');s=CachedService(c.Client(timeout=300),r/'fresh-cache');cases=[]
for n,base,j in itertools.product((3,7,16,31),(0.5,1.,1.3,2.,4.),range(-2,3)):
 a=value(f'{int(bits(base),16)+j:016x}');cases.append(dict(n=n,y=[a]*n,target=float(n+3),prediction=bits(a),role='adjacent_constant'))
for n,base,scale in itertools.product((3,7,16,31),(0.,-11.,7.),(-500,-100,100,500)):
 y=[math.ldexp(base+3.*i,scale)for i in range(n)];cases.append(dict(n=n,y=y,target=float(n+3),prediction=bits(math.ldexp(base+3.*(n+2),scale)),role='affine_exponent'))
q={}
for name in ('FORECAST.ETS','FORECAST.ETS.STAT','FORECAST.ETS.CONFINT'):
 rows=[];keys=[]
 for i,z in enumerate(cases):
  y=c.number_array([[v]for v in z['y']]);t=c.number_array([[float(j+1)]for j in range(z['n'])])
  if name=='FORECAST.ETS':rows.append([c.number(z['target']),y,t,c.number(0.)]);keys.append((i,None))
  elif name=='FORECAST.ETS.STAT':
   for k in (1,2,3,4,5,6,7,8):rows.append([y,t,c.number(float(k)),c.number(0.)]);keys.append((i,k))
  else:
   for p in (0.,0.5,0.95):rows.append([c.number(z['target']),y,t,c.number(p),c.number(0.)]);keys.append((i,p))
 q[name]=dict(keys=keys,rows=rows)
write(r/'ets-edges-questions.json',dict(cases=cases,questions=q,producer_sha256=sha(__file__),limits='Adjacent constant loads at binade boundaries and nonzero affine exponent controls; unchanged output/zero error is a hypothesis, not a scored pass.'))
for name,z in q.items():
 a=s.ask_rows(name,z['rows'],chunk_size=100);write(r/('ets-edges-'+name+'.json'),dict(keys=z['keys'],answers=a,receipts=s.receipts,producer_sha256=sha(__file__)))
 if name=='FORECAST.ETS':print(name,'matched',sum(v.get('bits')==cases[i]['prediction']for(i,k),v in zip(z['keys'],a)),len(a),flush=True)
 else:print(name,len(a),flush=True)
