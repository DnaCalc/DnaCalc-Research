import sys,collections,json,subprocess
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.fingerprint import CachedService,load_service,write,bits,sha
r=Path('/home/ubuntu/codex-runs/round38');out=r/'ets-period-fresh';out.mkdir(exist_ok=False)
c,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');s=CachedService(c.Client(timeout=300),r/'period-fresh-cache');q=collections.defaultdict(list);cases=[]
for n,origin,step in ((13,-31.,2.),(29,17.,.25)):
 for p in (8783.,8784.,8785.,8786.):
  z=dict(n=n,origin=origin,step=step,period=p,y=[float(17-3*i)for i in range(n)],t=[origin+i*step for i in range(n)]);cases.append(z);y=c.number_array([[v]for v in z['y']]);t=c.number_array([[v]for v in z['t']]);target=c.number(origin+(n+1)*step)
  q['FORECAST.ETS'].append([target,y,t,c.number(p)])
  for confidence in (0.,.875):q['FORECAST.ETS.CONFINT'].append([target,y,t,c.number(confidence),c.number(p)])
  for statistic in (1.,8.):q['FORECAST.ETS.STAT'].append([y,t,c.number(statistic),c.number(p)])
for p in (8783.,8784.,8785.,8786.):
 y=c.number_array([[v]for v in (1.,2.,4.,5.,8.,11.,16.)]);t=c.number_array([[float(i+1)]for i in range(7)])
 q['FORECAST.ETS.STAT'].append([y,t,c.number(8.),c.number(p)])
 q['FORECAST.ETS.CONFINT'].append([c.number(9.),y,t,c.number(0.),c.number(p)])
write(out/'questions.json',dict(cases=cases,questions=q,producer_sha256=sha(__file__),limits='Fresh histories, timelines and noisy-data step/confidence-zero controls at the integer period boundary. Predictions freeze after the guard is chosen.'))
exe=Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research/target/release/symbolic-racer');pred={}
def decode(a):return'0x'+a['bits']if a['type']=='number'else[[decode(v)for v in row]for row in a['values']]
for name,rows in q.items():
 inp=out/(name+'.inputs.json');p=out/(name+'.predictions.jsonl');write(inp,dict(function=name,witnesses=[dict(id=str(i),args=list(map(decode,row)))for i,row in enumerate(rows)]));subprocess.run([str(exe),'invoke-inputs',str(inp),str(p)],check=True,timeout=120);pred[name]=[json.loads(l)['calc_func_prediction']for l in p.read_text().splitlines()]
write(out/'prediction-binding.json',dict(executable_sha256=sha(exe),predictions=pred,producer_sha256=sha(__file__)));result={}
for name,rows in q.items():
 a=s.ask_rows(name,rows);fail=[]
 for i,(p,v)in enumerate(zip(pred[name],a)):
  expected='0x'+v['bits']if v['type']=='number'else'error:'+{'#NUM!':'Num'}[v['code']]
  if p!=expected:fail.append(dict(index=i,prediction=p,answer=v))
 result[name]=dict(rows=len(rows),matched=len(rows)-len(fail),failures=fail,answers=a)
write(out/'result.json',dict(functions=result,receipts=s.receipts,producer_sha256=sha(__file__)));print({k:(v['matched'],v['rows'],v['failures'][:2])for k,v in result.items()},flush=True)
