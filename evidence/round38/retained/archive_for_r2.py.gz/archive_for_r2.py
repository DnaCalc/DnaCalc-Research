"""Freeze raw round38 files in one archive and an independently hashed inventory."""
from pathlib import Path
import gzip
import hashlib
import json
import tarfile

root = Path('/home/ubuntu/codex-runs/round38')
output = Path('/home/ubuntu/codex-runs/round38-r2-upload')
output.mkdir(exist_ok=False)
paths = sorted(root.rglob('*'))
assert not any(p.is_symlink() for p in paths), 'archive source contains a symbolic link'
files = [p for p in paths if p.is_file()]
state = lambda: {str(p.relative_to(root)): (p.stat().st_size, p.stat().st_mtime_ns)
                 for p in root.rglob('*') if p.is_file()}
before = state()
inventory = []
archive = output/'round38-raw.tar.gz'
with archive.open('xb') as target:
    with gzip.GzipFile(filename='', mode='wb', fileobj=target, mtime=0, compresslevel=6) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as bundle:
            for path in files:
                with path.open('rb') as content:
                    digest = hashlib.file_digest(content, 'sha256').hexdigest()
                bundle.add(path, arcname='round38/'+str(path.relative_to(root)), recursive=False)
                inventory.append(dict(path=str(path.relative_to(root)), bytes=path.stat().st_size,
                                      sha256=digest))
assert before == state(), 'raw archive input changed'
with archive.open('rb') as content:
    digest = hashlib.file_digest(content, 'sha256').hexdigest()
manifest = dict(format='dnacalc-raw-archive/1', archive=archive.name, archive_sha256=digest,
                archive_bytes=archive.stat().st_size, raw_files=len(inventory),
                raw_bytes=sum(p['bytes'] for p in inventory), files=inventory,
                limits='All raw run files, including failed discoveries. This inventory identifies bytes; individual receipts define their evidential scope.')
payload = gzip.compress(json.dumps(manifest, sort_keys=True, separators=(',', ':')).encode(), mtime=0)
with (output/'contents.json.gz').open('xb') as target:
    target.write(payload)
print(json.dumps({k:v for k,v in manifest.items() if k != 'files'}))
