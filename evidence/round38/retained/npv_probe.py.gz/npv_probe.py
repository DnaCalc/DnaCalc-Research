import sys,json,itertools,math,random,collections
from pathlib import Path
import numpy as np
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.fingerprint import CachedService,load_service,write,bits,value,sha
r=Path('/home/ubuntu/codex-runs/round38');out=r/'npv';out.mkdir(exist_ok=False);rng=random.Random(380901)
c,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');s=CachedService(c.Client(timeout=300),r/'next-cache');cases=[]
for e,parity,sign in itertools.product((-300,-20,0,20,300),(0,1),(-1,1)):
 a=math.ldexp(value(f'{0x3ff0000000000000+parity:016x}'),e);b=math.ldexp(2.**-53+sign*2.**-65,e);cases.append(dict(rate=1.,flows=[2*a,4*b],role='sum_word'))
for rate,count,j in itertools.product((value('401f9ff8b1ae9622')-1.,.125,-.125,-2.25),(2,3,4,7),(-1,0,1)):
 rate=value(f'{int(bits(rate),16)+j:016x}');cases.append(dict(rate=rate,flows=[0.]*(count-1)+[1.],role='discount_word'))
while sum(z['role']=='quotient_word'for z in cases)<24:
 rate=rng.uniform(-.8,3.);base=1.+rate;cash=math.ldexp(rng.uniform(-2,2),rng.randrange(-300,301))
 if cash/base!=float(np.longdouble(cash)/np.longdouble(base)):cases.append(dict(rate=rate,flows=[cash],role='quotient_word'))
for i in range(96):
 n=rng.choice((2,3,5,7,13,23,31));rate=rng.choice((.013,.125,-.125,.5,1.,-2.25));flows=[math.ldexp(rng.uniform(-1,1),rng.randrange(-100,101))for j in range(n)];cases.append(dict(rate=rate,flows=flows,role='full_program'))
profiles=list(itertools.product(('recurrence','reciprocal','horner'),('strict','pc64'),('strict','pc64'),('strict','pc64')))
def evaluate(z,p):
 algorithm,mulword,divword,addword=p;base=1.+z['rate'];flows=z['flows']
 def op(kind,a,b,word):
  if word=='strict':return {'mul':lambda:a*b,'div':lambda:a/b,'add':lambda:a+b}[kind]()
  a,b=np.longdouble(a),np.longdouble(b);return float({'mul':lambda:a*b,'div':lambda:a/b,'add':lambda:a+b}[kind]())
 if algorithm=='horner':
  total=0.
  for v in flows[::-1]:total=op('div',op('add',total,v,addword),base,divword)
  return bits(total)
 discount=1.;total=0.;reciprocal=op('div',1.,base,divword)
 for v in flows:
  discount=op('mul',discount,base if algorithm=='recurrence'else reciprocal,mulword)
  term=op('div',v,discount,divword)if algorithm=='recurrence'else op('mul',v,discount,mulword)
  total=op('add',total,term,addword)
 return bits(total)
predictions={str(p):[evaluate(z,p)for z in cases]for p in profiles};rows=[[c.number(z['rate'])]+[c.number(v)for v in z['flows']]for z in cases]
write(out/'questions.json',dict(cases=cases,rows=rows,profiles=profiles,seed=380901,producer_sha256=sha(__file__),limits='Stage-separating quotient ties, sum ties, discount-power edges, then complete small cashflow programs. No bank-percentage selection.'))
write(out/'predictions.json',dict(predictions=predictions,producer_sha256=sha(__file__)))
a=s.ask_rows('NPV',rows,chunk_size=300);results=[]
for p,pred in predictions.items():
 failed=[dict(case=i,expected=v,prediction=w)for i,(v,w)in enumerate(zip(a,pred))if v.get('bits')!=w];results.append(dict(profile=p,rows=len(a),matched=len(a)-len(failed),first_failure=failed[:1]))
write(out/'result.json',dict(answers=a,profiles=results,survivors=[z['profile']for z in results if not z['first_failure']],receipts=s.receipts,producer_sha256=sha(__file__)));print('survivors',[z['profile']for z in results if not z['first_failure']],flush=True)
