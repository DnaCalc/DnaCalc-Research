import sys,json,random,math,collections,subprocess
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.fingerprint import CachedService,load_service,write,bits,value,sha
r=Path('/home/ubuntu/codex-runs/round38');out=r/'ets-preparation-fresh';out.mkdir(exist_ok=False);rng=random.Random(380917)
c,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');s=CachedService(c.Client(timeout=300),r/'preparation-fresh-cache');cases=[]
for aggr in range(1,8):
 for scale in (-300,0,300):
  n=7; a=-17+aggr;b=3-aggr;step=.25;origin=-73.;y=[];t=[]
  for j in range(n):
   if j==3:continue
   v=a+j*b
   for delta in (-2,0,2):y.append(math.ldexp(v+delta,scale));t.append(origin+j*step)
  cases.append(dict(id=len(cases),n=n,y=y,t=t,target=origin+(n+2)*step,aggregation=aggr))
questions=collections.defaultdict(list)
for z in cases:
 y=c.number_array([[v]for v in z['y']]);t=c.number_array([[v]for v in z['t']]);tail=[c.number(1.),c.number(float(z['aggregation']))]
 questions['FORECAST.ETS'].append(dict(id=f"{z['id']}:forecast",args=[c.number(z['target']),y,t,c.number(0.)]+tail))
 questions['FORECAST.ETS.SEASONALITY'].append(dict(id=f"{z['id']}:period",args=[y,t]+tail))
 questions['FORECAST.ETS.CONFINT'].append(dict(id=f"{z['id']}:confidence",args=[c.number(z['target']),y,t,c.number(.875),c.number(0.)]+tail))
 for k in range(1,9):questions['FORECAST.ETS.STAT'].append(dict(id=f"{z['id']}:stat:{k}",args=[y,t,c.number(float(k)),c.number(0.)]+tail))
write(out/'questions.json',dict(cases=cases,questions=questions,seed=380917,producer_sha256=sha(__file__),limits='Fresh exact duplicate reductions for all seven numeric options, three exponent scales and a missing timestamp. Predictions frozen after the preparation admission was fixed.'))
def decode(a):return '0x'+a['bits']if a['type']=='number'else[[decode(v)for v in row]for row in a['values']]
exe=Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research/target/release/symbolic-racer');pred={}
for name,rows in questions.items():
 p=out/(name+'.inputs.json');p.write_text(json.dumps(dict(function=name,witnesses=[dict(id=z['id'],args=list(map(decode,z['args'])))for z in rows]),separators=(',',':')))
 o=out/(name+'.predictions.jsonl');subprocess.run([str(exe),'invoke-inputs',str(p),str(o)],check=True,timeout=300);pred[name]=[json.loads(line)['calc_func_prediction']for line in o.read_text().splitlines()]
write(out/'prediction-binding.json',dict(executable_sha256=sha(exe),predictions=pred,producer_sha256=sha(__file__)))
for name,rows in questions.items():
 a=s.ask_rows(name,[z['args']for z in rows],chunk_size=80);fails=[]
 for z,w,v in zip(rows,pred[name],a):
  expected='0x'+v['bits']if v['type']=='number'else'error:'+{'#NUM!':'Num','#N/A':'NA','#DIV/0!':'Div0','#VALUE!':'Value'}[v['code']]
  if w!=expected:fails.append(dict(id=z['id'],prediction=w,answer=v))
 write(out/(name+'.json'),dict(rows=len(rows),matched=len(rows)-len(fails),failures=fails,answers=a,receipts=s.receipts,producer_sha256=sha(__file__)))
 print(name,len(rows)-len(fails),'/',len(rows),'first',fails[:3],flush=True)
