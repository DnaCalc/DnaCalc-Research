import json,struct,hashlib
from pathlib import Path
r=Path('/home/ubuntu/codex-runs/round38');bank=json.loads((r/'final-measurement/bank-counts.json').read_text());assert not any('FORECAST.ETS'in f.upper()for f in bank['functions']);doc=json.loads((r/'ets-catalogue-v2/prepared.json').read_text());periods=[]
for z in doc['rows']:
 i=3 if z['function']in ('FORECAST.ETS','FORECAST.ETS.STAT') else 4 if z['function']=='FORECAST.ETS.CONFINT' else None
 if i is not None:periods.append(struct.unpack('>d',bytes.fromhex(z['args'][i]['bits']))[0])
assert max(periods)<=8784
(r/'period-guard-bank-scope.json').write_text(json.dumps(dict(bank_functions=len(bank['functions']),bank_ets_functions=0,numeric_rows=len(doc['rows']),explicit_periods=len(periods),largest_catalogue_period=max(periods),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),limits='The final new guard is local to the four ETS outputs; no full-bank call can reach it. Every existing numeric ETS oracle call remains below its upper bound. Original bank source/executable bindings are retained; the final corpus replay supplies the complete value/verdict comparison.'),indent=2)+'\n');print('bank has no ETS calls; max catalogue period',max(periods))
