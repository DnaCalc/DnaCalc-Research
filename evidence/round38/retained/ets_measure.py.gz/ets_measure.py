import sys,json,gzip,collections,time,hashlib
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.fingerprint import CachedService,load_service,write,sha
root=Path('/home/ubuntu/codex-runs/round38');out=root/'ets';out.mkdir(exist_ok=True)
c,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');s=CachedService(c.Client(timeout=300),root/'service-cache')
design=Path('/home/ubuntu/codex-runs/round37/ets-design.json');d=json.loads(design.read_text());cases=d['cases'];assert len(cases)==980
def ask(function, rows):
 request=dict(function=function,rows=rows)
 key=hashlib.sha256(json.dumps(request,sort_keys=True,separators=(',',':')).encode()).hexdigest()
 known=list(s.directory.glob(key+'.refusal-*.json.gz'))
 try:
  if known and len(rows)>10:raise TimeoutError('previous timed-out batch retained')
  return s.ask(function,rows)['rows']
 except (RuntimeError,TimeoutError) as error:
  if len(rows)<=10:raise
  middle=len(rows)//2
  print('split',function,len(rows),str(error)[:80],flush=True)
  return ask(function,rows[:middle])+ask(function,rows[middle:])
for function in ('FORECAST.ETS.SEASONALITY','FORECAST.ETS','FORECAST.ETS.STAT','FORECAST.ETS.CONFINT'):
 records=[]
 for i,z in enumerate(cases):
  y=c.number_array([[v]for v in z['y']]);t=c.number_array([[v]for v in z['timeline']]);tail=[c.number(float(z[k]))for k in ('data_completion','aggregation')]
  if function=='FORECAST.ETS.SEASONALITY':variants=[(None,[y,t]+tail)]
  elif function=='FORECAST.ETS':variants=[(v,[c.number(float(max(z['timeline'])+v)),y,t,c.number(float(z['seasonality']))]+tail)for v in d['functions'][function]['target_offsets']]
  elif function=='FORECAST.ETS.STAT':variants=[(v,[y,t,c.number(float(v)),c.number(float(z['seasonality']))]+tail)for v in d['functions'][function]['stat_types']]
  else:variants=[(v,[c.number(float(max(z['timeline'])+1)),y,t,c.number(float(v)),c.number(float(z['seasonality']))]+tail)for v in d['functions'][function]['confidence']]
  records.extend(dict(case=i,variant=v,args=a)for v,a in variants)
 q=out/(function+'.questions.json.gz')
 if not q.exists():
  with gzip.open(q,'wt',compresslevel=9)as f:json.dump(dict(design_sha256=sha(design),producer_sha256=sha(__file__),records=records),f,separators=(',',':'))
 for start in range(0,len(records),100):
  batch=records[start:start+100];a=ask(function,[z['args']for z in batch])
  for z,v in zip(batch,a):z['answer']=v
  print(function,start+len(batch),'/',len(records),flush=True)
 with gzip.open(out/(function+'.answers.json.gz'),'wt',compresslevel=9)as f:json.dump(dict(design_sha256=sha(design),producer_sha256=sha(__file__),records=records,receipts=s.receipts),f,separators=(',',':'))
 counts=collections.Counter(v['answer']['type']+(':'+v['answer'].get('code','') if v['answer']['type']=='error' else '')for v in records)
 write(out/(function+'.summary.json'),dict(cases=len(cases),selections=len(records),counts=counts,receipts=s.receipts,producer_sha256=sha(__file__)))
 print(function,dict(counts),flush=True)
