import json,gzip,hashlib,shutil
from pathlib import Path
r=Path('/home/ubuntu/codex-runs/round38');repo=Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research');out=repo/'evidence/round38';out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
excluded={'before-racer','fn10-generator-output-preserved.xlsx'}
files=[p for p in r.iterdir()if p.is_file()and p.name not in excluded]
files += [r/'smoke-workbooks/dcj9k_r38_smoke/oracle.xlsx']
folders=['ets','ets-fresh','ets-fresh2','ets-horizon-fresh','ets-exponent-fresh','ets-preparation-fresh','ets-preparation-fresh2','ets-period-fresh','duration-fresh','qr-fresh','poisson-fresh','npv','cumulative-fresh','ets-route-first','ets-route-domain','ets-route-final','ets-route-corrected','ets-route-preparation-discovery','ets-route-final-preparation','ets-route-verified','ets-route-period-verified','ets-route-pushed','ets-catalogue','ets-catalogue-v2','review','next-corpus-inputs','bank-before-bits','bank-after-bits','stash-evidence','unit-sources']
folders += [p.name for p in r.glob('*cache')if p.is_dir()]
for folder in folders:
 files += [p for p in (r/folder).rglob('*')if p.is_file()and '__pycache__'not in p.parts]
for folder in ['baseline-receipt','final-receipt','publication-corpus','publication-receipt','reviewed-receipt','final-measurement','bounded-corpus','postmerge-receipt','postmerge-receipt-v2']:
 for p in (r/folder).rglob('*'):
  if p.is_file()and (p.parent==r/folder or p.name in ('summary.json','summary.md'))and 'workbooks'not in p.parts:
   files.append(p)
records=[]
for p in sorted(set(files)):
 rel=p.relative_to(r);original=p.read_bytes();same=rel.suffix=='.gz'
 # The canonical map keeps its exact referenced relative location and bytes.
 dest=out/'ets-catalogue/mapping.json.gz' if str(rel)=='ets-catalogue-v2/mapping.json.gz'else out/'retained'/rel
 if not same:dest=dest.with_name(dest.name+'.gz')
 dest.parent.mkdir(parents=True,exist_ok=True);payload=original if same else gzip.compress(original,mtime=0);dest.write_bytes(payload)
 records.append(dict(path=str(dest.relative_to(repo)),original_path=str(rel),source_sha256=sha(original),gzip_sha256=sha(payload),bytes=len(original),compressed_bytes=len(payload),already_compressed=same))
for p in sorted(repo.glob('round38*-unit.json')):
 dest=out/'retained/units'/p.name;dest=dest.with_name(dest.name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);original=p.read_bytes();payload=gzip.compress(original,mtime=0);dest.write_bytes(payload)
 records.append(dict(path=str(dest.relative_to(repo)),original_path=p.name,source_sha256=sha(original),gzip_sha256=sha(payload),bytes=len(original),compressed_bytes=len(payload),already_compressed=False))
(out/'files.json').write_text(json.dumps(records,indent=2)+'\n');print(len(records),sum(z['compressed_bytes']for z in records))
