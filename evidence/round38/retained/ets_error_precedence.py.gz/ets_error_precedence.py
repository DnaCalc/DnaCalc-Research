import sys,json
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.fingerprint import CachedService,load_service,write,sha
r=Path('/home/ubuntu/codex-runs/round38');c,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');s=CachedService(c.Client(timeout=300),r/'error-order-cache');q={}
for name in ('FORECAST.ETS','FORECAST.ETS.CONFINT','FORECAST.ETS.STAT'):
 rows=[]
 for ny,nt in ((3,5),(7,2),(2,0)):
  y=c.number_array([[float(i*i+2)]for i in range(ny)]);t=c.number_array([[float(i+11)]for i in range(nt)])if nt else c.number_array([[1.]])
  for bad in (-1.,.5):
   args=[c.number(21.),y,t,c.number(bad)]if name=='FORECAST.ETS'else[c.number(21.),y,t,c.number(1.),c.number(bad)]if name=='FORECAST.ETS.CONFINT'else[y,t,c.number(9.),c.number(bad)]
   rows.append(args)
 q[name]=rows
write(r/'ets-error-order-questions.json',dict(questions=q,producer_sha256=sha(__file__)))
for name,rows in q.items():
 ans=s.ask_rows(name,rows);write(r/('ets-error-order-'+name+'.json'),dict(answers=ans,receipts=s.receipts,producer_sha256=sha(__file__)));print(name,ans,flush=True)
