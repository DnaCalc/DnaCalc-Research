import sys,json,itertools,math
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.fingerprint import CachedService,load_service,write,bits,value,sha
r=Path('/home/ubuntu/codex-runs/round38');c,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');s=CachedService(c.Client(timeout=300),r/'domain-cache');cases=[]
for timeline in ([1.],[1.,2.],[0.,1.,2.,3.],[-2.,-1.,0.,1.],[1.,1.,1.,1.],[1.,2.,2.,3.],[1.,2.,4.,5.],[1.,2.,4.,8.],[1.,3.,6.,10.],[5.,3.,1.,-1.],[0.,.5,1.,1.5],[0.,1.,2.,4.,5.,6.,7.],[0.,1.,2.,5.,6.,7.],[0.,1.,2.,6.,7.]):
 cases.append(dict(y=[float(i+1)for i in range(len(timeline))],timeline=timeline,season=0.,completion=1.,aggregation=1.,label='timeline'))
for key,vals in (('season',[-2.,-1.,-.5,.5,1.,1.9,2.,3.,4.,5.,6.,7.,8.,9.,16.,8760.,8761.]),('completion',[-1.,-.5,.5,1.,1.5,2.]),('aggregation',[-1.,0.,.5,1.,1.5,2.,3.,4.,5.,6.,7.,7.5,8.])):
 for v in vals:
  z=dict(y=[2.,3.,5.,7.,11.,13.,17.,19.],timeline=list(map(float,range(1,9))),season=0.,completion=1.,aggregation=1.,label=key);z[key]=v;cases.append(z)
questions={}
for name in ('FORECAST.ETS','FORECAST.ETS.SEASONALITY','FORECAST.ETS.STAT','FORECAST.ETS.CONFINT'):
 rows=[];keys=[]
 for i,z in enumerate(cases):
  y=c.number_array([[v]for v in z['y']]);t=c.number_array([[v]for v in z['timeline']]);tail=[c.number(z['completion']),c.number(z['aggregation'])]
  if name=='FORECAST.ETS':variants=[(h,[c.number(h),y,t,c.number(z['season'])]+tail)for h in (min(z['timeline'])-1,max(z['timeline']),max(z['timeline'])+1)]
  elif name=='FORECAST.ETS.SEASONALITY':variants=[(None,[y,t]+tail)]
  elif name=='FORECAST.ETS.STAT':variants=[(k,[y,t,c.number(float(k)),c.number(z['season'])]+tail)for k in (0,1,8,9)]
  else:variants=[(p,[c.number(max(z['timeline'])+1),y,t,c.number(p),c.number(z['season'])]+tail)for p in (-.1,0.,.5,1.,1.1)]
  for key,row in variants:rows.append(row);keys.append((i,key))
 questions[name]=dict(keys=keys,rows=rows)
write(r/'ets-domain-questions.json',dict(cases=cases,questions=questions,producer_sha256=sha(__file__)))
for name,z in questions.items():
 a=s.ask_rows(name,z['rows'],chunk_size=100);write(r/('ets-domain-'+name+'.json'),dict(keys=z['keys'],answers=a,receipts=s.receipts,producer_sha256=sha(__file__)));print(name,len(a),flush=True)
