import sys,json,math,collections
from pathlib import Path
from fractions import Fraction
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.fingerprint import CachedService,load_service,write,bits,value,sha
r=Path('/home/ubuntu/codex-runs/round38');out=r/'cumulative-fresh';out.mkdir(exist_ok=False)
c,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');s=CachedService(c.Client(timeout=300),r/'next-cache')
loans=[]
for base in (.0078125,.0625):
 for j in (-1,0,1):
  rate=value(f'{int(bits(base),16)+j:016x}')
  for timing in (0,1):loans.append(dict(rate=rate,n=60,pv=16384.,timing=timing))
programs=['forward_public_terms','backward_public_terms','one_round_public_terms','forward_singleton_cumulative','backward_singleton_cumulative','payment_minus_other_cumulative']
write(out/'design.json',dict(loans=loans,ranges=[[1,12],[13,60],[2,59]],programs=programs,producer_sha256=sha(__file__),limits='Fixed public-component identities and summation orders; candidate order fixed before answers. The public leaves are conditional observations, not a private helper identification.'))
questions=collections.defaultdict(list)
for z in loans:
 a=lambda v:c.number(float(v))
 questions['PMT'].append([a(z['rate']),a(z['n']),a(z['pv']),a(0),a(z['timing'])])
 for p in range(1,61):
  for name in ('PPMT','IPMT'):questions[name].append([a(z['rate']),a(p),a(z['n']),a(z['pv']),a(0),a(z['timing'])])
  for name in ('CUMPRINC','CUMIPMT'):questions[name].append([a(z['rate']),a(z['n']),a(z['pv']),a(p),a(p),a(z['timing'])])
 for first,last in ((1,12),(13,60),(2,59)):
  for name in ('CUMPRINC','CUMIPMT'):questions[name].append([a(z['rate']),a(z['n']),a(z['pv']),a(first),a(last),a(z['timing'])])
write(out/'questions.json',questions)
answers={name:s.ask_rows(name,rows,chunk_size=100)for name,rows in questions.items()}
write(out/'answers.json',dict(answers=answers,receipts=s.receipts,producer_sha256=sha(__file__)))
def v(x):return value(x['bits'])
def fold(xs):
 a=0.
 for b in xs:a+=b
 return a
results={};firsts={}
for name,other,term in [('CUMPRINC','CUMIPMT','PPMT'),('CUMIPMT','CUMPRINC','IPMT')]:
 counts=collections.Counter();rows=[]
 for i,z in enumerate(loans):
  public=list(map(v,answers[term][i*60:(i+1)*60]));single=list(map(v,answers[name][i*63:i*63+60]));pmt=v(answers['PMT'][i])
  for k,(first,last)in enumerate(((1,12),(13,60),(2,59))):
   target=answers[name][i*63+60+k];other_v=v(answers[other][i*63+60+k]);ps=public[first-1:last];ss=single[first-1:last]
   preds=[fold(ps),fold(reversed(ps)),float(sum(map(Fraction,ps),Fraction())),fold(ss),fold(reversed(ss)),(last-first+1)*pmt-other_v]
   for program,pred in zip(programs,preds):
    counts[program]+=bits(pred)==target['bits']
    if bits(pred)!=target['bits']:firsts.setdefault(name+':'+program,dict(loan=i,first=first,last=last,answer=target,prediction=bits(pred)))
   rows.append(dict(loan=i,first=first,last=last,answer=target,predictions=dict(zip(programs,map(bits,preds)))))
 results[name]=dict(rows=len(rows),matched=counts,details=rows)
write(out/'result.json',dict(functions=results,first_contradictions=firsts,producer_sha256=sha(__file__),limits='All fixed complete public-sum and paired-output programs are scored, no correction fitted and no kernel changed. Every nonmatch remains a failure.'))
print({k:dict(rows=v['rows'],matched=v['matched'])for k,v in results.items()},flush=True)
