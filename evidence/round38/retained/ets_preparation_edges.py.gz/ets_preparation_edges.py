import sys,itertools,json
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.fingerprint import CachedService,load_service,write,sha
r=Path('/home/ubuntu/codex-runs/round38');c,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');s=CachedService(c.Client(timeout=300),r/'preparation-edge-cache');cases=[];q={}
for order in ([2.**53,1.,-2.**53],[2.**53,-2.**53,1.],[1.,2.**53,-2.**53]):
 for aggr in (1.,7.):cases.append(dict(y=list(order)*4,t=[float(i)for i in (1,1,1,2,2,2,3,3,3,4,4,4)],aggregation=aggr))
for name in ('FORECAST.ETS','FORECAST.ETS.STAT','FORECAST.ETS.CONFINT','FORECAST.ETS.SEASONALITY'):
 rows=[]
 for z in cases:
  y=c.number_array([[v]for v in z['y']]);t=c.number_array([[v]for v in z['t']]);tail=[c.number(0.),c.number(1.),c.number(z['aggregation'])]
  if name=='FORECAST.ETS':rows.append([c.number(5.),y,t]+tail)
  elif name=='FORECAST.ETS.STAT':
   for k in (1.,4.,8.):rows.append([y,t,c.number(k)]+tail)
  elif name=='FORECAST.ETS.CONFINT':
   for p in (0.,.95):rows.append([c.number(5.),y,t,c.number(p)]+tail)
  else:rows.append([y,t]+tail[1:])
 q[name]=rows
write(r/'ets-preparation-edge-questions.json',dict(cases=cases,questions=q,producer_sha256=sha(__file__),limits='Fixed duplicate-aggregation cancellation discriminators from independent review; no data-specific output correction.'))
for name,rows in q.items():
 ans=s.ask_rows(name,rows);write(r/('ets-preparation-edge-'+name+'.json'),dict(answers=ans,receipts=s.receipts,producer_sha256=sha(__file__)));print(name,ans,flush=True)
