import sys,json,itertools,math
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
from racer.fingerprint import CachedService,load_service,write,bits,value,sha
r=Path('/home/ubuntu/codex-runs/round38');c,_=load_service('/home/ubuntu/projects/DnaCalc/DnaCalc');s=CachedService(c.Client(timeout=300),r/'discovery-cache')
d=json.loads((r/'ets-small-answers.json').read_text());cases=[];rows=[]
for i,z in enumerate(d['cases']):
 if z['season']!=0:continue
 z=dict(z,statistics=d['reply']['rows'][i*8:(i+1)*8]);cases.append(z)
 for h in (0.,1.,2.,3.):rows.append([c.number(8.+h),c.number_array([[v]for v in z['y']]),c.number_array([[float(j+1)]for j in range(8)]),c.number(0.)])
write(r/'ets-initial-questions.json',dict(cases=cases,rows=rows,producer_sha256=sha(__file__)))
a=s.ask('FORECAST.ETS',rows)
results=[]
for i,z in enumerate(cases):
 y=z['y'];n=len(y);alpha=value(z['statistics'][0]['bits']);beta=value(z['statistics'][1]['bits']);my=sum(y)/n;mx=(n-1)/2;reg=sum((j-mx)*(v-my)for j,v in enumerate(y))/sum((j-mx)**2 for j in range(n))
 predictions={}
 for init,first,update in itertools.product(('first_diff','end_diff','reg_slope','reg_line'),(0,1),('classical','innovations')):
  trend=y[1]-y[0] if init=='first_diff' else (y[-1]-y[0])/(n-1)if init=='end_diff'else reg
  level=my-reg*mx if init=='reg_line' else y[0];errors=[]
  for v in y[first:]:
   old=level;e=v-(level+trend);errors.append(e)
   level=alpha*v+(1.-alpha)*(level+trend)
   trend=beta*(level-old)+(1.-beta)*trend if update=='classical'else trend+beta*e
  predictions[str((init,first,update))]=dict(forecast=[bits(level+h*trend)for h in (0,1,2,3)],rmse=bits(math.sqrt(sum(e*e for e in errors)/len(errors))))
 answers=a['rows'][i*4:(i+1)*4];survivors=[k for k,p in predictions.items()if p['forecast']==[z['bits']for z in answers]and p['rmse']==z['statistics'][6]['bits']]
 results.append(dict(case=z,answers=answers,predictions=predictions,survivors=survivors))
 print(z['pattern'],[value(v['bits'])for v in answers],survivors,flush=True)
write(r/'ets-initial-result.json',dict(records=results,reply=a,producer_sha256=sha(__file__),limits='All fixed initialization/update programs tested against complete output and RMSE. Alpha/beta are conditional observed leaves; no optimization or new curve is fitted.'))
