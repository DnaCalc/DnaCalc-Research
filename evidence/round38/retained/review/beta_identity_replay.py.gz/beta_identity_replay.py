"""Check the fixed beta-update discriminator, without importing the model."""
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import struct

root = Path('/home/ubuntu/codex-runs/round38')
sources = {}
def read(name):
    path = root / name
    data = path.read_bytes()
    sources[name] = hashlib.sha256(data).hexdigest()
    return json.loads(data)
def bits(value):
    return struct.pack('>d', float(value)).hex()
def strip_mode(value):
    if isinstance(value, dict):
        return {k: strip_mode(v) for k, v in value.items() if k != 'mode'}
    if isinstance(value, list):
        return [strip_mode(v) for v in value]
    return value

questions = read('ets-beta-identity-questions.json')['cases']
failed = []
count = 0
for name in ('FORECAST.ETS', 'FORECAST.ETS.STAT'):
    document = read('ets-beta-identity-' + name + '.json')
    reply = document['reply']
    assert reply['ok'] and strip_mode(document['rows']) == reply['inputs']
    assert reply['automation_security_before'] == reply['automation_security_after']
    assert reply['excel_file_version'] == '16.0.20527.20150'
    for i, answer in enumerate(reply['rows']):
        case = questions[i if name == 'FORECAST.ETS' else i // 7]
        if name == 'FORECAST.ETS':
            slope = Fraction(case['y'][1]) - Fraction(case['y'][0])
            horizon = Fraction(case['target']) - Fraction(case['t'][-1])
            expected = Fraction(case['y'][-1]) + horizon * slope
        else:
            expected = [0.9, 0.001, 2.0**-52, 0.0, 0.0, 0.0, 0.0][i % 7]
        count += 1
        if answer != {'type': 'number', 'bits': bits(expected)}:
            failed.append({'function': name, 'index': i, 'answer': answer,
                           'expected_bits': bits(expected)})
assert count == 32
sources[Path(__file__).name] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
receipt = {'complete': True, 'scalar_selections': count, 'failures': failed,
           'source_sha256': sources,
           'limits': 'Four fixed affine cases confirm the review discriminator. This does not identify beta arithmetic on nonzero innovations or any general ETS optimiser.'}
with (root/'review/beta-identity-replay.json').open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps({'scalar_selections': count, 'failures': failed}))
assert not failed
