"""Seal the required read-only source and tracker-note review against retained receipts."""
import hashlib
import json
from pathlib import Path
import re

main = Path('/home/ubuntu/projects/DnaCalc/DnaCalc')
research = main.parent/'DnaCalc-Research'
root = Path('/home/ubuntu/codex-runs/round38')
review = root/'review'
sources = {}
def sha(path):
    value = hashlib.sha256(path.read_bytes()).hexdigest()
    sources[str(path)] = value
    return value
def read(path):
    sha(path)
    return json.loads(path.read_bytes())
note_path,clarification_path = root/'tracker-note.txt',root/'tracker-clarification.txt'
sha(note_path);sha(clarification_path)
note,clarification = note_path.read_text().strip(),clarification_path.read_text().strip()
bead = next(json.loads(line) for line in (main/'.beads/issues.jsonl').read_text().splitlines()
            if json.loads(line).get('id') == 'dc-j9k')
recorded_note = bead['comments'][-2]['text']
normalized_note = recorded_note.replace(
    'Independent held-out fits match 1,056/1,056;',
    'The affine holdout matches 1,056/1,056 scalar answers from 96 histories with 11 selections each;')
normalized_note = normalized_note.replace(
    'ten fixed power-provider/store profiles;',
    'ten compiled power-provider/store profiles, a subset of 22 conditional profiles independently checked;')
assert normalized_note.strip() == note
assert bead['comments'][-1]['text'].strip() == clarification
assert '96 histories with 11 selections each' in clarification
assert '22 conditional profiles' in clarification and '44 first contradictions' in clarification
assert 'no private power identity was established' in clarification
source = read(review/'source-review-final.json')
assert source['open_source_findings'] == []
for path,digest in source['sha256'].items():
    assert sha(Path(path)) == digest
raw = read(review/'raw-reply-audit-with-period.json')
route = read(review/'route-outcome-audit-period.json')
corpus = read(review/'bounded-corpus-delta-audit.json')
bank = read(review/'bank-receipt-count-audit.json')
assert (raw['requests'],raw['selections'],len(raw['failures'])) == (411,35434,0)
assert route['totals'] == {'matched':18087,'refused':8843,'mismatched':0}
assert corpus['totals'] == {'formula_cells':58722,'pass':56444,'fail':2278}
assert (bank['before_matched'],bank['after_matched'],bank['total']) == (3887633,3887817,3910007)
native = read(root/'native-check-reconciliation.json')
assert native['combined'] == {'passed':2383,'failed':0,'ignored':5,'not_run':4}
for filename,digest in native['inputs_sha256'].items():
    assert sha(root/filename) == digest
workspace = (root/'workspace-tests-repaired.log').read_text()
results = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',workspace)
assert tuple(sum(int(row[i]) for row in results) for i in range(3)) == (2385,1,5)
assert len(set(re.findall(r'^ACCEPT-NOT-RUN: ([^:]+):',workspace,re.M))) == 3
unit = read(research/'round38-closure-unit.json')
for field,base in [('source_sha256',research),('check_source_sha256',research),
                   ('application_test_sources_sha256',main),('application_manifest_sha256',main)]:
    for filename,digest in unit[field].items():
        assert sha(base/filename) == digest
for filename,digest in unit['application_working_blobs'].items():
    data = (main/filename).read_bytes()
    assert hashlib.sha1(('blob '+str(len(data))+'\0').encode()+data).hexdigest() == digest
ubs = read(root/'ubs-main-reviewed.json')
critical = [finding for finding in ubs['findings'] if finding.get('severity') == 'critical']
assert len(critical) == 8
assert all('/tests/dc_xrxb_support/' in finding['file'] and finding['rule_id']=='rust.ownership.panic-macro' for finding in critical)
sha(Path(__file__))
receipt = {'complete':True,'source_review_complete':True,'tracker_note_review_complete':True,
           'open_findings':[],'reviewed_bead':'dc-j9k',
           'reviewed_comment_ids':[bead['comments'][-2]['id'],bead['comments'][-1]['id']],
           'clarification_required_and_present':True,
           'recorded_note_sha256':hashlib.sha256(recorded_note.encode()).hexdigest(),
           'cleaned_note_matches_only_the_recorded_clarifications':True,'source_sha256':sources,
           'limits':'Approves the tracker note together with its recorded clarification. Preserves the original failed full-check invocation, failed discoveries, conditional power leaves, all typed refusals, eight pending prefix cells, Windows/browser coverage limits and the bank executable binding. No source edits or Cargo runs were performed by the reviewer. Git commits/pushes and the final short work report are separate actions.'}
with (review/'close-note-review.json').open('x') as output:
    json.dump(receipt,output,indent=2);output.write('\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('source_sha256','limits')}))
