"""Independent R38 scalar-question mapping, operand, worksheet and record audit."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import struct
from zipfile import ZipFile
import xml.etree.ElementTree as ET

root = Path('/home/ubuntu/codex-runs/round38')
main = Path('/home/ubuntu/projects/DnaCalc/DnaCalc')
packet = root/'ets-catalogue-v2'
sheet = 'dcj9k_r38_ets'
sources = {}
def read(path, compressed=False):
    data = path.read_bytes()
    sources[str(path)] = hashlib.sha256(data).hexdigest()
    return json.loads(gzip.decompress(data) if compressed else data)
def digest(path):
    data = path.read_bytes()
    value = hashlib.sha256(data).hexdigest()
    sources[str(path)] = value
    return value
def bits(value):
    return struct.pack('>d', float(value)).hex()
def number(value):
    return {'type': 'number', 'bits': bits(value)}
def vector(values):
    return {'type': 'array', 'values': [[number(v)] for v in values]}
def strip_mode(value):
    if isinstance(value, dict):
        return {k:strip_mode(v) for k,v in value.items() if k != 'mode'}
    if isinstance(value, list):
        return [strip_mode(v) for v in value]
    return value
leaves = {}
def expression(arg):
    if arg['type'] == 'array':
        return '{' + ';'.join(','.join(expression(a) for a in row) for row in arg['values']) + '}'
    assert arg['type'] == 'number'
    value = struct.unpack('>d', bytes.fromhex(arg['bits']))[0]
    text = format(value, '.15g')
    assert bits(float(text)) == arg['bits']
    leaves[text] = '0x' + arg['bits']
    return text
def calls(case):
    y, t = vector(case['y']), vector(case['timeline'])
    tail = [number(case[k]) for k in ('seasonality', 'data_completion', 'aggregation')]
    target = number(max(case['timeline']) + 1)
    return [('FORECAST.ETS', [target,y,t]+tail),
            ('FORECAST.ETS.CONFINT', [target,y,t,number(.95)]+tail),
            ('FORECAST.ETS.SEASONALITY', [y,t]+tail[1:]),
            ('FORECAST.ETS.STAT', [y,t,number(8)]+tail)]

design_path = root.parent/'round37/ets-design.json'
design = read(design_path)
prepared = read(packet/'prepared.json')
mapping = read(packet/'mapping.json.gz', True)
receipt = read(packet/'receipt.json')
fixture = main/'crates/calc-func/tests/fixtures'/sheet/'oracle.xlsx'
capture_path = main/'crates/calc-func/tests/captures'/sheet/'sections'/(sheet+'.capture.json')
capture = read(capture_path)
assert len(design['cases']) == 980
assert prepared['design_sha256'] == sources[str(design_path)]
assert len(prepared['rows']) == len(mapping['cells']) == len(capture['formulas']) == len(capture['observations']) == 3920
assert mapping['prepared_sha256'] == sources[str(packet/'prepared.json')]
assert mapping['package_sha256'] == digest(fixture)
assert mapping['section_key'] == receipt['source'] == capture['source']
assert capture['version'] == 3 and 'session' not in capture
assert capture['acquisition'] == {'kind':'function_questions', 'entry':'DnaCalc-Research/evidence/round38/ets-catalogue/mapping.json.gz;sha256:'+sources[str(packet/'mapping.json.gz')]}
assert capture['environment'] is None
assert 'not opened, saved or reopened in Excel' in mapping['limits']
raws = {}
answer_counts = {}
formula_text = {}
for index, (selected, cell, formula, observation) in enumerate(zip(prepared['rows'],mapping['cells'],capture['formulas'],capture['observations'])):
    name, args = calls(design['cases'][index//4])[index%4]
    expected_formula = '_xlfn.'+name+'('+','.join(expression(a) for a in args)+')'
    address = 'D'+str(index+1)
    assert selected['case'] == index//4 and selected['function'] == name and selected['args'] == args
    assert selected['formula'] == cell['formula'] == expected_formula
    assert selected['row'] == index+1 and selected['column'] == 4 and cell['cell'] == address
    assert cell['args'] == args
    filename = cell['raw_file']
    assert re.fullmatch('[0-9a-f]{64}\\.json\\.gz', filename)
    if filename not in raws:
        path = root/'service-cache'/filename
        raws[filename] = read(path, True)
        assert sources[str(path)] == mapping['raw_replies'][filename]
        request, reply = raws[filename]['request'], raws[filename]['reply']
        assert reply['ok'] and len(request['rows']) == len(reply['rows'])
        assert strip_mode(request['rows']) == reply['inputs']
        assert reply['automation_security_before'] == reply['automation_security_after']
        assert reply['excel_file_version'] == '16.0.20527.20150'
    request, reply = raws[filename]['request'], raws[filename]['reply']
    slot = cell['index']
    assert request['function'] == name and request.get('result_index') is None
    assert request['rows'][slot] == args
    assert cell['request_id'] == selected['request_id'] == reply['id']
    assert cell['answer'] == selected['answer'] == reply['rows'][slot]
    assert cell['environment'] == selected['environment'] == reply['calculation_settings']
    answer = cell['answer']
    kind = answer['type'] + (':'+answer['code'] if answer['type']=='error' else '')
    answer_counts[kind] = answer_counts.get(kind,0)+1
    expected_raw = {'number':answer['bits']} if answer['type']=='number' else {'error':{'#NUM!':'num','#N/A':'na','#DIV/0!':'div0','#VALUE!':'value'}[answer['code']]}
    assert observation == {'sheet':sheet,'row':index+1,'column':4,'excel_raw':expected_raw}
    assert formula == {'sheet':sheet,'row':index+1,'column':4,'kind':'ordinary','formula':'='+expected_formula}
    formula_text[address] = expected_formula
assert len(raws) == len(mapping['raw_replies']) == receipt['raw_reply_files']
assert leaves == prepared['leaves']
with ZipFile(fixture) as package:
    xml = ET.fromstring(package.read('xl/worksheets/sheet1.xml'))
    ns = {'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
    worksheet = {c.attrib['r']:c.find('m:f',ns).text for c in xml.findall('.//m:c',ns) if c.find('m:f',ns) is not None}
assert worksheet == formula_text
echo_questions = read(packet/'operand-echo-questions.json')['questions']
echo_data = (packet/'operand-echo-predictions.jsonl').read_bytes()
echo_hash = hashlib.sha256(echo_data).hexdigest()
sources[str(packet/'operand-echo-predictions.jsonl')] = echo_hash
assert echo_hash == mapping['operand_echo_sha256']
echoes = [json.loads(line) for line in echo_data.splitlines()]
assert len(echoes) == len(echo_questions) == len(leaves) == receipt['operand_literals']
for index, (literal, expected) in enumerate(leaves.items()):
    assert echo_questions[index]['formula'] == literal
    assert echoes[index]['prediction_provenance'] == 'calculated'
    assert echoes[index]['calc_func_prediction'] == expected
assert digest(capture_path) == receipt['capture_sha256']
assert digest(packet/'mapping.json.gz') == receipt['mapping_sha256']
sources[str(Path(__file__))] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
result = {'complete':True,'cells':3920,'design_cases':980,'raw_reply_files':len(raws),
          'literal_echoes':len(leaves),'answer_counts':answer_counts,'failures':[],
          'source_sha256':sources,
          'limits':'Independent mapping and origin audit, not an Excel workbook capture. Existing application comparison receipts must establish match/refusal counts; no passes are inferred here.'}
with (root/'review/catalogue-mapping-audit-v2.json').open('x') as output:
    json.dump(result,output,indent=2);output.write('\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('source_sha256','limits')}))
