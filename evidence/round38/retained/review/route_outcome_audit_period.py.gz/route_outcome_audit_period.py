"""Reconcile every final ETS route result to its frozen original scalar reply."""
import collections
import gzip
import hashlib
import json
from pathlib import Path

root = Path('/home/ubuntu/codex-runs/round38')
review = root/'review'
route = root/'ets-route-period-verified'
sources = {}
def digest(path):
    value = hashlib.sha256(path.read_bytes()).hexdigest()
    sources[str(path)] = value
    return value
def read(path, compressed=False):
    digest(path)
    return json.loads(gzip.decompress(path.read_bytes()) if compressed else path.read_bytes())
def arg(value):
    if value['type'] == 'number':
        return '0x'+value['bits']
    if value['type'] == 'array':
        return [[arg(v) for v in row] for row in value['values']]
    raise AssertionError('unexpected ETS argument type')
def answer(value):
    if value['type'] == 'number':
        return '0x'+value['bits']
    return 'error:'+{'#NUM!':'Num','#N/A':'NA','#VALUE!':'Value','#DIV/0!':'Div0'}[value['code']]
summary = read(route/'summary.json')
frozen = read(review/'raw-reply-audit-with-period.json')
expected_sources = {}
observed = {}
for filename, expected_hash in frozen['source_sha256'].items():
    path = Path(filename)
    if path.suffix != '.gz':
        continue
    data = json.load(gzip.open(path,'rt'))
    request, reply = data['request'], data['reply']
    if request['function'] not in summary['functions']:
        continue
    assert digest(path) == expected_hash
    expected_sources[str(path)] = expected_hash
    for index, (args, value) in enumerate(zip(request['rows'],reply['rows'])):
        identity = reply['id']+':'+str(index)
        assert identity not in observed
        observed[identity] = (request['function'],[arg(a) for a in args],answer(value),path.parent.name)
assert expected_sources == summary['sources']
counts = {}
failures = []
seen = set()
for name, function in summary['functions'].items():
    inputs = read(route/(name+'.inputs.json.gz'), True)
    path = route/(name+'.predictions.jsonl.gz')
    digest(path)
    predictions = [json.loads(line) for line in gzip.decompress(path.read_bytes()).splitlines()]
    assert len(predictions) == len(inputs['witnesses']) == function['rows']
    totals = collections.Counter()
    by_cache = collections.defaultdict(collections.Counter)
    for witness, predicted in zip(inputs['witnesses'],predictions):
        identity = witness['id']
        assert identity == predicted['id'] and identity not in seen
        seen.add(identity)
        original_name, args, expected, cache = observed[identity]
        assert original_name == inputs['function'] == name
        assert witness['args'] == predicted['args'] == args
        assert predicted['not_excel_evidence'] is True
        value = predicted['calc_func_prediction']
        outcome = 'refused' if value == 'fault:NotHeld' else 'matched' if value == expected else 'mismatched'
        totals[outcome] += 1
        by_cache[cache][outcome] += 1
        if outcome == 'mismatched':
            failures.append({'id':identity,'expected':expected,'prediction':value})
    assert dict(totals) == function['counts']
    assert dict(by_cache) == function['by_source']
    counts[name] = dict(totals)
assert seen == set(observed)
totals = {key:sum(c.get(key,0) for c in counts.values()) for key in ('matched','refused','mismatched')}
assert totals == {'matched':18087,'refused':8843,'mismatched':0}
assert summary['incorrect'] == failures == []
sources[str(Path(__file__))] = digest(Path(__file__))
receipt = {'complete':True,'scalar_selections':len(seen),'totals':totals,
           'counts':counts,'source_sha256':sources,'failures':failures,
           'limits':'Audit of actual retained typed-kernel predictions against original Excel replies, not an independent evaluator. Refusals remain failures. Canonical workbook/corpus receipts separately establish the application import and verdict route.'}
with (review/'route-outcome-audit-period.json').open('x') as output:
    json.dump(receipt,output,indent=2);output.write('\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('source_sha256','limits')}))
