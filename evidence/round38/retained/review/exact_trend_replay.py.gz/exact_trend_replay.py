"""Independent R38 fresh-cohort replay, using rational arithmetic, not CalcFunc."""
import collections
from fractions import Fraction as Q
import hashlib
import json
from pathlib import Path
import struct

ROOT = Path('/home/ubuntu/codex-runs/round38')
OUT = ROOT / 'review'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def bits(value):
    return struct.pack('>d', float(value)).hex()


questions = ROOT / 'ets-fresh2/questions.json'
document = json.loads(questions.read_text())
counts = collections.Counter()
failures = []
bindings = {str(questions): sha(questions), str(Path(__file__)): sha(Path(__file__))}
for name in ('FORECAST.ETS', 'FORECAST.ETS.SEASONALITY', 'FORECAST.ETS.CONFINT', 'FORECAST.ETS.STAT'):
    path = ROOT / 'ets-fresh2' / (name + '.json')
    bindings[str(path)] = sha(path)
    actual = json.loads(path.read_text())
    queries = document['questions'][name]
    assert len(queries) == len(actual['answers'])
    for query, answer in zip(queries, actual['answers']):
        index = int(query['id'].split(':')[0])
        case = document['cases'][index]
        count = case['n']
        y = [Q(v) for v in case['y']]
        timeline = [Q(v) for v in case['t']]
        step = timeline[1] - timeline[0]
        if case['aggregation'] in (2, 3):
            y = [Q(1)] * count
        if name == 'FORECAST.ETS':
            value = y[-1] + (Q(case['target']) - timeline[-1]) / step * (y[1] - y[0])
            expected = dict(type='number', bits=bits(value))
        elif name == 'FORECAST.ETS.SEASONALITY':
            expected = dict(type='number', bits=bits(0))
        elif name == 'FORECAST.ETS.CONFINT':
            expected = (dict(type='error', code='#NUM!') if Q(case['target']) <= timeline[-1]
                        else dict(type='number', bits=bits(0)))
        else:
            statistic = int(query['id'].split(':')[-1])
            value = {1: .9, 2: .001, 3: 2.**-52, 4: 0, 5: 0, 6: 0, 7: 0, 8: step}[statistic]
            expected = dict(type='number', bits=bits(value))
        counts[name] += 1
        if answer != expected:
            failures.append(dict(function=name, id=query['id'], expected=expected, actual=answer))
assert sum(counts.values()) == 1056
receipt = dict(complete=True, counts=counts, total=1056, failures=failures,
               source_sha256=bindings,
               limits='Independent exact rational replay of the original second fresh ETS cohort. '
                      'Published default parameter statistics are checked as observed outputs; '
                      'this does not identify general ETS parameter optimisation or seasonal states.')
with (OUT / 'exact-trend-replay.json').open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps(dict(counts=counts, failures=len(failures))))
assert not failures
