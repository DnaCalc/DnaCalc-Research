"""Read-only audit of all complete R38 raw replies present at invocation time."""
import collections
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/ubuntu/codex-runs/round38')
OUT = ROOT / 'review'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical(value):
    if isinstance(value, list):
        return [canonical(v) for v in value]
    if isinstance(value, dict):
        return {k:canonical(v) for k,v in value.items() if k != 'mode'}
    return value


folders = ('service-cache','discovery-cache','fresh-cache','domain-cache',
           'proof-cache','proof2-cache','later-cache','next-cache')
# Freeze membership before reading: new service replies may arrive concurrently.
files = [path for folder in folders for path in sorted((ROOT/folder).glob('*.json.gz'))]
counts = collections.Counter()
types = collections.Counter()
versions = set()
ids = set()
bindings = {}
failures = []
for path in files:
    doc = json.load(gzip.open(path,'rt'))
    request, reply = doc['request'], doc['reply']
    if not reply.get('ok'):
        continue
    bindings[str(path)] = sha(path)
    if reply['id'] in ids:
        failures.append(dict(file=str(path),reason='duplicate reply identity'))
    ids.add(reply['id'])
    counts[(path.parent.name,request['function'])] += len(reply['rows'])
    types.update(answer['type'] for answer in reply['rows'])
    versions.add(reply.get('excel_file_version'))
    if len(request['rows']) != len(reply['rows']) or canonical(request['rows']) != canonical(reply.get('inputs')):
        failures.append(dict(file=str(path),reason='incomplete or changed input readbacks'))
    if reply.get('automation_security_before') != reply.get('automation_security_after'):
        failures.append(dict(file=str(path),reason='changed automation security'))
bindings[str(Path(__file__))] = sha(Path(__file__))
receipt = dict(complete=True,requests=len(ids),selections=sum(counts.values()),types=types,
               excel_file_versions=sorted(versions),failures=failures,
               groups=[dict(cache=k[0],function=k[1],selections=v)for k,v in sorted(counts.items())],
               source_sha256=bindings,
               earlier_unfrozen_snapshot=dict(requests=276,selections=25988,
                   types=dict(error=3650,number=22338),readback_errors=0,
                   note='Exact counts reported in the earlier review message. No membership manifest '
                        'was frozen for that first snapshot; this receipt is a later independently '
                        'frozen audit and may include additional completed requests.'),
               limits='Raw transport and provenance audit only. Numeric disagreements and refusals '
                      'remain outcomes of their respective comparisons; no product pass follows '
                      'from a successful input readback.')
with (OUT/'raw-reply-audit.json').open('x') as stream:
    json.dump(receipt,stream,indent=2)
    stream.write('\n')
print(json.dumps(dict(requests=len(ids),selections=sum(counts.values()),types=types,failures=len(failures))))
assert not failures
