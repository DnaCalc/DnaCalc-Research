"""Rational duplicate reduction/completion replay for the independent skewed holdout."""
from collections import defaultdict
from fractions import Fraction as Q
import hashlib
import json
from pathlib import Path
import struct

root = Path('/home/ubuntu/codex-runs/round38/ets-preparation-fresh2')
sources = {}
def read(name):
    data = (root/name).read_bytes()
    sources[name] = hashlib.sha256(data).hexdigest()
    return json.loads(data)
questions = read('questions.json')
series = []
for case in questions['cases']:
    groups = defaultdict(list)
    for time, value in zip(case['t'],case['y']):
        groups[Q(time)].append(Q(value))
    values = {}
    for time, group in groups.items():
        ordered = sorted(group)
        aggregation = case['aggregation']
        if aggregation == 1:
            value = sum(group)/len(group)
        elif aggregation in (2,3):
            value = Q(len(group))
        elif aggregation == 4:
            value = ordered[-1]
        elif aggregation == 5:
            middle = len(group)//2
            value = ordered[middle] if len(group)%2 else (ordered[middle-1]+ordered[middle])/2
        elif aggregation == 6:
            value = ordered[0]
        else:
            assert aggregation == 7
            value = sum(group)
        values[time] = value
    times = sorted(values)
    step = min(b-a for a,b in zip(times,times[1:]))
    completed = [values[times[0]]]
    for first,last in zip(times,times[1:]):
        gap = (last-first)/step
        assert gap.denominator == 1
        for i in range(1,int(gap)):
            completed.append(values[first]+(values[last]-values[first])*Q(i,gap))
        completed.append(values[last])
    slope = completed[1]-completed[0]
    assert all(value == completed[0]+i*slope for i,value in enumerate(completed))
    horizon = (Q(case['target'])-times[-1])/step
    assert horizon.denominator == 1
    series.append((completed[-1]+horizon*slope,step))
counts = {}
failures = []
for name, rows in questions['questions'].items():
    document = read(name+'.json')
    data = (root/(name+'.predictions.jsonl')).read_bytes()
    sources[name+'.predictions.jsonl'] = hashlib.sha256(data).hexdigest()
    predictions = [json.loads(line) for line in data.splitlines()]
    assert len(rows) == len(document['answers']) == len(predictions)
    for question, answer, prediction in zip(rows,document['answers'],predictions):
        fields = question['id'].split(':')
        forecast,step = series[int(fields[0])]
        value = forecast if name == 'FORECAST.ETS' else [0.9,0.001,2.0**-52,0.,0.,0.,0.,step][int(fields[2])-1] if name == 'FORECAST.ETS.STAT' else 0.
        expected = {'type':'number','bits':struct.pack('>d',float(value)).hex()}
        if answer != expected or prediction['calc_func_prediction'] != '0x'+expected['bits']:
            failures.append({'id':question['id'],'answer':answer,'expected':expected,
                             'prediction':prediction['calc_func_prediction']})
    counts[name] = len(rows)
assert sum(counts.values()) == 231
sources[Path(__file__).name] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
receipt = {'complete':True,'scalar_selections':231,'histories':len(series),
           'counts':counts,'failures':failures,'source_sha256':sources,
           'limits':'Independent skewed-group holdout. All seven reduction options and completion are computed as rational arithmetic from raw operands; general rounded preparation and fitted ETS remain outside this proof.'}
with (root.parent/'review/preparation-holdout-replay.json').open('x') as output:
    json.dump(receipt,output,indent=2);output.write('\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('source_sha256','limits')}))
assert not failures
