"""Qualify the failed all-scale identity while preserving the failed replay."""
import hashlib
import json
from pathlib import Path

review = Path('/home/ubuntu/codex-runs/round38/review')
packet = review.parent/'ets-exponent-fresh'
sources = {}
def read(path):
    data = path.read_bytes()
    sources[str(path)] = hashlib.sha256(data).hexdigest()
    return json.loads(data)
original = read(review/'exponent-edge-replay.json')
questions = read(packet/'questions.json')['questions']
predictions = {}
for name, rows in questions.items():
    path = packet/(name+'.predictions.jsonl')
    data = path.read_bytes()
    sources[str(path)] = hashlib.sha256(data).hexdigest()
    parsed = [json.loads(line) for line in data.splitlines()]
    predictions.update({row['id']:prediction['calc_func_prediction']
                        for row,prediction in zip(rows,parsed)})
assert len(original['failures']) == 12
assert all(predictions[f['id']] == 'fault:NotHeld' for f in original['failures'])
assert original['totals'] == {'matched':504,'refused':90,'mismatched':0}
sources[str(Path(__file__))] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
note = {'complete':True,'application_matches':504,'application_refusals':90,
        'application_calculated_mismatches':0,'outside_scope_rational_disagreements':12,
        'source_sha256':sources,
        'correction':'The original replay attempted the stronger identity that every raw answer, including refused high-scale cases, equals rational affine continuation and zero residual statistics. Twelve raw answers contradict that stronger identity. All twelve are typed refusals in the application. The original receipt and failed assertion are retained; its claim that all observations match rational answers is withdrawn. The supported result is 504 matched and 90 refused, with all ninety counted as failures.'}
with (review/'exponent-edge-scope-note.json').open('x') as output:
    json.dump(note,output,indent=2);output.write('\n')
print(json.dumps({k:v for k,v in note.items() if k not in ('source_sha256','correction')}))
