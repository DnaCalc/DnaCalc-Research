"""Check every retained integer-horizon boundary answer, using fixed arithmetic."""
import hashlib
import json
from pathlib import Path
import struct

root = Path('/home/ubuntu/codex-runs/round38')
sources = {}
def read(name):
    data = (root/name).read_bytes()
    sources[name] = hashlib.sha256(data).hexdigest()
    return json.loads(data)
cases = read('ets-horizon-integer-questions.json')['cases']
counts = {}
failures = []
for function in ('FORECAST.ETS','FORECAST.ETS.CONFINT'):
    document = read('ets-horizon-integer-'+function+'.json')
    count = {'number':0,'error':0}
    assert len(document['keys']) == len(document['answers'])
    for (index, confidence), answer in zip(document['keys'],document['answers']):
        case = cases[index]
        if case['h'] >= 2**31:
            expected = {'type':'error','code':'#NUM!'}
        else:
            value = 11.0 + 3.0*case['h'] if confidence is None else 0.0
            expected = {'type':'number','bits':struct.pack('>d',value).hex()}
        count[answer['type']] += 1
        if answer != expected:
            failures.append({'function':function,'case':index,'confidence':confidence,
                             'expected':expected,'answer':answer})
    counts[function] = count
assert len(cases) == 99
assert sum(sum(row.values()) for row in counts.values()) == 297
sources[Path(__file__).name] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
receipt = {'complete':True,'scalar_selections':297,'timeline_groups':3,
           'counts':counts,'failures':failures,'source_sha256':sources,
           'limits':'Only the retained affine integer-horizon boundary packet; no fractional-horizon or general ETS fit identity is claimed.'}
with (root/'review/horizon-boundary-replay.json').open('x') as output:
    json.dump(receipt,output,indent=2);output.write('\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('source_sha256','limits')}))
assert not failures
