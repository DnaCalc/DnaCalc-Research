"""Freeze and audit the completed R38 raw cache membership, preserving prior receipts."""
import collections
import gzip
import hashlib
import json
from pathlib import Path

root = Path('/home/ubuntu/codex-runs/round38')
out = root/'review'
folders = ('service-cache','discovery-cache','fresh-cache','domain-cache',
           'proof-cache','proof2-cache','later-cache','next-cache',
           'review-probe-cache','error-order-cache','horizon-fresh-cache','exponent-fresh-cache','preparation-edge-cache',
           'preparation-fresh-cache','preparation-fresh2-cache','period-edge-cache',
           'period-bound-cache','period-fresh-cache')
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def canonical(value):
    if isinstance(value, list):
        return [canonical(v) for v in value]
    if isinstance(value, dict):
        return {k:canonical(v) for k,v in value.items() if k != 'mode'}
    return value
files = [p for folder in folders for p in sorted((root/folder).glob('*.json.gz'))]
counts = collections.Counter()
types = collections.Counter()
versions = set()
ids = set()
bindings = {}
failures = []
for path in files:
    doc = json.load(gzip.open(path,'rt'))
    request, reply = doc['request'], doc['reply']
    if not reply.get('ok'):
        continue
    bindings[str(path)] = sha(path)
    if reply['id'] in ids:
        failures.append({'file':str(path),'reason':'duplicate reply identity'})
    ids.add(reply['id'])
    counts[(path.parent.name,request['function'])] += len(reply['rows'])
    types.update(answer['type'] for answer in reply['rows'])
    versions.add(reply.get('excel_file_version'))
    if len(request['rows']) != len(reply['rows']) or canonical(request['rows']) != canonical(reply.get('inputs')):
        failures.append({'file':str(path),'reason':'incomplete or changed input readbacks'})
    if reply.get('automation_security_before') != reply.get('automation_security_after'):
        failures.append({'file':str(path),'reason':'changed automation security'})
bindings[str(Path(__file__))] = sha(Path(__file__))
receipt = {'complete':True,'requests':len(ids),'selections':sum(counts.values()),
           'types':dict(types),'excel_file_versions':sorted(versions),'failures':failures,
           'groups':[{'cache':k[0],'function':k[1],'selections':v} for k,v in sorted(counts.items())],
           'source_sha256':bindings,
           'prior_frozen_audit_sha256':sha(out/'raw-reply-audit-publication.json'),
           'limits':'New independently frozen membership after horizon, mixed-error, cumulative, exponent and preparation probes. Prior receipts are preserved. Raw transport/provenance consistency does not imply a calculated product match.'}
with (out/'raw-reply-audit-with-period.json').open('x') as output:
    json.dump(receipt,output,indent=2);output.write('\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('groups','source_sha256','limits','prior_frozen_audit_sha256')}))
assert not failures
