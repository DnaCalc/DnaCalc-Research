"""Independent affine-answer replay; retain typed refusals as application failures."""
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import struct

root = Path('/home/ubuntu/codex-runs/round38/ets-exponent-fresh')
sources = {}
def read(name):
    data = (root/name).read_bytes()
    sources[name] = hashlib.sha256(data).hexdigest()
    return json.loads(data)
questions = read('questions.json')
counts = {}
failures = []
for name in questions['questions']:
    document = read(name+'.json')
    data = (root/(name+'.predictions.jsonl')).read_bytes()
    sources[name+'.predictions.jsonl'] = hashlib.sha256(data).hexdigest()
    predictions = [json.loads(line) for line in data.splitlines()]
    assert len(predictions) == len(document['answers']) == document['rows']
    count = {'matched':0,'refused':0,'mismatched':0}
    for question, answer, prediction in zip(questions['questions'][name],document['answers'],predictions):
        fields = question['id'].split(':')
        case = questions['cases'][int(fields[0])]
        if name == 'FORECAST.ETS':
            step = Fraction(case['t'][1])-Fraction(case['t'][0])
            h = (Fraction(case['target'])-Fraction(case['t'][-1]))/step
            value = Fraction(case['y'][-1])+h*(Fraction(case['y'][1])-Fraction(case['y'][0]))
        elif name == 'FORECAST.ETS.STAT':
            value = [0.9,0.001,2.0**-52,0.,0.,0.,0.,1.][int(fields[2])-1]
        else:
            value = 0.0
        expected = {'type':'number','bits':struct.pack('>d',float(value)).hex()}
        if answer != expected:
            failures.append({'id':question['id'],'answer':answer,'expected':expected})
        predicted = prediction['calc_func_prediction']
        if predicted == 'fault:NotHeld':
            count['refused'] += 1
        elif predicted == '0x'+answer['bits']:
            count['matched'] += 1
        else:
            count['mismatched'] += 1
            failures.append({'id':question['id'],'answer':answer,'prediction':predicted})
    counts[name] = count
totals = {key:sum(c[key] for c in counts.values()) for key in ('matched','refused','mismatched')}
assert totals == {'matched':504,'refused':90,'mismatched':0}
sources[Path(__file__).name] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
receipt = {'complete':True,'scalar_selections':594,'histories':54,'counts':counts,
           'totals':totals,'failures':failures,'source_sha256':sources,
           'limits':'All observations match rational affine answers, but the application refuses ninety outside its current quantum bound. Those ninety remain failures; no wider admission or general ETS optimiser is established.'}
with (root.parent/'review/exponent-edge-replay.json').open('x') as output:
    json.dump(receipt,output,indent=2);output.write('\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('source_sha256','limits')}))
assert not failures
