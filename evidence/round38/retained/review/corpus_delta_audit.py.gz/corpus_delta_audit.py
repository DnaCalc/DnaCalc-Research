"""Audit the final corpus delta, pending prefix cells and unchanged earlier workbooks."""
import hashlib
import json
from pathlib import Path
import sys
from zipfile import ZipFile
import xml.etree.ElementTree as ET

root = Path('/home/ubuntu/codex-runs/round38')
main = Path('/home/ubuntu/projects/DnaCalc/DnaCalc')
sources = {}
def read(path):
    data = path.read_bytes()
    sources[str(path)] = hashlib.sha256(data).hexdigest()
    return json.loads(data)
before = read(root/'baseline-receipt/corpus/summary.json')
after_path = Path(sys.argv[1]).resolve()
after = read(after_path)
old = {w['name']:w for w in before['workbooks']}
new = {w['name']:w for w in after['workbooks']}
assert len(old) == 56 and len(new) == 57
for name, workbook in old.items():
    assert workbook['sha256'] == new[name]['sha256']
    assert workbook['counts'] == new[name]['counts']
entry = new['calc-func/dcj9k_r38_ets/oracle.xlsx']
counts = entry['counts']
assert {k:counts[k] for k in ('formula_cells','pass','refused','awaiting_capture','mismatched','fail')} == {'formula_cells':3928,'pass':2348,'refused':1572,'awaiting_capture':8,'mismatched':0,'fail':1580}
assert '0 with workbook sessions, 1 with scalar question mappings' in entry['capture']
assert 'prefix_metadata (8 cells)' in entry['capture']
totals = after['totals']['counts']
assert {k:totals[k] for k in ('formula_cells','pass','fail','mismatched','refused','failed_or_missing','external_links','circular_rule','awaiting_capture')} == {'formula_cells':58722,'pass':56444,'fail':2278,'mismatched':510,'refused':1572,'failed_or_missing':1,'external_links':73,'circular_rule':14,'awaiting_capture':108}
assert totals['formula_cells'] == totals['pass']+totals['fail']
assert totals['pass_rate'] == totals['pass']/totals['formula_cells']
assert totals['fail'] == sum(totals[k] for k in ('mismatched','refused','failed_or_missing','external_links','circular_rule','awaiting_capture'))
fixture = main/'crates/calc-func/tests/fixtures/dcj9k_r38_ets/oracle.xlsx'
sources[str(fixture)] = hashlib.sha256(fixture.read_bytes()).hexdigest()
assert sources[str(fixture)] == entry['sha256']
ns = {'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with ZipFile(fixture) as package:
    workbook = ET.fromstring(package.read('xl/workbook.xml'))
    assert [s.attrib['name'] for s in workbook.find('m:sheets',ns)] == ['dcj9k_r38_ets','prefix_metadata']
    prefix = ET.fromstring(package.read('xl/worksheets/sheet2.xml'))
    formulas = {c.attrib['r']:c.find('m:f',ns).text for c in prefix.findall('.//m:c',ns) if c.find('m:f',ns) is not None}
assert len(formulas) == 8
for row in range(1,5):
    assert formulas['A'+str(row)] == '_xlfn.'+formulas['B'+str(row)]
assert not (main/'crates/calc-func/tests/captures/dcj9k_r38_ets/sections/prefix_metadata.capture.json').exists()
sources[str(Path(__file__))] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
receipt = {'complete':True,'old_workbooks_unchanged':56,'new_numeric_cells':3920,
           'new_prefix_cells_pending':8,'new_matched':2348,'new_refused':1572,
           'totals':{k:totals[k] for k in ('formula_cells','pass','fail')},
           'source_sha256':sources,
           'limits':'No saved-prefix proof is inferred from scalar replies. The eight prefix cells and all typed refusals remain inclusive failures.'}
destination = root/'review'/sys.argv[2]
with destination.open('x') as output:
    json.dump(receipt,output,indent=2);output.write('\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('source_sha256','limits')}))
