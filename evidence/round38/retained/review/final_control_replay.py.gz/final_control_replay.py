"""Independent rational horizon holdout and mixed-error observation checks."""
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import struct

root = Path('/home/ubuntu/codex-runs/round38')
sources = {}
def read(name):
    path = root/name
    data = path.read_bytes()
    sources[name] = hashlib.sha256(data).hexdigest()
    return json.loads(data)
q = read('ets-horizon-fresh/questions.json')
result = read('ets-horizon-fresh/result.json')
counts = {}
failures = []
for name, document in result['functions'].items():
    data = (root/'ets-horizon-fresh'/(name+'.prediction.jsonl')).read_bytes()
    sources['ets-horizon-fresh/'+name+'.prediction.jsonl'] = hashlib.sha256(data).hexdigest()
    predictions = [json.loads(line) for line in data.splitlines()]
    assert len(predictions) == len(document['answers'])
    for i, (answer, prediction) in enumerate(zip(document['answers'],predictions)):
        case = q['cases'][i if name == 'FORECAST.ETS' else i//2]
        if case['h'] >= 2**31:
            expected = {'type':'error','code':'#NUM!'}
            predicted = 'error:Num'
        else:
            value = (Fraction(case['y'][-1]) + case['h']*(Fraction(case['y'][1])-Fraction(case['y'][0]))) if name == 'FORECAST.ETS' else Fraction(0)
            expected = {'type':'number','bits':struct.pack('>d',float(value)).hex()}
            predicted = '0x'+expected['bits']
        if answer != expected or prediction['calc_func_prediction'] != predicted:
            failures.append({'function':name,'case':i,'answer':answer,'expected':expected,
                             'prediction':prediction['calc_func_prediction']})
    counts[name] = len(document['answers'])
assert counts == {'FORECAST.ETS':60,'FORECAST.ETS.CONFINT':120}
errors = 0
for name in ('FORECAST.ETS','FORECAST.ETS.CONFINT','FORECAST.ETS.STAT'):
    document = read('ets-error-order-'+name+'.json')
    assert document['answers'] == [{'type':'error','code':'#N/A'}]*6
    errors += len(document['answers'])
sources[Path(__file__).name] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
receipt = {'complete':True,'horizon_selections':180,'counts':counts,
           'mixed_error_observations':errors,'failures':failures,'source_sha256':sources,
           'limits':'Rational replay and retained typed-kernel predictions for the frozen horizon holdout. The eighteen mixed-error replies establish Excel observations only; the amended source and its final route replay must establish corrected application behavior.'}
with (root/'review/final-control-replay.json').open('x') as output:
    json.dump(receipt,output,indent=2);output.write('\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('source_sha256','limits')}))
assert not failures
