"""Verify bank counts/attribution and the scope of the final ETS-only guard."""
import hashlib
import json
from pathlib import Path
import struct

root = Path('/home/ubuntu/codex-runs/round38')
sources = {}
def read(path):
    data = path.read_bytes()
    sources[str(path)] = hashlib.sha256(data).hexdigest()
    return json.loads(data)
before = read(root/'baseline-receipt/bank-counts.json')
after = read(root/'final-measurement/bank-counts.json')
assert sum(before['totals'].values()) == sum(after['totals'].values()) == 3910007
assert before['totals']['matched'] == 3887633
assert after['totals']['matched'] == 3887817
assert before['totals']['refused']-after['totals']['refused'] == 183
assert before['totals']['other_mismatch']-after['totals']['other_mismatch'] == 1
for key in ('last_bit','larger_numeric','unread'):
    assert before['totals'][key] == after['totals'][key]
assert set(before['functions']) == set(after['functions'])
assert len(after['functions']) == 295
assert not any('FORECAST.ETS' in name.upper() for name in after['functions'])
assert all(after['functions'][name].get('matched',0) >= values.get('matched',0)
           for name,values in before['functions'].items())
assert before['functions']['IMDIV'].get('other_mismatch',0)-after['functions']['IMDIV'].get('other_mismatch',0) == 1
prepared = read(root/'ets-catalogue-v2/prepared.json')
periods = []
for row in prepared['rows']:
    name = row['function']
    if name == 'FORECAST.ETS.SEASONALITY':
        continue
    index = 4 if name == 'FORECAST.ETS.CONFINT' else 3
    periods.append(struct.unpack('>d',bytes.fromhex(row['args'][index]['bits']))[0])
assert len(periods) == 2940 and max(periods) == 4.
sources[str(Path(__file__))] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
receipt = {'complete':True,'before_matched':3887633,'after_matched':3887817,
           'total':3910007,'after_failures':22190,'matched_delta':184,
           'refusals_reduced_by':183,'other_mismatch_gain':{'IMDIV':1},
           'bank_functions':295,'bank_ets_functions':0,
           'catalogue_explicit_periods':2940,'largest_catalogue_period':4.,
           'source_sha256':sources,
           'limits':'Counts establish net category changes, not an independently replayed per-row transition table. This supersedes the stronger old_refusals_now_matched field wording in bank-receipt-audit.json. The full-bank receipt retains its original executable/source binding before the final ETS period guard. No bank function can reach that guard; this scope audit does not relabel its execution. The final bounded corpus and typed ETS replay separately execute the final guard. No bank improvement is attributed to ETS.'}
with (root/'review/bank-receipt-count-audit.json').open('x') as output:
    json.dump(receipt,output,indent=2);output.write('\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('source_sha256','limits')}))
