"""Retain the read-only source review and its evidence qualifications."""
import hashlib
import json
from pathlib import Path

main = Path('/home/ubuntu/projects/DnaCalc/DnaCalc')
research = main.parent/'DnaCalc-Research'
review = Path('/home/ubuntu/codex-runs/round38/review')
paths = [main/p for p in (
    'crates/calc-func/src/catalogue/statistics/ets.rs',
    'crates/calc-func/src/catalogue/statistics.rs','crates/calc-func/src/file_prefix.rs',
    'crates/calc-func/src/ported/regression_forecast_family.rs',
    'crates/calc-func/tests/f1_stats.rs','crates/calc-func/tests/import_excel.rs',
    'crates/calc-func/tests/dc_xrxb_support/mod.rs',
    'crates/calc-func/tests/fixtures/make-catalogue-fixtures.ps1',
    'tools/calc-verdict/src/capture.rs','tools/calc-verdict/src/lib.rs',
    'tools/calc-verdict/src/section.rs','tools/xtask-harness/src/verdict.rs',
    'tools/xtask-harness/src/corpus.rs','tools/xtask-harness/src/corpus_tests.rs',
    'apps/dna-calc-desktop/Cargo.toml','tools/excel-service/test_service.py')]
paths += [research/'racer/corpus_cases.py',research/'racer/src/main.rs',Path(__file__)]
evidence = ('raw-reply-audit-publication.json','catalogue-mapping-audit-v2.json',
            'route-outcome-audit-verified.json','final-corpus-delta-audit.json',
            'exact-trend-replay.json','preparation-holdout-replay.json',
            'horizon-boundary-replay.json','final-control-replay.json',
            'beta-identity-replay.json','bond-consumer-replay.json',
            'exponent-edge-replay.json','exponent-edge-scope-note.json')
paths += [review/p for p in evidence]
receipt = {
    'complete_source_review':True,'open_source_findings':[],
    'close_note_review':'Pending final bank receipt and proposed close note; this receipt does not certify either.',
    'fixed_findings':[
        'Completed-point count is bounded before usize products; portable 432-point regression retained.',
        'Numeric literal spelling must reproduce original bits and is audited through Workbook::enter.',
        'Prepared cells are revalidated against original raw replies, frozen design and actual worksheet formulas.',
        'Shared INT32 future-index control precedes confidence-zero; rounded extrapolation is refused.',
        'Vector length NA precedes invalid statistic/confidence NUM; failed discovery and fresh controls retained.',
        'Duplicate reduction and completion require proved preparation before fitted outputs; cancellation discovery retained.',
        'Reduction option mapping is 4=MAX, 5=MEDIAN, 6=MIN; independent skewed holdout retained.',
        'Scalar-question mappings retain separate grouping identities and are not reported as workbook sessions.',
        'Function-question capture documentation now excepts worksheet-session requirements.'
    ],
    'preserved_checks':[
        'No source file was edited and no Cargo command was run by this reviewer.',
        'Both earlier prefix captures and all their saved-XML/raw-value assertions remain; eight new prefix cells are pending inclusive failures.',
        'The third prefix oracle has the existing generator byte-equivalence check from the same generator run.',
        'The desktop common dependency fixes an unconditional native import module.',
        'The import fixture changes only the embedded path; the spaced lookup key, Excel answer and assertions remain.',
        'Windows session-host test bodies/assertions remain unchanged and execute on Windows; native result is twelve passed, four skipped, with the original three-error run retained.'
    ],
    'qualifications':[
        'The original full-check invocation failed at the incoming desktop build issue; subsequent repaired build/tests must be reported separately.',
        'A source hash is not a test execution. The reviewer checked retained receipts rather than running Cargo.',
        'The bond replay verifies forty-four first contradictions across twenty-two fixed profiles conditional on declared public/platform/compiled power leaves; it identifies no private power.',
        'The attempted all-scale rational exponent identity failed twelve times outside the admitted region. The original failed replay is retained and its stronger claim withdrawn by exponent-edge-scope-note.json.',
        'ETS optimisation, seasonal states, nonzero residuals and unproved rounded preparation remain typed refusals owned by dc-j9k; every refusal is a failure.',
        'Scalar Value2 questions do not establish Excel-saved prefix XML or a workbook round trip.'
    ],
    'sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
}
with (review/'source-review.json').open('x') as output:
    json.dump(receipt,output,indent=2);output.write('\n')
print(json.dumps({'complete_source_review':True,'open_source_findings':0,'bound_files':len(paths),'close_note_review':receipt['close_note_review']}))
