"""Check the bisected period boundary and independent domain/precedence holdout."""
from fractions import Fraction as Q
import hashlib
import json
from pathlib import Path
import struct

root = Path('/home/ubuntu/codex-runs/round38')
sources = {}
def read(path):
    data = path.read_bytes()
    sources[str(path)] = hashlib.sha256(data).hexdigest()
    return json.loads(data)
def number(arg):
    assert arg['type'] == 'number'
    return struct.unpack('>d',bytes.fromhex(arg['bits']))[0]
def vector(arg):
    assert arg['type'] == 'array'
    return [Q(number(v)) for row in arg['values'] for v in row]
bound = read(root/'ets-period-bound-result.json')
assert bound['last_numeric'] == 8784 and bound['first_num_error'] == 8785
for period, answer in bound['steps']:
    expected = {'type':'error','code':'#NUM!'} if period > 8784 else {'type':'number','bits':'402c000000000000'}
    assert answer == expected
packet = root/'ets-period-fresh'
questions = read(packet/'questions.json')['questions']
result = read(packet/'result.json')
counts = {}
failures = []
for name, rows in questions.items():
    path = packet/(name+'.predictions.jsonl')
    data = path.read_bytes()
    sources[str(path)] = hashlib.sha256(data).hexdigest()
    predictions = [json.loads(line) for line in data.splitlines()]
    answers = result['functions'][name]['answers']
    assert len(rows) == len(predictions) == len(answers)
    for i, (args, answer, prediction) in enumerate(zip(rows,answers,predictions)):
        offset = 0 if name == 'FORECAST.ETS.STAT' else 1
        y,t = vector(args[offset]),vector(args[offset+1])
        period = number(args[4 if name == 'FORECAST.ETS.CONFINT' else 3])
        if len(y) != len(t):
            expected = {'type':'error','code':'#N/A'}
            expected_prediction = 'error:NA'
        elif period > 8784:
            expected = {'type':'error','code':'#NUM!'}
            expected_prediction = 'error:Num'
        else:
            step = t[1]-t[0]
            if name == 'FORECAST.ETS':
                h = (Q(number(args[0]))-t[-1])/step
                value = y[-1]+h*(y[1]-y[0])
            elif name == 'FORECAST.ETS.STAT':
                value = [0.9,.001,2.0**-52,0.,0.,0.,0.,step][int(number(args[2]))-1]
            else:
                value = 0.
            expected = {'type':'number','bits':struct.pack('>d',float(value)).hex()}
            expected_prediction = '0x'+expected['bits']
        if answer != expected or prediction['calc_func_prediction'] != expected_prediction:
            failures.append({'function':name,'index':i,'answer':answer,'expected':expected,
                             'prediction':prediction['calc_func_prediction']})
    counts[name] = len(rows)
assert sum(counts.values()) == 48
sources[str(Path(__file__))] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
receipt = {'complete':True,'bisected_last_valid_period':8784,'discovery_observations':len(bound['steps']),
           'fresh_observations':48,'counts':counts,'failures':failures,'source_sha256':sources,
           'limits':'The independent holdout covers translated/scaled timelines, distinct history lengths, confidence zero and .95, step statistics, and length-NA precedence. No general ETS fitting claim follows.'}
with (root/'review/period-domain-replay.json').open('x') as output:
    json.dump(receipt,output,indent=2);output.write('\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('source_sha256','limits')}))
assert not failures
