"""Independent exact arithmetic of the R38 fixed bond profiles' contradictions.

Power values remain conditional leaves: public POWER answers, the declared
platform pow provider, or frozen compiled power-boundary predictions. No private
Excel power producer is inferred from this consumer replay.
"""
import ast
from fractions import Fraction as Q
import hashlib
import json
import math
from pathlib import Path
import struct

ROOT = Path('/home/ubuntu/codex-runs/round38')
OUT = ROOT / 'review'
bindings = {}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(relative):
    path = ROOT / relative
    bindings[str(path)] = sha(path)
    return json.loads(path.read_text())


def value(raw):
    return struct.unpack('>d', bytes.fromhex(raw))[0]


def bits(number):
    return struct.pack('>d', float(number)).hex()


def rn64(q):
    if not q:
        return Q(0)
    sign = -1 if q < 0 else 1
    q = abs(q)
    exponent = q.numerator.bit_length() - q.denominator.bit_length()
    def pow2(k):
        return Q(2**k) if k >= 0 else Q(1, 2**(-k))
    if q < pow2(exponent):
        exponent -= 1
    scaled = q / pow2(exponent - 63)
    integer, remainder = divmod(scaled.numerator, scaled.denominator)
    if 2*remainder > scaled.denominator or (2*remainder == scaled.denominator and integer % 2):
        integer += 1
    return sign * integer * pow2(exponent - 63)


def divide(a, b):
    return float(rn64(Q(a) / Q(b)))


def add(a, b):
    return float(rn64(Q(a) + Q(b)))


def calculate(case, form, provider):
    count = case['n']
    frequency = case['frequency']
    days = 360. / frequency
    offset = ((days-case['offset'])/days if form != 'complement'
              else 1-case['offset']/days)
    numerator = denominator = 0.
    coupon = 100*case['coupon']/frequency
    for index in range(count):
        time = (offset+index if form != 'day_numerator'
                else (days-case['offset']+index*days)/days)
        discount = provider(case['base'], time, index, offset)
        pv = divide(coupon, discount)
        numerator = add(numerator, time*pv)
        denominator = add(denominator, pv)
        if index == count-1:
            numerator = add(numerator, divide(time*100., discount))
            denominator = add(denominator, divide(100., discount))
    duration = divide(numerator, denominator)/frequency
    return dict(DURATION=bits(duration), MDURATION=bits(divide(duration, case['base'])))


cases = read('duration-fresh/questions.json')['cases']
observed_powers = read('duration-fresh/powers.json')
powers = {tuple(k): value(answer['bits']) for k, answer in
          zip(observed_powers['keys'], observed_powers['answers'])}
original = read('duration-fresh/result.json')
answers, profiles = original['answers'], original['profiles']
checked = []
for profile in profiles:
    shape, form = ast.literal_eval(profile['label'])
    def provider(base, time, index, offset):
        if shape == 'public':
            return powers[bits(base), bits(time)]
        if shape == 'math':
            return math.pow(base, time)
        if shape == 'factored_public':
            return math.pow(base, index) * powers[bits(base), bits(offset)]
        return math.pow(base, index) * math.pow(base, offset)
    for function, failure in profile['first_failures'].items():
        result = calculate(cases[failure['case']], form, provider)[function]
        assert result == failure['prediction']
        assert failure['expected'] == answers[function][failure['case']]
        assert result != failure['expected'].get('bits')
        checked.append(dict(profile=profile['label'], function=function, **failure))

power_records = read('duration-power-boundaries.json')['records']
lookup = {(record['input']['base'], record['input']['exponent']): record['predictions']
          for record in power_records}
private_profiles = read('duration-power-boundary-result.json')['profiles']
for profile in private_profiles:
    def provider(base, time, index, offset):
        return value(lookup[bits(base), bits(time)][profile['profile']])
    for function, failure in profile['first'].items():
        result = calculate(cases[failure['case']], 'offset', provider)[function]
        assert result == failure['prediction']
        assert failure['expected'] == answers[function][failure['case']]
        assert result != failure['expected'].get('bits')
        checked.append(dict(profile=profile['profile'], function=function, **failure))
assert len(profiles) + len(private_profiles) == 22
assert len(checked) == 44
bindings[str(Path(__file__))] = sha(Path(__file__))
receipt = dict(complete=True, profiles=22, contradictions=44, checked=checked,
               source_sha256=bindings,
               limits='Independent exact rational RN64/store cashflow-consumer replay. '
                      'Public POWER and compiled power-leaf values remain conditional inputs. '
                      'The declared platform math.pow provider is called as that candidate specifies; '
                      'no private power identity, new kernel or product gain is claimed.')
with (OUT / 'bond-consumer-replay.json').open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print('44 first contradictions across 22 fixed bond profiles independently replayed')
