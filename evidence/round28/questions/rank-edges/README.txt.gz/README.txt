R28 unanswered adaptive rank bisection workbook.
Capture only the new workbook listed in manifest.json through the existing capture route.
Excel chooses exact integer-offset midpoints from its own preceding degrees-of-freedom answers.
Return every helper cell, input echo, df, coefficient, final bracket width and original worker/canonical capture.
Predictions use the application route and are never Excel answers. No rank tolerance is inferred or fitted.
