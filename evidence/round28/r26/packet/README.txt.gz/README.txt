R26 question packets: fingerprints/ has the original scalar and regression workbooks; root-transfer/ has the GEOMEAN input-route and stored-mean workbook.
Capture only the workbooks listed in each packet manifest through the existing capture route. Preserve original bytes, complete canonical/raw observations and operand echoes.
Three workbooks,9691 formula cells. All workbook outcomes await capture; predictions are not answers. Do not replace or append to either existing packet.
