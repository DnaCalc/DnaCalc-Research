"""Round15 coordinator. Reuses the retained round14 capture/audit/session helpers."""
import importlib.util,pathlib,json,os,sys,shutil,collections,datetime,subprocess
ROOT=pathlib.Path('C:/Work/DnaCalc/codex-runs');HERE=ROOT/'xll15';REPO=pathlib.Path('C:/Work/DnaCalc/DnaCalc-win')
spec=importlib.util.spec_from_file_location('retained_capture',ROOT/'xll14/run-data.py');d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
d.HERE=HERE;d.EXE=HERE/'xtask-harness.exe';d.SESSION=REPO/'target/excel-session-r15';d.ENV={**os.environ,'DNACALC_EXCEL_SESSION':str(d.SESSION)}

def begin(name):
    assert d.load(HERE/'published-state.json')['pushed']
    out=ROOT/('excel-results-'+name);out.mkdir(exist_ok=False);shutil.copytree(ROOT/('excel-questions-'+name),out/'packet')
    manifests=list((out/'packet').rglob('manifest.json')) if name=='r26' else [out/'packet/packet-manifest.json']
    for p in manifests:
        m=d.load(p);files=m.get('files_sha256',m.get('files',{}))
        if isinstance(files,list):files={r['path']:r['sha256'] for r in files}
        for f,h in files.items():assert d.sha(p.parent/f)==h,(str(p),f)
    d.write(out/'packet-sha256.json',{p.relative_to(out/'packet').as_posix():d.sha(p) for p in (out/'packet').rglob('*') if p.is_file()})
    d.write(out/'command-executable.json',dict(path=str(d.EXE),sha256=d.sha(d.EXE),revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),published_state=d.load(HERE/'published-state.json'),session=str(d.SESSION),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    return out,{**d.ENV,'DNACALC_EXCEL_PACKET':str(out)}

def run(name):
    out,env=begin(name);books=[];results=[]
    if name=='r26':
        for part in ['fingerprints','root-transfer']:
            m=d.load(out/'packet'/part/'manifest.json')
            for b in m['workbooks']:
                fixture=out/'packet'/part/b['workbook'];questions=out/'packet'/part/b['name']/'workbook-questions.json'
                q=d.load(questions);assert len(q['questions'])==b['formula_cells']
                books.append(dict(name='r26-'+b['name'],fixture=str(fixture),questions=str(questions),formula_cells=b['formula_cells'],selected_calls=b['selected_calls']))
        assert len(books)==3 and sum(b['formula_cells'] for b in books)==9691
    elif name=='fn7':
        for family in d.load(out/'packet/families.json'):
            n=family['family'];fixture=next((out/'packet'/n).glob('*.xlsx'));q=d.load(fixture.parent/'questions.json');assert all(x['expected'] is None for x in q)
            books.append(dict(name='functions-fn7-'+n,family=n,fixture=str(fixture),questions=str(fixture.parent/'questions.json'),formula_cells=d.formula_count(fixture),primaries=len(q)))
        assert sum(b['primaries'] for b in books)==384 and sum(b['formula_cells'] for b in books)==8160
    d.write(out/'workbooks.json',books)
    for b in books:
        fixture=pathlib.Path(b['fixture'])
        if name=='fn7':
            audit=out/'input-audit'/b['family'];audit.mkdir(parents=True);inputs=[];seen=set()
            for q in d.load(pathlib.Path(b['questions'])):
                for f in q['fixtures']:
                    key=(q['sheet'],f['target'])
                    if key not in seen:inputs.append(dict(sheet=key[0],address=key[1],declared=f['value']));seen.add(key)
            d.write(audit/'request.json',dict(input=str(fixture),inputs=inputs,questions=d.load(pathlib.Path(b['questions'])),versions=[],variants_directory=str(audit)))
            code=d.submit(out,env,ROOT/'xll14/prepare-input-audit.ps1',audit/'request.json',audit/'result.json',audit/'console.log')
            results.append(dict(name=b['name'],stage='input-audit',exit=code));d.write(out/'capture-results.json',results)
        results.append(d.capture(out,env,fixture,b['name']));d.write(out/'capture-results.json',results)
    if name=='fn7':
        code=d.run([d.EXE,'collation','probe',out/'packet/windows-sort-key-pairs.json','--out',out/'windows-sort-key-observations.json'],out/'windows-sort-key-probe.log',env)
        d.write(out/'windows-sort-key-probe-status.json',dict(exit=code,source_commit='203c46fd199eb8a58346e544d06909faba426329',input_sha256=d.sha(out/'packet/windows-sort-key-pairs.json'),executable_sha256=d.sha(d.EXE),output_sha256=d.sha(out/'windows-sort-key-observations.json') if (out/'windows-sort-key-observations.json').exists() else None,native_evidence_not_excel_answers=True))
    finalize(name)
    failures=[r for r in results if r.get('capture_exit',r.get('exit',0)) != 0]
    if name=='fn7':
        failures += [dict(input_audit=str(p)) for p in (out/'input-audit').glob('*/result.json') if d.load(p).get('fatal')]
        if d.load(out/'windows-sort-key-probe-status.json')['exit']:failures.append(dict(native_probe='failed'))
    if failures:raise RuntimeError('Retained failed jobs need separate retries: '+json.dumps(failures))

def finalize(name):
    out=ROOT/('excel-results-'+name);answers=[];books=[];drift=[];echoes=[]
    for b in d.load(out/'workbooks.json'):
        oo,cc,c,raw=d.maps(out,b['name']);qd=d.load(pathlib.Path(b['questions']));questions=qd['questions'] if name=='r26' else qd
        for q in questions:
            key=(qd['sheet'],q['row'],q['column']) if name=='r26' else (q['sheet'],*d.a1(q['formula_cell']))
            o=oo.get(key);r=cc.get(key)
            a=dict(question=q,condition=b['name'],observation=o,raw_cell=r,status='observed' if o and 'excel_raw' in o else 'unread_or_refused')
            if name=='fn7':a.update(family=b['family'],observers=[dict(address=p,observation=oo.get((q['sheet'],*d.a1(p))),raw_cell=cc.get((q['sheet'],*d.a1(p)))) for p in q['observer_cells']])
            elif q['role']=='operand_echo':
                expected=q.get('intended_bits');actual=o.get('excel_raw') if o else None
                echoes.append(dict(id=q['id'],expected=expected,actual=actual,agrees=(actual=={'number':expected.lower().removeprefix('0x')}) if expected else None))
            answers.append(a)
        books.append(dict(**b,comparison=d.comparison(out,b['name']),environment=c.get('environment'),capture_failures=c.get('session',{}).get('failures'),observations=len(oo)))
    if name=='fn7':
        for p in (out/'input-audit').glob('*/result.json'):
            for v in d.load(p).get('inputs',[]):
                expected=dict(v['declared'])
                if 'number' in expected:expected['number']=expected['number'].lower().removeprefix('0x')
                if 'text' in expected:expected['text']=''.join(f'{u:04x}' for u in expected['text'])
                if expected=={'error':'NA'}:expected={'error_code':2042}
                if expected!=v['value']:drift.append(dict(family=p.parent.name,**v,expected_raw=expected))
        d.write(out/'input-changes.json',drift)
    else:d.write(out/'operand-echoes.json',echoes)
    assert len(answers)==(9691 if name=='r26' else 384)
    (out/'answers.jsonl').write_text(''.join(json.dumps(a,ensure_ascii=True,separators=(',',':'))+'\n' for a in answers),encoding='utf-8')
    total=sum(b['formula_cells'] for b in books);passed=sum(b['comparison']['pass_count'] for b in books if b['comparison'])
    status=dict(packet=name,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),launches=d.session(out),results=dict(answers=len(answers),statuses=dict(collections.Counter(a['status'] for a in answers)),input_changes=len(drift),formula_comparison=dict(denominator=total,pass_count=passed,fail=total-passed,pass_rate=passed/total),workbooks=books))
    if name=='r26':status['results'].update(selected_calls=sum(b['selected_calls'] for b in books),operand_echoes=len(echoes),known_operand_differences=sum(e['agrees'] is False for e in echoes))
    if name=='fn7':status['native_probe']=d.load(out/'windows-sort-key-probe-status.json')
    evidence=out/'run-evidence';evidence.mkdir(exist_ok=True)
    for p in [pathlib.Path(__file__),ROOT/'xll14/run-data.py',ROOT/'xll14/prepare-input-audit.ps1',HERE/'published-state.json',HERE/d.load(HERE/'published-state.json')['check']]:shutil.copy2(p,evidence/p.name if p.name!='run-data.py' or p.parent==HERE else evidence/'round14-helper.py')
    d.write(out/'delivery-status.json',status)
    (out/'README.txt').write_text('Read delivery-status.json and answers.jsonl. Original packet bytes, complete raw/canonical captures, saved/reopened files, current frozen executable comparisons, owned launch identities and successful/failed receipts are retained. Answers are observations; nothing was adjusted to predictions. Unread, mismatched and refused formulas count as failures. Native Windows sort keys are separate evidence, not Excel answers.\n',encoding='utf-8')
    d.write(out/'delivery-sha256.json',{p.relative_to(out).as_posix():d.sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='delivery-sha256.json'})
    print(json.dumps(dict(packet=name,launches=status['launches'],results={k:v for k,v in status['results'].items() if k!='workbooks'})),flush=True)
if __name__=='__main__':
    for n in sys.argv[1:]:
        if n.startswith('finalize-'):finalize(n.removeprefix('finalize-'))
        else:run(n)
