# Round 30 — 2026-11-06
Worked 12:04–16:19 UTC on both master clones; the excluded engine clone was untouched.
Recovered interrupted work first: reviewed, checked and pushed main c63ce530 and Research bab0485.
Kept fixed trees, exponent edges, adjacent doubles, primitive inverses and paired public calls; no count-based selection.
ERF/negative ERFC complement: bank +13/-17, corpus +0/-5; every loss classified. Positive ERFC F remains open.
Positive PMT type 1 coefficient: financial bank +3735/-22, corpus +59/-19; every downstream loss classified.
PMT exponent controls: 1135→1171/1274 (+36/-0); replay encoding fix recognizes 91 matching #NUM! values; raw records unchanged.
BESSELJ argument admission: corpus +12/-0, bank unchanged; numeric Bessel bodies unchanged.
Gamma density: 128 anchor groups and 512 scaled answers identify stored(alpha/x) then multiply, independently of the prefix.
Gamma bank +654/-172; corpus +0/-0; exponent controls +22/-0; separate holdout +44/-12.
Independent review verified all 184 losses: current prefixes lie outside all four declared strict/PC64 final-word preimages.
Gamma prefix production/storage remain open. Original answers, provenance and selections were preserved.
Integrated bank: 3777655/3910007 matched, 132352 fail including 116 unread; corpus 52883/54794, 1911 fail including 100 pending.
Incoming work separately contributes 54 IMLOG2 bank gains, 586 collation corpus gains, then 7 PMT bank gains before Gamma.
Integrated engine/native/complex work leaves those totals unchanged; final rendering-only merge changes no calculation source.
Regenerated docs/generated/problem-functions.md/json; Research/evidence/round30/ranking-final.json ranks counts and dependencies.
Remaining bank leaders: BINOM.DIST 38335, GAMMA.DIST 29872, NORM.S.DIST 11075, POISSON.DIST 10309, GAMMA 6197, PMT 4663.
GAMMALN windows refute the frozen-table store-only change; coefficient-independent final-P-store discrimination remains open.
Unit-shape Gamma PDF has 34/250 neighbor increases; tested direct EXP/prefactor models fail; no shortcut adopted.
ERFC F/NORM, Poisson seed/log models, HYPGEOM products and CUMPRINC routes remain open; QR workbook packet is pending.
CUMIPMT singleton = PMT−CUMPRINC 816/816, but published-component sums fail. Numerical Bessel J/Y remains open.
Evidence extends the existing cache/index: about 9 MB compressed/source archives, no bulk corpus or executables committed.
Checks: Gamma 1883/0; integrated calculation tree 1889/0, 14 packages. Final check 1890/0, 5 ignored, 3 not run across 14 packages.
Research: 125 Python and 137 Rust tests passed (2 ignored); published-unit validation also passed 137/0 (2 ignored).
Painting: 18 controls pass with the documented DNACALC_PAINT_PYTHON pointing to an isolated Pillow/NumPy environment.
UBS: zero critical; Python analysis partial due analyzer limitation. No Windows/browser sweep claimed; no new workbook question.
Main 3268aaa1; Research f88badc plus the final publication receipt on master.
