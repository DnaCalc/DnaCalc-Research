"""Read-only independent replay of R30's GAMMALN near-binade observations.

No research producer, graph interpreter or product calculation is imported.
Each arithmetic operation executes a separate native x87 instruction. The only
created file is the requested review JSON. Sources: original Excel observations,
IEEE754, Intel x87 operations and the installed high-precision math interface.
"""
from pathlib import Path
import ctypes as C
import datetime
import hashlib
import json
import math
import struct
import sys
import gzip

try:
    import mpmath as mp
except ImportError:
    sys.path.insert(0, '/home/ubuntu/claude-work/gamma/pylib')
    import mpmath as mp

mp.mp.prec = 200
ROOT = Path('/home/ubuntu/codex-runs/r30')
RESEARCH = Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
study = ROOT/'gammaln-near-stores.json'
questions = ROOT/'gammaln-near-stores.json.questions.json'
prior = ROOT/'gammaln-store-edges.json.questions.json'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
doc, manifest, previous = [json.loads(p.read_text()) for p in (study, questions, prior)]
bound_libraries = [Path(p) for p in doc['source_bindings'] if p.endswith('.so')]
assert len(bound_libraries) == 1
library = bound_libraries[0]
assert sha(questions) == doc['questions_sha256']
assert sha(library) == doc['source_bindings'][str(library)]
frozen = {str(p): sha(p) for p in (Path(__file__), study, questions, prior, library,
          RESEARCH/'racer/x87_native.c', Path(mp.__file__))}

class Register(C.Structure):
    _fields_ = [('bytes', C.c_ubyte*10)]

lib = C.CDLL(str(library))
pointer = C.POINTER(Register)
lib.x87_leaf.argtypes = [C.c_int, pointer, pointer, C.c_uint16, pointer]
lib.x87_leaf.restype = None
lib.x87_publish.argtypes = [pointer, C.c_uint16]
lib.x87_publish.restype = C.c_uint64

def instruction(op, a, b=None):
    aa = Register.from_buffer_copy(a)
    bb = Register.from_buffer_copy(a if b is None else b)
    out = Register()
    lib.x87_leaf(op, C.byref(aa), C.byref(bb), 0x133f, C.byref(out))
    return bytes(out)

def publish(a):
    raw = Register.from_buffer_copy(a)
    return lib.x87_publish(C.byref(raw), 0x133f)

def load(h):
    n = int(h, 16) if isinstance(h, str) else h
    exponent, fraction = (n >> 52) & 2047, n & ((1 << 52)-1)
    if exponent == 0 and fraction == 0:
        return bytes(8)+((n >> 63) << 15).to_bytes(2, 'little')
    assert 0 < exponent < 2047
    return ((1 << 63) | (fraction << 11)).to_bytes(8, 'little') + (
        (exponent-1023+16383) | ((n >> 63) << 15)).to_bytes(2, 'little')

def value(h):
    return struct.unpack('>d', int(h, 16).to_bytes(8, 'big'))[0]

def stored(a):
    return load(publish(a))

tables = {k: list(map(load, v)) for k, v in previous['tables'].items()}

def horner(coefficients, x, final_stored):
    result = coefficients[-1]
    for index in range(7, -1, -1):
        result = instruction(2, stored(instruction(4, result, x)), coefficients[index])
        if index != 0 or final_stored:
            result = stored(result)
    return result

def calculate(h, numerator_stored, denominator_stored):
    x = load(h)
    p = horner(tables['P'], x, numerator_stored)
    q = horner(tables['Q'], x, denominator_stored)
    ratio = stored(instruction(5, p, q))
    difference = instruction(3, x, load('4000000000000000'))
    return f'{publish(instruction(4, difference, ratio)):016x}'

answers = {}
original_calls = 0
for receipt in doc['receipts']:
    path = RESEARCH/'evidence/round29/scalar-cache'/receipt['file']
    assert sha(path) == receipt['sha256']
    frozen[str(path)] = sha(path)
    raw = json.loads(gzip.decompress(path.read_bytes()))
    request, reply = raw['request'], raw['reply']
    assert request['function'] == 'GAMMALN' and reply['ok'] and reply['version'] == 1
    assert reply['inputs'] == request['rows']
    assert len(reply['rows']) == len(request['rows']) == receipt['calls']
    assert reply['automation_security_before'] == reply['automation_security_after']
    assert all(reply[k] == receipt[k] for k in ('request_sha256', 'excel_build', 'machine', 'timestamp'))
    for args, answer in zip(request['rows'], reply['rows']):
        assert args[0]['bits'] not in answers or answers[args[0]['bits']] == answer
        answers[args[0]['bits']] = answer
    original_calls += len(reply['rows'])

labels = {'President_Qresident': (False, False), 'Pstored_Qresident': (True, False),
          'President_Qstored': (False, True)}
remainder_bound = mp.mpf(0)
sampled_actual_remainder = mp.mpf(0)
results = []
assert len(doc['records']) == len(manifest['windows']) == len(previous['edges']) == 4
for row, window, old_edge in zip(doc['records'], manifest['windows'], previous['edges']):
    assert row['center'] == window['center'] == old_edge['estimated_edge']
    center = mp.mpf(value(row['center']))
    f0, f1, f2 = mp.loggamma(center), mp.digamma(center), mp.polygamma(1, center)
    residuals = []
    assert len(row['samples']) == len(window['inputs']) == 4096
    for index, sample in enumerate(row['samples']):
        h = sample['input']
        assert h == window['inputs'][index]
        assert int(h, 16) == int(row['center'], 16)+index-2048
        assert sample['offset'] == index-2048 and sample['excel'] == answers[h]
        dx = mp.mpf(value(h))-center
        truth = f0+f1*dx+f2*dx*dx/2
        unit = mp.mpf(math.ulp(value(sample['excel']['bits'])))
        remainder_bound = max(remainder_bound, abs(dx)**3/(6*unit))
        assert sample['predictions'] == {name: calculate(h, *flags) for name, flags in labels.items()}
        values = dict(Excel=sample['excel']['bits'], **sample['predictions'])
        expected = {name: float((mp.mpf(value(raw))-truth)/unit) for name, raw in values.items()}
        assert all(abs(expected[k]-sample['error_in_result_ulps'][k]) < 1e-14 for k in expected)
        residuals.append(expected)
        if index in (0, 2048, 4095):
            sampled_actual_remainder = max(sampled_actual_remainder,
                abs((mp.loggamma(mp.mpf(value(h)))-truth)/unit))
    for index, block in enumerate(row['blocks']):
        assert (block['first_offset'], block['last_offset']) == (128*index-2048, 128*index-1921)
        means = {k: sum(v[k] for v in residuals[index*128:(index+1)*128])/128 for k in residuals[0]}
        assert all(abs(means[k]-block['means'][k]) < 1e-14 for k in means)
    jumps = {k: sum(v[k] for v in residuals[2048:])/2048 -
                sum(v[k] for v in residuals[:2048])/2048 for k in residuals[0]}
    centered_rms = {}
    for name in labels:
        squares = []
        for half in (residuals[:2048], residuals[2048:]):
            differences = [v['Excel']-v[name] for v in half]
            mean = sum(differences)/len(differences)
            squares.extend((v-mean)**2 for v in differences)
        centered_rms[name] = math.sqrt(sum(squares)/len(squares))
    results.append(dict(polynomial=row['polynomial'], level=row['level'],
                        half_window_jumps=jumps, separate_half_dc_removed_rms=centered_rms))

assert abs(remainder_bound-mp.mpf(doc['quadratic_remainder_bound_in_ulps'])) < mp.mpf('1e-65')
assert frozen == {p: sha(p) for p in frozen}
review = dict(complete=True, reviewer='round30_read_only_review',
    utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), original_calls=original_calls,
    original_readbacks_verified=True, all_samples_predictions_residuals_and_blocks_verified=True,
    mathematical_precision_bits=200, quadratic_remainder_bound_in_ulps=str(remainder_bound),
    sampled_actual_remainder_in_ulps=str(sampled_actual_remainder), results=results,
    recommendation='defer_GAMMALN_store_only_change',
    reasoning='The sharp P-only event strengthens the numerator-quantization hypothesis. '
        'The frozen Pstored model still does not reproduce its jumps, and removing a separate '
        'unknown DC bias on each half does not improve its noise agreement at either P edge. '
        'The observations therefore do not yet establish that every regression from the '
        'proposed store-only implementation would be caused by unresolved coefficient low bits.',
    limits='Descriptive diagnostics, not independent random samples or proof that Pstored is false. '
        'No coefficient, threshold, graph or private helper is inferred from match counts. '
        'The current product GAMMALN body remains unchanged.', inputs_sha256=frozen)
output = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT/'gammaln-near-review.json'
with output.open('x', encoding='utf-8') as stream:
    json.dump(review, stream, indent=2)
    stream.write('\n')
print(json.dumps(dict(original_calls=original_calls, results=results,
                      recommendation=review['recommendation'])))
