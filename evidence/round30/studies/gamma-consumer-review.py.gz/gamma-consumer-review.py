"""Independent exact review of the corrected gamma scale holdout.

Original MIT review arithmetic: Fraction midpoint cells, with no import of
producer/checker calculations. Only the requested review JSON is created.
"""
from collections import Counter
from fractions import Fraction as Q
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import struct
import sys

ROOT = Path('/home/ubuntu/codex-runs/r30')
RESEARCH = Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
study = ROOT/'gamma-scale-holdout-corrected.json'
questions = Path(str(study)+'.questions.json')
anchors = ROOT/'gamma-scale-holdout.json.anchors.json'
anchor_questions = Path(str(anchors)+'.questions.json')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
doc, manifest, original, old_manifest = [json.loads(p.read_text()) for p in
                                         (study, questions, anchors, anchor_questions)]
assert sha(questions) == doc['questions_sha256']
assert sha(anchor_questions) == original['questions_sha256']
frozen = {str(p): sha(p) for p in (Path(__file__), study, questions, anchors, anchor_questions)}

def number(h):
    return Q(*struct.unpack('>d', int(h.removeprefix('0x'), 16).to_bytes(8, 'big'))[0].as_integer_ratio())

def two(e):
    return Q(1 << e) if e >= 0 else Q(1, 1 << -e)

def exponent(v):
    e = v.numerator.bit_length()-v.denominator.bit_length()
    return e-1 if v < two(e) else e

def rounded(v, precision):
    if not v:
        return v
    sign = -1 if v < 0 else 1
    v = abs(v)
    step = two(exponent(v)-precision+1)
    scaled = v/step
    k, r = divmod(scaled.numerator, scaled.denominator)
    if 2*r > scaled.denominator or (2*r == scaled.denominator and k % 2):
        k += 1
    return sign*k*step

def floor_coordinate(v, precision):
    e = exponent(v)
    scaled = v/two(e-precision+1)
    return e*(1 << (precision-1))+scaled.numerator//scaled.denominator-(1 << (precision-1))

def value_at(k, precision):
    e, m = divmod(k, 1 << (precision-1))
    return ((1 << (precision-1))+m)*two(e-precision+1)

def coordinates(span, precision):
    if span is None:
        return None
    lo, hi, lc, hc = span
    k = floor_coordinate(lo, precision)
    low = k if value_at(k, precision) == lo and lc else k+1
    k = floor_coordinate(hi, precision)
    high = k-(value_at(k, precision) == hi and not hc)
    return None if low > high else (low, high)

def cell(y, precision):
    k = floor_coordinate(y, precision)
    assert value_at(k, precision) == y
    return ((value_at(k-1, precision)+y)/2, (y+value_at(k+1, precision))/2,
            k % 2 == 0, k % 2 == 0)

def pullback(span, precision):
    bounds = coordinates(span, precision)
    if bounds is None:
        return None
    first, last = [value_at(k, precision) for k in bounds]
    a, b = cell(first, precision), cell(last, precision)
    return a[0], b[1], a[2], b[3]

def inverse(y, constant, operation, model):
    span = cell(y, 53)
    if model != 'strict':
        span = pullback(span, 64)
    lo, hi, lc, hc = span
    result = ((lo*constant, hi*constant, lc, hc) if operation == 'div'
              else (lo/constant, hi/constant, lc, hc))
    # A strict binary64 operation stores its input as well as its output.
    return pullback(result, 53) if model == 'strict' else result

def intersect(a, b):
    if a is None or b is None:
        return None
    lo, hi = max(a[0], b[0]), min(a[1], b[1])
    lc = (a[2] if lo == a[0] else True) and (b[2] if lo == b[0] else True)
    hc = (a[3] if hi == a[1] else True) and (b[3] if hi == b[1] else True)
    return None if lo > hi or (lo == hi and not (lc and hc)) else (lo, hi, lc, hc)

def decode(span):
    if span is None:
        return None
    return Q(*map(int, span['lower'])), Q(*map(int, span['upper'])), span['lower_closed'], span['upper_closed']

answers = {}
raw_calls = 0
for receipt in doc['receipts']:
    path = RESEARCH/'evidence/round29/scalar-cache'/receipt['file']
    assert sha(path) == receipt['sha256']
    frozen[str(path)] = sha(path)
    raw = json.loads(gzip.decompress(path.read_bytes()))
    request, reply = raw['request'], raw['reply']
    assert request['function'] == receipt['function'] == 'GAMMA.DIST'
    assert reply['ok'] and reply['version'] == 1
    assert reply['inputs'] == [[{k: v for k, v in arg.items() if k != 'mode'}
                               for arg in row] for row in request['rows']]
    assert len(request['rows']) == len(reply['rows']) == receipt['calls']
    assert reply['automation_security_before'] == reply['automation_security_after']
    assert all(reply[k] == receipt[k] for k in ('request_sha256', 'excel_build', 'machine', 'timestamp'))
    for args, answer in zip(request['rows'], reply['rows']):
        answers[tuple(arg['bits'] for arg in args)] = answer
    raw_calls += len(request['rows'])

assert len(doc['groups']) == len(original['records']) == 70
assert len(doc['records']) == 280
assert len(old_manifest['shapes']) == 14
assert not manifest['original_counterparts'] and not old_manifest['original_bank_counterparts']
profiles = doc['profiles']
assert [(p['kind'], p['model']) for p in profiles] == [
    ('divide', 'strict'), ('divide', 'stored_pc64'), ('stored_ratio_multiply', 'strict'),
    ('stored_ratio_multiply', 'stored_pc64'), ('resident_ratio_multiply', 'stored_pc64')]
accumulated = []
initial_empty = Counter()
for group, anchor in zip(doc['groups'], original['records']):
    assert group['shape'] == anchor['shape'] and group['ratio'] == anchor['input']
    assert group['density'] == anchor['density']
    a, y, density = number(group['shape']), number(group['ratio']), number(group['density']['bits'])
    ratio = a/y
    assert ratio.numerator.bit_count() == ratio.denominator.bit_count() == 1
    prefix = density*y/a
    assert prefix == rounded(prefix, 53) == number(group['prefix_publication'])
    anchor_args = (group['ratio'], group['shape'], '3ff0000000000000', '0000000000000000')
    assert anchor_args in map(tuple, old_manifest['rows'])
    assert answers[anchor_args] == anchor['density']
    domains = [inverse(density, y, 'div', p['model']) if p['kind'] == 'divide'
               else cell(prefix, 53) for p in profiles]
    for index, domain in enumerate(domains):
        initial_empty[index] += domain is None
    accumulated.append(domains)

forward = Counter()
for row, selected in zip(doc['records'], manifest['rows']):
    assert row['group'] == selected['group'] and row['args'] == selected['args']
    group = doc['groups'][row['group']]
    x, a, beta, cumulative = map(number, row['args'])
    assert beta in (3, 5, 7, 10) and cumulative == 0
    assert x == beta*number(group['ratio']) and x/beta == number(group['ratio'])
    assert answers[tuple(row['args'])] == row['answer']
    target, prefix = number(row['answer']['bits']), number(group['prefix_publication'])
    for index, profile in enumerate(profiles):
        kind, model = profile['kind'], profile['model']
        if kind == 'divide':
            # S is the arbitrary rounded post-alpha product, not R*a inferred from the anchor.
            constant, operation = x, 'div'
        else:
            if kind == 'resident_ratio_multiply':
                constant = rounded(a/x, 64)
            elif model == 'strict':
                constant = rounded(a/x, 53)
            else:
                constant = rounded(rounded(a/x, 64), 53)
            operation = 'mul'
        domain = inverse(target, constant, operation, model)
        assert domain == decode(row['required_prefixes'][index])
        accumulated[row['group']][index] = intersect(accumulated[row['group']][index], domain)
        if kind != 'divide':
            out = prefix*constant
            out = rounded(out, 53) if model == 'strict' else rounded(rounded(out, 64), 53)
            forward[index] += out == target

counts = [Counter() for _ in profiles]
for group, domains in zip(doc['groups'], accumulated):
    for index, domain in enumerate(domains):
        published = group['prefix_constraints'][index]
        assert domain == decode(published['required_shared_prefix'])
        b, e = coordinates(domain, 53), coordinates(domain, 64)
        assert published['binary64_count'] == (0 if b is None else b[1]-b[0]+1)
        assert published['resident64_count'] == (0 if e is None else e[1]-e[0]+1)
        counts[index]['groups'] += 1
        counts[index]['binary64_nonempty'] += b is not None
        counts[index]['resident64_nonempty'] += e is not None
assert list(map(dict, counts)) == doc['counts']
assert forward[2] == forward[3] == 280
assert raw_calls == 350
assert frozen == {p: sha(p) for p in frozen}

review = dict(complete=True, approved_for_isolated_association_trial=True,
    reviewer='round30_read_only_review', utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    original_anchor_calls=70, fresh_scaled_calls=280, exact_scale_and_quotient_verified=True,
    every_inverse_endpoint_intersection_and_lattice_count_verified=True,
    independent_fixed_anchor_predictions=dict(strict_ratio_multiply=forward[2], stored_pc64_ratio_multiply=forward[3]),
    profile_counts=list(map(dict, counts)), empty_anchor_domains=dict(initial_empty),
    scope='The generic density final consumer R*(stored(alpha/x)) is supported within the shared-prefix '
          'family. The corrected divide alternative admits an arbitrary post-alpha product S, including '
          'any rounded fractional-alpha multiplication. No prefix producer is assumed.',
    publication_conditions=['Measure full bank and frozen corpus through the application route before landing.',
        'Retain every lost original match and classify it with exact original observations.',
        'Exercise the predeclared exponent/ratio-overflow controls; an overflowing alpha/x cannot silently '
        'turn a previously finite density into an unqualified success claim. Any fallback is a separate '
        'explicitly measured or prior-route-preserving domain decision.',
        'Run the required cargo xtask check green before push.'],
    limits=['The data do not distinguish strict from PC64 quotient/final-multiply words on this grid; '
            'retaining the existing PC64 primitives is not a newly identified ABI.',
        'Binary64 and resident-prefix feasibility remain separate. No logarithm, exponential, GAMMALN '
        'normalizer, prefix storage, private helper, or complete Gamma algorithm is identified.',
        'The shape-one consumer observations are separate and do not authorize changing its distinct product route.',
        'These are original functional observations and necessary-model constraints, not measured product gains.'],
    inputs_sha256=frozen)
output = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT/'gamma-consumer-review.json'
with output.open('x', encoding='utf-8') as stream:
    json.dump(review, stream, indent=2)
    stream.write('\n')
print(json.dumps(dict(calls=raw_calls, counts=review['profile_counts'], fixed_predictions=review['independent_fixed_anchor_predictions'])))
