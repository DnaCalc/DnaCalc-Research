//! Excel's exponential, logarithm and power chains on the x87 (dc-96l.3): a clean-room
//! implementation of the interface in `C:\Work\DnaCalc\parked\licence\nt-chains-interface.md`,
//! written without reading the code it replaces.
//!
//! # Sources
//!
//! - Intel 64 and IA-32 Architectures Software Developer's Manual, vol. 1 ch. 8 (the x87 FPU, its
//!   register format, control word and rounding) and vol. 2 (the instructions `FLDL2E`, `FLDLN2`,
//!   `FLDLG2`, `FLD1`, `FMUL`, `FSUB`, `FADD`, `FDIV`, `FRNDINT`, `F2XM1`, `FSCALE`, `FYL2X`,
//!   `FST`): the textbook x87 sequences `e^x = 2^(x log2 e)`, split into an integer part (`FRNDINT`,
//!   round to nearest) and a fraction in [-1/2, 1/2] for `F2XM1`, rejoined with `FSCALE`;
//!   `ln x = ln 2 * log2 x` and `log10 x = log10 2 * log2 x` by `FYL2X`.
//! - IEEE 754-2008 for binary64 and the rounding of the final store.
//! - Excel measurements: the control word (precision 64, round to nearest), the store rounded
//!   toward zero at GAMMA.DIST's series step, and the 249 EXP and LN witnesses of
//!   `x87_excel_ground_truth.tsv`, all from the interface record; the special values as the
//!   interface states them. Scoring candidate sequences against the 136 EXP witnesses showed that
//!   a negative exponent is computed as the extended reciprocal of the positive one (132 of 136
//!   rows; the plain sequence gives 128); the four remaining rows are one unit in the last place
//!   away and listed in `mod.rs`. The LN sequence matches all 113 LN witnesses on the hardware.
//!
//! Each chain runs on [`Native`]: the x87 instructions on x86_64, the software x87 ([`soft87`]) on
//! wasm32 and under the `soft-x87` feature.
//!
//! [`soft87`]: super::soft87

use super::{CW, Ext80, Fpu, Native, ext_chs, ext_l2e, ext_lg2, ext_ln2, ext_one, load};

/// The control word with rounding toward zero (RC = 11), precision 64, exceptions masked.
const CW_RZ: u16 = CW | 0x0C00;

/// `2^t` for an extended `t >= 0`: `FRNDINT`, `F2XM1` of the fraction, `+1`, `FSCALE`.
fn pow2_positive<F: Fpu>(t: &Ext80) -> Ext80 {
    let whole = F::rndint(t, CW);
    let fraction = F::sub(t, &whole, CW);
    let m = F::add(&F::f2xm1(&fraction, CW), &ext_one(), CW);
    F::scale(&m, &whole, CW)
}

/// `2^t` for an extended `t`; a negative `t` as the extended reciprocal of `2^-t` (measured: the
/// EXP witnesses of small negative arguments are the reciprocals' roundings).
fn pow2<F: Fpu>(t: &Ext80) -> Ext80 {
    if t.0[9] & 0x80 != 0 {
        F::div(&ext_one(), &pow2_positive::<F>(&ext_chs(t, CW)), CW)
    } else {
        pow2_positive::<F>(t)
    }
}

/// `e^t` for an extended `t`: `2^(t log2 e)`.
fn exp_ext<F: Fpu>(t: &Ext80) -> Ext80 {
    pow2::<F>(&F::mul(t, &ext_l2e(), CW))
}

fn exp_with<F: Fpu>(x: f64, cw: u16) -> f64 {
    if x.is_nan() {
        return x;
    }
    if x == f64::INFINITY {
        return x;
    }
    if x == f64::NEG_INFINITY {
        return 0.0;
    }
    F::store(&exp_ext::<F>(&load(x)), cw)
}

/// Excel's `EXP`.
pub(crate) fn excel_exp(x: f64) -> f64 {
    exp_with::<Native>(x, CW)
}

/// Excel's `EXP` with the final rounding toward zero.
pub(crate) fn excel_exp_rz(x: f64) -> f64 {
    exp_with::<Native>(x, CW_RZ)
}

/// `exp(start - terms[0] - terms[1] ...)` as Excel forms the exponential of a difference. Each
/// subtraction is stored and what the store dropped is kept: the exponential is the public EXP of
/// the last stored difference, then one stored multiply by the stored `1 + dropped` per subtraction,
/// in order.
///
/// Measured on POISSON.DIST's prefactor route: at `x = 2` and negligible `lambda` the answers sit a
/// sawtooth of one unit in the last place, with period 1/8 of the significand, away from one
/// rounding of `exp(t - c)`. That is the double rounding of `exp(hi) * (1 + lo)` with `lo = 2^-49`,
/// the part of GAMMALN(3) below the grid of `t`. At `x = 1` a run of 7,500 adjacent means then has
/// no miss.
pub(crate) fn excel_exp_compensated(start: f64, terms: &[f64]) -> f64 {
    exp_compensated::<Native>(start, terms)
}

fn exp_compensated<F: Fpu>(start: f64, terms: &[f64]) -> f64 {
    let mut stored = start;
    let mut factors = [1.0_f64; 2];
    for (term, factor) in terms.iter().zip(factors.iter_mut()) {
        let next = F::store(&F::sub(&load(stored), &load(*term), CW), CW);
        // `(a - s) - b`, not `(a - b) - s`: a row whose register difference lost `b`'s low bits sits
        // on a tie of `1 + dropped`, and Excel's answer there is not that tie's.
        let dropped = F::store(&F::sub(&F::sub(&load(stored), &load(next), CW), &load(*term), CW), CW);
        *factor = F::store(&F::add(&ext_one(), &load(dropped), CW), CW);
        stored = next;
    }
    let mut value = exp_with::<F>(stored, CW);
    for factor in &factors[..terms.len()] {
        value = F::store(&F::mul(&load(value), &load(*factor), CW), CW);
    }
    value
}

/// `exp(start - terms...)` with one correction: the difference is stored after every subtraction,
/// the same subtractions run on in the registers, and the exponential is the public EXP of the last
/// stored difference times the stored `1 + (registers - stored)`. BINOM.DIST's normalizer.
pub(crate) fn excel_exp_running(start: f64, terms: &[f64]) -> f64 {
    exp_running::<Native>(start, terms)
}

fn exp_running<F: Fpu>(start: f64, terms: &[f64]) -> f64 {
    let mut stored = start;
    let mut registers = load(start);
    for term in terms {
        stored = F::store(&F::sub(&load(stored), &load(*term), CW), CW);
        registers = F::sub(&registers, &load(*term), CW);
    }
    let dropped = F::store(&F::sub(&registers, &load(stored), CW), CW);
    let factor = F::store(&F::add(&ext_one(), &load(dropped), CW), CW);
    F::store(&F::mul(&load(exp_with::<F>(stored, CW)), &load(factor), CW), CW)
}

/// `exp(-(start + terms[0] + terms[1] ...))` as LOGNORM.DIST's density forms it. The sum is stored
/// after every addition and runs on in the registers, as in [`excel_exp_running`], but what the
/// stores dropped comes back with the wrong sign: EXP of minus the stored sum times the stored
/// `1 + (registers - stored)`, where `1 - (registers - stored)` would correct it. So the answer's
/// error is twice what the stores dropped, up to a whole grid step of the sum. Excel's own oddity.
///
/// The exponent `-ln Q`, read to a thousandth of its grid, is `2 S - R` with `S` the stored sum and
/// `R` the registers': 312 of 312 bank rows with an exponent above 100, rms 0.003 of a grid step.
pub(crate) fn excel_exp_of_sum(start: f64, terms: &[f64]) -> f64 {
    exp_of_sum::<Native>(start, terms)
}

fn exp_of_sum<F: Fpu>(start: f64, terms: &[f64]) -> f64 {
    let mut stored = start;
    let mut registers = load(start);
    for term in terms {
        stored = F::store(&F::add(&load(stored), &load(*term), CW), CW);
        registers = F::add(&registers, &load(*term), CW);
    }
    let dropped = F::store(&F::sub(&registers, &load(stored), CW), CW);
    let factor = F::store(&F::add(&ext_one(), &load(dropped), CW), CW);
    F::store(&F::mul(&load(exp_with::<F>(-stored, CW)), &load(factor), CW), CW)
}

/// `stirling_error(n)` from its asymptotic series, ten terms in the registers, stored once. Ten terms
/// because `n = 7` reads 2.2e-17 under the true value, where the tenth term leaves 2.0e-17 and the
/// ninth and eleventh are 1.0e-16 and 4.5e-18 over. From 8 on the answers in the series range hold it
/// to the true value within a few units in the last place.
pub(crate) fn excel_stirling_series(n: f64) -> f64 {
    stirling_series::<Native>(n)
}

const STIRLING_TERMS: [f64; 10] = [
    1.0 / 12.0,
    -1.0 / 360.0,
    1.0 / 1260.0,
    -1.0 / 1680.0,
    1.0 / 1188.0,
    -691.0 / 360360.0,
    1.0 / 156.0,
    -3617.0 / 122400.0,
    43867.0 / 244188.0,
    -174611.0 / 125400.0,
];

fn stirling_series<F: Fpu>(n: f64) -> f64 {
    let t = F::div(&ext_one(), &F::mul(&load(n), &load(n), CW), CW);
    let mut w = load(STIRLING_TERMS[9]);
    for term in STIRLING_TERMS[..9].iter().rev() {
        w = F::add(&F::mul(&w, &t, CW), &load(*term), CW);
    }
    F::store(&F::div(&w, &load(n), CW), CW)
}

/// GAMMALN's correction uses the same ten Bernoulli terms, with the reciprocal,
/// square, every Horner product and sum, and final product stored from PC64.
/// R44's frozen 10,212-input set supports this stored program; reciprocal
/// division separates PC64 from binary64. Individual Horner store sites
/// have not all been separated from alternatives.
pub(super) fn stirling_series_stored(n: f64) -> f64 {
    let z = super::excel_x87_div(1.0, n);
    let t = super::excel_x87_mul(z, z);
    let mut w = STIRLING_TERMS[9];
    for term in STIRLING_TERMS[..9].iter().rev() {
        w = super::excel_x87_add(super::excel_x87_mul(w, t), *term);
    }
    super::excel_x87_mul(z, w)
}

/// `ln(1 + u)` as Excel's internal logarithm forms it, times `c`, the product stored. For
/// `|u| < 3/8` the logarithm is `2 S`: `2 + u` is stored, `v = u / (2 + u)` runs the series of
/// `atanh v`, and `S` is the stored sum of the stored `v` and the tail, as in
/// [`excel_deviance_series`]. From `3/8` it is the public LN of the stored `1 + u`.
///
/// `n ln(1 - p)` in BINOM.DIST's zero-success mass: 11,901 of 11,901 bank rows, where LN of the
/// stored `1 - p` misses below `p = 3/8`, as the mass does for all `p` above. The bound was
/// bisected on GAMMA.DIST between `n = 2.66664` and `2.66668` with `u = 1/n`.
pub(crate) fn excel_log1p_times(c: f64, u: f64) -> f64 {
    log1p_times::<Native>(&load(c), u)
}

fn log1p_times<F: Fpu>(c: &Ext80, u: f64) -> f64 {
    let product = if u.abs() < 0.375 {
        let q = F::store(&F::add(&load(2.0), &load(u), CW), CW);
        let v = F::div(&load(u), &load(q), CW);
        let sum = F::store(&F::add(&load(F::store(&v, CW)), &atanh_tail::<F>(&v), CW), CW);
        F::mul(c, &F::mul(&load(2.0), &load(sum), CW), CW)
    } else {
        let log = log_with::<F>(F::store(&F::add(&ext_one(), &load(u), CW), CW), &ext_ln2());
        F::mul(c, &load(log), CW)
    };
    F::store(&product, CW)
}

/// One step down the recurrence `s(n) = s(n + 1) + (n + 1/2) ln(1 + 1/n) - 1`, the part after
/// `s(n + 1)`: [`excel_log1p_times`] of the stored `n + 1/2` and the stored `u = 1/n`, less one.
///
/// Read from GAMMA.DIST on adjacent doubles and on pairs `(x, a)` with `x` next to `a`, where the
/// deviance vanishes and the exponent is `-s(a)`, pinning each `s(a)` to a double. Lines at the
/// frequencies of `1/n` and `1 + 1/(2n)` name `u` and the stored `2 + u`, with the weights `n` and
/// `-1/(2 (1 + u/2))` that this form gives them.
pub(crate) fn excel_stirling_step(n: f64) -> f64 {
    stirling_step::<Native>(n)
}

fn atanh_tail<F: Fpu>(v: &Ext80) -> Ext80 {
    let stored = load(F::store(v, CW));
    let w = load(F::store(&F::mul(&stored, &stored, CW), CW));
    let (mut tail, mut power, mut j) = (load(0.0), stored, 1.0);
    loop {
        power = load(F::store(&F::mul(&power, &w, CW), CW));
        let next = load(F::store(&F::add(&tail, &F::div(&power, &load(2.0 * j + 1.0), CW), CW), CW));
        if next.0 == tail.0 {
            return tail;
        }
        tail = next;
        j += 1.0;
    }
}

fn stirling_step<F: Fpu>(n: f64) -> f64 {
    let one = ext_one();
    let u = F::store(&F::div(&one, &load(n), CW), CW);
    let half = load(F::store(&F::add(&load(n), &load(0.5), CW), CW));
    F::store(&F::sub(&load(log1p_times::<F>(&half, u)), &one, CW), CW)
}

/// Whether `x` and `np` are in the deviance's series range: `|x - np| < 0.2 (x + np)` in the
/// registers, so that the double 0.2, a little above a fifth, keeps `x/np = 3/2` inside. Of the
/// 125 misses of 2,431 interior masses at `n` to 12 and `p = m/N`, 97 sat on that edge.
pub(crate) fn excel_deviance_in_series(x: f64, np: f64) -> bool {
    in_series::<Native>(x, np)
}

fn in_series<F: Fpu>(x: f64, np: f64) -> bool {
    let (fx, fnp) = (load(x), load(np));
    let d = F::sub(&fx, &fnp, CW);
    let d = if d.0[9] & 0x80 != 0 { ext_chs(&d, CW) } else { d };
    let gap = F::sub(&F::mul(&load(0.2), &F::add(&fx, &fnp, CW), CW), &d, CW);
    gap.0[9] & 0x80 == 0 && gap.0[..8].iter().any(|&byte| byte != 0)
}

/// The upper tail's continued fraction as Moshier's Cephes writes igamc, in the 64-bit registers,
/// the answer stored once: `Q(a, x) = r` times this, with `r = x^a exp(-x) / Gamma(a)`.
pub(crate) fn excel_gamma_fraction(a: f64, x: f64) -> f64 {
    gamma_fraction::<Native>(a, x)
}

fn gamma_fraction<F: Fpu>(a: f64, x: f64) -> f64 {
    const BIG: f64 = 4_503_599_627_370_496.0;
    const BIG_INVERSE: f64 = 2.220_446_049_250_313e-16;
    let (mut y, mut c) = (1.0 - a, 0.0);
    let mut z = x + y + 1.0;
    let (mut pkm2, mut qkm2) = (ext_one(), load(x));
    let mut pkm1 = F::add(&load(x), &ext_one(), CW);
    let mut qkm1 = F::mul(&load(z), &load(x), CW);
    let mut ans = F::div(&pkm1, &qkm1, CW);
    loop {
        c += 1.0;
        y += 1.0;
        z += 2.0;
        let yc = F::mul(&load(y), &load(c), CW);
        let pk = F::sub(&F::mul(&pkm1, &load(z), CW), &F::mul(&pkm2, &yc, CW), CW);
        let qk = F::sub(&F::mul(&qkm1, &load(z), CW), &F::mul(&qkm2, &yc, CW), CW);
        let mut t = 1.0;
        if qk.0[..8].iter().any(|&byte| byte != 0) {
            let next = F::div(&pk, &qk, CW);
            t = F::store(&F::div(&F::sub(&ans, &next, CW), &next, CW), CW).abs();
            ans = next;
        }
        (pkm2, qkm2) = (pkm1, qkm1);
        (pkm1, qkm1) = (pk, qk);
        if F::store(&pk, CW).abs() > BIG {
            let inverse = load(BIG_INVERSE);
            (pkm2, pkm1) = (F::mul(&pkm2, &inverse, CW), F::mul(&pkm1, &inverse, CW));
            (qkm2, qkm1) = (F::mul(&qkm2, &inverse, CW), F::mul(&qkm1, &inverse, CW));
        }
        if t <= 1.110_223_024_625_156_5e-16 {
            return F::store(&ans, CW);
        }
    }
}

/// The deviance `x ln(x/np) + np - x` inside its series range. With `d = x - np` and `x + np` stored
/// and `V` their stored quotient, `S` is the stored sum of `V` and the tail `v^3/3 + v^5/5 + ...` of
/// `atanh v`, so that `ln(x/np) = 2 S`. The answer is the stored sum of the stored
/// `(np - x) + st(2 x S) - st(2 x V)`, then `d`, then the stored `d V`.
///
/// Read from POISSON.DIST on runs of adjacent means, one rounding at a time. Each stored sum leaves
/// a sawtooth in the exponent's error, and the sawtooth's frequency names the sum: the tail's
/// rounding to `x` times the grid of `V` at `x = 100`, `x + np` stored at `x = 1024`, the products at
/// `x = 501`. All 1,000 rows at `x = 100` and 1,199 of 1,200 at `x = 1024` agree.
///
/// The running sums are the two sides of that reading. The series loop is compiled C on doubles:
/// `v`, `v^2`, the power and the tail are each stored, BINOM.DIST's bank 70,231 to 70,271 of 70,349.
/// The sum of the stored parts then stays in the registers up to the last addition, 70,320:
/// a store before `d` is 70,271 again, and each product left in the registers loses thousands.
pub(crate) fn excel_deviance_series(x: f64, np: f64) -> f64 {
    deviance_series::<Native>(x, np)
}

fn deviance_series<F: Fpu>(x: f64, np: f64) -> f64 {
    let (fx, fnp) = (load(x), load(np));
    let d = F::store(&F::sub(&fx, &fnp, CW), CW);
    let v = F::div(&load(d), &load(F::store(&F::add(&fx, &fnp, CW), CW)), CW);
    let tail = atanh_tail::<F>(&v);
    let quotient = load(F::store(&v, CW));
    let sum = load(F::store(&F::add(&quotient, &tail, CW), CW));
    let twice_x = load(2.0 * x);
    let gap = load(F::store(&F::sub(&fnp, &fx, CW), CW));
    let near = F::add(&gap, &load(F::store(&F::mul(&twice_x, &sum, CW), CW)), CW);
    let near = F::sub(&near, &load(F::store(&F::mul(&twice_x, &quotient, CW), CW)), CW);
    let near = F::add(&near, &load(d), CW);
    let product = F::store(&F::mul(&load(d), &quotient, CW), CW);
    F::store(&F::add(&near, &load(product), CW), CW)
}

/// `constant * log2 x` by `FYL2X`, with the logarithm's special values.
fn log_with<F: Fpu>(x: f64, constant: &Ext80) -> f64 {
    if x.is_nan() {
        return x;
    }
    if x < 0.0 {
        return f64::NAN;
    }
    if x == 0.0 {
        return f64::NEG_INFINITY;
    }
    if x == f64::INFINITY {
        return x;
    }
    if x == 1.0 {
        return 0.0;
    }
    F::store(&F::fyl2x(constant, &load(x), CW), CW)
}

/// Excel's `LN`.
pub(crate) fn excel_log(x: f64) -> f64 {
    log_with::<Native>(x, &ext_ln2())
}

/// Excel's `LOG10`.
pub(crate) fn excel_log10(x: f64) -> f64 {
    log_with::<Native>(x, &ext_lg2())
}

/// `base^exponent` with every intermediate extended: `2^(exponent log2 base)`, one store.
pub(crate) fn excel_pow_x87_direct(base: f64, exponent: f64) -> f64 {
    pow_direct::<Native>(base, exponent)
}

fn pow_direct<F: Fpu>(base: f64, exponent: f64) -> f64 {
    let t = F::fyl2x(&load(exponent), &load(base), CW);
    F::store(&pow2::<F>(&t), CW)
}

/// GEOMEAN's current root reconstruction from its caller's stored product.
pub(crate) fn excel_root_x87(product: f64, count: usize) -> f64 {
    root::<Native>(product, count)
}

fn root<F: Fpu>(product: f64, count: usize) -> f64 {
    // Original singleton controls return the stored product unchanged.
    if count == 1 {
        return product;
    }
    // R28 normalized-product controls distinguish this exact exponent step
    // independently of the private root. Adjust frexp to a significand in
    // [1, 2), then divide its integer exponent toward zero (not floor).
    // The caller supplies a positive normal stored product and count > 0.
    let exponent = ((product.to_bits() >> 52) & 0x7ff) as i64 - 1023;
    let n = count as i64;
    let scale = exponent / n;
    let reduced = libm::scalbn(product, -(scale * n) as i32);
    // Paired original LN/EXP controls isolate these assignments. Removing any
    // one publication contradicts the observed reduced roots. The reciprocal
    // is assigned before the multiply; direct division is distinguished too.
    let log = log_with::<F>(reduced, &ext_ln2());
    let reciprocal = F::store(&F::div(&ext_one(), &load(count as f64), CW), CW);
    let mean = F::store(&F::mul(&load(log), &load(reciprocal), CW), CW);
    libm::scalbn(F::store(&exp_ext::<F>(&load(mean)), CW), scale as i32)
}

#[cfg(test)]
mod tests {
    use super::super::Soft;
    use super::*;

    /// The software x87 gives the same bits as the backend the entry points run, on the values the
    /// interface names.
    #[cfg_attr(not(target_arch = "wasm32"), test)]
    #[cfg_attr(target_arch = "wasm32", wasm_bindgen_test::wasm_bindgen_test)]
    fn chains_run_on_the_software_x87() {
        assert_eq!(exp_with::<Soft>(1.0, CW), core::f64::consts::E);
        assert_eq!(exp_with::<Soft>(0.0, CW), 1.0);
        assert_eq!(log_with::<Soft>(core::f64::consts::E, &ext_ln2()), 1.0);
        assert_eq!(log_with::<Soft>(1000.0, &ext_lg2()), 3.0);
        assert_eq!(pow_direct::<Soft>(2.0, 10.0), 1024.0);
        assert_eq!(root::<Soft>(16.0, 2), 4.0);
        assert!(exp_with::<Soft>(1.5, CW_RZ) <= exp_with::<Soft>(1.5, CW));
        assert_eq!(exp_compensated::<Soft>(1.5, &[0.25]), exp_with::<Soft>(1.25, CW));
        assert_eq!(exp_running::<Soft>(1.5, &[0.25]), exp_with::<Soft>(1.25, CW));
        let exact = 4.0 * (4.0_f64 / 3.0).ln() + 3.0 - 4.0;
        assert!((deviance_series::<Soft>(4.0, 3.0) - exact).abs() < 1e-15);
    }
}
