"""R45 mapping driver. Original MIT, service only; no restricted sources."""
import sys, pathlib, json, math, random, time
import numpy as np
R=pathlib.Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
D=pathlib.Path('/home/ubuntu/projects/DnaCalc/DnaCalc')
sys.path[:0]=[str(R),str(R/'racer'),str(R/'checker')]
from fingerprint import CachedService, load_service, bits, value, spectrum, sha
from x87_programs import Native, Builder
from x87 import load64, encode, decode
from exact import EXTENDED64 as E, BINARY64 as B, binary64, Span, inverse, operation, two
from fractions import Fraction as Q
OUT=pathlib.Path('/home/ubuntu/codex-runs/r45')
c,_=load_service(D)
s=CachedService(c.Client(timeout=90),OUT/'cache',offline='--offline' in sys.argv,priority='interactive')
native=Native('/home/ubuntu/codex-runs/r44/x87.so')
def write(name,obj):
    (OUT/name).write_text(json.dumps(obj,indent=2)+'\n')
def ask(fn,rows):
    t=time.monotonic();r=s.ask_rows(fn,rows,chunk_size=16000);dt=time.monotonic()-t
    with (OUT/'waits.tsv').open('a') as f:
        if dt>3:f.write(f'{fn}\t{len(rows)}\t{dt:.6f}\n')
    print(fn,len(rows),round(dt,3),flush=True)
    return r
def nn(x):return c.number(bits(x))
def gamma():
    rng=random.Random(45001);xs=[];windows=[]
    for center in [.125,.3,.4999,.5,.6999,.7,.7001,.875,1.-2**-18,1.+2**-18,1.3,1.4999,1.5,1.5001,1.625,1.9999,2.,2.0001,2.375,2.9999,3.,3.0001,7.9999,8.]:
        start=int(bits(center),16)-512
        windows.append(dict(center=bits(center),start=start,count=1024,offset=len(xs)))
        xs.extend(value(f'{start+i:016x}')for i in range(1024))
    xs.extend(2.**e for e in range(-100,-1))
    xs.extend(rng.uniform(.01,7.99)for _ in range(512))
    write('gamma.questions.json',dict(xs=[bits(x)for x in xs],windows=windows,hypotheses=['shift to 8, product then LN','shift to 8, sum of LN','reflection from 1-x','lower 1+x recurrence','small x: -LN(x)-EulerGamma*x'],seed=45001))
    target=ask('GAMMALN',[[nn(x)]for x in xs]);alias=ask('GAMMALN.PRECISE',[[nn(x)]for x in xs])
    uppers=sorted({x+math.ceil(8-x)for x in xs})
    ur=ask('GAMMALN',[[nn(x)]for x in uppers]);um=dict(zip(uppers,ur))
    lo=[x for x in xs if x<.7];shift=sorted({x+1 for x in lo}|{1-x for x in lo})
    sr=ask('GAMMALN',[[nn(x)]for x in shift]);sm=dict(zip(shift,sr))
    products=[];factor_rows=[]
    for x in xs:
        z=1.;facts=[]
        for k in range(math.ceil(8-x)):
            v=x+k;facts.append(v);z=float(np.longdouble(z)*np.longdouble(v))
        products.append(z);factor_rows.append(facts)
    logxs=sorted(set(xs+products+[v for vs in factor_rows for v in vs]+[math.sin(math.pi*x)for x in lo]))
    lr=ask('LN',[[nn(x)]for x in logxs]);lm=dict(zip(logxs,lr))
    records=[]
    def num(r):return r.get('type')=='number'
    for i,(x,y)in enumerate(zip(xs,target)):
        u=um[x+math.ceil(8-x)];pred={}
        if num(u) and num(lm[products[i]]):
            pred['up_product']=bits(float(np.longdouble(value(u['bits']))-np.longdouble(value(lm[products[i]]['bits']))))
            logs=[value(lm[v]['bits'])for v in factor_rows[i]]
            v=value(u['bits'])
            for a in logs[::-1]:v=float(np.longdouble(v)-np.longdouble(a))
            pred['up_reverse_sub']=bits(v)
            pred['up_sum_logs']=bits(float(np.longdouble(value(u['bits']))-np.longdouble(sum(logs))))
        if x<.7 and num(sm[x+1]):
            pred['lower_public']=bits(float(np.longdouble(value(sm[x+1]['bits']))-np.longdouble(value(lm[x]['bits']))))
            pred['minus_log']=bits(-value(lm[x]['bits']))
            pred['small_linear']=bits(-value(lm[x]['bits'])-0.5772156649015329*x)
            if num(sm[1-x]):pred['reflection']=bits(math.log(math.pi)-value(lm[math.sin(math.pi*x)]['bits'])-value(sm[1-x]['bits']))
        records.append(dict(x=bits(x),answer=y,alias=alias[i],predictions=pred))
    for w in windows:
        rs=records[w['offset']:w['offset']+w['count']]
        w['spectrum']=spectrum([r['answer']for r in rs])
        w['counts']={k:sum(r['predictions'].get(k)==r['answer'].get('bits')for r in rs)for k in rs[0]['predictions']}
    write('gamma.results.json',dict(records=records,windows=windows,aliases_equal=sum(a==b for a,b in zip(target,alias)),receipts=s.receipts))
    print([(value(w['center']),w['counts'])for w in windows],flush=True)
if __name__=='__main__' and sys.argv[1]=='gamma':gamma()

def beta_graph(product_store, exponent_store, exp_store, reciprocal_scale, negative_reciprocal=True,normalizer_inside=False):
    g=Builder(3)  # LN(x), a, arbitrary extended positive -ln B(a,b)
    def op(kind,a=0,b=0,store=False):
        j=g.op(kind,a,b,store=False)
        if store:g.nodes[j]['site']=0;g.sites=1
        return j
    if normalizer_inside:z=op('mul',op('add',0,2,exponent_store),1,product_store)
    else:
        p=op('mul',0,1,product_store)
        z=op('add',p,2,exponent_store)
    z=op('mul',z,op('fldl2e'))
    if negative_reciprocal:z=op('neg',z)
    whole=op('frndint',z)
    frac=op('sub',z,whole)
    exp=op('fscale',op('add',g.one,op('f2xm1',frac)),whole)
    if negative_reciprocal:exp=op('div',g.one,exp)
    if exp_store:exp=op('add',exp,g.constant(bits(0.)),True)
    out=op('mul',exp,op('div',g.one,1,True))if reciprocal_scale else op('div',exp,1)
    return g.graph(out,out)

def beta(normalizer_inside=False):
    import itertools
    pairs=[(2,3),(3,2),(4,7),(8,9),(9,8),(10,11),(11,10),(8.5,9.5),(9.5,8.5),(8,8),(12,12),(1.5,2.5),(2.5,1.5)]
    rng=random.Random(45002);rows=[];groups=[]
    for a,b in pairs:
        group=[]
        for e in range(65,81):
            for m in (1.,1.+2**-20,rng.uniform(1,2)):
                group.append(len(rows));rows.append((m*2**-e,a,b))
        groups.append(group)
    profiles=[dict(product_store=p,exponent_store=e,exp_store=x,reciprocal_scale=r,negative_reciprocal=n)
              for p,e,x,r,n in itertools.product((True,False),repeat=5)]
    name='beta-ahead'if normalizer_inside else 'beta'
    if normalizer_inside:
        profiles=[dict(p,normalizer_inside=True)for p in profiles]
    write(name+'.questions.json',dict(rows=[[bits(v)for v in row]for row in rows],groups=groups,profiles=profiles,
        premise='Pure tiny-x controls of the retained bpser arm. A shape-only extended normalizer is permitted; no value is installed. LN is independently measured or the resident x87 LN instruction.',seed=45002))
    ans=ask('BETA.DIST',[[nn(x),nn(a),nn(b),c.boolean(True)]for x,a,b in rows])
    ln=ask('LN',[[nn(x)]for x,a,b in rows])
    write(name+'.answers.json',dict(answers=ans,ln=ln,receipts=s.receipts))
    for log_mode in ('public','resident'):
        result=[]
        for gi,group in enumerate(groups):
            a,b=pairs[gi];center=Q(math.lgamma(a+b)-math.lgamma(a)-math.lgamma(b));radius=Q(1,2**24)
            if normalizer_inside:center/=Q(a)
            box=(E.floor_coordinate(center-radius),E.ceiling_coordinate(center+radius))
            aa=load64(int(bits(a),16));reads=[]
            for i in group:
                x=rows[i][0]
                ll=load64(int(ln[i]['bits'],16))if log_mode=='public'else native.leaf('fyl2x',native.leaf('fldln2',aa,aa,0x133f),load64(int(bits(x),16)),0x133f)
                reads.append((i,ll))
            for pi,profile in enumerate(profiles):
                graph=beta_graph(**profile);interval=list(box);proof=[]
                for i,ll in reads:
                    want=int(ans[i]['bits'],16)
                    def run(k):
                        raw=native.evaluate(graph,[],0x133f,mask=1,extended=ll+aa+encode(E.value(k)))
                        return native.publish(raw[:10])
                    def first_ge(strict):
                        low,high=interval[0],interval[1]+1
                        while low<high:
                            mid=(low+high)//2;actual=run(mid)
                            if actual>want or (actual==want and not strict):high=mid
                            else:low=mid+1
                        return low
                    low=first_ge(False);high=first_ge(True)-1
                    if low>high:
                        proof.append(dict(index=i,low=low,high=high,lower_prediction=f'{run(max(interval[0],min(interval[1],low))):016x}',answer=ans[i]))
                        interval=None;break
                    interval=[low,high]
                    proof.append(dict(index=i,low=low,high=high))
                result.append(dict(group=gi,a=a,b=b,profile=pi,log_mode=log_mode,search_box=list(box),feasible=interval,steps=proof))
            print(log_mode,a,b,'survivors',sum(r['feasible']is not None for r in result if r['group']==gi),flush=True)
            write(name+'.'+log_mode+'.results.json',dict(profiles=profiles,groups=result,
                limits='Native instruction candidate programs, local monotone bisection in the declared extended-normalizer box. The normalizer is unconstrained within each shape. Empty intersections refute these conditional interfaces; surviving intervals do not identify a normalizer producer.'))
if __name__=='__main__' and sys.argv[1]=='beta':beta()
if __name__=='__main__' and sys.argv[1]=='beta-ahead':beta(True)

def normal():
    from racer.normal_quantile import cancellation_grid
    centers=[.52,.58,.64,.70,.706,.72,.78,.84,.86]
    xs=[];windows=[]
    for t in centers:
        start=int(bits(.5+t/2),16)-128
        windows.append(dict(t=t,offset=len(xs),count=256))
        xs.extend(value(f'{start+i:016x}')for i in range(256))
    profiles=[dict(power_s=k,power_one_minus_s=m,order=order,exponent=e)
              for k in range(4)for m in range(4)for order in ('t_first','t_last')for e in range(-51,-45)]
    write('normal.questions.json',dict(xs=[bits(x)for x in xs],windows=windows,profiles=profiles,
        premise='U=C-stored(R) on a coarse exact binary grid, followed by stored s powers, divisions by 1-s, t, sqrt2; s=stored(t*t). Tests necessary arithmetic independently of every R coefficient.'))
    answers=ask('NORM.S.INV',[[nn(x)]for x in xs])
    records=[]
    for w in windows:
        for profile in profiles:
            first=None;tested=0
            for i in range(w['offset'],w['offset']+w['count']):
                t=2*(xs[i]-.5);ss=float(np.longdouble(t)*np.longdouble(t));v=1.-ss
                factors=[('mul',ss)]*profile['power_s']+[('div',v)]*profile['power_one_minus_s']
                factors=([('mul',t)]+factors if profile['order']=='t_first'else factors+[('mul',t)])+[('mul',math.sqrt(2.))]
                y=answers[i];tested+=1
                if y.get('type')!='number' or not cancellation_grid(t,value(y['bits']),profile['exponent'],factors):
                    first=dict(index=i,p=bits(xs[i]),answer=y,factors=factors);break
            records.append(dict(window=w,profile=profile,tested=tested,first_contradiction=first))
        print('normal',w['t'],'survivors',sum(r['first_contradiction']is None for r in records if r['window']==w),flush=True)
    write('normal.results.json',dict(records=records,receipts=s.receipts,answers=answers,
        limits='Necessary exact lattice test, finite fixed suffix families only. A contradiction excludes the declared grid and suffix; arbitrary rational denominators, other stored coordinates and additional cancellation stages remain open.'))
if __name__=='__main__' and sys.argv[1]=='normal':normal()

def beta_corrected(expanded=False,product_path=None):
    from racer.gamma_stages import corrected_exponent_normalizer
    import itertools
    q=json.loads((OUT/'beta.questions.json').read_text());d=json.loads((OUT/'beta.answers.json').read_text())
    rows=[[value(v)for v in row]for row in q['rows']];ans=d['answers'];ln=d['ln']
    candidates=[];sums=set()
    for (x,a,b),y in zip(rows,ans):
        center=int(bits(math.log(value(y['bits'])*a)),16)
        vv=[f'{center+j:016x}'for j in range(-4,5)];candidates.append(vv);sums.update(vv)
    profiles=[dict(log=log,product_store=p,product_correction=sign,scale=scale,correction_first=first)
        for log,p,sign,scale,first in itertools.product(('public','resident'),(True,False),(-1,0,1),('div','reciprocal'),(True,False))
        if p or sign==0]
    name='beta-corrected2'if expanded else 'beta-corrected'
    if product_path:
        profiles=[dict(p,log=product_path)for p in profiles if p['log']=='resident']
        name='beta-'+product_path
    if expanded:
        profiles=[dict(p,exp_resident=er,product_model=pm,scale_model=sm)for p in profiles
            for er,pm,sm in itertools.product((True,False),('stored_pc64','resident_pc64'),('stored_pc64','resident_pc64'))
            if sm=='stored_pc64' or not p['correction_first']]
    write(name+'.questions.json',dict(stored_sum_candidates=candidates,profiles=profiles,
        beta_questions_sha256=sha(OUT/'beta.questions.json'),beta_answers_sha256=sha(OUT/'beta.answers.json'),
        limits='A fixed nine-double stored-exponent enumeration around log(a*answer), used only for necessary inverse constraints. It is not claimed to cover every possible exponential implementation.'))
    sx=sorted(sums);ex=ask('EXP',[[c.number(x)]for x in sx]);em=dict(zip(sx,ex))
    if expanded:
        g=Builder(1)
        z=g.op('mul',g.op('neg',0,store=False),g.op('fldl2e',store=False),store=False)
        w=g.op('frndint',z,store=False)
        frac=g.op('sub',z,w,store=False)
        ee=g.op('fscale',g.op('add',g.one,g.op('f2xm1',frac,store=False),store=False),w,store=False)
        ee=g.op('div',g.one,ee,store=False);graph=g.graph(ee,ee)
        er={ss:decode(native.evaluate(graph,[int(ss,16)],0x133f)[:10])for ss in sx}
        assert all(bits(float(er[ss]))==em[ss]['bits']for ss in sx)
    results=[]
    for gi,group in enumerate(q['groups']):
        for pi,profile in enumerate(profiles):
            feasible=None;steps=[]
            for i in group:
                x,a,b=rows[i];raw=load64(int(ln[i]['bits'],16))
                if profile['log']=='resident':raw=native.leaf('fyl2x',native.leaf('fldln2',raw,raw,0x133f),load64(int(bits(x),16)),0x133f)
                aa=load64(int(bits(a),16));xx=load64(int(bits(x),16));ln2=native.leaf('fldln2',aa,aa,0x133f)
                if profile['log'].startswith('weighted'):
                    co=native.leaf('mul',aa,ln2,0x133f)
                    if profile['log']=='weighted_stored':co=load64(native.publish(co))
                    product=decode(native.leaf('fyl2x',co,xx,0x133f))
                elif profile['log'].startswith('base2'):
                    p=native.leaf('fyl2x',aa,xx,0x133f)
                    if profile['log']=='base2_stored':p=load64(native.publish(p))
                    product=decode(native.leaf('mul',p,ln2,0x133f))
                else:product=decode(native.leaf('mul',aa,raw,0x133f))
                start=B.round(product)if profile['product_store']else product
                correction=B.round(E.round(1+profile['product_correction']*(product-start)))
                scale=('div',Q(a))if profile['scale']=='div'else ('mul',B.round(E.round(1/Q(a))))
                if expanded:scale=(*scale,profile['scale_model'])
                possible=[]
                for ss in candidates[i]:
                    if em[ss].get('type')!='number':continue
                    # Product correction comes after the corrected EXP; both
                    # before/after final division are fixed alternatives.
                    suffix=([('mul',correction),scale]if profile['correction_first']else [scale,('mul',correction)])
                    exp=er[ss]if expanded and profile['exp_resident']else binary64(em[ss]['bits'])
                    span=corrected_exponent_normalizer(start,binary64(ss),exp,binary64(ans[i]['bits']),suffix,
                        product_model=profile.get('product_model','stored_pc64'))
                    bounds=E.coordinates(span)
                    if bounds is not None:possible.append(bounds)
                if feasible is None:feasible=possible
                else:feasible=[(max(a,c),min(b,d))for a,b in feasible for c,d in possible if max(a,c)<=min(b,d)]
                feasible=sorted(set(feasible))
                steps.append(dict(index=i,possible=possible,remaining=feasible))
                if not feasible:break
            results.append(dict(group=gi,profile=pi,feasible=feasible,steps=steps))
        print('corrected',gi,'survivors',sum(bool(r['feasible'])for r in results if r['group']==gi),flush=True)
        write(name+'.results.json',dict(profiles=profiles,groups=results,receipts=s.receipts,
            limits='Exact rational inverse constraints with public EXP leaves for each enumerated stored exponent. The common normalizer may be extended64 and is never installed. Empty intersections refute this finite corrected-interface family; other exponent enumerations, private leaves and normalizer dependence on x remain open.'))
if __name__=='__main__' and sys.argv[1]=='beta-corrected':beta_corrected()
if __name__=='__main__' and sys.argv[1]=='beta-corrected2':beta_corrected(True)
if __name__=='__main__' and sys.argv[1]=='beta-product-path':beta_corrected(False,sys.argv[2])

def gamma_tables():
    import re,itertools
    doc=json.loads((OUT/'gamma.results.json').read_text())
    source=(D/'crates/calc-func/src/ported/excel_numeric/gammaln.rs').read_text()
    tables={}
    for name in ('P1','Q1','P2','Q2'):
        b=source.split('const '+name+':',1)[1].split('];',1)[0].split('= [',1)[1]
        if name.endswith('1'):a=[binary64(h.replace('_',''))for h in re.findall(r'0x([0-9a-fA-F_]+)',b)]
        else:a=[Q(v.strip())for v in b.split(',')if v.strip()]
        tables[name]=a
    def translate(descending,initial):
        p=[Q(initial)]
        for c in descending:
            n=[Q(0)]*(len(p)+1)
            for i,v in enumerate(p):n[i]-=2*v;n[i+1]+=v
            n[0]+=c;p=n
        while p[-1]==0:p.pop()
        return p
    p=translate(tables['P2'],0);q=translate(tables['Q2'],1)
    n=[binary64('3fdb0ee6072093ce')*v for v in q]
    for i,v in enumerate(p):n[i]-=2*v;n[i+1]+=v
    records=[]
    for band in ('B1','B2'):
        # Algebraically equivalent published forms, with fixed degrees only.
        p0,q0=(tables['P1'],tables['Q1'])if band=='B1'else(n,q)
        for coordinate,normalise,stores in itertools.product(('x','reciprocal'),(False,True),('continuous','stored','last_resident','pc53')):
            pp=[v/q0[0] for v in p0]if normalise else p0
            qq=[v/q0[0] for v in q0]if normalise else q0
            pp=[bits(float(v))for v in pp];qq=[bits(float(v))for v in qq]
            g=Builder(1)
            def op(kind,a,b=0,store=True):
                j=g.op(kind,a,b,store=False)
                if store and stores!='continuous':g.nodes[j]['site']=0;g.sites=1
                return j
            x=0 if coordinate=='x'else op('div',g.one,0)
            def chain(co):
                cc=co[::-1]if coordinate=='x'else co
                v=g.constant(cc[0])
                for i,c0 in enumerate(cc[1:]):v=op('add',op('mul',v,x),g.constant(c0),stores!='last_resident' or i<len(cc)-2)
                return v
            ratio=op('div',chain(pp),chain(qq))
            result=op('mul',op('sub',0,g.constant(bits(1. if band=='B1'else 2.))),ratio)
            graph=g.graph(result,result);cw=0x123f if stores=='pc53'else 0x133f
            selected=[r for r in doc['records']if (.7<=value(r['x'])<1.5 if band=='B1'else 1.5<=value(r['x'])<2.)]
            inputs=np.array([[int(r['x'],16)]for r in selected],dtype=np.uint64)
            out=native.grid(graph,inputs,cw=cw,mask=1)[:,0]
            bad=[i for i,(v,r)in enumerate(zip(out,selected))if f'{int(v):016x}'!=r['answer'].get('bits')]
            records.append(dict(band=band,coordinate=coordinate,normalise=normalise,stores=stores,graph=graph,rows=len(selected),mismatches=len(bad),
                first_contradiction=dict(original=selected[bad[0]],prediction=f'{int(out[bad[0]]):016x}')if bad else None))
    write('gamma-tables.results.json',dict(records=records,source_sha256=sha(D/'crates/calc-func/src/ported/excel_numeric/gammaln.rs'),
        limits='Existing published Cody tables only, exact rational basis change then binary64 loads. No coefficient is adjusted. The expanded B2 degree is eight, fixed by algebra, not residual fitting. Replay on the mapping cohort is not fresh validation of a discovered program.'))
    print('published tables',len(records),'survivors',sum(r['first_contradiction']is None for r in records),flush=True)
if __name__=='__main__' and sys.argv[1]=='gamma-tables':gamma_tables()

def gamma_lanczos():
    import re,itertools
    source=(D/'crates/calc-func/src/ported/special_dist_family.rs').read_text()
    block=source.split('const LANCZOS_COEFFS:',1)[1].split('];',1)[0].split('= [',1)[1]
    coefficients=[float(v.strip().replace('_',''))for v in block.split(',')if v.strip()]
    doc=json.loads((OUT/'gamma.results.json').read_text());records=[]
    for band,low,high in [('B1',.7,1.5),('B2',1.5,2.),('B3',2.,3.)]:
        selected=[r for r in doc['records']if low<=value(r['x'])<high]
        for stored,cw in itertools.product((True,False),(0x123f,0x133f)):
            outputs=[];graphs={}
            for lift in (False,True):
                g=Builder(1)
                def op(kind,a=0,b=0):
                    j=g.op(kind,a,b,store=False)
                    if stored:g.nodes[j]['site']=0;g.sites=1
                    return j
                x=op('add',0,g.one)if lift else 0
                z=op('sub',x,g.one);acc=g.constant(bits(coefficients[0]))
                for i,co in enumerate(coefficients[1:],1):acc=op('add',acc,op('div',g.constant(bits(co)),op('add',z,g.constant(bits(i)))))
                t=op('add',z,g.constant(bits(7.5)))
                def log(v):return op('fyl2x',op('fldln2'),v)
                out=op('sub',op('mul',op('add',z,g.constant(bits(.5))),log(t)),t)
                out=op('add',g.constant('3fed67f1c864beb5'),out)
                out=op('add',out,log(acc))
                if lift:out=op('sub',out,log(0))
                graphs[str(lift)]=g.graph(out,out)
            for r in selected:
                graph=graphs[str(value(r['x'])<1)]
                pred=f'{native.publish(native.evaluate(graph,[int(r["x"],16)],cw,mask=1)[:10],cw):016x}'
                outputs.append(pred)
            bad=[i for i,(p,r)in enumerate(zip(outputs,selected))if p!=r['answer'].get('bits')]
            records.append(dict(band=band,stored=stored,cw=cw,graphs=graphs,rows=len(selected),mismatches=len(bad),
                first_contradiction=dict(original=selected[bad[0]],prediction=outputs[bad[0]])if bad else None))
    write('gamma-lanczos.results.json',dict(records=records,source_sha256=sha(D/'crates/calc-func/src/ported/special_dist_family.rs'),
        limits='Only the existing cleared g=7, nine-coefficient Lanczos form, continuous/stored and PC53/PC64, worksheet-LN instructions. Refutation of these candidates does not exclude every Lanczos approximation or an unexamined Numerical Recipes table.'))
    print('Lanczos candidates',len(records),'survivors',sum(r['first_contradiction']is None for r in records),flush=True)
if __name__=='__main__' and sys.argv[1]=='gamma-lanczos':gamma_lanczos()

def beta_collisions():
    from collections import defaultdict
    pairs=[(2,3),(3,2),(8,9),(9,8),(8.5,9.5),(9.5,8.5)]
    xs=[];windows=[]
    for e in (61,65,70,77,80):
        start=int(bits(2.**-e),16)-128
        windows.append(dict(e=e,offset=len(xs),count=256))
        xs.extend(value(f'{start+i:016x}')for i in range(256))
    ln=ask('LN',[[nn(x)]for x in xs]);rows=[]
    for a,b in pairs:
        aa=load64(int(bits(a),16));ln2=native.leaf('fldln2',aa,aa,0x133f)
        for i,x in enumerate(xs):
            xx=load64(int(bits(x),16));ll=native.leaf('fyl2x',ln2,xx,0x133f)
            resident=native.leaf('mul',aa,ll,0x133f)
            weighted=native.leaf('fyl2x',native.leaf('mul',aa,ln2,0x133f),xx,0x133f)
            base2=native.leaf('mul',native.leaf('fyl2x',aa,xx,0x133f),ln2,0x133f)
            prefixes=dict(public_log=ln[i]['bits'],resident_log=ll.hex(),
                stored_resident_product=f'{native.publish(resident):016x}',resident_product=resident.hex(),
                stored_weighted_product=f'{native.publish(weighted):016x}',weighted_product=weighted.hex(),
                stored_base2_product=f'{native.publish(base2):016x}',base2_product=base2.hex())
            rows.append(dict(x=bits(x),a=a,b=b,index=i,prefixes=prefixes))
    write('beta-collisions.questions.json',dict(rows=rows,windows=windows,
        premise='For fixed shape, any deterministic program receiving only one stated prefix must return the same answer whenever that prefix is identical. Counterexamples do not depend on coefficients, normalizer, EXP, final scaling or arithmetic after that interface.'))
    ans=ask('BETA.DIST',[[c.number(r['x']),nn(r['a']),nn(r['b']),c.boolean(True)]for r in rows])
    result=[]
    for a,b in pairs:
        for w in windows:
            selected=[i for i,r in enumerate(rows)if r['a']==a and r['b']==b and w['offset']<=r['index']<w['offset']+w['count']]
            for name in rows[0]['prefixes']:
                buckets=defaultdict(list)
                for i in selected:buckets[rows[i]['prefixes'][name]].append(i)
                collisions=[bucket for bucket in buckets.values()if len(bucket)>1]
                bad=[bucket for bucket in collisions if len({ans[i].get('bits')for i in bucket})>1]
                first=None
                if bad:
                    i=bad[0][0];j=next(j for j in bad[0][1:]if ans[j].get('bits')!=ans[i].get('bits'))
                    first=dict(left=rows[i],left_answer=ans[i],right=rows[j],right_answer=ans[j])
                result.append(dict(a=a,b=b,window=w,prefix=name,collision_classes=len(collisions),inconsistent_classes=len(bad),first_contradiction=first))
    write('beta-collisions.results.json',dict(records=result,answers=ans,ln=ln,receipts=s.receipts,
        limits='Exact equality constraint on independently observed output bits. A contradiction refutes dependence on that prefix alone. Absence of a collision or contradiction does not prove the prefix is used. Tiny-x series dependencies beyond a rounded unit series factor are outside the prefix-only premise.'))
    print([(a,b,name,sum(r['inconsistent_classes']for r in result if r['a']==a and r['b']==b and r['prefix']==name))for a,b in pairs for name in ('public_log','stored_resident_product')],flush=True)
if __name__=='__main__' and sys.argv[1]=='beta-collisions':beta_collisions()
