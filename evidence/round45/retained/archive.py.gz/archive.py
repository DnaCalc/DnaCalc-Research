"""Small immutable R45 evidence; large corpus output is copied to R2."""
import datetime, hashlib, json, pathlib, subprocess, sys, tarfile
ROOT=pathlib.Path('/home/ubuntu/codex-runs/r45')
RESEARCH=pathlib.Path('/home/ubuntu/projects/DnaCalc/DnaCalc-Research')
MAIN=RESEARCH.parent/'DnaCalc'
sys.path.insert(0,str(RESEARCH))
from racer.retain_evidence import retain
def read(name):return json.loads((ROOT/name).read_text())
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
before,after=read('bank-before.json'),read('bank-after.json')
assert before==after
c0,c1=read('corpus-before/summary.json'),read('corpus-after/summary.json')
assert c0['totals']['counts']==c1['totals']['counts']
binding=dict(bank_before=before['totals'],bank_after=after['totals'],
    corpus_before=c0['totals']['counts'],corpus_after=c1['totals']['counts'],
    bank_reports_identical=True,corpus_counts_identical=True,
    files={p:digest(ROOT/p)for p in ('bank-before.json','bank-after.json','corpus-before/summary.json','corpus-after/summary.json')},
    limitation='No application numerical source changed; no gain is attributed to this research. Failures retain every mismatch, refusal, missing, external, circular-policy and pending observation.')
(ROOT/'measurement-bindings.json').write_text(json.dumps(binding,indent=2)+'\n')
raw=ROOT/'raw-evidence';raw.mkdir(exist_ok=True)
for name in ('corpus-before','corpus-after'):
    dest=raw/(name+'.tar.gz')
    if not dest.exists():
        with tarfile.open(dest,'w:gz')as stream:stream.add(ROOT/name,arcname=name)
prefix='dnacalc-evidence/research/round45/'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-dna-firehorse'
args=['rclone','--config','/home/ubuntu/.config/dnacalc/rclone.conf']
for command,extra in [('copy',['--checksum']),('check',['--one-way'])]:
    with (ROOT/('r2-'+command+'.log')).open('a')as log:
        subprocess.run(args+[command,str(raw),'r2:'+prefix]+extra,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
files=[dict(path=p.name,bytes=p.stat().st_size,sha256=digest(p))for p in sorted(raw.iterdir())]
r2=dict(prefix=prefix,files=files,count=len(files),bytes=sum(p['bytes']for p in files),checksum_copy=True,one_way_check='0 differences; see r2-check.log')
(ROOT/'r2-evidence.json').write_text(json.dumps(r2,indent=2)+'\n')
print(json.dumps(r2),flush=True)
inputs=[p for p in ROOT.iterdir()if p.is_file()and p.suffix in ('.json','.py','.log','.tsv')]
inputs += [p for folder in ('cache','producers')for p in (ROOT/folder).rglob('*')if p.is_file()]
print(retain(ROOT,RESEARCH/'evidence/round45',inputs),flush=True)
